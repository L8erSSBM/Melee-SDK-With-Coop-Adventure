from pathlib import Path
import json,hashlib
r=Path('../PCsaveNow.ram').read_bytes()
regions={'report_exit':(0x806664A8,0x806664E0),'game_end':(0x80666BA4,0x80666C04),'skip_stall':(0x80666E50,0x80666E5C),'prediction':(0x80667214,0x80667220),'native_ring':(0x8066DFB4,0x8066E0C8)}
fixture={'provenance':'PPC instruction bytes extracted from user supplied PCsaveNow.sav. Report scene guard restored to original retail branch; all other instruction bytes unchanged.','save_sha256':'32f2b779d35a3a623fcc13704c30fced31d2920bd01c332d17198232261296fb','regions':{}}
for name,(start,end) in regions.items():
 b=bytearray(r[start-0x80000000:end-0x80000000])
 if name=='report_exit':b[0x10:0x14]=bytes.fromhex('40820028')
 fixture['regions'][name]={'address':start,'hex':b.hex()}
Path('tests/fixtures').mkdir(exist_ok=True)
Path('tests/fixtures/slippi_k16_native_lifecycle.json').write_text(json.dumps(fixture,indent=2))
