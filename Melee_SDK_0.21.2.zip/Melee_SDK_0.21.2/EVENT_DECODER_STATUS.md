# Phase 13 control-flow correction

Phase 13 corrects an important assumption left over from earlier decoder work: **Subroutine (opcode 5)** and **Goto (opcode 7)** occupy two 32-bit words in fighter command storage. The second word is the HSD-relocated command pointer consumed after `NEXT_CMD(info)` in `lbcommand.c`. The Phase 13 parser, CFG analyzer, and assembler treat these as two-word control-flow instructions, preserve/retarget their destinations symbolically, and validate relocation entries. A null Goto is also accepted for the one validated Pichu termination idiom.

The command-family notes below remain useful for opcodes 10–58; any older implication that all opcodes 0–9 are one word should be treated as historical.

---

# Phase 10 — Fighter command decoder status

Phase 10 cross-references fighter subaction opcode 10–58 directly against the current `ftAction_803C06E8` dispatch table and `ftAction_803C0870` command-size table in `src/melee/ft/ftaction.c`.

## Important correction from earlier SDK phases

The previous labels at opcodes 54–58 were shifted/misidentified. The decomp dispatch table establishes:

- 54 — Footstep SFX / GFX (`ftAction_80072CD8`)
- 55 — Fighter effect / SFX (`ftAction_80072E4C`)
- 56 — Smash charge (`ftAction_80073008`)
- 57 — Smash vibration/state (`ftAction_800730B8`)
- 58 — Wind effect (`ftAction_80073118`)

The Phase 10 decoder now uses those corrected labels.

## Newly semantic/readable command families

Phase 10 exposes structured parameters in the Moves / Hitboxes inspector for many non-hitbox commands, including:

- hitbox flag mutation
- command variables
- throw flags
- airborne/ground-state command values
- hurtbox state
- model-part selection
- article/fighter visibility
- texture animation
- part animation
- parasol animation synchronization
- rumble start/stop
- sword-item animation commands
- color-animation start/stop
- bone dynamics
- self-damage
- fighter model flags
- footstep effect parameters
- fighter effect parameters
- smash charge parameters
- smash vibration parameters
- wind effect parameters

Some command names remain intentionally generic where the decomp itself still exposes anonymous runtime fields. Those commands are decoded structurally but are not given invented gameplay semantics.

## Editing policy

Only timer and hitbox commands remain directly editable in Phase 10. The newly decoded command parameters are currently read-only. This is deliberate: understanding a bitfield does not by itself prove that arbitrary values are safe. The next step is to add writers one command family at a time after round-trip and behavioral validation.
