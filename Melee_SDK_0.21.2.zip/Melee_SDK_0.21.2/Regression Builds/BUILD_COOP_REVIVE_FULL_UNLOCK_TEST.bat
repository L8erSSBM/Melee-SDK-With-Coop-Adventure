@echo off
setlocal EnableExtensions
set "ROOT=%~dp0.."
cd /d "%ROOT%"

set "LOG=%~dp0BUILD_COOP_REVIVE_FULL_UNLOCK_TEST.log"
>"%LOG%" echo Phase 40 Co-op Adventure REVIVE ISO Builder
>>"%LOG%" echo Started: %DATE% %TIME%
>>"%LOG%" echo SDK folder: %CD%
>>"%LOG%" echo.

echo ============================================================
echo  Melee SDK - Co-op Adventure REVIVE + FULL UNLOCK
echo ============================================================
echo.
echo A diagnostic log will be kept at:
echo   "%LOG%"
echo.

rem ---- Resolve source ISO -------------------------------------------------
if "%~1"=="" (
  echo Drag-and-drop did not provide an ISO path.
  echo Please paste the full path to your CLEAN GALE01 v1.02 ISO.
  echo.
  set /p "CLEANISO=Clean Melee ISO: "
) else (
  set "CLEANISO=%~1"
)

>>"%LOG%" echo Source argument: "%CLEANISO%"

if not defined CLEANISO (
  echo.
  echo ERROR: No ISO path was provided.
  >>"%LOG%" echo ERROR: No ISO path was provided.
  goto :failed
)

if not exist "%CLEANISO%" (
  echo.
  echo ERROR: ISO not found:
  echo   "%CLEANISO%"
  >>"%LOG%" echo ERROR: ISO not found: "%CLEANISO%"
  goto :failed
)

if not exist "%ROOT%\iso_build_tools.py" (
  echo.
  echo ERROR: iso_build_tools.py is missing from the SDK folder.
  >>"%LOG%" echo ERROR: Missing "%ROOT%\iso_build_tools.py"
  goto :failed
)

if not exist "%ROOT%\sdk\iso_builder.py" (
  echo.
  echo ERROR: sdk\iso_builder.py is missing from the SDK folder.
  >>"%LOG%" echo ERROR: Missing "%ROOT%\sdk\iso_builder.py"
  goto :failed
)

rem ---- Find a real Python interpreter ------------------------------------
set "PYEXE="
set "PYARGS="

where py >nul 2>&1
if not errorlevel 1 (
  py -3 --version >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py"
    set "PYARGS=-3"
  )
)

if not defined PYEXE (
  where python >nul 2>&1
  if not errorlevel 1 (
    python --version >nul 2>&1
    if not errorlevel 1 set "PYEXE=python"
  )
)

if not defined PYEXE (
  where python3 >nul 2>&1
  if not errorlevel 1 (
    python3 --version >nul 2>&1
    if not errorlevel 1 set "PYEXE=python3"
  )
)

rem Common per-user Python installs, useful when VS Code knows Python but PATH does not.
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"

if not defined PYEXE (
  echo.
  echo ERROR: I could not find Python from this CMD session.
  echo.
  echo If Python works inside VS Code, open a VS Code terminal in this SDK
  echo folder and run BUILD_COOP_TEST_FIXED.bat from there, or tell me the
  echo Python interpreter path shown by VS Code and I will wire it in.
  >>"%LOG%" echo ERROR: No usable py/python/python3 interpreter found.
  goto :failed
)

>>"%LOG%" echo Python command: "%PYEXE%" %PYARGS%

rem ---- Choose output paths ------------------------------------------------
for %%I in ("%CLEANISO%") do set "OUTISO=%%~dpnI_Phase40ReviveFullUnlock.iso"
set "MANIFEST=%OUTISO%.build_manifest.json"

if /I "%OUTISO%"=="%CLEANISO%" (
  echo.
  echo ERROR: Output path unexpectedly equals the source ISO.
  >>"%LOG%" echo ERROR: Source and output paths match.
  goto :failed
)

echo Python: "%PYEXE%" %PYARGS%
echo Source: "%CLEANISO%"
echo Output: "%OUTISO%"
echo.
>>"%LOG%" echo Output ISO: "%OUTISO%"
>>"%LOG%" echo NOTE: temporary DOL staging is internal and is deleted automatically.
>>"%LOG%" echo.

rem ---- Build --------------------------------------------------------------
echo Building... this can take a while because a GameCube ISO is large.
echo Do not close this window.
echo.

"%PYEXE%" %PYARGS% "%ROOT%\iso_build_tools.py" --clean-iso "%CLEANISO%" --output-iso "%OUTISO%" --variant coop_showcase --scene-revive --unlock-all --manifest "%MANIFEST%" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo BUILD FAILED with exit code %RC%.
  echo Your clean ISO was NOT modified.
  echo.
  echo Build log:
  echo ------------------------------------------------------------
  type "%LOG%"
  echo ------------------------------------------------------------
  echo.
  echo Send me BUILD_COOP_REVIVE_TEST.log and I can pinpoint the failure.
  goto :failed
)

if not exist "%OUTISO%" (
  echo.
  echo ERROR: Builder returned success but the output ISO was not found.
  >>"%LOG%" echo ERROR: Missing expected output ISO after successful command.
  goto :failed
)

echo.
echo ============================================================
echo  BUILD COMPLETE
echo ============================================================
echo.
echo New ISO - THIS is the file to open in Dolphin:
echo   "%OUTISO%"
echo.
echo Do NOT launch a standalone start.dol. This launcher does not leave one behind.
echo.
echo Your clean ISO was left untouched.
echo.
echo TEST-ONLY FULL UNLOCK is active: normal characters/stages report unlocked.
echo Save unlock bits are NOT written by this option.
echo.
echo Open the NEW ISO in Dolphin and test:
echo   1-P Game ^> Adventure
echo with controllers in ports 1 and 2.
echo   Eliminated players should return NEXT SCENE with the run starting stock count.
echo   Test C-stick attacks and verify either controller can pause.
echo.
>>"%LOG%" echo BUILD COMPLETE: "%OUTISO%"
>>"%LOG%" echo Finished: %DATE% %TIME%

goto :done

:failed
echo.
echo Log file:
echo   "%LOG%"
echo.
echo The window will stay open so you can read the error.

:done
echo.
pause
endlocal
