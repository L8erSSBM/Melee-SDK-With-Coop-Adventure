from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.stage_select_pages import StagePageSet, inspect_sss_menu, runtime_plan, visual_manifest, preflight_sss_dol, write_hub_bundle
from sdk.adventure_coop import CoopAdventureCampaign

p=argparse.ArgumentParser(description='Phase 26 paged Stage Select / custom + co-op hub tools')
p.add_argument('--pages', help='stage_pages.json')
p.add_argument('--inspect-menu', help='MnSlMap.dat or MnSlMap.usd')
p.add_argument('--runtime-plan', help='write runtime plan JSON')
p.add_argument('--visual-manifest', help='write visual manifest JSON')
p.add_argument('--hub-bundle', help='write integrated Stage Select Hub bundle folder')
p.add_argument('--dol', help='start.dol to preflight')
p.add_argument('--symbols', default=str(Path(__file__).with_name('data')/'runtime_symbols_GALE01.txt'))
p.add_argument('--preflight', help='write DOL preflight JSON')
a=p.parse_args()
result={}
if a.inspect_menu: result['menu']=inspect_sss_menu(a.inspect_menu)
pages=None
if a.pages:
    pages=StagePageSet.from_dict(json.loads(Path(a.pages).read_text(encoding='utf-8')))
    result['pages']=pages.to_dict()
    if a.runtime_plan:
        plan=runtime_plan(pages); Path(a.runtime_plan).write_text(json.dumps(plan,indent=2),encoding='utf-8'); result['runtime_plan']=plan
    if a.visual_manifest:
        vm=visual_manifest(pages); Path(a.visual_manifest).write_text(json.dumps(vm,indent=2),encoding='utf-8'); result['visual_manifest']=vm
    if a.hub_bundle:
        write_hub_bundle(a.hub_bundle,pages,campaign=CoopAdventureCampaign.vanilla_sequence('Co-op Adventure'))
        result['hub_bundle']=str(Path(a.hub_bundle))
if a.dol:
    pf=preflight_sss_dol(a.dol,a.symbols)
    if a.preflight: Path(a.preflight).write_text(json.dumps(pf,indent=2),encoding='utf-8')
    result['preflight']=pf
print(json.dumps(result,indent=2))
