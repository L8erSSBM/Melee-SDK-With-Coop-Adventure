from pathlib import Path
p=Path('tests/hf29d_ppc.py');s=p.read_text().replace('        elif op in (10,11):','''        elif op in (46,47): # lmw/stmw
            ea=((regs[ra] if ra else 0)+imm)&0xFFFFFFFF
            for reg in range(rt,32):
                if op==46: regs[reg]=get(mem,ea+(reg-rt)*4)
                else: put(mem,ea+(reg-rt)*4,regs[reg])
        elif op in (10,11):''');p.write_text(s)
p=Path('tests/test_sdk02021k16_session_lifetime.py');s=p.read_text().replace('stop_targets={0x806673AC})','stop_targets={0x806673AC,0x80376CEC})').replace("    assert result['target']==0x806673AC\n    assert sent==[own]", "    assert result['target'] in (0x806673AC,0x80376CEC)\n    assert sent==[own]")
s=s.replace('    applied=bytes(mem.get(parent+0x2C+(1-local)*12+i,0) for i in range(12))','''    if result['target']==0x80376CEC:
        assert get(mem,odb+0xDF,1)==1 # Correction queues replay instead of consuming a new raw input.
        return mem
    applied=bytes(mem.get(parent+0x2C+(1-local)*12+i,0) for i in range(12))''');p.write_text(s)
