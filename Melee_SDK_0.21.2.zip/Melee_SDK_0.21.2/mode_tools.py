from __future__ import annotations

import argparse, json
from pathlib import Path
from sdk.dol_patch import DOLImage, SymbolMap
from sdk.game_modes import OnePlayerModeEditor, CustomModeRecipe, ModePlayer


def main():
    ap=argparse.ArgumentParser(description='Phase 21 source-grounded Melee 1P / duo-mode tools')
    ap.add_argument('dol', nargs='?', help='GALE01 1.02 main/start.dol')
    ap.add_argument('--symbols', default=str(Path(__file__).parent/'data'/'runtime_symbols_GALE01.txt'))
    ap.add_argument('--export', help='Export Classic + Adventure tables to JSON')
    ap.add_argument('--classic-index', type=int)
    ap.add_argument('--adventure-index', type=int)
    ap.add_argument('--stage-kind', type=lambda x:int(x,0))
    ap.add_argument('--scale0', type=int)
    ap.add_argument('--scale1', type=int)
    ap.add_argument('--output-dol')
    ap.add_argument('--make-duo', help='Create a duo recipe JSON instead of patching a DOL')
    ap.add_argument('--stages', default='2,3,4')
    ap.add_argument('--stocks', type=int, default=4)
    ap.add_argument('--cpu-level', type=int, default=7)
    args=ap.parse_args()
    if args.make_duo:
        stages=[int(x.strip(),0) for x in args.stages.split(',') if x.strip()]
        r=CustomModeRecipe(Path(args.make_duo).stem, players=[ModePlayer(0,'human',0),ModePlayer(1,'human',0),ModePlayer(2,'cpu',1,cpu_level=args.cpu_level),ModePlayer(3,'disabled',1)], stage_kinds=stages, stock_count=args.stocks)
        r.save(args.make_duo); print(args.make_duo); return
    if not args.dol: ap.error('dol is required unless --make-duo is used')
    image=DOLImage(args.dol); ed=OnePlayerModeEditor(image,SymbolMap.from_file(args.symbols))
    if args.export:
        ed.export_tables(args.export); print(args.export)
    patched=[]
    kwargs={k:v for k,v in {'stage_kind':args.stage_kind,'scale0_pct':args.scale0,'scale1_pct':args.scale1}.items() if v is not None}
    if args.classic_index is not None:
        patched.append(ed.patch_classic(args.classic_index,**kwargs))
    if args.adventure_index is not None:
        patched.append(ed.patch_adventure(args.adventure_index,**kwargs))
    if patched:
        if not args.output_dol: ap.error('--output-dol is required when patching')
        image.save_as(args.output_dol); print(json.dumps(patched,indent=2))
    elif not args.export:
        print(json.dumps({'classic_entries':len(ed.classic_entries()),'adventure_entries':len(ed.adventure_entries())},indent=2))

if __name__=='__main__': main()
