Phase 26 Stage Select Hub bundle

This bundle ties the paged retail MnSlMap grid to custom stage dispatch and the Co-op Adventure runtime contract.
It is an authoring/runtime-preflight bundle; final PowerPC hook installation still requires a project start.dol.
