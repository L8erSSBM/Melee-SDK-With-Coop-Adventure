import argparse, json
from pathlib import Path
from sdk.melee_dat import scan_fighter_directory

p=argparse.ArgumentParser(description='Scan standard Melee fighter DATs and validate matching AJ archives.')
p.add_argument('folder')
p.add_argument('-o','--output')
a=p.parse_args()
rows=scan_fighter_directory(a.folder)
text=json.dumps(rows,indent=2)
if a.output: Path(a.output).write_text(text,encoding='utf-8')
else: print(text)
