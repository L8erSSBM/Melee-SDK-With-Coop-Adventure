from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.one_player_resources import inspect_one_player_resources, adventure_resource_audit, write_resource_report


def main():
    ap=argparse.ArgumentParser(description='Inspect Melee 1P resource packages and audit retail Adventure stage dependencies')
    ap.add_argument('source', nargs='?', help='1P resource ZIP/folder')
    ap.add_argument('--report', help='write package inventory JSON')
    ap.add_argument('--stage-folder', help='folder containing Gr*.dat stage resources for Adventure audit')
    ns=ap.parse_args()
    out={}
    if ns.source:
        r=inspect_one_player_resources(ns.source)
        out['one_player_resources']=r.to_dict()
        if ns.report:
            write_resource_report(ns.source,ns.report)
    extra=[]
    if ns.stage_folder:
        extra=[p.name for p in Path(ns.stage_folder).rglob('Gr*.dat')]
        out['adventure_stage_audit']=adventure_resource_audit(extra_filenames=extra)
    if not out:
        ap.error('provide a source package and/or --stage-folder')
    print(json.dumps(out,indent=2))

if __name__=='__main__': main()
