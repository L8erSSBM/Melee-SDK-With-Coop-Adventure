# K20R validation

- Built a complete 1,459,978,240-byte GALE01 disc from the locally available verified clean v1.02 source. Embedded DOL matches the staged DOL.
- 23 focused tests passed: K20R archive isolation/copy safety, K20P Start/commit behavior and runtime budget, updated visual asset checks, K20N valid row contract, and the Direct bridge suite.
- Executed the renderer extracted from the rebuilt DOL against each actual embedded language archive. Checked 32 copy operations across repeated Page 2 / Default transitions. Icon, palette, caption and footer matched their selected payloads exactly; retail restoration was byte-exact.
- Missing signature and incorrect record-count cases make no memcpy or cache calls. PPC nonvolatile registers and stack are preserved across copy/cache calls that clobber volatile registers.
- SSS injected allocation: 1,216 bytes (0x4C0). Existing memory-budget regression passes.
- Decoded the rebuilt disc's I4 title/footer and C8 icon/palette to a visual preview and inspected the result.
- Two historical tests also fail on the unmodified supplied K20Q baseline: K20L's exact renderer-size assertion and K20D's obsolete synthetic archive without MnSelectStageDataTable. They are not claimed as passing. An exploratory older suite also encountered sandbox temp-directory permission errors; the 23 focused tests above completed without those errors.

Crash evidence from Crashagain.sav:

- Decoded state size: 91,619,328 bytes; MEM1 begins at decoded offset 0x71056E.
- STPG address: 0x804F43C0; page=1, saved=1, completed toggle count=0.
- Loaded models pointer: 0x80C18410.
- K20Q expected table address: 0x80CB5FEC; bytes begin BFA9B1B8, not SSVQ.
- Stock-name Slippi menu diffs are installed locally. Slippi's source confirms that these diffs are applied to ISO file contents by filename.

Limit: no live two-peer Slippi session was run. The supplied crash state is diagnostic evidence, not a test of the rebuilt code. Cold boot both peers for the final gameplay check.
