from pathlib import Path
p=Path('tests/test_sdk02021k16_session_lifetime.py');s=p.read_text().replace('for i,b in enumerate(remote_pad):mem[rx+0x2A+i]=b','for history in range(7):\n                for i,b in enumerate(remote_pad):mem[rx+0x2A+12*history+i]=b');s+='''

@pytest.mark.parametrize('local',[0,1])
def test_native_late_movement_requests_the_correct_pre_prediction_frame(local):
    mem=native_input_step({},local,remote_latest=199,frame=200,remote_pad=bytes(12))
    assert get(mem,nb.STABLE_ODB+0x38D)==200
    mem=native_input_step(mem,local,remote_latest=201,frame=201)
    assert get(mem,nb.STABLE_ODB+0xDF,1)==1
    assert get(mem,nb.STABLE_ODB+0xE0,1)==1
    assert get(mem,nb.STABLE_ODB+0x38D)==200
    assert get(mem,nb.STABLE_ODB+0xE1)==201
''';p.write_text(s)
