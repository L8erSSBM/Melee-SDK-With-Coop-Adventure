from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.stage import scan_stage_folder


def main():
    ap=argparse.ArgumentParser(description='Validate Melee Gr*.dat stage archives for Phase 14 stage-workbench structures.')
    ap.add_argument('folder', help='Folder containing Gr*.dat resources (for example Project/Working)')
    ap.add_argument('-o','--output', default='stage_validation_latest.json')
    args=ap.parse_args()
    rows=scan_stage_folder(args.folder)
    report={'files':len(rows),'passed':sum(r.get('status')=='PASS' for r in rows),'failed':sum(r.get('status')!='PASS' for r in rows),'stages':rows}
    Path(args.output).write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(f"Stage archives: {report['passed']}/{report['files']} PASS")
    for r in rows:
        if r.get('status')!='PASS': print(f"FAIL {r['filename']}: {r.get('error')}")
    return 1 if report['failed'] else 0

if __name__=='__main__':
    raise SystemExit(main())
