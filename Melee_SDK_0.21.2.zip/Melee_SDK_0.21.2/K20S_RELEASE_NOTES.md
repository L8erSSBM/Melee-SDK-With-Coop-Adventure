# 0.20.21K20S — Page 2 standalone stages

Implemented and enabled in the builder and prebuilt disc assets:

| Selection | Match behavior |
|---|---|
| Mushroom Kingdom | Adventure flagpole mission |
| Underground Maze | Adventure Triforce search |
| Brinstar Escape | Adventure escape mission |
| Corneria Part 2 | Original second fight and scripted Arwings |
| F-Zero Grand Prix | Adventure finish-line mission |
| Race to the Finish | Classic bonus subtype 2, GrNPo.dat |
| Link Arenas 1–6 | Separate maze layouts, normal two-human versus |
| Yoshi Arena | Isolated multi-Yoshi location, normal two-human versus |
| Coop Adventure | Existing full campaign |

Challenge completion and match exit use the existing captured Direct-origin
return. Versus arenas use four stocks, eight minutes, and no items. Their native
enemy generators and route controllers are disabled; stock outcomes and rebirth
hooks use retail behavior. Full Coop Adventure retains its existing rules.

Each new selection has a two-line caption and a thumbnail drawn from its stage's
collision geometry. The six Link thumbnails show their differing platforms.
Page 1 retains its original stage artwork. K20R menu filename isolation and
texture-table validation remain enabled for both language archives.

## Build and play

1. Extract the whole SDK ZIP to a new folder.
2. Run BUILD_MELEE_SDK.bat or melee_sdk.py and select your clean USA v1.02 ISO.
3. Build the Co-op Showcase/Direct variant. Both players use the identical ISO.
4. Cold-boot Slippi, connect through Direct, and press D-Pad Down on Stage Select.
5. Select a challenge or versus arena. D-Pad Up returns to the retail stage page.

The new required files are StSolo.dat, GrSL1.dat through GrSL6.dat, GrSYs.dat,
MnCoMap.usd, and MnCoMap.dat. The builder inserts these automatically. Copying
only start.dol into another disc image is insufficient.

## Validation boundary

This is an implemented runtime test release. Compilation, disc reconstruction,
emitted PPC execution, menu byte restoration, scope guards, and archive checks
have passed. Actual gameplay, camera feel, respawns, objective completion, and
return to Direct still need Dolphin/Slippi testing, including both peers. No
live gameplay or two-peer success is claimed by this release.

The original 16 KiB boot reservation stays fixed. Word-aligning internal code
recovers space; the new immutable module loads after the Direct handoff into the
unused 0x817FC000–0x817FE000 gap. It does not overlap the seven rollback slots or
the session data. File size and magic are checked before executing it.

## Build launcher correction (K20S1 package)

The batch launcher no longer automatically enables developer test shortcuts.
That option combined with the standalone stages exceeded the reserved runtime
block by 192 bytes. All thirteen stage selections and unlock-all remain enabled.
Leave the optional GUI test-shortcuts checkbox off for this build.
