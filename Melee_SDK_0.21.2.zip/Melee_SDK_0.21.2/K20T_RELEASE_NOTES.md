# K20T — Standalone exits and return to Direct

Based on the supplied K20S STANDALONE_STAGES_BUILD_FIX SDK.

Standalone selections now intercept the actual state-exit callback before native
Adventure progression. Completing or quitting the selected playable scene requests
the captured Direct/Online origin. Intro scenes retain their native progression.
The full Coop Adventure marker (A5) bypasses this interception entirely.

On the first scene after a completed return to Online, restore all 33 patched
Slippi engine instructions and turn off the Adventure bridge. Previously those
hooks stayed active until a CleanupConnections packet, allowing Adventure's
rollback/input loop to keep running in the returned menu. Cleanup occurs before
menu initialization; it does not send a disconnect packet. Active Adventure and
Staff Roll/Congratulations transitions are excluded.

Coop Adventure chapter progression, credits, Congratulations and Coming Soon
remain unchanged. The cosmetic missing P2 credits laser animation is not fixed
in this release.

## Use

Extract the complete ZIP into a fresh folder. Run BUILD_MELEE_SDK.bat using an
untouched GALE01 v1.02 ISO. Both players must cold-boot the same K20T build.
Do not resume a save made by an older build. Leave developer test shortcuts off.

## Validation and limits

- Full ISO build passed with normal difficulty, three stocks, friendly fire on,
  unlock-all on, scene revive off and developer shortcuts off.
- 194 focused tests passed, including the actual mtlr/blrl callback convention,
  all thirteen standalone selections, and campaign/intro exclusion cases.
- Executed the emitted ISO's thirteen return paths through the captured-origin
  wrapper: all request Online and clear Adventure ownership.
- Executed both emitted native-hook restoration paths; all 33 originals restore.
- Menu texture restoration, thirteen module launch paths and archive checks pass.
- Runtime ends at 0x804F4B20, leaving 224 bytes in the existing 16 KiB reservation.
- Live Dolphin/two-peer gameplay has not been tested here. In-game confirmation
  is still required for the reported quit freeze and post-campaign black screen.

The older broad historical suite is not a release-wide pass claim; its earlier
bridge-size/count assumptions predate the current Slippi integration.
