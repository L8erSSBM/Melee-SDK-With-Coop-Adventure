#!/usr/bin/env python3
from __future__ import annotations
import argparse, json

from sdk.dol_patch import DOLImage, SymbolMap, write_patch_manifest
from sdk.stage_slot import StageSlotAuthor
from sdk.character_slot import CharacterSlotAuthor, FT_KIND_BOY, FT_KIND_GIRL


def main():
    ap = argparse.ArgumentParser(description='Phase 17 runtime stage/fighter slot engineering tools')
    ap.add_argument('main_dol', help='GALE01 1.02 main.dol')
    ap.add_argument('symbols', help='doldecomp config/GALE01/symbols.txt')
    ap.add_argument('--report', action='store_true', help='Print stage and character slot report')
    ap.add_argument('--inject-stage', metavar='TEMPLATE_SYMBOL',
                    help='Activate dormant Akaneia StageData cloned from e.g. grNBa_StageData')
    ap.add_argument('--filename', default='/GrMy.dat', help='New FST stage filename to load (default: /GrMy.dat)')
    ap.add_argument('--legacy-cave', type=lambda x: int(x, 0),
                    help='Use the legacy explicit DOL data-cave method instead of an appended data section')
    ap.add_argument('--clone-ftkind', type=lambda x: int(x, 0), metavar='DONOR_KIND',
                    help='Clone donor FighterKind callback-table entries into Boy/Girl')
    ap.add_argument('--target', choices=['Boy','Girl','boy','girl'], default='Boy')
    ap.add_argument('--output-dol', help='Write patched DOL here')
    ap.add_argument('--patch-manifest', help='Write patch manifest JSON here')
    args = ap.parse_args()

    d = DOLImage(args.main_dol)
    s = SymbolMap.from_file(args.symbols)
    stage = StageSlotAuthor(d, s)
    chars = CharacterSlotAuthor(d, s)
    did_patch = False
    output: dict = {}

    if args.report or (not args.inject_stage and args.clone_ftkind is None):
        output['stage'] = stage.report()
        output['character'] = chars.report()

    all_patches = []
    if args.inject_stage:
        if args.legacy_cave is None:
            result = stage.inject_hidden_stage_slot_expanded(args.inject_stage, args.filename)
        else:
            result = stage.inject_hidden_stage_slot(args.inject_stage, args.filename, args.legacy_cave)
        all_patches.extend(result.patches)
        output['injected_stage'] = result.__dict__
        did_patch = True

    if args.clone_ftkind is not None:
        target_kind = FT_KIND_BOY if args.target.lower() == 'boy' else FT_KIND_GIRL
        patches = chars.clone_ftkind_callback_tables(args.clone_ftkind, target_kind)
        all_patches.extend(patches)
        output['fighter_prototype'] = {
            'donor_kind': args.clone_ftkind,
            'target': args.target,
            'target_kind': target_kind,
            'patch_count': len(patches),
        }
        did_patch = True

    if did_patch:
        if not args.output_dol:
            raise SystemExit('--output-dol is required when applying runtime patches')
        d.save_as(args.output_dol)
        output['output_dol'] = args.output_dol
        if args.patch_manifest:
            write_patch_manifest(args.patch_manifest, all_patches)
            output['patch_manifest'] = args.patch_manifest

    print(json.dumps(output, indent=2, default=str))

if __name__ == '__main__':
    main()
