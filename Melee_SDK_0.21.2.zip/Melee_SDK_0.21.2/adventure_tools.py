from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.adventure_coop import CoopAdventureCampaign, write_campaign_bundle

def main():
    ap=argparse.ArgumentParser(description='Melee SDK co-op Adventure campaign authoring')
    ap.add_argument('--create', metavar='DIR', help='create a complete vanilla-order co-op Adventure campaign bundle')
    ap.add_argument('--name', default='Co-op Adventure')
    ap.add_argument('--p2-character', type=lambda x:int(x,0))
    ap.add_argument('--report', action='store_true')
    ns=ap.parse_args()
    c=CoopAdventureCampaign.vanilla_sequence(ns.name)
    c.rules.p2_character_kind=ns.p2_character
    if ns.create:
        out=write_campaign_bundle(ns.create,c); print(out)
    if ns.report or not ns.create:
        print(json.dumps({'chapters':len(c.chapters),'segments':len(c.linear_segments()),'runtime_plan':c.runtime_plan(),'compatibility':c.compatibility_report()},indent=2))
if __name__=='__main__': main()
