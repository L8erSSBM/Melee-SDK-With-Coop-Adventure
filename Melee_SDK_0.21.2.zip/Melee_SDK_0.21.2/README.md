# Melee SDK 0.21.2 — Adventure transition repair

Based on 0.21.1, with the supplied Direct-handoff and P2 credits-animation patches merged.

- Fixes the presentation-patch overwrite of the Mario/Luigi encounter setup.
- Returns standalone Page-2 selections to Direct without advancing Adventure.
- Assigns the next SDK-return stage selection to canonical P1; P2 waits.
- Preserves full Adventure progression, Race to the Finish, and the Yoshi carrier.

Extract into a fresh folder and run **BUILD_MELEE_SDK.bat** with an untouched
USA v1.02 ISO. Both players must cold-boot the same rebuilt disc. Do not resume
old savestates: they contain the broken executable.

Build and instruction-level validation passed; live two-peer gameplay remains
to be checked. See [0.21.2_RELEASE_NOTES.md](0.21.2_RELEASE_NOTES.md) for the
crash evidence, merge details, validation limits, and playtest steps.
