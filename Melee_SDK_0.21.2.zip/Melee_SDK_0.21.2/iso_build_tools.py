from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.iso_builder import BUILD_VARIANTS, ADVENTURE_DIFFICULTIES, build_test_iso


def main(argv=None):
    p=argparse.ArgumentParser(description='Melee SDK 0.21.1 open-testing clean-ISO builder')
    p.add_argument('--clean-iso',required=True,help='Untouched GALE01 v1.02 ISO backup')
    p.add_argument('--output-iso',required=True,help='New ISO to create; source is never overwritten')
    p.add_argument('--variant',choices=BUILD_VARIANTS,default='coop_showcase')
    p.add_argument('--symbols',default='data/runtime_symbols_GALE01.txt')
    p.add_argument('--content-dir',help='Optional flat Build/ directory of DAT/AJ/etc replacements/additions')
    p.add_argument('--work-dir',help='Optional retained scratch/staging directory for inspection')
    p.add_argument('--manifest',help='Optional build manifest path')
    p.add_argument('--scene-revive',action='store_true',help='Revive eliminated P1/P2 at the next Adventure scene using the run\'s original starting stock count')
    p.add_argument('--test-shortcuts',action='store_true',help='TEST ONLY: enable L+D-Pad Adventure stage-clear/KO/stock-restore shortcuts')
    p.add_argument('--unlock-all',action='store_true',help='TEST ONLY: report all normal characters/stages unlocked without writing save unlock bits')
    p.add_argument('--vs-p2-profile',action='store_true',help='TEST ONLY: preserve independent normal-VS human P2 identity in Adventure')
    p.add_argument('--adventure-sss-gateway',action='store_true',help="enable Co-op Adventure runtime; Slippi Direct uses the custom D-Pad Down stage page while local VS remains retail")
    ff=p.add_mutually_exclusive_group()
    ff.add_argument('--friendly-fire',dest='friendly_fire',action='store_true',help='Enable P1/P2 team damage in Co-op Adventure')
    ff.add_argument('--no-friendly-fire',dest='friendly_fire',action='store_false',help='Disable P1/P2 team damage in Co-op Adventure')
    p.set_defaults(friendly_fire=None)
    p.add_argument('--adventure-difficulty',choices=ADVENTURE_DIFFICULTIES,default='normal',help='Gateway Adventure difficulty; SDK default is normal')
    p.add_argument('--adventure-stocks',type=int,default=3,help='Gateway Adventure starting stocks (1-9; default 3)')
    p.add_argument('--no-phase43-repairs',dest='phase43_repairs',action='store_false',help='Regression only: disable Phase 43 Falco/Kirby route repairs')
    p.set_defaults(phase43_repairs=True)
    args=p.parse_args(argv)
    m=build_test_iso(args.clean_iso,args.output_iso,variant=args.variant,symbols_path=args.symbols,
                     content_dir=args.content_dir,work_dir=args.work_dir,manifest_path=args.manifest,
                     scene_revive=args.scene_revive,test_shortcuts=args.test_shortcuts,unlock_all=args.unlock_all,
                     vs_p2_identity_bridge=(args.vs_p2_profile or args.adventure_sss_gateway),
                     adventure_sss_gateway=args.adventure_sss_gateway,
                     friendly_fire=args.friendly_fire,adventure_difficulty=args.adventure_difficulty,
                     adventure_stocks=args.adventure_stocks,phase43_repairs=args.phase43_repairs)
    print(json.dumps(m,indent=2))

if __name__=='__main__': main()
