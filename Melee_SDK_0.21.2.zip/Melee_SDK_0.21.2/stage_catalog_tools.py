from __future__ import annotations
import argparse
from pathlib import Path
from sdk.stage_builder_catalog import write_catalog_bundle

def main():
    ap=argparse.ArgumentParser(description='Build a human-readable Melee stage-asset catalogue from a folder containing Gr*.dat files.')
    ap.add_argument('stage_folder')
    ap.add_argument('-o','--output',default='stage_builder_catalog')
    a=ap.parse_args()
    result=write_catalog_bundle(Path(a.stage_folder),Path(a.output))
    for k,v in result.items(): print(f'{k}: {v}')
if __name__=='__main__': main()
