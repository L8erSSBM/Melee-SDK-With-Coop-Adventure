# Melee Character SDK 0.20.21K20P — SSS Start/Commit Repair

The supplied K20O savestate freezes immediately at Stage Select lock-in with the SSS custom state already clear (`page=0`, `saved=0`, transaction trace `0`) while all three K20O SSS hooks are resident. K20P therefore hardens both the ordinary retail commit path and the custom-page presentation boundary instead of changing Adventure or rollback code.

- Ordinary SSS selection now tail-branches directly into the original retail stage mapper with no injected stack frame or helper calls.
- The Co-op wrapper runs only when the private page byte is exactly Page 2.
- Removes K20O's one-frame cursor row `29` refresh sentinel; the cursor remains on valid slot `27`.
- Slot 27 keeps native `x9=27` on both pages. No synthetic animation index is handed to retail Start/transition code.
- Co-op title and footer are alternate image payloads selected by `ImageDesc.image_ptr` swaps on existing valid descriptors.
- Co-op thumbnail remains on valid special-icon frame 1; the seven-entry retail special-icon table is not extended.
- Runtime visual swaps use a compact MnSlMap-resident relocation table, keeping the injected SSS payload within the validated aligned `0x4C0` budget.
- No Slippi Direct ownership, rollback, Adventure, Team Kirby/Icies, credits, stock, camera, or completion-return code was changed.
