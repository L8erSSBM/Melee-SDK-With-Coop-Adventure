from pathlib import Path
import json, tempfile
from sdk.melee_dat import FighterDAT, analyze_figatree_archive, retime_figatree_archive

PLAYABLE = ['PlMr','PlDr','PlLg','PlKp','PlPe','PlYs','PlDk','PlCa','PlGn','PlFc','PlFx','PlNs','PlPp','PlNn','PlKb','PlSs','PlZd','PlSk','PlLk','PlCl','PlPr','PlPk','PlPc','PlMt','PlGw','PlMs','PlFe']

def validate(folder: Path):
    rows=[]; total_chunks=parsed=full_move_pass=0; total_tracks=total_waits=0
    for stem in PLAYABLE:
        dat=folder/(stem+'.dat'); ajp=folder/(stem+'AJ.dat')
        if not dat.exists() or not ajp.exists():
            rows.append({'fighter_file':stem,'status':'MISSING'}); continue
        f=FighterDAT(dat); aj=ajp.read_bytes(); seen=set(); failures=[]; local=0; tracks=waits=0
        for a in f.animations:
            if not a.symbol or not a.anim_archive_size: continue
            key=(a.anim_archive_offset,a.anim_archive_size)
            if key in seen: continue
            seen.add(key); total_chunks += 1; local += 1
            try:
                info=analyze_figatree_archive(aj[key[0]:key[0]+key[1]])
                tracks += info['track_count']; waits += info['wait_count']; parsed += 1
            except Exception as exc:
                failures.append(f'{a.action_name}: {exc}')
        total_tracks += tracks; total_waits += waits
        integ='SKIP'
        try:
            # Prefer a hitbox-bearing action so script timing and AJ timing are both exercised.
            candidate=None
            for a in f.animations:
                if not a.symbol or not a.anim_archive_size or not a.script_offset: continue
                if any(e.get('opcode') == 11 for e in f.parse_script(a)):
                    candidate=a; break
            if candidate is None:
                candidate=next(a for a in f.animations if a.symbol and a.anim_archive_size and a.script_offset)
            newaj,result=f.retime_full_move(candidate,aj,1.30)
            with tempfile.TemporaryDirectory() as td:
                q=Path(td)/(stem+'AJ.dat'); q.write_bytes(newaj)
                r=f.validate_animation_archive(q)
                if r['errors']: raise ValueError(r['errors'][0])
            integ='PASS'; full_move_pass += 1
        except Exception as exc:
            integ='FAIL: '+str(exc); failures.append('integration: '+str(exc))
        rows.append({'fighter':f.fighter_name,'fighter_file':stem,'unique_chunks':local,'tracks':tracks,'encoded_key_waits':waits,'full_move_1_30x':integ,'status':'PASS' if not failures else 'FAIL','errors':failures[:5]})

    # Explicitly exercise variable-size AJ rebuilding by slowing Falcon Punch 4x.
    resize_check={}
    try:
        f=FighterDAT(folder/'PlCa.dat'); a=next(x for x in f.animations if x.action_name=='SpecialN'); aj=(folder/'PlCaAJ.dat').read_bytes()
        chunk=aj[a.anim_archive_offset:a.anim_archive_offset+a.anim_archive_size]
        new_chunk, info=retime_figatree_archive(chunk,4.0)
        verify=analyze_figatree_archive(new_chunk)
        resize_check={'status':'PASS','old_size':len(chunk),'new_size':len(new_chunk),'delta':len(new_chunk)-len(chunk),'old_frames':info['old_frames'],'new_frames':verify['frames']}
    except Exception as exc:
        resize_check={'status':'FAIL','error':str(exc)}

    return {'total_unique_chunks':total_chunks,'parsed_ok':parsed,'parse_failures':total_chunks-parsed,'total_figatree_tracks':total_tracks,'total_encoded_key_waits':total_waits,'fighter_full_move_1_30x_pass':full_move_pass,'variable_size_rebuild_check':resize_check,'rows':rows}

if __name__=='__main__':
    import sys
    result=validate(Path(sys.argv[1] if len(sys.argv)>1 else '.'))
    print(json.dumps(result,indent=2))
