"""Reproducible native SSS typography (Pillow is a development-only dependency)."""
from pathlib import Path
from PIL import Image, ImageDraw, ImageFont

ROOT=Path(__file__).resolve().parent
ASSETS=ROOT/'assets/sss_qol'
SCALE=4


def lettering(text, font, size, width, height, italic=False):
    f=ImageFont.truetype(str(Path('C:/Windows/Fonts')/font),size*SCALE)
    box=f.getbbox(text)
    im=Image.new('RGBA',(box[2]-box[0]+8*SCALE,box[3]-box[1]+2*SCALE))
    ImageDraw.Draw(im).text((4*SCALE-box[0],-box[1]),text,font=f,fill='white')
    bounds=im.getbbox();im=im.crop(bounds)
    if italic:
        shift=round(im.height*.23)
        im=im.transform((im.width+shift,im.height),Image.Transform.AFFINE,
                        (1,.23,-shift,0,1,0),Image.Resampling.BICUBIC)
    return im.resize((width*SCALE,height*SCALE),Image.Resampling.LANCZOS)


def save_surface(im,path):
    im=im.resize((im.width//SCALE,im.height//SCALE),Image.Resampling.LANCZOS)
    # Native I4 uses luminance; keep zero-alpha texels black.
    im.putdata([(r,g,b,a) if a else (0,0,0,0) for r,g,b,a in im.getdata()])
    im.save(path)
    return im


def navigation(next_page=None, previous=False):
    im=Image.new('RGBA',(232*SCALE,16*SCALE))
    def legend(x,text,up,width):
        d=ImageDraw.Draw(im)
        def rect(box,fill):d.rectangle(tuple(round(v*SCALE) for v in box),fill=fill)
        tint=(188,183,215,255)
        rect((x+6,0,x+10,15),tint);rect((x,5,x+16,10),tint)
        rect((x+7,0 if up else 11,x+9,4 if up else 15),(115,135,220,255))
        mask=lettering(text,'ariblk.ttf',20,width,15,italic=True)
        color=Image.new('RGBA',mask.size,tint);color.putalpha(mask.getchannel('A'))
        im.alpha_composite(color,((x+20)*SCALE,0))
    if previous:legend(3,'DEFAULT',True,94)
    if next_page is not None:legend(122,f'PAGE {next_page}',False,90)
    return im


if __name__=='__main__':
    title=Image.new('RGBA',(224*SCALE,56*SCALE))
    # Retail Dream Land uses a small centered serif heading and a larger,
    # condensed italic stage name. Keep the user's exact title case.
    title.alpha_composite(lettering('Special Mode','timesbd.ttf',18,118,16),(53*SCALE,0))
    title.alpha_composite(lettering('Coop Adventure','ARIALNBI.TTF',43,214,35),(5*SCALE,20*SCALE))
    saved_title=save_surface(title,ASSETS/'coop_adventure_title_only.png')
    down=save_surface(navigation(next_page=2),ASSETS/'sss_nav_default_down.png')
    up=save_surface(navigation(previous=True),ASSETS/'sss_nav_page2_up.png')
    # This preview is conditional design documentation, not an enabled Page 3.
    future=navigation(previous=True,next_page=3).resize((232,16),Image.Resampling.LANCZOS)
    preview=Image.new('RGB',(760,430),(18,17,44));draw=ImageDraw.Draw(preview)
    draw.text((20,12),'DEFAULT PAGE',fill='white')
    preview.paste(down.resize((696,48)),(20,38),down.resize((696,48)))
    draw.text((20,105),'PAGE 2 (CURRENT TWO-PAGE SDK)',fill='white')
    preview.paste(up.resize((696,48)),(20,130),up.resize((696,48)))
    draw.text((20,195),'PAGE 2 (ONLY IF A REAL PAGE 3 IS ADDED)',fill='white')
    preview.paste(future.resize((696,48)),(20,220),future.resize((696,48)))
    preview.paste(saved_title.resize((448,112)),(160,300),saved_title.resize((448,112)))
    preview.save(ROOT/'Build/k20r/artwork_preview.png')
