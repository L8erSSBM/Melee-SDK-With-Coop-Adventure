# 0.20.21K20O validation

- Python compile: pass.
- Focused K20O/K20N SSS regression set: 6 passed.
- Retail special-icon table remains 7 entries; no animation-table extension.
- Retail visible special-icon frames 2..6 verify byte-for-byte unchanged after patching MnSlMap.
- Co-op frame 1 decodes as a 48x48 C8 image with a native 16-entry RGB565 TLUT.
- Runtime SSS payload remains at or below K20N's validated aligned 0x4C0 budget.
