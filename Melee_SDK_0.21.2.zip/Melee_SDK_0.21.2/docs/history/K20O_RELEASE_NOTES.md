# Melee Character SDK 0.20.21K20O — Valid-Frame SSS Presentation Repair

- Keeps the K20N/K20L working Slippi Direct D-Pad page transition.
- Removes the invalid eighth special-icon animation frame that produced the barcode artifact.
- Reuses existing, otherwise-unselected special-icon frame 1 for the 48x48 Co-op Adventure thumbnail.
- Leaves retail special-icon frames 2..6 byte-for-byte untouched, including Yoshi's Island frame 5.
- Keeps custom stage-title frame 29, rebuilt with clean serif typography closer to Melee's retail stage-name treatment.
- Page 1 footer: large right-anchored D-Pad Down + PAGE 2.
- Page 2 footer: large left-anchored D-Pad Up + DEFAULT.
- Footer switching uses only the static footer ImageDesc image-pointer field; no live texture memcpy and no extra icon table extension.
