@echo off
rem Compatibility marker: MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE
rem Compatibility marker: SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE
rem Compatibility marker: _MeleeSDK_0.20.18.iso
setlocal EnableExtensions
cd /d "%~dp0"

rem ========================================================================
rem  Melee SDK 0.21.2 Disc Assets + GUI - configurable ISO builder
rem  Preserves 0.20.3 runtime relocation and all subsequent retail-safety fixes.
rem
rem  Change only these four values for normal Adventure testing:
rem    DIFFICULTY    = very_easy, easy, normal, hard, very_hard
rem    STOCKS        = 1..9
rem    SCENE_REVIVE  = off or on
rem    FRIENDLY_FIRE = off or on
rem ========================================================================
set "DIFFICULTY=normal"
set "STOCKS=3"
set "SCENE_REVIVE=off"
set "FRIENDLY_FIRE=on"

set "LOG=%~dp0BUILD_MELEE_SDK.log"
>"%LOG%" echo Melee SDK 0.21.2 Disc Assets + GUI ISO Builder
>>"%LOG%" echo Started: %DATE% %TIME%
>>"%LOG%" echo SDK folder: %CD%
>>"%LOG%" echo Difficulty: %DIFFICULTY%
>>"%LOG%" echo Stocks: %STOCKS%
>>"%LOG%" echo Scene Revive: %SCENE_REVIVE%
>>"%LOG%" echo Friendly Fire: %FRIENDLY_FIRE%
>>"%LOG%" echo.

echo ============================================================
echo  MELEE CHARACTER SDK 0.21.2 - DISC ASSETS + GUI
echo ============================================================
echo.
echo Difficulty    : %DIFFICULTY%
echo Stocks        : %STOCKS%
echo Scene Revive  : %SCENE_REVIVE%
echo Friendly Fire : %FRIENDLY_FIRE%
echo.
echo 0.21.2 keeps the validated carrier + marker path and isolates SSS archives and validates page artwork copies:
echo   - First Direct match remains Slippi's normal random legal stage
echo   - Back out to Stage Select, press D-Pad Down for the Custom + Co-op page
echo   - Page 2 includes six challenges, six Link arenas, Yoshi Arena, and full Co-op Adventure
echo   - Choose a new stage or the bottom-row Co-op Adventure tile; D-Pad Up returns to retail stages
echo   - Both peers synchronize the chosen Page 2 entry before launch
echo   - Ordinary Yoshi's Story always remains ordinary Yoshi's Story
echo   - Slippi ODB/input session relocates into reserved 0x817FE000..0x81800000 before Adventure
echo   - Direct-origin presentation screens auto-advance identically on both peers as sync barriers
echo   - Pre-carrier Direct logical roles + P1/P2 identities are latched before Yoshi can reorder them
echo   - K16 keeps chapter exits from reporting the Direct transport game as ended
echo   - Each machine keeps its native physical input source; Slippi maps that input to the captured logical fighter slot
echo   - 12 audited engine/input/rumble/sound hooks stay scoped active in Adventure
echo   - Native prediction/stall handling remains live throughout the Adventure session
echo.
echo Frozen Adventure behavior remains:
echo   - Retail 1-P Adventure stays P1-only with retail Continue / Quit
echo   - Local/retail Yoshi's Island ^(N64^) remains the real retail stage
echo   - The retired local-VS Yoshi gateway is not used by this Direct test path
echo   - Independent stocks, camera transfer, scripted encounters, completion routing,
echo     independent credits lenses, credits exit repair, and Team-Kirby/Icies repairs remain
echo   - Friendly/team damage is ON by default in this test package
echo.
echo Runtime safety:
echo   - Developer L+D-Pad test shortcuts are OFF in the normal K20S standalone-stage build
echo     so the fixed 16 KiB Slippi-safe low runtime reservation is not exceeded
echo   - SDK runtime remains relocated outside Slippi m-ex globals / OS stacks
echo   - Original 16 KiB arena reservation is restored; Slippi dynamic addresses are not shifted
echo   - K5 preserves Slippi local-player, opponent-player, and physical input-source bytes independently
echo   - Engine simulation clock and SDK gameplay state restore with B2
echo   - Heap reservation and first-match rollback map initialization are repaired
echo   - Read K20S_RELEASE_NOTES.md for the SSS Start repair and preserved runtime scope
echo.
echo PRIMARY TARGET FOR THIS BUILD:
echo   PC P1 Link controls Link + ROG P2 Mewtwo controls Mewtwo,
echo   with both movements visible on BOTH peers and the first rollback surviving.
echo.
echo IMPORTANT: this is an experimental peer-to-peer runtime candidate.
echo Both players must use the exact same rebuilt 0.21.2 ISO from a cold Slippi boot.

rem ---- Resolve source ISO -------------------------------------------------
if "%~1"=="" (
  echo Paste the full path to your CLEAN GALE01 v1.02 ISO.
  echo.
  set /p "CLEANISO=Clean Melee ISO: "
) else (
  set "CLEANISO=%~1"
)

if not defined CLEANISO (
  echo ERROR: No ISO path was provided.
  >>"%LOG%" echo ERROR: No ISO path was provided.
  goto :failed
)
if not exist "%CLEANISO%" (
  echo ERROR: ISO not found: "%CLEANISO%"
  >>"%LOG%" echo ERROR: ISO not found: "%CLEANISO%"
  goto :failed
)
if not exist "%~dp0iso_build_tools.py" (
  echo ERROR: iso_build_tools.py is missing.
  >>"%LOG%" echo ERROR: iso_build_tools.py missing.
  goto :failed
)

rem ---- Find Python --------------------------------------------------------
set "PYEXE="
set "PYARGS="
where py >nul 2>&1
if not errorlevel 1 (
  py -3 --version >nul 2>&1
  if not errorlevel 1 (
    set "PYEXE=py"
    set "PYARGS=-3"
  )
)
if not defined PYEXE (
  where python >nul 2>&1
  if not errorlevel 1 (
    python --version >nul 2>&1
    if not errorlevel 1 set "PYEXE=python"
  )
)
if not defined PYEXE (
  where python3 >nul 2>&1
  if not errorlevel 1 (
    python3 --version >nul 2>&1
    if not errorlevel 1 set "PYEXE=python3"
  )
)
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
if not defined PYEXE if exist "%LOCALAPPDATA%\Programs\Python\Python310\python.exe" set "PYEXE=%LOCALAPPDATA%\Programs\Python\Python310\python.exe"
if not defined PYEXE (
  echo ERROR: Could not find Python from this CMD session.
  >>"%LOG%" echo ERROR: No usable Python interpreter found.
  goto :failed
)

rem ---- Translate config into SDK CLI switches ----------------------------
set "REVIVEFLAG="
if /I "%SCENE_REVIVE%"=="on" set "REVIVEFLAG=--scene-revive"

set "FFFLAG=--no-friendly-fire"
if /I "%FRIENDLY_FIRE%"=="on" set "FFFLAG=--friendly-fire"

for %%I in (very_easy easy normal hard very_hard) do if /I "%DIFFICULTY%"=="%%I" set "DIFFICULTY_VALID=1"
if not defined DIFFICULTY_VALID (
  echo ERROR: DIFFICULTY must be very_easy, easy, normal, hard, or very_hard.
  >>"%LOG%" echo ERROR: Invalid difficulty: %DIFFICULTY%
  goto :failed
)

set /a STOCKS_NUM=%STOCKS% 2>nul
if %STOCKS_NUM% LSS 1 goto :badstocks
if %STOCKS_NUM% GTR 9 goto :badstocks
goto :stocksok

:badstocks
echo ERROR: STOCKS must be 1 through 9.
>>"%LOG%" echo ERROR: Invalid stocks: %STOCKS%
goto :failed

:stocksok
rem ---- Output -------------------------------------------------------------
for %%I in ("%CLEANISO%") do set "OUTISO=%~dp0%%~nI_MeleeSDK_0.21.2.iso"
set "MANIFEST=%OUTISO%.build_manifest.json"
if /I "%OUTISO%"=="%CLEANISO%" (
  echo ERROR: Output unexpectedly equals source ISO.
  >>"%LOG%" echo ERROR: Source and output paths match.
  goto :failed
)

echo Source: "%CLEANISO%"
echo Output: "%OUTISO%"
echo.
>>"%LOG%" echo Python: "%PYEXE%" %PYARGS%
>>"%LOG%" echo Output ISO: "%OUTISO%"

rem ---- Build --------------------------------------------------------------
echo Building full GameCube ISO...
echo.
"%PYEXE%" %PYARGS% "%~dp0iso_build_tools.py" --clean-iso "%CLEANISO%" --output-iso "%OUTISO%" --variant coop_showcase --unlock-all --vs-p2-profile --adventure-sss-gateway --adventure-difficulty %DIFFICULTY% --adventure-stocks %STOCKS% %REVIVEFLAG% %FFFLAG% --manifest "%MANIFEST%" >>"%LOG%" 2>&1
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
  echo BUILD FAILED with exit code %RC%.
  echo Your clean ISO was NOT modified.
  echo.
  type "%LOG%"
  goto :failed
)
if not exist "%OUTISO%" (
  echo ERROR: Builder returned success but output ISO was not found.
  >>"%LOG%" echo ERROR: Missing expected output ISO.
  goto :failed
)

echo.
echo ============================================================
echo  BUILD COMPLETE - MELEE CHARACTER SDK 0.21.2
echo ============================================================
echo.
echo Open this ISO first in REGULAR SLIPPI from a cold boot:
echo   "%OUTISO%"
echo.
echo Primary 0.21.2 Slippi Adventure connected-handoff test:
echo   1^) BOTH players build/use this exact same 0.21.2 ISO and cold-boot it in Slippi.
echo   2^) Open Direct Connect and connect normally.
echo   3^) Use the same assignment as the savestate comparison if convenient: logical P1 Link, logical P2 Mewtwo.
echo   4^) Finish/back out of the initial random Direct match to Stage Select. Press D-Pad Down, then choose the Co-op Adventure tile.
echo   5^) DO NOT press LRA+Start in the Yoshi carrier. It should leave automatically once the live Slippi input exchange runs.
echo   6^) CRITICAL: verify each machine controls only its own logical fighter:
echo        - the player assigned Link controls Link
echo        - the player assigned Mewtwo controls Mewtwo
echo      Neither machine should have both local controllers mapped back to Adventure P1.
echo   7^) Direct-origin presentation/cutscene screens should auto-advance identically on BOTH peers; do not press Start to force them.
echo   8^) Fight/move for at least 20-30 seconds and confirm remote movement/attacks remain synchronized.
echo   9^) If that succeeds, continue into the first playable chapter and test simultaneous combat/team damage.
echo  10^) Do NOT use LRA+Start during this test; this build's milestone is a connected automatic Adventure handoff.
echo  11^) If either peer freezes/desyncs/loses ownership, make a savestate on BOTH peers immediately and send both.

echo Retail isolation targets remain:
echo   - Normal 1-P Adventure is P1-only
echo   - Retail 1-P Continue and Quit remain genuine retail
echo   - Local/original VS Yoshi N64 always loads the real retail Yoshi's Island stage
echo.
echo 0.21.2 retains canonical Direct ownership and K13 frame/RNG continuity, then refreshes the relocated Slippi control state on the first carrier B0 after native InitOnlinePlay initialization.
echo Physical local Port 1 remains Slippi-owned; Adventure stays true GM_ADVENTURE so synchronized cutscene filtering remains active.
echo.
>>"%LOG%" echo BUILD COMPLETE: "%OUTISO%"
>>"%LOG%" echo Finished: %DATE% %TIME%
goto :done

:failed
echo.
echo Log file:
echo   "%LOG%"
echo.
:done
pause
endlocal
