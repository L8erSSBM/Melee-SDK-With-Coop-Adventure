import argparse, json
from pathlib import Path
from sdk.melee_dat import FighterDAT

p=argparse.ArgumentParser(description='Decode a standard Melee fighter DAT to JSON.')
p.add_argument('dat')
p.add_argument('-o','--output')
p.add_argument('--move',help='Only print moves whose action name contains this text')
a=p.parse_args()
f=FighterDAT(a.dat)
if a.move:
    out=[]
    for m in f.find_moves(a.move):
        out.append({'index':m.index,'action':m.action_name,'script':f.parse_script(m)})
else: out=f.export_summary()
text=json.dumps(out,indent=2)
if a.output: Path(a.output).write_text(text,encoding='utf-8')
else: print(text)
