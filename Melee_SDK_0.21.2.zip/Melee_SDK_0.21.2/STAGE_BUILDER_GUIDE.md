# Stage Builder — Human-Oriented Guide

The old Stage Workbench grew feature-by-feature and exposed reverse-engineering concepts directly. Phase 39 Hotfix 3 does **not** throw away those safe editors; it reorganizes them around what a stage creator is actually trying to build.

The complete retail-corpus catalogue is in:

- `data/stage_builder_catalog/STAGE_BUILDER_ASSET_CATALOG.md` — readable overview and 71-stage index
- `data/stage_builder_catalog/stage_builder_stage_index.csv` — compact stage-by-stage counts
- `data/stage_builder_catalog/stage_builder_asset_catalog.json` — full machine-readable inventory, including every discovered texture descriptor and marker inventory
- `stage_catalog_tools.py` — regenerate the catalogue from any folder containing `Gr*.dat`

## Think of a stage as six layers

### 1. Identity / template

A `Gr*.dat` contains stage resources, but the game also needs runtime `StageData`, `StKind` / `GrKind`, FST identity, and Stage Select presentation. The SDK can clone a donor stage into an independent project resource and use the dormant Akaneia runtime identity for a real extra stage. The donor still supplies stage callbacks until you author new executable behavior.

### 2. Layout

This is the gameplay collision world, separate from the visual model.

Current safe tools:

- vertex editing
- add collision segment
- split / join / delete segment
- floor / ceiling / left wall / right wall / dynamic categories
- material lookup ID
- pass-through/platform bit
- ledge-grab bit
- dynamic-floor-source bit
- MapJoint range/bounds inventory
- translate joint-owned base collision geometry

### 3. Gameplay markers

Source-known marker meanings:

- `0x00..0x03` — Player Spawn 1..4
- `0x04..0x07` — Respawn Platform 1..4
- `0x94` — Camera Center
- `0x95..0x96` — Camera Range markers
- `0x97..0x98` — Blast Zone markers

Retail stages contain many additional marker IDs. The builder shows them and their positions, but deliberately labels them **Undecoded** until their stage-specific meaning is source-traced.

### 4. Visuals

The builder inventories HSD JObj trees reachable from the stage map resources and lets you edit base JObj transforms. This is visual placement, not collision.

Textures are inventoried by symbol, dimensions, GX format, mipmap state, descriptor offset, and encoded size. Same-size PNG replacement is supported for non-mipmapped I4, I8, IA4, IA8, RGB565, RGB5A3, RGBA8, and CMPR.

Paletted C4/C8/C14X2 textures stay read-only until TLUT editing is paired with them. Mipmapped textures stay read-only until the full mip chain can be regenerated safely.

### 5. Motion / hazards / effects

These are intentionally the next major reverse-engineering layer rather than fake controls in the GUI.

- Dynamic collision ownership is understood enough to edit base geometry.
- HSD animation data exists and is preserved, but track-to-object/keyframe authoring is not yet safe enough for a general editor.
- `yakumono_param` exists in all 71 supplied retail stage archives, but its payload is stage-specific.
- `itemdata`, particle/effect, lighting, texture-group, and quake-related public data are catalogued where present but are not given guessed semantic controls.
- Stage hazards and transformations are also driven by DOL callbacks; a DAT-only editor cannot honestly represent all of that.

### 6. Presentation

These live outside the core gameplay DAT and should stay visibly separate in the builder:

- Stage Select tile / page
- thumbnail / preview image
- displayed name / labels
- music/audio routing
- runtime launch identity

Keeping presentation separate prevents a common modding mistake: assuming changing a `Gr*.dat` automatically creates a fully independent Stage Select entry.

## Recommended workflow today

1. Pick the closest retail donor.
2. **Create NEW Stage…** so Original/Working isolation is preserved.
3. Use **Layout / Collision…** for collision, spawns, camera and blast zones.
4. Use **Stage Builder…** for the categorized asset overview, marker inventory, scene objects, textures, and advanced undecoded data.
5. Keep donor animation/hazard logic until the relevant stage-specific systems are decoded.
6. Install the independent runtime stage identity / Stage Select bridge when you are ready to test.
7. Build a separate ISO; never patch the source ISO in place.

## Why unknowns are still shown

“Undecoded” is not the same as “ignore it.” An unknown marker or public symbol may be crucial to a particular stage. The SDK now surfaces those objects in a dedicated advanced area so we can study them without mixing them into the safe, user-facing controls.

## Hotfix 7: constructing geometry

The Stage Builder now has a friendly construction layer above the raw collision editor.

1. Open the working stage and choose **Stage Builder…**.
2. Click **+ Add Asset** (or **+ Add Primitive…** in Current Stage Architecture).
3. Choose Floor, Slope, Soft Platform, Grab-Enabled Floor, Left/Right Wall, or Ceiling.
4. Enter/place the two endpoints, choose a structurally compatible collision owner, and adjust the common source-known surface flags.
5. Click **Add to Stage**.
6. Use **Draft Preview…** to inspect the new geometry.
7. Use **Advanced Collision…** whenever you need exact line flags, split/join/delete, or other low-level edits.
8. Save with the normal **Save Stage Working** workflow.

For retail references, go to **Asset Library**, choose a type and source stage, select one collision record, and click **Add Selected Collision to Stage…**. This copies gameplay collision only; visual mesh/material/texture/animation ownership is not guessed.
