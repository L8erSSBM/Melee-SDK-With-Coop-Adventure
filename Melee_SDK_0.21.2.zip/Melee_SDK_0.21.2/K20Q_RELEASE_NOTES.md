# Melee Character SDK 0.20.21K20Q — Page 2 Visual + Retail Isolation Repair

- Keeps K20P Start/commit fast-path and valid slot-27 cursor behavior.
- Removes the K20P permanent special-icon frame-1 rewrite entirely. No retail stage icon/title frame is reserved for Co-op artwork.
- Restores the verified page-local live-buffer visual swap: Page 2 copies Co-op icon/palette/title/footer bytes into the live MnSlMap buffers; returning to Default copies exact retail bytes back.
- Targets every selected-stage caption descriptor at retail frame 27, so both the small heading and large stage-name presentation are replaced on Page 2.
- Page 1 footer remains the right-aligned shaded D-Pad Down / PAGE 2 artwork. Page 2 footer is the left-aligned shaded D-Pad Up / DEFAULT artwork.
- Yoshi's Island (N64) remains retail on Page 1 and is never permanently overwritten in MnSlMap.
- No Adventure, rollback, Direct identity, stock, camera, credits, Team Kirby/Icies, or completion-return behavior is changed.
