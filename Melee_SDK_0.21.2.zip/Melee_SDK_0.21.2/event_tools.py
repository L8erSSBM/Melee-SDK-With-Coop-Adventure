from __future__ import annotations

import argparse
import json
from pathlib import Path

from sdk.event_match import EventMatchArchive


def main() -> int:
    ap=argparse.ArgumentParser(description='Melee SDK Phase 21 — GmEvent.dat / Duo Event tools')
    ap.add_argument('gmevent',help='Input GmEvent.dat')
    ap.add_argument('--report',action='store_true',help='Print a compact event table report')
    ap.add_argument('--export',help='Write full source-grounded JSON report')
    ap.add_argument('--event',type=lambda x:int(x,0),help='1-based Event Match number to edit')
    ap.add_argument('--stage-kind',type=lambda x:int(x,0))
    ap.add_argument('--time-limit',type=lambda x:int(x,0))
    ap.add_argument('--game-speed',type=float)
    ap.add_argument('--duo',action='store_true',help='Convert selected normal event into P1+P2 co-op')
    ap.add_argument('--p2-character',type=lambda x:int(x,0),help='Fixed CharacterKind for P2')
    ap.add_argument('--cpu-level',type=int,default=7)
    ap.add_argument('--stocks',type=int)
    ap.add_argument('--output',help='Output GmEvent.dat; required for edits unless --in-place')
    ap.add_argument('--in-place',action='store_true')
    args=ap.parse_args()

    src=Path(args.gmevent); arc=EventMatchArchive(src)
    if args.report:
        r=arc.report()
        print(f"{src.name}: {r['event_count']} events ({r['ordinary_events']} normal, {r['bonus_events']} bonus, {r['multiround_events']} multi-round)")
        for e in r['events']:
            ps=', '.join(f"P{p['pointer_index']+1}:{p['slot_type_name']}/C{p['character_kind']}" for p in e['players'][:4])
            print(f"{e['number']:02d} kind={e['kind']} stage={e['stage_kind']} time={e['time_limit']} players={e['player_count_field']} {ps}")
    if args.export:
        arc.export_json(args.export)
        print(f'Wrote {args.export}')

    editing=any(v is not None for v in (args.stage_kind,args.time_limit,args.game_speed)) or args.duo
    if editing:
        if args.event is None: ap.error('--event is required for edits')
        idx=args.event-1
        if any(v is not None for v in (args.stage_kind,args.time_limit,args.game_speed)):
            arc.set_rules(idx,stage_kind=args.stage_kind,time_limit=args.time_limit,game_speed=args.game_speed)
        if args.duo:
            if args.p2_character is None: ap.error('--p2-character is required with --duo')
            result=arc.make_duo_coop(idx,p2_character_kind=args.p2_character,cpu_level=args.cpu_level,stocks=args.stocks)
            print(json.dumps(result,indent=2))
        out=src if args.in_place else (Path(args.output) if args.output else None)
        if out is None: ap.error('edits require --output or --in-place')
        arc.save(out); print(f'Wrote {out}')
    return 0

if __name__=='__main__': raise SystemExit(main())
