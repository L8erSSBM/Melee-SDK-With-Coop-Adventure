# 0.20.21K20R — Stage Select crash and artwork fix

The Page 2 copy routine in Crashagain.sav had already selected the custom page but had not completed a toggle. Its expected SSVQ table was absent. The bytes at that address were unrelated texture/object data, which the unchecked routine treated as destination/source offsets and a copy length.

Slippi's GameFiles loader applies stock filename-specific .diff files to data read from the ISO. The installed Slippi has both MnSlMap.usd.diff and MnSlMap.dat.diff. The SDK now adds MnCoMap.usd and MnCoMap.dat to the disc and changes the two menu-load filename literals. Original stock-named disc archives remain unchanged. No user Slippi files or settings need editing.

Both language archives have their own original textures and replacement payloads, with a shared table location for the compact runtime. A signature/count check prevents copying from an absent or incompatible table. The complete SSS runtime is 0x4C0 bytes, within its existing budget; the original 16 KiB arena reservation remains unchanged.

Presentation:

- Page 1: right-aligned D-pad Down + PAGE 2.
- Page 2: left-aligned D-pad Up + DEFAULT.
- No Page 3 is currently enabled, so no misleading Page 3 legend is shown. The artwork preview includes the requested conditional two-legend design for a future real third page; this release does not add a third-page runtime.
- Caption: Special Mode / Coop Adventure, using the small-heading/large-italic-name hierarchy of retail stage captions.
- Included Adventure thumbnail and its matching palette load together on Page 2. Returning to Default restores the exact retail icon, palette, and caption bytes.
- Antialiasing alpha is baked into the native intensity textures so thin transparent edges do not become solid white.

Build with BUILD_MELEE_SDK.bat and a clean GALE01 v1.02 ISO. Both Direct peers must use this same rebuilt revision from a cold boot. Old savestates restore old executable code and menu data and are unsuitable for testing this fix.

Validation includes the actual emitted PPC and both disc archives, but a live connected Slippi test remains outstanding. Check Down, Up, repeated toggles, selection of Coop Adventure, and ordinary retail stage selection.

Reference for the filename-based replacement mechanism: https://github.com/project-slippi/Ishiiruka/blob/slippi/Source/Core/Core/Slippi/SlippiGameFileLoader.cpp
