from __future__ import annotations

import os
import tempfile
from pathlib import Path

from sdk.melee_dat import CommonFighterDAT
from sdk.workspace import MeleeProject

FIGHTER_DIR = Path(os.environ['MELEE_FIGHTER_DIR']) if os.environ.get('MELEE_FIGHTER_DIR') else None


def test_plco_airdodge_values_and_roundtrip():
    if not FIGHTER_DIR or not (FIGHTER_DIR / 'PlCo.dat').exists():
        return
    src = FIGHTER_DIR / 'PlCo.dat'
    c = CommonFighterDAT(src)
    a = c.attributes()
    assert abs(a['escapeair_deadzone_x']['value'] - 0.25) < 1e-6
    assert abs(a['escapeair_deadzone_y']['value'] - 0.25) < 1e-6
    assert a['escapeair_timer']['value'] == 3
    assert abs(a['escapeair_force']['value'] - 3.1) < 1e-5
    assert abs(a['escapeair_decay']['value'] - 0.9) < 1e-5

    original = src.read_bytes()
    c.set_attribute('escapeair_force', 3.5)
    assert abs(c.attributes()['escapeair_force']['value'] - 3.5) < 1e-6
    c.set_attribute('escapeair_force', 3.1)
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / 'PlCo.dat'
        c.save_as(out)
        # 3.1 as Python float serializes to the same f32 bit pattern as vanilla 3.0999999...
        assert out.read_bytes() == original


def test_workspace_builds_plco_change():
    if not FIGHTER_DIR or not (FIGHTER_DIR / 'PlCo.dat').exists():
        return
    with tempfile.TemporaryDirectory() as td:
        project = MeleeProject.create(FIGHTER_DIR, Path(td) / 'Project')
        common_path = project.working_common_path()
        assert common_path is not None
        c = CommonFighterDAT(common_path)
        c.set_attribute('escapeair_force', 3.5)
        project.save_common(c)
        changed_names = {x['filename'] for x in project.changed_files()}
        assert 'PlCo.dat' in changed_names
        result = project.build()
        built_names = {x['filename'] for x in result['modified_files']}
        assert 'PlCo.dat' in built_names
        assert (project.build_dir / 'PlCo.dat').exists()
        project.reset_common()
        assert 'PlCo.dat' not in {x['filename'] for x in project.changed_files()}


def test_plco_expanded_named_globals():
    if not FIGHTER_DIR or not (FIGHTER_DIR / 'PlCo.dat').exists():
        return
    a = CommonFighterDAT(FIGHTER_DIR / 'PlCo.dat').attributes()
    expected = {
        'horizontal_stick_deadzone': 0.28,
        'vertical_stick_deadzone': 0.28,
        'walk_stick_threshold': 0.18,
        'dash_smash_window': 2,
        'tap_jump_window': 4,
        'kb_squat_mul': 2/3,
        'start_shield_health': 60.0,
        'powershield_input_window': 2,
        'ledge_cooldown': 30,
        'sdi_min_stick_mag': 0.7,
        'sdi_stick_window': 4,
        'sdi_pos_scale': 6.0,
        'metal_armor': 30.0,
        'damageice_gravity_mult': 0.7,
        'kb_smashcharge_mul': 1.2,
    }
    for name, value in expected.items():
        got = a[name]['value']
        if isinstance(value, int):
            assert got == value
        else:
            assert abs(got - value) < 1e-5, (name, got, value)
