from pathlib import Path

from sdk import slippi_direct_gateway as dg
from tests.hf29d_ppc import execute, get, put, SENTINEL

R13 = 0x80400000
BASE = 0x804F9000
TRAMP = 0x804F8F00
STATE = 0x804F8000
PENDING = 0x804F7F00
P2VALID = 0x804F7F01
ARM = 0x804F8E00
CHANGE_MODE = dg.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE


def _run(marker: int, arm_result: int = 1):
    mem = {}
    put(mem, STATE + dg.S_BOOTSTRAP_PENDING, 1, 1)
    put(mem, STATE + dg.S_BOOTSTRAP_WAIT, 0, 1)
    put(mem, dg.GM_CURRENT_MODE_ADDR, dg.GM_ONLINE, 1)
    put(mem, dg.GM_SCENE_BYTE3_ADDR, dg.ONLINE_INGAME_BYTE3, 1)
    put(mem, dg.NETPLAY_READY_SITE, dg.NETPLAY_READY_WORD, 4)
    put(mem, dg.SLIPPI_ALT_MODE_STATIC, marker, 1)
    put(mem, dg.MAIN_HEAP_END_ADDR, 0x811DE400, 4)
    blob = dg.build_ingame_bootstrap_wrapper(
        BASE, TRAMP, state_addr=STATE, gateway_pending_addr=PENDING,
        p2_identity_valid_addr=P2VALID, netplay_arm_addr=ARM)

    def arm(regs, _mem):
        regs[3] = arm_result

    def change_mode(regs, _mem):
        # The real helper consumes r3=GM_ADVENTURE. Nothing else is needed for
        # this contract test.
        pass

    result = execute(blob, BASE, mem=mem, initial_regs={13: R13},
                     callees={ARM: arm, CHANGE_MODE: change_mode},
                     stop_targets={TRAMP})
    return result, mem


def test_k12_synchronized_adventure_marker_primes_future_heap_before_first_b0():
    r, mem = _run(dg.ADVENTURE_ALT_MARKER)
    assert r['target'] == TRAMP
    assert get(mem, dg.MAIN_HEAP_END_ADDR, 4) == dg.FULL_ROLLBACK_HEAP_END == 0x817FE000
    assert get(mem, dg.SLIPPI_ALT_MODE_STATIC, 1) == 0
    assert get(mem, PENDING, 1) == 1
    assert get(mem, STATE + dg.S_NETPLAY_ARM_RESULT, 1) == 1


def test_k12_ordinary_yoshi_carrier_never_expands_reported_heap():
    r, mem = _run(0)
    assert r['target'] == TRAMP
    assert get(mem, dg.MAIN_HEAP_END_ADDR, 4) == 0x811DE400
    assert get(mem, PENDING, 1) == 0
    assert get(mem, STATE + dg.S_TRACE, 1) == dg.TRACE_CARRIER_ORDINARY


def test_k12_prime_occurs_before_arm_helper_can_observe_heap_boundary():
    mem = {}
    put(mem, STATE + dg.S_BOOTSTRAP_PENDING, 1, 1)
    put(mem, dg.GM_CURRENT_MODE_ADDR, dg.GM_ONLINE, 1)
    put(mem, dg.GM_SCENE_BYTE3_ADDR, dg.ONLINE_INGAME_BYTE3, 1)
    put(mem, dg.NETPLAY_READY_SITE, dg.NETPLAY_READY_WORD, 4)
    put(mem, dg.SLIPPI_ALT_MODE_STATIC, dg.ADVENTURE_ALT_MARKER, 1)
    put(mem, dg.MAIN_HEAP_END_ADDR, 0x811DE400, 4)
    blob = dg.build_ingame_bootstrap_wrapper(
        BASE, TRAMP, state_addr=STATE, gateway_pending_addr=PENDING,
        p2_identity_valid_addr=P2VALID, netplay_arm_addr=ARM)
    observed = {}

    def arm(regs, memory):
        observed['heap_end'] = get(memory, dg.MAIN_HEAP_END_ADDR, 4)
        regs[3] = 1

    def change_mode(regs, memory):
        pass

    execute(blob, BASE, mem=mem, initial_regs={13: R13},
            callees={ARM: arm, CHANGE_MODE: change_mode}, stop_targets={TRAMP})
    assert observed['heap_end'] == dg.FULL_ROLLBACK_HEAP_END


def test_k12_source_no_longer_relies_on_selector_only_sss_heap_prime():
    root = Path(__file__).resolve().parents[1]
    sss = (root / 'sdk' / 'slippi_coop_stage_page.py').read_text(encoding='utf-8')
    # Constants remain for ABI/history tests, but the commit wrapper no longer
    # writes FULL_ROLLBACK_HEAP_END. The synchronized gateway owns that action.
    fn = sss[sss.index('def build_stage_commit_wrapper'):sss.index('def install', sss.index('def build_stage_commit_wrapper'))]
    assert 'FULL_ROLLBACK_HEAP_END' not in fn
    gateway = (root / 'sdk' / 'slippi_direct_gateway.py').read_text(encoding='utf-8')
    ingame = gateway[gateway.index('def build_ingame_bootstrap_wrapper'):gateway.index('def install', gateway.index('def build_ingame_bootstrap_wrapper'))]
    assert 'FULL_ROLLBACK_HEAP_END' in ingame
