"""HF29 retail Team-Kirby isolation and standalone warp tests."""
from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, encode_branch
from sdk import team_kirby_retail_warp as hf
from sdk import clear_screen_memory as hf22
from sdk import clear_screen_background_omit as hf29c

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804E2000
OLD = 0x804DF980
FLAG = 0x804E1C10
REQCNT = 0x804E1C14
APPLYCNT = 0x804E1C18
SENTINEL = 0x81234560


def put(mem, addr, value, size=4):
    raw = int(value & ((1 << (size * 8)) - 1)).to_bytes(size, 'big')
    for i, b in enumerate(raw):
        mem[addr + i] = b


def get(mem, addr, size=4):
    return int.from_bytes(bytes(mem.get(addr + i, 0) for i in range(size)), 'big')


def execute(blob, base, *, mem=None, lr=SENTINEL, r31=0, stop_targets=()):
    mem = {} if mem is None else mem
    regs = [0] * 32
    regs[1] = 0x817FF000
    regs[31] = r31
    cr = {2: False, 30: False}
    pc = base
    stop = set(stop_targets) | {SENTINEL}

    def s16(x):
        return x - 0x10000 if x & 0x8000 else x

    def signed32(x):
        return x - 0x100000000 if x & 0x80000000 else x

    for _ in range(3000):
        if pc in stop:
            return {'target': pc, 'mem': mem, 'regs': regs}
        if not base <= pc < base + len(blob):
            raise AssertionError(hex(pc))
        w = struct.unpack_from('>I', blob, pc - base)[0]
        op = w >> 26
        nxt = pc + 4
        rt = (w >> 21) & 31
        ra = (w >> 16) & 31
        imm = s16(w & 0xFFFF)
        if op == 14:  # addi
            regs[rt] = ((regs[ra] if ra else 0) + imm) & 0xFFFFFFFF
        elif op == 15:  # addis/lis
            regs[rt] = ((regs[ra] if ra else 0) + (imm << 16)) & 0xFFFFFFFF
        elif op == 32:  # lwz
            regs[rt] = get(mem, (regs[ra] + imm) & 0xFFFFFFFF, 4)
        elif op == 34:  # lbz
            regs[rt] = get(mem, (regs[ra] + imm) & 0xFFFFFFFF, 1)
        elif op == 36:  # stw
            put(mem, (regs[ra] + imm) & 0xFFFFFFFF, regs[rt], 4)
        elif op == 37:  # stwu
            ea = (regs[ra] + imm) & 0xFFFFFFFF
            put(mem, ea, regs[rt], 4)
            regs[ra] = ea
        elif op == 38:  # stb
            put(mem, (regs[ra] + imm) & 0xFFFFFFFF, regs[rt], 1)
        elif op == 28:  # andi.
            regs[ra] = regs[rt] & (w & 0xFFFF)
            cr[2] = (regs[ra] == 0)
        elif op == 11:  # cmpwi
            cr[30] = (signed32(regs[ra]) == imm)
        elif op == 16:  # bc
            bd = w & 0xFFFC
            if bd & 0x8000:
                bd -= 0x10000
            bo, bi = (w >> 21) & 31, (w >> 16) & 31
            bit = cr.get(bi, False)
            take = bo == 20 or (bo == 12 and bit) or (bo == 4 and not bit)
            if take:
                nxt = (pc + bd) & 0xFFFFFFFF
        elif op == 18:  # b/bl
            info = decode_branch(pc, w.to_bytes(4, 'big'))
            if info['link']:
                lr = (pc + 4) & 0xFFFFFFFF
            nxt = info['target']
        elif w == 0x4E800020:  # blr
            nxt = lr
        else:
            raise AssertionError(f'unsupported {w:08x} @ {pc:08x}')
        pc = nxt
    raise AssertionError('wrapper did not terminate')


def shortcut_run(*, state=1, trigger=0, button=0, pad=0):
    blob = hf.shortcut_wrapper(
        BASE,
        old_shortcut_addr=OLD,
        warp_flag_addr=FLAG,
        request_counter_addr=REQCNT,
    )
    mem = {}
    put(mem, hf.ADVENTURE_MODE_ADDR, hf.GM_ADVENTURE, 1)
    put(mem, hf.ADVENTURE_STATE_ADDR, state, 1)
    p = hf.HSD_PAD_COPY_STATUS + hf.PAD_STATUS_STRIDE * pad
    put(mem, p + hf.PAD_BUTTON_OFF, button)
    put(mem, p + hf.PAD_TRIGGER_OFF, trigger)
    return execute(blob, BASE, mem=mem, stop_targets=(OLD + 4,))


def test_left_warps_without_touching_team_kirby_fight():
    r = shortcut_run(
        state=1,
        button=hf.PAD_BUTTON_L,
        trigger=hf.PAD_BUTTON_DLEFT,
    )
    assert r['target'] == SENTINEL
    assert get(r['mem'], FLAG, 1) == 1
    assert get(r['mem'], REQCNT) == 1
    assert get(r['mem'], hf.VS_MATCH_RESULT_ADDR, 1) == hf.MATCH_OUTCOME_1P_STAGE_END
    assert get(r['mem'], hf.VS_TERMINATE_MATCH_ADDR, 1) == 1


def test_left_is_noop_once_team_kirby_is_active():
    r = shortcut_run(
        state=hf.TEAM_KIRBY_FIGHT_STATE,
        button=hf.PAD_BUTTON_L,
        trigger=hf.PAD_BUTTON_DLEFT,
    )
    assert r['target'] == SENTINEL
    assert get(r['mem'], FLAG, 1) == 0
    assert get(r['mem'], hf.VS_TERMINATE_MATCH_ADDR, 1) == 0


def test_other_shortcuts_fall_through_to_original_pre_hf26_helper():
    initial_sp = 0x817FF000
    r = shortcut_run(state=1, button=hf.PAD_BUTTON_L, trigger=0x0002)
    assert r['target'] == OLD + 4
    # The displaced original stwu r1,-0x20(r1) has been replayed exactly once.
    assert r['regs'][1] == initial_sp - 0x20
    assert get(r['mem'], FLAG, 1) == 0


def test_routing_hook_applies_only_the_pending_test_route():
    base = BASE + 0x400
    blob = hf.routing_wrapper(
        base,
        warp_flag_addr=FLAG,
        applied_counter_addr=APPLYCNT,
    )
    mem = {}
    put(mem, FLAG, 1, 1)
    put(mem, hf.ADVENTURE_NEXT_STATE_ADDR, 0x03, 1)
    put(mem, hf.ADVENTURE_STATE_ADDR, 0x01, 1)
    r = execute(
        blob,
        base,
        mem=mem,
        r31=0x80479D30,
        stop_targets=(hf.ROUTING_RETURN,),
    )
    assert r['target'] == hf.ROUTING_RETURN
    assert get(mem, FLAG, 1) == 0
    assert get(mem, hf.ADVENTURE_NEXT_STATE_ADDR, 1) == 0x24
    assert get(mem, APPLYCNT) == 1
    assert r['regs'][0] == 0x01


def test_packaged_dol_is_hf29_plus_only_minimal_results_background_omit(tmp_path):
    # Historical HF29C containment; current HF29D has a separate delta test.
    start = ROOT / 'Build' / 'historical' / 'HF29C.dol'
    manifest = json.loads((ROOT / 'Build' / 'HF29C_runtime_manifest.json').read_text())
    raw = bytearray(start.read_bytes())
    d = DOLImage(raw)

    # HF29C removes the HF22-HF28 stack entirely. One new hook omits only
    # the optional captured background on the verified Icies terminal path.
    assert b'HF29CBGO' in raw
    assert b'HF29TKRW' in raw
    for marker in (
        b'HF22CLEAR', b'HF23FXMG', b'HF24CLSK', b'HF25ECLR',
        b'HF26TKFC', b'HF27TKWP', b'HF28TKFF',
    ):
        assert marker not in raw

    assert manifest['clear_screen_memory'] is None
    assert manifest['clear_screen_background_omit'] is not None
    for key in (
        'effect_memory_protection', 'clear_screen_failsafe',
        'early_clear_failsafe', 'team_kirby_force_clear', 'team_kirby_test_warp',
        'team_kirby_fast_forward',
    ):
        assert manifest[key] is None

    # Optional-effect guards stay retail, and HF22 copy/draw hooks are gone.
    m23 = json.loads((ROOT / 'Build' / 'HF23_runtime_manifest.json').read_text())
    for row in m23['effect_memory_protection']['hooks']:
        assert d.read_at_address(row['site_address'], 4) == bytes.fromhex(row['expected'])
    assert d.read_at_address(hf22.COPY_SITE, 4) == encode_branch(hf22.COPY_SITE, hf22.COPY_RETAIL, link=True)
    assert d.read_at_address(hf22.DRAW_SITE, 4) == encode_branch(hf22.DRAW_SITE, hf22.DRAW_RETAIL, link=True)

    guard = manifest['clear_screen_background_omit']
    assert decode_branch(hf29c.ALLOC_SITE, d.read_at_address(hf29c.ALLOC_SITE, 4))['target'] == guard['stub_address']

    warp = manifest['team_kirby_retail_warp']
    assert decode_branch(OLD, d.read_at_address(OLD, 4))['target'] == warp['shortcut_stub']
    assert decode_branch(hf.ROUTING_HOOK, d.read_at_address(hf.ROUTING_HOOK, 4))['target'] == warp['routing_stub']

    # Remove HF29C and restore the retail allocation call: exact shipped HF29.
    marker_off = raw.find(b'HF29CBGO')
    assert marker_off > 0
    sec = next(s for s in d.sections if s.kind == 'data' and s.index == 8)
    baseline_size = marker_off - sec.file_offset - guard['section']['padding']
    off = d.file_offset_for_address(hf29c.ALLOC_SITE, 4)
    raw[off:off + 4] = encode_branch(hf29c.ALLOC_SITE, hf29c.ALLOC_RETAIL, link=True)
    struct.pack_into('>I', raw, 0xAC + 8 * 4, baseline_size)
    del raw[sec.file_offset + baseline_size:]

    meta = manifest['hf29c_results_headroom']
    assert hashlib.sha1(raw).hexdigest() == meta['base_sha1']
    assert hashlib.sha256(raw).hexdigest() == meta['base_sha256']

    rebuilt = DOLImage(raw)
    result = hf29c.install(rebuilt, 8, manifest['probe_section']['address'] + 0x2F)
    out = tmp_path / 'hf29c.dol'
    rebuilt.save_as(out)
    assert result['marker'] == 'HF29CBGO'
    assert out.read_bytes() == start.read_bytes()


def test_packaged_falco_wrapper_uses_character_kind_ids():
    """HF29 fixes the Phase43 FtKind/CKind namespace mix-up in Corneria."""
    from sdk import adventure_probe as a
    start = ROOT / 'Build' / 'start.dol'
    manifest = json.loads((ROOT / 'Build' / 'SDK023_runtime_manifest.json').read_text())
    d = DOLImage(bytearray(start.read_bytes()))
    row = next(x for x in manifest['hooks'] if x['name'] == 'falco_cpu_substitution')
    expected = a._falco_cpu_substitution_wrapper(row['stub_address'])
    got = d.read_at_address(row['stub_address'], len(expected))
    assert got == expected
    assert a.CKIND_FOX == 0x02
    assert a.CKIND_FALCO == 0x14
    assert bytes.fromhex('2f8b0014') in got
    assert got.count(bytes.fromhex('2f8b0002')) == 2
    assert bytes.fromhex('39600014') in got
