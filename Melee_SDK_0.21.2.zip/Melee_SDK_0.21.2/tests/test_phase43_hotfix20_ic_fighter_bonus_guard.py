import struct
from pathlib import Path

import sdk.adventure_probe as ap
from sdk.ppc import decode_branch


def _branch_targets(blob: bytes, base: int):
    out=[]
    for off in range(0, len(blob)-3, 4):
        word=struct.unpack_from('>I', blob, off)[0]
        if word >> 26 != 18:
            continue
        try:
            info=decode_branch(base+off, blob[off:off+4])
        except ValueError:
            continue
        out.append((off, info))
    return out


def _final_blob():
    return ap._team_kirby_final_wave_wrapper(
        0x80410000, 0x8040F000,
        p1_ckind_addr=0x8040002A,
        p2_ckind_addr=0x80400026,
        icies_teardown_guard_addr=0x8040002F,
        icies_diag_addr=0x80400032,
        icies_wave_armed_addr=0x80400033,
    )


def _bonus_blob():
    return ap._team_kirby_bonus_guard_wrapper(
        0x80411000, 0x80410F00,
        p1_ckind_addr=0x8040002A,
        p2_ckind_addr=0x80400026,
        icies_teardown_guard_addr=0x8040002F,
        icies_diag_addr=0x80400032,
    )


def test_hf20_hooks_exact_fn_80039618_entry():
    assert ap.FN_BONUS_FIGHTER_HOOK == 0x80039618
    assert ap.FN_BONUS_FIGHTER_EXPECTED == bytes.fromhex('7c0802a6')
    assert not hasattr(ap, 'PL_BONUS_EVAL_HOOK')


def test_terminal_wrapper_remains_observation_only():
    targets=[x[1]['target'] for x in _branch_targets(_final_blob(), 0x80410000) if x[1]['link']]
    assert targets.count(ap.EVENT_ENEMY_IS_ACTIVE) >= 2
    assert targets.count(ap.EVENT_ENEMY_IS_COMPLETE) == 1
    assert ap.PLAYER_GET_ENTITY not in targets
    assert ap.PLAYER_MATCH_END_HOOK not in targets
    assert ap.PLAYER_DESTROY_ENTITIES not in targets
    assert ap.PLAYER_CLEAR_ENTITY_REF not in targets


def test_terminal_completion_false_guard_is_beq():
    base=0x80410000
    blob=_final_blob()
    call_off=None
    for off, info in _branch_targets(blob, base):
        if info['link'] and info['target'] == ap.EVENT_ENEMY_IS_COMPLETE:
            call_off=off
            break
    assert call_off is not None
    assert struct.unpack_from('>I', blob, call_off+4)[0] == 0x2F830000  # cmpwi cr7,r3,0
    bc=struct.unpack_from('>I', blob, call_off+8)[0]
    assert bc >> 26 == 16
    assert ((bc >> 21) & 31) == 12
    assert ((bc >> 16) & 31) == 30


def test_fighter_bonus_guard_checks_entity_once_and_never_cleans_up():
    targets=[x[1]['target'] for x in _branch_targets(_bonus_blob(), 0x80411000) if x[1]['link']]
    assert targets.count(ap.PLAYER_GET_ENTITY) == 1
    assert ap.PLAYER_MATCH_END_HOOK not in targets
    assert ap.PLAYER_DESTROY_ENTITIES not in targets
    assert ap.PLAYER_CLEAR_ENTITY_REF not in targets


def test_fighter_bonus_guard_nonnull_entity_runs_retail():
    base=0x80411000
    blob=_bonus_blob()
    call_off=None
    for off, info in _branch_targets(blob, base):
        if info['link'] and info['target'] == ap.PLAYER_GET_ENTITY:
            call_off=off
            break
    assert call_off is not None
    assert struct.unpack_from('>I', blob, call_off+4)[0] == 0x2F830000
    bc=struct.unpack_from('>I', blob, call_off+8)[0]
    assert bc >> 26 == 16
    assert ((bc >> 21) & 31) == 4   # bne -> retail when entity != NULL
    assert ((bc >> 16) & 31) == 30


def test_fighter_bonus_guard_covers_all_physical_slots_not_only_event_slots():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _team_kirby_bonus_guard_wrapper'):src.index('def _teardown_trace_wrapper')]
    assert 'Valid player slots 0..5' in fn
    assert 'cmpwi(3,0,crf=7)' in fn
    assert 'cmpwi(3,5,crf=7)' in fn
    assert 'b_retail_lt0' in fn and 'bi=28' in fn
    assert 'b_retail_gt5' in fn and 'bi=29' in fn
    assert 'event slots 2..5' not in fn


def test_fighter_bonus_guard_is_terminal_team_kirby_icies_only():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _team_kirby_bonus_guard_wrapper'):src.index('def _teardown_trace_wrapper')]
    assert 'GM_CURRENT_STATE_ADDR' in fn
    assert 'TEAM_KIRBY_FIGHT_STATE' in fn
    assert 'icies_teardown_guard_addr' in fn
    assert fn.count('CKIND_POPO_NANA') >= 2


def test_null_owner_skips_only_fn_80039618_and_marks_d_slot():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _team_kirby_bonus_guard_wrapper'):src.index('def _teardown_trace_wrapper')]
    assert 'return from fn_80039618' in fn
    assert 'caller continues with fn_8003B044' in fn
    assert 'addi(11,3,0xD0)' in fn
    assert 'blr()' in fn
    assert 'StaticPlayer' in fn and 'MatchEnd' in fn


def test_hf20_marker_and_diagnostics():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert "payload[0x34:0x38]=b'KTDG'" in src  # HF21 supersedes the package marker
    assert 'C0 active' in src and 'C1 terminal' in src
    assert 'D0..D5' in src


def test_hf20_installs_fn_guard_with_expected_byte_check():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert "(FN_BONUS_FIGHTER_HOOK,FN_BONUS_FIGHTER_EXPECTED,'team_kirby_fighter_bonus_boundary')" in src
    assert 'dol.patch_at_address(FN_BONUS_FIGHTER_HOOK,bonus_branch,expected=FN_BONUS_FIGHTER_EXPECTED)' in src
    assert 'FN_BONUS_FIGHTER_HOOK+4' in src


def test_hf20_bonus_dummy_and_final_layout_are_guarded():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert 'dummy_bonus_tramp' in src and 'dummy_bonus' in src
    assert 'len(dummy_bonus_tramp) != len(bonus_trampoline)' in src
    assert 'len(dummy_bonus) != len(bonus_wrapper)' in src
    assert 'Adventure payload blob overlap:' in src


def test_hf20_current_finalwave_has_no_forced_match_end_calls():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    final=src[src.index('def _team_kirby_final_wave_wrapper'):src.index('def _team_kirby_bonus_guard_wrapper')]
    assert 'PLAYER_MATCH_END_HOOK' not in final
    assert 'PLAYER_DESTROY_ENTITIES' not in final
    assert 'PLAYER_CLEAR_ENTITY_REF' not in final
    assert 'observation/arming only' in final


def test_hf20_retail_manager_runs_before_terminal_observation():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    final=src[src.index('def _team_kirby_final_wave_wrapper'):src.index('def _team_kirby_bonus_guard_wrapper')]
    assert final.index('trampoline_addr,link=True') < final.index('EVENT_ENEMY_IS_ACTIVE')


def test_hf20_preserves_outer_pl_80039450_pipeline():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert 'FN_BONUS_FIGHTER_HOOK = 0x80039618' in src
    assert 'PL_BONUS_EVAL_HOOK =' not in src
    fn=src[src.index('def _team_kirby_bonus_guard_wrapper'):src.index('def _teardown_trace_wrapper')]
    assert 'Preserve pl_80039450 and all later bonus/stat routines' in fn
