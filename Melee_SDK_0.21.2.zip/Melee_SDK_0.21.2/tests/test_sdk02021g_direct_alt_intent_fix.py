from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk import slippi_coop_stage_page as sp
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]
R13 = 0x80400000
BASE = 0x804F7000
TRAMP = 0x804F6F00
STATE = 0x804F6C00


ALT_BLOCK = 0x80667000
ALT_BYTE = sp.SLIPPI_ALT_MODE_STATIC


def _run(*, page: int, external_id: int = 8, retail_stkind: int = 0x08):
    mem = {}
    put(mem, STATE + sp.S_PAGE, page, 1)
    put(mem, sp.SLIPPI_ALT_MODE_HOOK,
        int.from_bytes(sp.encode_branch(sp.SLIPPI_ALT_MODE_HOOK, ALT_BLOCK), 'big'), 4)
    put(mem, ALT_BYTE, 0, 1)
    put(mem, sp.MAIN_HEAP_END_ADDR, 0x811DE400, 4)
    blob = sp.build_stage_commit_wrapper(BASE, TRAMP, state_addr=STATE)

    def retail(regs, _mem):
        # Model the exact six-instruction retail external-ID -> StKind helper.
        regs[3] = retail_stkind

    result = execute(blob, BASE, mem=mem, initial_regs={3: external_id, 13: R13},
                     callees={TRAMP: retail})
    return result, mem


def test_custom_direct_page_sends_legal_carrier_plus_alt_intent_marker():
    r, mem = _run(page=1, external_id=8, retail_stkind=0x08)
    assert r['regs'][3] == sp.DIRECT_CARRIER_STKIND == 0x08
    assert get(mem, ALT_BYTE, 1) == sp.ADVENTURE_ALT_MARKER == 0xA5
    assert get(mem, STATE + sp.S_TX_TRACE, 1) == sp.TX_TRACE_ALT_INTENT
    assert get(mem, sp.MAIN_HEAP_END_ADDR, 4) == 0x811DE400  # K12 primes only in the two-peer HUD-init path
    # One-shot scoping prevents the global retail helper from retagging later calls.
    assert get(mem, STATE + sp.S_PAGE, 1) == 0


def test_normal_direct_yoshis_story_remains_yoshis_story():
    r, mem = _run(page=0, external_id=8, retail_stkind=0x08)
    assert r['regs'][3] == 0x08
    assert get(mem, STATE + sp.S_TX_TRACE, 1) == 0


def test_normal_other_stage_remains_retail_value():
    r, _ = _run(page=0, external_id=3, retail_stkind=0x02)
    assert r['regs'][3] == 0x02


def test_override_is_one_shot_even_if_mapper_is_called_again():
    first, mem = _run(page=1, retail_stkind=0x08)
    assert first['regs'][3] == 0x08
    assert get(mem, ALT_BYTE, 1) == 0xA5
    # Re-run against the same state: S_PAGE was consumed, so retail wins and
    # the marker is not rewritten by the global mapper hook.
    put(mem, ALT_BYTE, 0, 1)
    blob = sp.build_stage_commit_wrapper(BASE, TRAMP, state_addr=STATE)
    def retail(regs, _mem): regs[3] = 0x02
    second = execute(blob, BASE, mem=mem, initial_regs={3:8,13:R13}, callees={TRAMP:retail})
    assert second['regs'][3] == 0x02
    assert get(mem, ALT_BYTE, 1) == 0


def test_installer_hooks_exact_retail_external_to_stkind_mapper_and_stays_compact():
    dol = DOLImage((ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    assert dol.read_at_address(sp.STAGE_COMMIT_HOOK, len(sp.STAGE_COMMIT_FUNCTION_EXPECTED)) == sp.STAGE_COMMIT_FUNCTION_EXPECTED
    row = sp.install(dol, 8)
    assert row['stage_commit_hook'] == 0x8025BC08
    assert dol.read_at_address(sp.STAGE_COMMIT_HOOK, 4) != sp.STAGE_COMMIT_EXPECTED
    assert row['coop_intent_stkind'] is None  # K3 never mutates retail StKind
    assert row['adventure_alt_marker'] == 0xA5
    assert row['direct_carrier_stkind'] == 0x08
    assert row['section']['size'] <= 0x400  # K11 ABI-safe LR frame adds one 0x20-aligned block
