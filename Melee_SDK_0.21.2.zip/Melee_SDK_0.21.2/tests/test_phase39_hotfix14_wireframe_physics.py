from pathlib import Path

from sdk.adventure_probe import (
    WIRE_FRAME_FIGHT_STATE,
    WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK,
    _wireframe_human_physics_guard,
)


def test_wireframe_fix_targets_player_physics_property_not_classifier():
    assert WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK == 0x80034B0C
    assert WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK != 0x801693BC
    assert WIRE_FRAME_FIGHT_STATE == 0x51


def test_wireframe_physics_guard_is_bounded_ppc_stub():
    blob = _wireframe_human_physics_guard(0x80412000, 0x80412100)
    assert len(blob) % 4 == 0
    assert 0 < len(blob) < 0x80


def test_runtime_manifest_names_physics_modifier_guard():
    text = (Path(__file__).resolve().parents[1] / 'sdk' / 'adventure_probe.py').read_text()
    assert 'wireframe_human_physics_modifier_guard' in text
    assert "ProbeHook('wireframe_human_role_guard'" not in text
