from pathlib import Path

import sdk.sss_visual_qol as q
from sdk import slippi_coop_stage_page as sp

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'/'sss_qol'


def test_k20l_contextual_footer_assets_are_separate_and_lowered():
    down=q._load_png_rgba(ASSETS/'sss_nav_default_down.png')
    up=q._load_png_rgba(ASSETS/'sss_nav_page2_up.png')
    assert down.size==(232,16)
    assert up.size==(232,16)
    # K20L deliberately lowers both prompts by one pixel to avoid top-edge clipping.
    def bounds(im):
        pts=[(i%im.width,i//im.width) for i,p in enumerate(im.pixels) if p[3]>64]
        xs=[p[0] for p in pts];ys=[p[1] for p in pts]
        return min(xs),min(ys),max(xs),max(ys)
    assert bounds(down)[1] >= 4 and bounds(down)[3] == 15
    assert bounds(up)[1] >= 4 and bounds(up)[3] == 15
    assert down.pixels != up.pixels


def test_k20i_title_fits_stock_stage_name_surface():
    title=q._load_png_rgba(ASSETS/'coop_adventure_title_only.png')
    assert title.size==(224,56)
    pts=[(i%title.width,i//title.width) for i,p in enumerate(title.pixels) if p[3]>64]
    assert pts
    assert min(x for x,_ in pts)>=0
    assert max(x for x,_ in pts)<224
    assert max(y for _,y in pts)<56


def test_k20i_icon_encoder_is_crop_to_fill_not_letterbox():
    src=q._load_png_rgba(ASSETS/'coop_adventure_icon_source.png')
    fitted=q._fit_asset(src,48,48,contain=False)
    assert fitted.size==(48,48)
    # Corner rows are image content, not transparent/black letterbox bands.
    top=sum(1 for x in range(48) if max(fitted.pixels[x][:3])>16)
    bottom=sum(1 for x in range(48) if max(fitted.pixels[(47*48)+x][:3])>16)
    assert top>40 and bottom>40


def test_k20i_table_driven_visual_renderer_stays_compact():
    blob=sp.build_render_page(0x804F0000,state_addr=0x804EF000,
        visual_models_offset=0x10,visual_table_offset=0x9DBEC,visual_record_count=4)
    assert len(blob) <= 0x200
