from sdk import slippi_coop_stage_page as sp
from tests.hf29d_ppc import execute, put, get

BASE=0x804F7000
TRAMP=0x804F6F00
STATE=0x804F6C00


def test_default_sss_commit_tail_calls_retail_without_custom_stack_frame():
    mem={}
    put(mem,STATE+sp.S_PAGE,0,1)
    seen=[]
    def retail(regs,_mem):
        seen.append(regs[1])
        regs[3]=0x12
    blob=sp.build_stage_commit_wrapper(BASE,TRAMP,state_addr=STATE)
    start_sp=0x817FEF00
    r=execute(blob,BASE,mem=mem,initial_regs={1:start_sp,3:7},callees={TRAMP:retail})
    assert seen==[start_sp]
    assert r['regs'][1]==start_sp
    assert r['regs'][3]==0x12
    assert get(mem,STATE+sp.S_TX_TRACE,1)==0
    assert get(mem,sp.SLIPPI_ALT_MODE_STATIC,1)==0


def test_custom_sss_commit_uses_private_frame_and_emits_carrier():
    mem={}
    put(mem,STATE+sp.S_PAGE,1,1)
    put(mem,STATE+sp.S_SAVED,0,1)  # no descriptor loop needed for this ABI test
    seen=[]
    def retail(regs,_mem):
        seen.append(regs[1])
        regs[3]=0x1D
    blob=sp.build_stage_commit_wrapper(BASE,TRAMP,state_addr=STATE,
                                       descriptor_restore_addr=0x804F6E00)
    # Model the descriptor helper as a normal ABI leaf.
    def restore(_regs,_mem):
        return
    start_sp=0x817FEF00
    r=execute(blob,BASE,mem=mem,initial_regs={1:start_sp,3:27},
              callees={TRAMP:retail,0x804F6E00:restore})
    assert seen==[start_sp-0x20]
    assert r['regs'][1]==start_sp
    assert r['regs'][3]==sp.DIRECT_CARRIER_STKIND
    assert get(mem,STATE+sp.S_TX_TRACE,1)==sp.TX_TRACE_ALT_INTENT
    assert get(mem,sp.SLIPPI_ALT_MODE_STATIC,1)==sp.ADVENTURE_ALT_MARKER


def test_renderer_never_emits_k20o_synthetic_x9_or_cursor29_sequences():
    base=0x804F0000
    blob=sp.build_render_page(base,state_addr=base,
                              visual_models_offset=0x10,
                              visual_table_offset=0x98000,
                              visual_record_count=2)
    # K20O generated x9 = 27 + 2*page using mulli r9,r28,2.
    assert sp._ppc_mulli(9,28,2) not in blob
    # K20O also wrote cursor row 29 as a one-frame refresh sentinel.
    synthetic_cursor=sp.li(10,29)+sp.stb(10,0,11)
    assert synthetic_cursor not in blob
    # K20P explicitly repairs slot 27 x9 and cursor back to valid row 27.
    assert sp.li(9,sp.COOP_TILE_SLOT)+sp.stb(9,0,10) in blob
    assert sp.li(10,sp.COOP_TILE_SLOT)+sp.stb(10,0,11) in blob


def test_two_visual_records_still_fit_k20n_4c0_runtime_budget():
    base=0x804F0000; state=base; cursor=base+sp.STATE_SIZE
    def add(fn,align=4):
        nonlocal cursor
        cursor=(cursor+align-1)&~(align-1); a=cursor; cursor+=len(fn(a)); return a
    et=add(lambda a:sp.PROLOGUE_EXPECTED+sp.encode_branch(a+4,sp.ONENTER_HOOK+4))
    ft=add(lambda a:sp.PROLOGUE_EXPECTED+sp.encode_branch(a+4,sp.ONFRAME_HOOK+4))
    ct=add(lambda a:sp.STAGE_COMMIT_EXPECTED+sp.encode_branch(a+4,sp.STAGE_COMMIT_HOOK+4))
    rd=add(lambda a:sp.build_render_page(a,state_addr=state,canonical_valid_addr=base+0x1000,
                                         visual_models_offset=0x10,visual_table_offset=0x98000,
                                         visual_record_count=2))
    dr=add(lambda a:sp.build_restore_descriptor_leaf(a,state_addr=state))
    cap=add(lambda a:sp.build_capture_canonical(a,canonical_valid_addr=base+0x1000,
                                                 canonical_local_addr=base+0x1001,
                                                 canonical_remote_addr=base+0x1002,
                                                 canonical_trace_addr=base+0x1003))
    add(lambda a:sp.build_enter_wrapper(a,et,state_addr=state,descriptor_restore_addr=dr))
    add(lambda a:sp.build_frame_wrapper(a,ft,state_addr=state,render_addr=rd))
    add(lambda a:sp.build_stage_commit_wrapper(a,ct,state_addr=state,
                                                descriptor_restore_addr=dr,capture_addr=cap))
    assert ((cursor-base+31)&~31) <= 0x4C0
