from __future__ import annotations
import json
from pathlib import Path
from sdk.dol_patch import DOLImage
from sdk import clear_screen_background_omit as bgo
from sdk import team_kirby_pool_packing as pool
from sdk.ppc import decode_branch

ROOT = Path(__file__).resolve().parents[1]


def test_current_dol_has_pool_packing_and_broad_coop_results_gate():
    d = DOLImage(ROOT / 'Build' / 'start.dol')
    m = json.loads((ROOT / 'Build' / 'SDK023_runtime_manifest.json').read_text())
    g = m['clear_screen_background_omit']
    probe_base = m['probe_section']['address']
    persistence_valid = probe_base + 0x21
    icies_guard = probe_base + 0x2F

    assert b'HF29DSLP' in (ROOT / 'Build' / 'start.dol').read_bytes()
    # HF29G now puts a gateway-scope dispatch in front of the unchanged HF29D
    # pool handler. Verify the old handler remains the active downstream target.
    hf29g = json.loads((ROOT / 'Build' / 'SDK023_runtime_manifest.json').read_text())
    guards = {x['site_address']: x for x in hf29g['adventure_gateway_scope']['guarded_hooks']}
    pool_guard = guards[pool.SITE]
    assert pool_guard['hf29f_branch'] == m['team_kirby_pool_packing']['site_branch']
    assert pool_guard['hf29f_target'] == m['team_kirby_pool_packing']['stub_address']
    sdk020 = json.loads((ROOT / 'Build' / 'SDK023_runtime_manifest.json').read_text())
    front = {x['site_address']: x for x in sdk020['slippi_boot_hardening']['mode_first_guards']}
    assert front[pool.SITE]['hf29g_guard_stub'] == pool_guard['guard_stub']
    assert front[pool.SITE]['hf29ef_active_target'] == m['team_kirby_pool_packing']['stub_address']
    assert decode_branch(pool.SITE, d.read_at_address(pool.SITE, 4))['target'] == front[pool.SITE]['mode_first_guard']

    expected = bgo.wrapper(g['stub_address'], persistence_valid, g['skip_counter'])
    actual = d.read_at_address(g['stub_address'], len(expected))
    assert actual == expected
    assert actual != bgo.wrapper(g['stub_address'], icies_guard, g['skip_counter'])


def test_astra_hf29d_binary_delta_is_only_two_gate_bytes():
    old = (ROOT / 'Build' / 'historical' / 'HF29D_POOL_PACKING.dol').read_bytes()
    # Freeze the HF29D -> HF29E containment assertion against the archived
    # HF29E binary so later hotfix payloads can append safely.
    new = (ROOT / 'Build' / 'historical' / 'HF29E.dol').read_bytes()
    assert len(old) == len(new)
    diff = [i for i, (a, b) in enumerate(zip(old, new)) if a != b]
    assert len(diff) == 1
    # Both bytes are the low immediate of the existing address-load instruction.
    assert new[diff[0]] == 0x81


def test_evidence_matches_expected_double_sheik_results_pressure():
    e = json.loads((ROOT / 'HF29D_DOUBLE_SHEIK_RESULTS_EVIDENCE.json').read_text())
    assert e['runtime']['hf29d_slist_marker'] is True
    assert e['runtime']['slist_hook_word'] == '0x48165b25'
    assert e['runtime']['mode'] == 4
    assert e['runtime']['adventure_state'] == '0x23'
    assert e['runtime']['coop_campaign_valid'] == 1
    assert e['runtime']['icies_terminal_guard'] == 0
    assert e['runtime']['background_skip_counter'] == 0
    assert e['heap']['largest_free_cell'] == 201888
    assert e['heap']['free_bytes'] == 349152
    assert e['slist_pool']['free'] == 3566
    assert 0x80180A0C in {int(x['return_address'], 16) for x in e['relevant_stack']}
