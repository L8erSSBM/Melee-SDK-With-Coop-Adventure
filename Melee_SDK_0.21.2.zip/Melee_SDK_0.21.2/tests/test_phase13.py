from pathlib import Path
import tempfile

from sdk.melee_dat import FighterDAT
from sdk.gamecube_iso import GameCubeISO, fresh_rebuild, quick_update
from tests.test_gamecube_iso import make_fake_iso

FIX = Path('/mnt/data/fighters_extract/Melee_Fighters')


def test_control_flow_decoder_reads_pointer_word_and_relocation():
    f = FighterDAT(FIX / 'PlPk.dat')
    wait = f.animations[2]
    evs = f.parse_script(wait)
    sub = next(e for e in evs if e['opcode'] == 5)
    assert len(sub['words']) == 2
    assert sub['pointer_target'] == 0x3518
    assert sub['pointer_relocated'] is True
    assert sub['pointer_location'] in f.archive.relocations


def test_goto_root_is_two_words_and_execution_reaches_target():
    f = FighterDAT(FIX / 'PlPk.dat')
    goto_wait = f.animations[6]
    root = f.parse_script(goto_wait)
    assert len(root) == 1
    assert root[0]['opcode'] == 7
    assert root[0]['pointer_target'] == f.animations[2].script_offset
    trace = f.trace_script_execution(goto_wait, max_steps=1000)
    assert trace[0]['opcode'] == 7
    assert trace[-1]['opcode'] == 0
    assert trace[-1]['frame'] == 401.0


def test_graph_assembler_noop_is_byte_identical_with_subroutines():
    original = (FIX / 'PlPk.dat').read_bytes()
    f = FighterDAT(FIX / 'PlPk.dat')
    model = f.script_editor_model(f.animations[2])
    result = f.replace_script_graph(f.animations[2], model)
    assert result['control_flow_relocations'] == 7
    assert bytes(f.archive.raw) == original


def test_graph_assembler_can_resize_control_flow_script_and_retarget_incoming_goto():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'PlPk.dat'
        p.write_bytes((FIX / 'PlPk.dat').read_bytes())
        f = FighterDAT(p)
        target = f.animations[2]
        goto_action = f.animations[6]
        old_goto_offset = goto_action.script_offset
        # Insert before End into a script containing seven Subroutine commands.
        result = f.insert_event(target, len(f.script_editor_model(target)) - 1, f.make_timer_words(1, 3))
        assert result['script_delta'] == 4
        assert f.trace_script_execution(f.animations[target.index], max_steps=1000)[-1]['frame'] == 404.0
        # The action table moved, but its Goto target still points to the edited root start.
        new_goto = f.parse_script(f.animations[goto_action.index])[0]
        assert f.animations[goto_action.index].script_offset == old_goto_offset + 4
        assert new_goto['pointer_target'] == f.animations[target.index].script_offset
        assert new_goto['pointer_relocated'] is True


def test_loop_execution_matches_decompiled_repeat_semantics():
    f = FighterDAT(FIX / 'PlPk.dat')
    move = f.animations[69]  # AttackAirF: Set Loop 4 around a 3+1 frame cycle
    root = f.parse_script(move)
    assert any(e['opcode'] == 3 and (e['words'][0] & 0x03FFFFFF) == 4 for e in root)
    trace = f.trace_script_execution(move, max_steps=1000)
    # The loop body Spawn Hitboxes execute four times.
    hits = [e for e in trace if e['opcode'] == 11]
    assert len(hits) == 8
    assert trace[-1]['opcode'] == 0
    assert trace[-1]['frame'] == 40.0


def test_fresh_rebuild_auto_repacks_resized_resource(tmp_path):
    clean = tmp_path / 'clean.iso'; out = tmp_path / 'out.iso'; build = tmp_path / 'Build'; build.mkdir()
    make_fake_iso(clean, b'ABCD')
    (build / 'PlFx.dat').write_bytes(b'RESIZED-PAYLOAD')
    result = fresh_rebuild(clean, out, build, verify_hash=False)
    assert result['mode'] == 'repack_rebuild'
    iso = GameCubeISO(out)
    ent = iso.find_file('PlFx.dat')
    assert ent.size == len(b'RESIZED-PAYLOAD')
    assert iso.read_file(ent) == b'RESIZED-PAYLOAD'


def test_quick_update_rebuilds_when_repacked_layout_needs_restore(tmp_path):
    clean = tmp_path / 'clean.iso'; out = tmp_path / 'out.iso'; build = tmp_path / 'Build'; build.mkdir()
    make_fake_iso(clean, b'ABCD')
    (build / 'PlFx.dat').write_bytes(b'LONGER THAN FOUR')
    first = quick_update(clean, out, build, verify_hash=False)
    assert first['mode'] == 'repack_rebuild'
    (build / 'PlFx.dat').unlink()
    second = quick_update(clean, out, build, verify_hash=False)
    assert second['mode'] == 'fresh_rebuild'
    iso = GameCubeISO(out)
    assert iso.read_file(iso.find_file('PlFx.dat')) == b'ABCD'


def test_null_goto_is_valid_non_relocated_terminator():
    f = FighterDAT(FIX / 'PlPc.dat')
    move = f.animations[207]  # FuraSleepLoop
    root = f.parse_script(move)
    assert root[-1]['opcode'] == 7
    assert root[-1]['pointer_target'] == 0
    assert root[-1]['pointer_relocated'] is False
    cfg = f.analyze_script_control_flow(move)
    assert cfg['gotos'] == 1


def test_loop_graph_noop_is_byte_identical():
    original = (FIX / 'PlPk.dat').read_bytes()
    f = FighterDAT(FIX / 'PlPk.dat')
    move = f.animations[69]
    model = f.script_editor_model(move)
    f.replace_script_graph(move, model)
    assert bytes(f.archive.raw) == original


def test_repacker_shifts_following_files_and_updates_each_fst_entry(tmp_path):
    # Two-file synthetic image proving resized file A moves file B while both
    # remain readable through the rewritten FST.
    iso_path = tmp_path / 'two.iso'
    size = 0x9000
    data = bytearray(size); data[:6] = b'GALE01'
    fst_off = 0x1000; dol_off = 0x2000
    data[0x420:0x424] = dol_off.to_bytes(4,'big'); data[0x424:0x428] = fst_off.to_bytes(4,'big')
    dol = bytearray(0x104); dol[0:4]=(0x100).to_bytes(4,'big'); dol[0x90:0x94]=(4).to_bytes(4,'big'); dol[0x100:0x104]=b'DOL!'
    data[dol_off:dol_off+len(dol)] = dol
    strings=b'A.dat\0B.dat\0'
    fst=bytearray()
    fst += (0x01000000).to_bytes(4,'big') + (0).to_bytes(4,'big') + (3).to_bytes(4,'big')
    fst += (0).to_bytes(4,'big') + (0x5000).to_bytes(4,'big') + (4).to_bytes(4,'big')
    fst += (6).to_bytes(4,'big') + (0x6000).to_bytes(4,'big') + (5).to_bytes(4,'big')
    fst += strings
    data[0x428:0x42c] = len(fst).to_bytes(4,'big'); data[fst_off:fst_off+len(fst)] = fst
    data[0x5000:0x5004]=b'AAAA'; data[0x6000:0x6005]=b'BBBBB'; iso_path.write_bytes(data)
    repl=tmp_path/'A.dat'; repl.write_bytes(b'A'*0x180)
    out=tmp_path/'out.iso'
    result=GameCubeISO(iso_path).repack_files(out, {'A.dat': repl})
    check=GameCubeISO(out); a=check.find_file('A.dat'); b=check.find_file('B.dat')
    assert check.read_file(a)==b'A'*0x180
    assert check.read_file(b)==b'BBBBB'
    assert b.offset > a.offset + a.size - 1
    assert result['files_repacked']==2


def test_internal_goto_uses_symbolic_label_after_resize():
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'PlPk.dat'; p.write_bytes((FIX / 'PlPk.dat').read_bytes())
        f = FighterDAT(p); move = f.animations[7]  # WalkSlow cycles back to root start
        model = f.script_editor_model(move)
        goto = model[-1]
        assert (goto['words'][0] >> 26) == 7
        assert goto['target_label'] == model[0]['label']
        # Insert a timer after the root's first command. The Goto must continue
        # targeting the symbolic first event, not a stale byte offset.
        f.insert_event(move, 1, f.make_timer_words(1, 1))
        edited = f.script_editor_model(f.animations[move.index])
        assert edited[-1]['target_label'] == edited[0]['label']
        assert edited[-1]['target'] == edited[0]['source_offset']


def test_full_move_clone_duplicates_script_and_animation_with_destination_symbol(tmp_path):
    from sdk.melee_dat import analyze_figatree_archive
    f = FighterDAT(FIX / 'PlCa.dat')
    source = next(a for a in f.animations if a.action_name == 'SpecialN')
    target = next(a for a in f.animations if a.action_name == 'SpecialAirN')
    aj = (FIX / 'PlCaAJ.dat').read_bytes()
    source_ops = [e['opcode'] for e in f.parse_script(source)]
    new_aj, result = f.clone_full_move(source, target, aj)
    edited = f.animations[target.index]
    assert [e['opcode'] for e in f.parse_script(edited)] == source_ops
    assert edited.anim_archive_offset >= len(aj)
    assert len(new_aj) > len(aj)
    info = analyze_figatree_archive(new_aj[edited.anim_archive_offset:edited.anim_archive_offset + edited.anim_archive_size])
    assert info['symbol'] == edited.symbol
    assert info['frames'] == 100.0
    ajp = tmp_path / 'PlCaAJ.dat'; ajp.write_bytes(new_aj)
    validation = f.validate_animation_archive(ajp)
    assert validation['errors'] == []
    assert result['aj_size_delta'] > 0
