from pathlib import Path
import inspect

from sdk import adventure_gateway_scope as scope
from sdk import adventure_probe
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]


def _run_onload(*, pending_value: int, active_value: int, origin_value: int, prev_mode: int):
    base = 0x804F2000
    pending = 0x804F0C00
    active = 0x804F0C10
    origin = active + 1
    downstream = 0x80123454
    blob = scope._onload_capture_wrapper(
        base, pending_addr=pending, active_addr=active,
        old_target=downstream, origin_addr=origin)
    mem = {}
    put(mem, pending, pending_value, 1)
    put(mem, active, active_value, 1)
    put(mem, origin, origin_value, 1)
    put(mem, scope.PREVIOUS_MODE, prev_mode, 1)
    result = execute(blob, base, mem=mem, stop_targets=(downstream,))
    return result, get(mem, active, 1), get(mem, origin, 1)


def test_02011_branding_and_manifest_format():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    build = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    gui = (ROOT / 'melee_sdk.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.18'" in src
    assert "'format':'melee-character-sdk-0.20.18-slippi-adventure-netplay-bridge'" in src
    assert 'MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in build
    assert '_MeleeSDK_0.20.18.iso' in build
    assert '0.20.18 — Slippi Adventure Netplay Bridge' in gui


def test_fresh_gateway_launch_captures_launcher_origin():
    result, active, origin = _run_onload(
        pending_value=1, active_value=0, origin_value=0, prev_mode=2)
    assert result['target'] == 0x80123454
    assert active == 1
    assert origin == 2


def test_staffroll_adventure_reentry_preserves_active_campaign_and_original_origin():
    # This is the 0.20.10 runtime bug: Staff Roll returns to Adventure with the
    # one-shot gateway_pending already cleared and prev_mode now describing the
    # GOver/credits lifecycle.  We must preserve the original launcher origin.
    result, active, origin = _run_onload(
        pending_value=0,
        active_value=1,
        origin_value=2,
        prev_mode=scope.GM_ADVENTURE_GOVER,
    )
    assert result['target'] == 0x80123454
    assert active == 1
    assert origin == 2


def test_inactive_non_gateway_adventure_still_clears_stale_origin():
    _, active, origin = _run_onload(
        pending_value=0, active_value=0, origin_value=2, prev_mode=9)
    assert active == 0
    assert origin == 0


def test_completion_still_uses_retail_staffroll_then_guarded_final_adventure_exit():
    installer = inspect.getsource(adventure_probe.install_phase30_coop_spawn_probe)
    assert 'requires guarded GOver completion bridge' in installer
    assert 'requires captured-origin completion wrapper' in installer
    assert 'state 0x68' in installer


def test_02011_legacy_credits_wrapper_remains_available_after_02014():
    src = inspect.getsource(adventure_probe._staffroll_dual_pad_wrapper)
    assert 'Retail only owns one cursor' in src
    readme = (ROOT / 'README.md').read_text(encoding='utf-8')
    assert 'P2-local pass' in readme or "P2's clone" in readme
    assert 'independent' in readme.lower()
