from types import SimpleNamespace

from melee_sdk import MeleeSDK


class FakeRow:
    def __init__(self, value):
        self._value = value
        self.last_set = None

    def parsed_value(self):
        return self._value

    def set_value(self, value):
        self.last_set = value
        self._value = value


class FakeFighter:
    def __init__(self):
        self.values = {
            'walk_accel_mul': 0.2,
            'walk_accel_base': 0.1,
        }

    def common_attributes(self):
        return {k: {'value': v} for k, v in self.values.items()}

    def set_common_attribute(self, name, value):
        self.values[name] = float(value)


def test_apply_group_commits_multiple_pending_values_together():
    sdk = MeleeSDK.__new__(MeleeSDK)
    sdk.fighter = FakeFighter()
    sdk.attr_rows = {
        'walk_accel_mul': FakeRow(0.35),
        'walk_accel_base': FakeRow(0.15),
    }
    sdk.dirty = False

    assert sdk.apply_attr_group('Ground Movement', announce=False)
    assert sdk.fighter.values['walk_accel_mul'] == 0.35
    assert sdk.fighter.values['walk_accel_base'] == 0.15
    assert sdk.dirty is True


def test_value_match_ignores_float32_display_noise():
    assert MeleeSDK._value_matches(0.20000000298023224, 0.2, 'float')
    assert not MeleeSDK._value_matches(0.2, 0.25, 'float')
