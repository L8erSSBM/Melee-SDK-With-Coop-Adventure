"""Execute the preserved Falco wrapper for both selections and human/CPU layouts."""
import pytest
from sdk import adventure_probe as a
from hf29d_ppc import execute, put
@pytest.mark.parametrize('selection', [0x02, 0x14])
@pytest.mark.parametrize('cpus', [(0x02, 0xFF), (0xFF, 0x02), (0x02, 0x02), (0x01, 0x16)])
@pytest.mark.parametrize('humans', [(0x0E, 0x09), (0x09, 0x0E), (0x0E, 0x0E), (0x14, 0x02)])
def test_falco_execution(selection, cpus, humans):
    base, scene, data, adventure = 0x804DFFA0, 0x81000000, 0x81001000, 0x81002000
    mem = {}
    put(mem, scene + 0x10, data)
    put(mem, adventure + 0x7C, selection, 1)
    for slot, kind in enumerate(humans + cpus):
        for offset in range(a.PLAYER_INIT_SIZE):
            put(mem, data + 0x60 + slot*a.PLAYER_INIT_SIZE + offset, (offset + slot*37) & 255, 1)
        put(mem, data + 0x60 + slot*a.PLAYER_INIT_SIZE, kind, 1)
    before = dict(mem)
    calls = []
    def setup(regs, memory):
        assert regs[3] == scene
        calls.append('setup')
        for r in range(3, 13): regs[r] = 0xDEAD0000+r
    def get_adventure(regs, memory):
        calls.append('adventure')
        for r in range(3, 13): regs[r] = 0xDEAD0000+r
        regs[3] = adventure
    result = execute(a._falco_cpu_substitution_wrapper(base), base, mem=mem,
                     initial_regs={3:scene}, callees={a.ADVENTURE_COMMON_VS_SETUP:setup, a.GM_GET_ADVENTURE_DATA:get_adventure})
    expected = dict(before)
    if selection == 0x14 and 0x02 in cpus:
        put(expected, data+0x60+(2+cpus.index(0x02))*a.PLAYER_INIT_SIZE, 0x14, 1)
    for addr in before: assert mem[addr] == expected[addr]
    assert result['regs'][1] == 0x817FF000
    assert calls == ['setup', 'adventure']

