"""Execute the emitted PPC wrappers, including hostile volatile-register callees."""
import struct

import pytest

from sdk import clear_screen_memory as cm
from sdk.ppc import decode_branch, encode_branch


BASE, GUARD, STOP = 0x804E4000, 0x804DEC8F, 0x80001000


def execute(blob, args, *, mode=4, state=0x23, guard=1, width=320, height=240,
            scale=(1.0, 1.0), clear_result=None):
    regs = [0] * 32; regs[1] = 0x81700000
    for i, value in enumerate(args, 3): regs[i] = value
    floats = [0.0] * 32; floats[1:5] = [7.0, 9.0, *scale]
    memory = {}
    def write(a, v, size):
        for i, b in enumerate(v.to_bytes(size, 'big')): memory[a+i] = b
    def read(a, size):
        return int.from_bytes(bytes(memory.get(a+i, 0) for i in range(size)), 'big')
    write(0x80479D30, mode, 1); write(0x80479D33, state, 1); write(GUARD, guard, 1)
    write(cm.IMAGE_DESC, 0x81000000, 4)
    write(cm.IMAGE_DESC+4, width, 2); write(cm.IMAGE_DESC+6, height, 2)
    pc, lr, equal = BASE, STOP, False
    calls = []
    def signed(v): return v-65536 if v & 0x8000 else v
    for _ in range(250):
        if pc == STOP: return calls, regs, floats
        if not BASE <= pc < BASE+len(blob):
            calls.append((pc, tuple(regs[3:8]), tuple(floats[1:5])))
            result = clear_result if clear_result is not None else 0x81234560
            for r in [0, *range(3, 13)]: regs[r] = 0xD00D0000+r
            regs[3] = result
            pc = lr
            continue
        word = struct.unpack_from('>I', blob, pc-BASE)[0]
        op, rt, ra, rb = word>>26, (word>>21)&31, (word>>16)&31, (word>>11)&31
        imm = signed(word & 0xFFFF); nxt = pc+4
        if op in (14, 15):
            regs[rt] = ((regs[ra] if ra else 0) + (imm << 16 if op == 15 else imm)) & 0xFFFFFFFF
        elif op in (32, 34, 40):
            regs[rt] = read((regs[ra]+imm)&0xFFFFFFFF, {32:4, 34:1, 40:2}[op])
        elif op in (36, 37):
            addr = (regs[ra]+imm)&0xFFFFFFFF; write(addr, regs[rt], 4)
            if op == 37: regs[ra] = addr
        elif op == 11: equal = regs[ra] == imm
        elif op == 16:
            displacement = signed(word & 0xFFFC)
            bo = (word>>21)&31
            if (bo == 4 and not equal) or (bo == 12 and equal): nxt = pc+displacement
        elif op == 18:
            decoded = decode_branch(pc, word.to_bytes(4, 'big'))
            if decoded['link']: lr = pc+4
            nxt = decoded['target']
        elif op == 31:
            xo = (word>>1)&1023
            if xo == 0: equal = regs[ra] == regs[rb]
            elif xo == 339: regs[rt] = lr
            elif xo == 467: lr = regs[rt]
            else: raise AssertionError(hex(word))
        elif word == 0x4E800020: nxt = lr
        elif op == 59 and (word>>1)&31 == 21: floats[rt] = floats[ra]+floats[rb]
        else: raise AssertionError(f'unsupported instruction {word:08x}')
        pc = nxt
    raise AssertionError('wrapper did not return')


def test_terminal_allocation_uses_quarter_storage_and_returns_retail_result():
    calls, regs, _ = execute(cm.allocation_wrapper(BASE, GUARD), [cm.IMAGE_DESC,640,480,5,0])
    assert calls[0][:2] == (cm.ALLOC_RETAIL, (cm.IMAGE_DESC,320,240,5,0))
    assert len(calls) == 1 and regs[3] == 0x81234560


@pytest.mark.parametrize('overrides', [{'mode':2}, {'guard':0}, {'guard':2}, {'state':0x28}])
def test_other_modes_states_and_unarmed_terminal_keep_retail_dimensions(overrides):
    calls, _, _ = execute(cm.allocation_wrapper(BASE, GUARD), [cm.IMAGE_DESC,640,480,5,0], **overrides)
    assert calls[0][1] == (cm.IMAGE_DESC,640,480,5,0)


@pytest.mark.parametrize('args', [[cm.IMAGE_DESC,320,240,5,0], [cm.IMAGE_DESC,640,480,4,0],
                                  [cm.IMAGE_DESC,640,480,5,1]])
def test_unexpected_allocation_arguments_are_forwarded(args):
    calls, _, _ = execute(cm.allocation_wrapper(BASE, GUARD), args)
    assert calls[0][1] == tuple(args)


@pytest.mark.parametrize('clear', [0,1])
def test_capture_downsamples_entire_efb_and_preserves_clear_and_stack(clear):
    calls, regs, _ = execute(cm.copy_wrapper(BASE), [cm.IMAGE_DESC,0,0,clear])
    assert calls[0][:2] == (cm.COPY_SRC, (0,0,640,480,0))
    assert calls[1][0] == cm.COPY_DST and calls[1][1][:4] == (320,240,5,1)
    addresses = [x[0] for x in calls]
    assert addresses == [cm.COPY_SRC, cm.COPY_DST] + ([cm.ZMODE] if clear else []) + [cm.COPY_TEX,cm.PIX_SYNC,cm.INVALIDATE]
    capture = next(x for x in calls if x[0] == cm.COPY_TEX)
    assert capture[1][:2] == (0x81000000,clear)
    assert regs[1] == 0x81700000


@pytest.mark.parametrize('wrapper,target', [(cm.copy_wrapper,cm.COPY_RETAIL), (cm.draw_wrapper,cm.DRAW_RETAIL)])
@pytest.mark.parametrize('descriptor,width,height', [(cm.IMAGE_DESC,640,480), (cm.IMAGE_DESC,320,480), (0x81000000,320,240)])
def test_other_images_keep_retail_capture_and_scale(wrapper,target,descriptor,width,height):
    calls, _, _ = execute(wrapper(BASE), [descriptor,0,0,1], width=width, height=height)
    assert len(calls) == 1 and calls[0][0] == target
    assert calls[0][1][:4] == (descriptor,0,0,1)
    assert calls[0][2] == (7.0,9.0,1.0,1.0)


def test_display_doubles_only_scale_for_fullscreen_coverage():
    calls, _, _ = execute(cm.draw_wrapper(BASE), [cm.IMAGE_DESC,0,2,50], scale=(1.0,1.0), guard=0)
    assert calls[0][2] == (7.0,9.0,2.0,2.0)
    assert 320*calls[0][2][2] == 640 and 240*calls[0][2][3] == 480


@pytest.mark.parametrize('largest,total', [(236992,370240),(302208,449280),(211104,349280),(176928,323680)])
def test_new_buffer_fits_every_captured_heap_with_room_for_clear_ui(largest,total):
    required = (cm.BUFFER_BYTES+32+31)&~31
    assert required == 153632
    assert largest >= required and total-required >= 170048
    assert largest < 614432 and total < 614432


def test_installer_refuses_wrong_call_before_mutating():
    class WrongDOL:
        def read_at_address(self, addr, size):
            if addr == cm.ALLOC_SITE: return encode_branch(addr,cm.ALLOC_RETAIL,link=True)
            return bytes(4)
    with pytest.raises(ValueError, match='expected-byte guard'):
        cm.install(WrongDOL(), 0, GUARD)
