from pathlib import Path
from sdk import slippi_coop_stage_page as sp
from sdk.sss_visual_qol import patch_mnslmap_bytes, _public_root, _iter_matanim_tables
from sdk.melee_dat import HSDArchive


def test_k20n_page_runtime_budget_matches_final_16k_headroom():
    base=0x804F0000; state=base
    rec={'target_data':0x50000,'default_data':0x90000,'coop_data':0x90740,'size':0x740,'kind':'footer'}
    cursor=base+sp.STATE_SIZE
    def add(fn,align=4):
        nonlocal cursor
        cursor=(cursor+align-1)&~(align-1); a=cursor; cursor+=len(fn(a)); return a
    et=add(lambda a:sp.PROLOGUE_EXPECTED+sp.encode_branch(a+4,sp.ONENTER_HOOK+4))
    ft=add(lambda a:sp.PROLOGUE_EXPECTED+sp.encode_branch(a+4,sp.ONFRAME_HOOK+4))
    ct=add(lambda a:sp.STAGE_COMMIT_EXPECTED+sp.encode_branch(a+4,sp.STAGE_COMMIT_HOOK+4))
    rd=add(lambda a:sp.build_render_page(a,state_addr=state,canonical_valid_addr=base+0x1000,visual_models_offset=0x10,footer_record=rec))
    dr=add(lambda a:sp.build_restore_descriptor_leaf(a,state_addr=state))
    cap=add(lambda a:sp.build_capture_canonical(a,canonical_valid_addr=base+0x1000,canonical_local_addr=base+0x1001,canonical_remote_addr=base+0x1002,canonical_trace_addr=base+0x1003))
    add(lambda a:sp.build_enter_wrapper(a,et,state_addr=state,descriptor_restore_addr=dr))
    add(lambda a:sp.build_frame_wrapper(a,ft,state_addr=state,render_addr=rd))
    add(lambda a:sp.build_stage_commit_wrapper(a,ct,state_addr=state,descriptor_restore_addr=dr,capture_addr=cap))
    assert ((cursor-base+31)&~31)==0x440


def test_k20n_row_x9_contract():
    assert sp.ROW_X9 == 0x09
    assert sp.COOP_TILE_SLOT == 27
