from pathlib import Path

from sdk.adventure_probe import (
    ADVENTURE_PRESENTATION_STATES,
    CPU_SLOT2_INIT_OFFSET,
    CPU_SLOT3_INIT_OFFSET,
    WIRE_FRAME_FIGHT_STATE,
    _adventure_presentation_start_wrapper,
    _luigi_cpu_substitution_wrapper,
    _wireframe_human_physics_guard,
)


def test_hotfix14_wireframe_physics_guard_is_small_and_scene_specific():
    blob = _wireframe_human_physics_guard(0x80410000, 0x80410100)
    assert len(blob) % 4 == 0
    assert WIRE_FRAME_FIGHT_STATE == 0x51
    assert len(blob) < 0x80


def test_hotfix13_presentation_states_exclude_vs_and_results_behavior():
    # Wireframe VS must never be affected by the presentation START mirror.
    assert 0x51 not in ADVENTURE_PRESENTATION_STATES
    # Known intro/cutscene states are explicitly enumerated rather than using a
    # broad Adventure controller remap.
    assert 0x00 in ADVENTURE_PRESENTATION_STATES
    assert 0x02 in ADVENTURE_PRESENTATION_STATES
    assert 0x50 in ADVENTURE_PRESENTATION_STATES
    assert 0x52 in ADVENTURE_PRESENTATION_STATES
    blob = _adventure_presentation_start_wrapper(0x80410200, 0x80410300)
    assert len(blob) % 4 == 0
    assert len(blob) < 0x200


def test_hotfix13_luigi_substitution_never_targets_human_init_slots():
    assert CPU_SLOT2_INIT_OFFSET == 0xA8
    assert CPU_SLOT3_INIT_OFFSET == 0xCC
    blob = _luigi_cpu_substitution_wrapper(0x80410400)
    assert len(blob) % 4 == 0
    assert len(blob) < 0x100


def test_hotfix13_normal_build_bat_still_requests_hotfix8_runtime_features():
    root = Path(__file__).resolve().parents[1]
    text = (root / 'Regression Builds' / 'BUILD_COOP_CHAOS_REVIVE_TEST.bat').read_text(errors='replace')
    assert '--variant coop_chaos' in text
    assert '--scene-revive' in text
    assert '--test-shortcuts' in text
    assert 'wireframe-callback-bypass' not in text
    assert 'legacy-shared-pad' not in text
