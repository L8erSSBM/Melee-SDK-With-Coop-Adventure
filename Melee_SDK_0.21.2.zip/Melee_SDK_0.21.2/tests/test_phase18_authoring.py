from PIL import Image

from sdk.stage_assets import encode_gx_texture, texture_level_size


def test_phase18_gx_texture_encoders_have_exact_layout_sizes():
    im=Image.new('RGBA',(16,16),(120,80,40,255))
    for fmt in (0,1,2,3,4,5,6,14):
        raw=encode_gx_texture(im,fmt)
        assert len(raw)==texture_level_size(16,16,fmt)


def test_phase18_cmpr_encoder_handles_transparency():
    im=Image.new('RGBA',(8,8),(255,0,0,255))
    for y in range(4):
        for x in range(4): im.putpixel((x,y),(0,0,0,0))
    raw=encode_gx_texture(im,14)
    assert len(raw)==32
    assert raw != bytes(32)
