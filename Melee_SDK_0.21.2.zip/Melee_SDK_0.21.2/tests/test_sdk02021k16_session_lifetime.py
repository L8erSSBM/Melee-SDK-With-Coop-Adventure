"""K16 regression: execute native lifecycle and input decision instructions.

These capture-based tests reproduce K15's game-over latch, and verify its repair.
They do not emulate a connected Dolphin host or replace a two-device smoke test.
"""
import json
from pathlib import Path
import pytest
from sdk import slippi_adventure_netplay_bridge as nb
from sdk import slippi_engine_repair as er
from sdk.ppc import encode_branch
from tests.hf29d_ppc import execute,put,get
from tests.test_sdk02021k15_engine_repair import run,BASE,STATE

FIXTURE=json.loads((Path(__file__).parent/'fixtures'/'slippi_k16_native_lifecycle.json').read_text())
R13=0x804DB6A0

def code(name,override=None):
    item=FIXTURE['regions'][name];base=item['address'];blob=bytearray.fromhex(item['hex'])
    for site,word in (override or {}).items():
        if base<=site<base+len(blob):blob[site-base:site-base+4]=word
    return base,bytes(blob)

def overrides():return er.patches(STATE,BASE,BASE+0x100,BASE+0x200,nb)

def run_exit(mem,scene,patch):
    put(mem,0x80479D30,scene);put(mem,R13+nb.OFST_R13_ODB_ADDR,nb.STABLE_ODB)
    base,blob=code('report_exit',patch)
    return execute(blob,base,mem=mem,initial_regs={13:R13},stop_targets={0x806664D4,er.REPORT_EXIT_CONTINUE})

@pytest.mark.parametrize('scene',[0x08000802,0x04040801,0x04040823])
def test_k15_native_no_contest_hook_reproduces_stopped_prediction(scene):
    mem={}
    r=run_exit(mem,scene,{er.REPORT_EXIT_GATE:bytes.fromhex('60000000')})
    assert r['target']==0x806664D4
    assert get(mem,nb.STABLE_ODB+0xF,1)==1
    for name,expected in [('skip_stall',0x80666E84),('prediction',0x806672D0)]:
        base,blob=code(name)
        r=execute(blob,base,mem=mem,initial_regs={27:nb.STABLE_ODB},stop_targets={0x80666E84,0x80666E5C,0x80667220,0x806672D0})
        assert r['target']==expected

@pytest.mark.parametrize('scene',[0x08000802,0x04040801,0x04040823])
def test_k16_carrier_and_chapter_exit_keep_native_stall_and_prediction(scene):
    mem={}
    r=run_exit(mem,scene,overrides())
    assert r['target']==er.REPORT_EXIT_CONTINUE
    assert get(mem,nb.STABLE_ODB+0xF,1)==0
    for name,expected in [('skip_stall',0x80666E5C),('prediction',0x80667220)]:
        base,blob=code(name)
        r=execute(blob,base,mem=mem,initial_regs={27:nb.STABLE_ODB},stop_targets={0x80666E84,0x80666E5C,0x80667220,0x806672D0})
        assert r['target']==expected

@pytest.mark.parametrize('scene,ended',[(0x08000802,1),(0x04040801,0)])
def test_restored_retail_exit_only_ends_normal_online_match(scene,ended):
    mem={};run_exit(mem,scene,{})
    assert get(mem,nb.STABLE_ODB+0xF,1)==ended

@pytest.mark.parametrize('patched',[False,True])
def test_native_engine_completion_does_not_end_campaign_transport(patched):
    mem={};put(mem,0x8046B6A8,2,1);put(mem,nb.STABLE_ODB+0xB,100)
    base,blob=code('game_end',overrides() if patched else {})
    r=execute(blob,base,mem=mem,initial_regs={30:nb.STABLE_ODB,31:108},stop_targets={0x80666C00,er.GAME_END_CONTINUE})
    assert get(mem,nb.STABLE_ODB+0xF,1)==(0 if patched else 1)
    assert r['target']==(er.GAME_END_CONTINUE if patched else 0x80666C00)

def test_guard_policy_enables_only_audited_engine_input_sound_rumble_paths():
    enabled={g.name for g in nb.ACTIVE_GUARDS}
    assert len(enabled)==14
    assert {'init_client_pause','prevent_pause_stranding'} <= enabled  # K19 paired pause repair
    assert {'report_no_contest_lras','lgl_game_end_message','customize_lras_message','teams_prevent_dead_stranding'}.isdisjoint(enabled)
    table=nb.build_patch_table(guard_shims=overrides(),exi_wrapper_addr=BASE)
    rows={int.from_bytes(table[i:i+4],'big'):table[i+8:i+12] for i in range(0,len(table),12)}
    assert rows[er.REPORT_EXIT_GATE]==encode_branch(er.REPORT_EXIT_GATE,er.REPORT_EXIT_CONTINUE)
    assert rows[er.GAME_END_CHECK]==encode_branch(er.GAME_END_CHECK,er.GAME_END_CONTINUE)
    assert rows[0x80665D10]==bytes.fromhex('60000000') # K19 keeps client pause bookkeeping paired.
    assert rows[0x80666C58]==bytes.fromhex('60000000') # Remote input hook still enabled.

def test_frame_requested_by_native_loader_exists_after_scene_timer_reset():
    # Match the supplied frozen request, but capture under the input timeline.
    mem={};put(mem,nb.STABLE_ODB+3,4081);put(mem,0x804C1F7B,1,1)
    put(mem,nb.GLOBAL_FRAME_ADDR,4122)
    run(er.batch,mem,{4:4080,5:nb.STABLE_ODB,27:1},stop_targets={er.BATCH_SITE+4})
    r=run(er.start,mem,{26:0,30:nb.STABLE_ODB},stop_targets={0x806667CC})
    frame=r['regs'][31];assert frame==4080
    put(mem,nb.STABLE_SSCB,1,1);put(mem,nb.STABLE_SSCB+2,frame)
    base,blob=code('native_ring')
    r=execute(blob,base,mem=mem,initial_regs={24:4080,26:nb.STABLE_SSCB},stop_targets={0x8066DFC8,0x8066E0C8})
    assert r['target']==0x8066E0C8
    assert get(mem,nb.GLOBAL_FRAME_ADDR)==4122

def native_input_step(mem, local, remote_latest=200, game_over=0, frame=200, remote_pad=None):
    # Emulate EXI and memcpy only; input mapping and prediction run captured PPC.
    odb=nb.STABLE_ODB;parent=0x804D0000;sp=parent-0x100
    put(mem,sp,parent)
    put(mem,R13+nb.OFST_R13_ODB_ADDR,odb)
    put(mem,odb+0,local,1);put(mem,odb+1,1-local,1);put(mem,odb+2,0,1)
    put(mem,odb+3,frame);put(mem,odb+0xF,game_over,1);put(mem,odb+0x21,2,1)
    put(mem,odb+nb.ODB_TXB_ADDR,nb.STABLE_TXB);put(mem,odb+nb.ODB_RXB_ADDR,nb.STABLE_RXB)
    put(mem,odb+nb.ODB_SSRB_ADDR,nb.STABLE_SSRB)
    own=bytes.fromhex('010050000000000000000000')
    remote_pad=remote_pad or bytes.fromhex('0200b0000000000000000000')
    for i,b in enumerate(own):mem[parent+0x2C+i]=b
    sent=[]
    def memcpy(regs,mem):
        data=[mem.get(regs[4]+i,0) for i in range(regs[5])]
        for i,b in enumerate(data):mem[regs[3]+i]=b
    def exi(regs,mem):
        if regs[5]==1:
            sent.append(bytes(mem.get(regs[3]+14+i,0) for i in range(12)))
        else:
            rx=regs[3];put(mem,rx,1,1);put(mem,rx+1,1,1)
            # Other non-participating slots report current frame, as the host does.
            for i in range(3):put(mem,rx+0x1A+4*i,remote_latest if i==0 else frame)
            for history in range(7):
                for i,b in enumerate(remote_pad):mem[rx+0x2A+12*history+i]=b
    base,blob=code('trigger_inputs')
    result=execute(blob,base,mem=mem,initial_regs={1:sp,13:R13},callees={0x800031F4:memcpy,0x800055F0:exi},stop_targets={0x806673AC,0x80376CEC})
    assert result['target'] in (0x806673AC,0x80376CEC)
    assert sent==[own] # Each peer's physical port 1 reaches its outgoing packet.
    if result['target']==0x80376CEC:
        assert get(mem,odb+0xDF,1)==1 # Correction queues replay instead of consuming a new raw input.
        return mem
    applied=bytes(mem.get(parent+0x2C+(1-local)*12+i,0) for i in range(12))
    assert applied==remote_pad
    assert get(mem,odb+3)==frame+1
    return mem

@pytest.mark.parametrize('local',[0,1])
def test_native_connected_remote_movement_maps_to_the_other_logical_player(local):
    mem=native_input_step({},local)
    assert get(mem,nb.STABLE_ODB+0x38C,1)==0
    assert get(mem,nb.STABLE_ODB+0xADA)==200

@pytest.mark.parametrize('local',[0,1])
@pytest.mark.parametrize('game_over',[0,1])
def test_native_delayed_remote_input_requests_snapshot_only_for_live_session(local,game_over):
    mem=native_input_step({},local,remote_latest=199,game_over=game_over)
    assert get(mem,nb.STABLE_ODB+0x38C,1)==1-game_over
    assert get(mem,nb.STABLE_ODB+0x38D)==(200 if not game_over else 0)


@pytest.mark.parametrize('local',[0,1])
def test_native_late_movement_requests_the_correct_pre_prediction_frame(local):
    mem=native_input_step({},local,remote_latest=199,frame=200,remote_pad=bytes(12))
    assert get(mem,nb.STABLE_ODB+0x38D)==200
    mem=native_input_step(mem,local,remote_latest=201,frame=201)
    assert get(mem,nb.STABLE_ODB+0xDF,1)==1
    assert get(mem,nb.STABLE_ODB+0xE0,1)==1
    assert get(mem,nb.STABLE_ODB+0x38D)==200
    assert get(mem,nb.STABLE_ODB+0xE1)==201

def test_installed_cleanup_restores_both_native_match_end_paths():
    from sdk.dol_patch import DOLImage
    from tests.test_sdk02021k10_canonical_direct_mapping import _seed_arm, R13 as ARM_R13
    root=Path(__file__).resolve().parents[1]
    dol=DOLImage(root/'Build'/'start.dol')
    bridge=nb.install(dol,8,gateway_pending_addr=0x804F1000,gateway_active_addr=0x804F1001)
    sec=next(s for s in dol.sections if s.kind=='data' and s.index==8)
    mem={sec.address+i:b for i,b in enumerate(dol.read_at_address(sec.address,sec.size))}
    table=dol.read_at_address(bridge['patch_table'],bridge['patch_table_size'])
    _seed_arm(mem,state=bridge['state_address'],table_addr=bridge['patch_table'],table=table)
    blob=dol.read_at_address(bridge['arm_stub'],sec.end_address-bridge['arm_stub'])
    execute(blob,bridge['arm_stub'],mem=mem,initial_regs={13:ARM_R13})
    assert get(mem,er.REPORT_EXIT_GATE)==int.from_bytes(encode_branch(er.REPORT_EXIT_GATE,er.REPORT_EXIT_CONTINUE),'big')
    put(mem,0x804F1000,0,1);put(mem,0x804F1001,0,1)
    put(mem,nb.GM_SCENE_WORD_ADDR,nb.GM_ONLINE_MAJOR,1) # K19 defers cleanup until Online.
    command=0x81000000;put(mem,command,nb.CLEANUP_CONNECTIONS,1)
    blob=dol.read_at_address(bridge['exi_wrapper'],sec.end_address-bridge['exi_wrapper'])
    prime=bridge['k15']['prime']
    prime_blob=dol.read_at_address(prime,bridge['k15']['snapshot']-prime)
    execute(blob,bridge['exi_wrapper'],mem=mem,initial_regs={13:ARM_R13,3:command},extra_code=[(sec.address,dol.read_at_address(sec.address,sec.size))],stop_targets={nb.SLIPPI_EXI_TRANSFER})
    for spec in nb.GUARDS:assert get(mem,spec.site)==int.from_bytes(spec.expected,'big')
    assert get(mem,bridge['state_address']+nb.S_PHASE,1)==0
