from pathlib import Path
import inspect

from sdk import adventure_probe as a
from sdk.iso_builder import build_test_iso

ROOT=Path(__file__).resolve().parents[1]


def test_gateway_constants_and_layout_are_source_grounded():
    assert a.GM_VS_MELEE_EXIT_SSS == 0x801A57A8
    assert a.GM_MODE_ADVENTURE_ONLOAD == 0x801B5214
    assert a.ADVENTURE_GATEWAY_STKIND == 0x1D
    assert a.SSS_START_GAME_OFFSET == 0x04
    assert a.SSS_STKIND_LOW_BYTE_OFFSET == 0x1F
    assert a.SSS_P1_INIT_OFFSET == 0x70
    assert a.SSS_P2_INIT_OFFSET == 0x94
    assert a.ADVENTURE_PROFILE_OFFSET == 0x0522


def test_gateway_is_opt_in_and_requires_identity_bridge():
    sig=inspect.signature(a.install_phase30_coop_spawn_probe)
    assert sig.parameters['enable_adventure_sss_gateway'].default is False
    assert sig.parameters['enable_legacy_local_vs_gateway'].default is False
    sig2=inspect.signature(build_test_iso)
    assert sig2.parameters['adventure_sss_gateway'].default is False


def test_gateway_wrappers_generate_bounded_ppc_payloads():
    x=a._adventure_sss_gateway_exit_wrapper(
        0x80410000,0x80411000,
        gateway_pending_addr=0x8041202E,
        p1_ckind_addr=0x8041202A,p1_color_addr=0x8041202B,
        p1_subcolor_addr=0x8041202C,p1_nametag_addr=0x8041202D,
        p2_identity_valid_addr=0x80412025,p2_ckind_addr=0x80412026,
        p2_color_addr=0x80412027,p2_subcolor_addr=0x80412028,
        p2_nametag_addr=0x80412029)
    y=a._adventure_gateway_onload_wrapper(
        0x80413000,0x80414000,
        gateway_pending_addr=0x8041202E,camera_owner_addr=0x80412020,
        persistence_valid_addr=0x80412021,p1_stocks_addr=0x80412022,
        p2_stocks_addr=0x80412023,initial_stocks_addr=0x80412024,
        p1_ckind_addr=0x8041202A,p1_color_addr=0x8041202B,
        p1_nametag_addr=0x8041202D)
    assert 200 <= len(x) <= 512
    assert 180 <= len(y) <= 512
    assert len(x) % 4 == 0
    assert len(y) % 4 == 0


def test_gateway_bat_uses_direct_sss_option_and_full_unlock():
    p=ROOT/'Regression Builds'/'BUILD_COOP_ADVENTURE_GATE_TEST.bat'
    text=p.read_text(encoding='utf-8')
    assert '--adventure-sss-gateway' in text
    assert '--vs-p2-profile' in text
    assert '--unlock-all' in text
    assert '--test-shortcuts' in text
    assert "Yoshi's Island" in text
    assert 'no longer an Adventure gateway' in text
    assert 'D-Pad Down' in text
    assert 'back out and enter 1-P Adventure' not in text
