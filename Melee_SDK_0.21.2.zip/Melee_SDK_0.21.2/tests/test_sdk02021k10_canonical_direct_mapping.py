from pathlib import Path

from sdk import slippi_adventure_netplay_bridge as nb
from sdk import slippi_coop_stage_page as sp
from sdk import slippi_direct_gateway as dg
from tests.hf29d_ppc import execute, get, put, SENTINEL

R13=0x80400000
ROOT=Path(__file__).resolve().parents[1]


def _seed_msrb(mem, *, cssdt=0x810EF560, msrb=0x810EF5A0,
               local=0, remote=1, p1=0x06, p2=0x0A):
    put(mem, sp.SLIPPI_CSSDT_SIG_ADDR, sp.SLIPPI_CSSDT_SIG_WORD, 4)
    put(mem, sp.SLIPPI_CSSDT_PTR_SLOT, cssdt, 4)
    put(mem, cssdt + sp.CSSDT_MSRB_ADDR, msrb, 4)
    put(mem, msrb + sp.MSRB_LOCAL_PLAYER_INDEX, local, 1)
    put(mem, msrb + sp.MSRB_REMOTE_PLAYER_INDEX, remote, 1)
    gi=msrb+sp.MSRB_GAME_INFO_BLOCK
    put(mem, gi+sp.MSRB_P1+sp.MSRB_PLAYER_TYPE, 0, 1)
    put(mem, gi+sp.MSRB_P2+sp.MSRB_PLAYER_TYPE, 0, 1)
    # Link / Mewtwo from the supplied working regular Slippi saves.
    for off,val in ((sp.MSRB_CKIND,p1),(sp.MSRB_COLOR,0x04),
                    (sp.MSRB_SUBCOLOR,0),(sp.MSRB_NAMETAG,9)):
        put(mem, gi+sp.MSRB_P1+off, val, 1)
    for off,val in ((sp.MSRB_CKIND,p2),(sp.MSRB_COLOR,0x04),
                    (sp.MSRB_SUBCOLOR,1),(sp.MSRB_NAMETAG,9)):
        put(mem, gi+sp.MSRB_P2+off, val, 1)
    return cssdt,msrb


def _capture_blob(base, valid):
    return sp.build_capture_canonical(
        base, canonical_valid_addr=valid, canonical_local_addr=valid+1,
        canonical_remote_addr=valid+2, canonical_trace_addr=valid+3)


def test_k10_precarrier_capture_matches_regular_pc_mapping_and_identities():
    base=0x804F9000; valid=0x804F6000; snap=sp.CANONICAL_PLAYERS_HIGH
    blob=_capture_blob(base,valid)
    mem={}; _seed_msrb(mem,local=0,remote=1,p1=0x06,p2=0x0A)
    r=execute(blob,base,mem=mem)
    assert r['target']==SENTINEL
    assert get(mem,valid,1)==1
    assert get(mem,valid+1,1)==0 and get(mem,valid+2,1)==1
    assert get(mem,valid+3,1)==sp.CANONICAL_TRACE_CAPTURED
    assert get(mem,snap+sp.MSRB_CKIND,1)==0x06
    assert get(mem,snap+0x24+sp.MSRB_CKIND,1)==0x0A


def test_k10_precarrier_capture_matches_regular_rog_mapping_with_same_visible_slots():
    base=0x804F9000; valid=0x804F6000; snap=sp.CANONICAL_PLAYERS_HIGH
    blob=_capture_blob(base,valid)
    mem={}; _seed_msrb(mem,cssdt=0x810EF300,msrb=0x810EF340,
                       local=1,remote=0,p1=0x06,p2=0x0A)
    execute(blob,base,mem=mem)
    assert get(mem,valid,1)==1
    assert get(mem,valid+1,1)==1 and get(mem,valid+2,1)==0
    assert get(mem,snap+sp.MSRB_CKIND,1)==0x06
    assert get(mem,snap+0x24+sp.MSRB_CKIND,1)==0x0A


def test_k10_capture_is_one_shot_and_carrier_reorder_cannot_replace_it():
    base=0x804F9000; valid=0x804F6000; snap=sp.CANONICAL_PLAYERS_HIGH
    blob=_capture_blob(base,valid)
    mem={}; _seed_msrb(mem,local=0,remote=1,p1=0x06,p2=0x0A)
    execute(blob,base,mem=mem)
    _seed_msrb(mem,local=1,remote=0,p1=0x0A,p2=0x06)
    execute(blob,base,mem=mem)
    assert get(mem,valid+1,1)==0 and get(mem,valid+2,1)==1
    assert get(mem,snap+sp.MSRB_CKIND,1)==0x06
    assert get(mem,snap+0x24+sp.MSRB_CKIND,1)==0x0A


def _seed_arm(mem, *, state, table_addr, table, odb=0x80BF3960,
              txb=0x80BF4680,rxb=0x80BF46C0,ssrb=0x80BF4820,sscb=0x80BF4880,
              carrier_local=1,carrier_remote=0,input_source=0):
    for i,b in enumerate(table): mem[table_addr+i]=b
    put(mem,(R13+nb.OFST_R13_ODB_ADDR)&0xffffffff,odb,4)
    for base,size,seed in ((odb,nb.ODB_SIZE,0x11),(txb,nb.TXB_SIZE,0x22),
                           (rxb,nb.RXB_SIZE,0x33),(ssrb,nb.SSRB_SIZE,0x44),
                           (sscb,nb.SSCB_SIZE,0x55)):
        for i in range(size): put(mem,base+i,(seed+i*3)&0xff,1)
    put(mem,odb+nb.ODB_LOCAL_PLAYER_INDEX,carrier_local,1)
    put(mem,odb+nb.ODB_ONLINE_PLAYER_INDEX,carrier_remote,1)
    put(mem,odb+nb.ODB_INPUT_SOURCE_INDEX,input_source,1)
    put(mem,odb+nb.ODB_TXB_ADDR,txb,4); put(mem,odb+nb.ODB_RXB_ADDR,rxb,4)
    put(mem,odb+nb.ODB_SSRB_ADDR,ssrb,4); put(mem,odb+nb.ODB_SSCB_ADDR,sscb,4)
    for g in nb.GUARDS: put(mem,g.site,int.from_bytes(g.expected,'big'),4)
    put(mem,nb.SLIPPI_EXI_VENEER,int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED,'big'),4)
    put(mem,(R13+nb.OFST_R13_ARENA_HI)&0xffffffff,0x81800000,4)


def test_k10_arm_restores_precarrier_logical_roles_but_preserves_physical_port1():
    base=0x804F7000; state=0x804F6800; table_addr=0x804F7A00
    txrx=0x804F7B00; ss=0x804F7B08; meta=0x804F7B10
    valid=0x804F6100; local=valid+1; remote=valid+2
    exi=0x804FB000
    table=nb.build_patch_table(exi_wrapper_addr=exi)
    blob=nb.build_arm_stub(base,state_addr=state,guard_shims={},exi_wrapper_addr=exi,
                           patch_table_addr=table_addr,txrx_blob_addr=txrx,
                           ss_blob_addr=ss,ssrb_meta_blob_addr=meta,
                           canonical_valid_addr=valid,canonical_local_addr=local,
                           canonical_remote_addr=remote)
    mem={}; _seed_arm(mem,state=state,table_addr=table_addr,table=table,
                      carrier_local=1,carrier_remote=0,input_source=0)
    # Supporting blobs normally emitted by install().
    for i,b in enumerate(nb.STABLE_TXB.to_bytes(4,'big')+nb.STABLE_RXB.to_bytes(4,'big')): put(mem,txrx+i,b,1)
    for i,b in enumerate(nb.STABLE_SSRB.to_bytes(4,'big')+nb.STABLE_SSCB.to_bytes(4,'big')): put(mem,ss+i,b,1)
    meta_blob=(nb.STABLE_ODB.to_bytes(4,'big')+nb.ODB_SIZE.to_bytes(4,'big')+
               nb.STABLE_RXB.to_bytes(4,'big')+nb.RXB_SIZE.to_bytes(4,'big')+
               nb.STABLE_SSCB.to_bytes(4,'big')+nb.SSCB_SIZE.to_bytes(4,'big'))
    for i,b in enumerate(meta_blob): put(mem,meta+i,b,1)
    # PC canonical role from regular save: logical local P1, remote P2.
    put(mem,valid,1,1); put(mem,local,0,1); put(mem,remote,1,1)
    r=execute(blob,base,mem=mem,initial_regs={13:R13})
    assert r['regs'][3]==1
    assert get(mem,nb.STABLE_ODB+nb.ODB_LOCAL_PLAYER_INDEX,1)==0
    assert get(mem,nb.STABLE_ODB+nb.ODB_ONLINE_PLAYER_INDEX,1)==1
    # Never translate physical Port 1 into logical P1/P2; Slippi owns it.
    assert get(mem,nb.STABLE_ODB+nb.ODB_INPUT_SOURCE_INDEX,1)==0
    assert get(mem,state+nb.S_LOCAL_INDEX,1)==0
    assert get(mem,state+nb.S_ARM_ONLINE_INDEX,1)==1
    assert get(mem,state+nb.S_ARM_INPUT_SOURCE_INDEX,1)==0


def test_k10_adventure_scene_word_is_not_spoofed_and_audio_rollback_guards_are_scoped():
    assert nb.STATE_VERSION == 11
    names={g.name for g in nb.ACTIVE_GUARDS}
    assert len(names)==17
    assert {'sound_assign_instance_id','sound_no_destroy_voice','sound_no_destroy_voice2',
            'sound_prevent_duplicate_sounds'} <= names
    assert {g.name for g in nb.SNAPSHOT_GUARDS} == {'teams_prevent_dead_stranding'}

    base=0x804FC000; state=0x804F6800; pending=0x804F6700; active=0x804F6701
    mem={}; put(mem,state+nb.S_PHASE,nb.PHASE_TRANSITION,1)
    put(mem,state+nb.S_LOCAL_INDEX,0,1); put(mem,state+nb.S_ARM_ONLINE_INDEX,1,1)
    put(mem,state+nb.S_ARM_INPUT_SOURCE_INDEX,0,1)
    put(mem,pending,0,1); put(mem,active,1,1)
    scene=0x04000002; put(mem,nb.GM_SCENE_WORD_ADDR,scene,4)
    req=0x81201000; put(mem,req,nb.ONLINE_INPUTS,1)
    blob=nb.build_exi_wrapper(base,pending_addr=pending,active_addr=active,state_addr=state,
                              patch_table_addr=0x804FD100)
    execute(blob,base,mem=mem,initial_regs={3:req,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert get(mem,nb.GM_SCENE_WORD_ADDR,4)==scene


def test_k10_probe_wires_canonical_state_through_sss_gateway_and_bridge():
    src=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.21K14'" in src
    for token in ('canonical_direct_valid_addr','canonical_direct_local_addr',
                  'canonical_direct_remote_addr','canonical_direct_trace_addr'):
        assert token in src
    assert 'canonical_valid_addr=canonical_direct_valid_addr' in src

def test_k10_preload_uses_canonical_snapshot_not_reordered_carrier_identity():
    base=0x804FA000; tramp=0x804F9F00; state=0x804F9800; pending=0x804F9700
    p2=pending+0x10; p1=p2+4; valid=pending+0x20
    blob=dg.build_wrapper(
        base,tramp,state_addr=state,gateway_pending_addr=pending,
        p1_ckind_addr=p1,p1_color_addr=p1+1,p1_subcolor_addr=p1+2,p1_nametag_addr=p1+3,
        p2_identity_valid_addr=pending+5,p2_ckind_addr=p2,p2_color_addr=p2+1,
        p2_subcolor_addr=p2+2,p2_nametag_addr=p2+3,
        netplay_arm_addr=None,canonical_valid_addr=valid,
        canonical_players_addr=sp.CANONICAL_PLAYERS_HIGH)
    mem={}
    # Supported Direct context with a deliberately reordered carrier block.
    put(mem,dg.GM_CURRENT_MODE_ADDR,dg.GM_ONLINE,1)
    put(mem,(R13+dg.OFST_R13_ONLINE_MODE)&0xffffffff,dg.ONLINE_MODE_DIRECT,1)
    gmm=0x81200000; match=gmm+dg.DIRECT_MATCH_DATA_OFFSET
    put(mem,(R13+dg.OFST_R13_GM_MAINLIB)&0xffffffff,gmm,4)
    put(mem,match+dg.DIRECT_STAGE_LOW_BYTE,dg.CARRIER_STAGE,1)
    put(mem,match+dg.P1+dg.PLAYER_TYPE,0,1); put(mem,match+dg.P2+dg.PLAYER_TYPE,0,1)
    put(mem,match+dg.P1+dg.CKIND,0x0A,1); put(mem,match+dg.P2+dg.CKIND,0x06,1)
    # Canonical pre-carrier snapshot remains Link in P1 and Mewtwo in P2.
    snap=sp.CANONICAL_PLAYERS_HIGH
    put(mem,snap+dg.P1-dg.P1+dg.CKIND,0x06,1)
    put(mem,snap+dg.P1-dg.P1+dg.COLOR,0x04,1)
    put(mem,snap+dg.P1-dg.P1+dg.SUBCOLOR,0,1)
    put(mem,snap+dg.P1-dg.P1+dg.NAMETAG,9,1)
    put(mem,snap+0x24+dg.CKIND,0x0A,1)
    put(mem,snap+0x24+dg.COLOR,0x04,1)
    put(mem,snap+0x24+dg.SUBCOLOR,1,1)
    put(mem,snap+0x24+dg.NAMETAG,9,1)
    put(mem,valid,1,1)
    execute(blob,base,mem=mem,initial_regs={13:R13},stop_targets={tramp})
    assert get(mem,p1,1)==0x06
    assert get(mem,p2,1)==0x0A


def test_k11_stage_commit_preserves_caller_lr_when_canonical_capture_clobbers_r12():
    """Regression for the exact gateway-select crash seen in K10.

    K10 saved the incoming LR in volatile r12.  The canonical capture helper
    then used r12 for canonical_valid_addr, so the wrapper returned into the
    four state bytes instead of its Slippi caller.  Model a helper that leaves
    r12 clobbered and require a clean return to the original caller.
    """
    base=0x804FA000; tramp=0x804FB000; capture=0x804FB100; restore=0x804FB200
    state=0x804F9000; clobbered=0x804F0C94
    blob=sp.build_stage_commit_wrapper(
        base,tramp,state_addr=state,descriptor_restore_addr=restore,
        capture_addr=capture)
    mem={}; put(mem,state+sp.S_PAGE,1,1); put(mem,state+sp.S_SAVED,1,1)

    def retail_mapper(regs, mem):
        # Retail mapper is a leaf for this contract; leave volatile state alone.
        pass

    def canonical_capture(regs, mem):
        # Reproduce K10's real helper behavior: r12 ends on canonical_valid_addr.
        regs[12]=clobbered

    def restore_descriptors(regs, mem):
        # This helper may also use volatile registers; callers must not depend on them.
        regs[11]=0xDEADBEEF

    r=execute(blob,base,mem=mem,callees={
        tramp:retail_mapper,capture:canonical_capture,restore:restore_descriptors})
    assert r['target']==SENTINEL
    assert r['lr']==SENTINEL
    assert r['regs'][1]==0x817FF000
    assert r['regs'][3]==sp.DIRECT_CARRIER_STKIND
    assert get(mem,state+sp.S_TX_TRACE,1)==sp.TX_TRACE_ALT_INTENT
