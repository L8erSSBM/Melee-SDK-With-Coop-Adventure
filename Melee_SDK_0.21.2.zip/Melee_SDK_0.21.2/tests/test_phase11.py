from pathlib import Path
import tempfile

from sdk.melee_dat import FighterDAT

FIX = Path('/mnt/data/fighters_extract/Melee_Fighters')


def _falcon_copy():
    td = tempfile.TemporaryDirectory()
    p = Path(td.name) / 'PlCa.dat'
    p.write_bytes((FIX / 'PlCa.dat').read_bytes())
    return td, FighterDAT(p)


def test_falcon_punch_timing_analysis():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    t = f.analyze_move_timing(move)
    assert t['first_active'] == 52.0
    assert t['active_end'] == 57.0
    assert t['interrupt_frame'] == 65.0
    assert t['script_end'] == 77.0
    assert t['recovery'] == 20.0
    assert t['active_windows'] == [{'start': 52.0, 'end': 57.0}]


def test_set_first_active_frame_preserves_relative_tail():
    td, f = _falcon_copy()
    try:
        move = next(a for a in f.animations if a.action_name == 'SpecialN')
        original_size = len(f.archive.raw)
        f.set_first_active_frame(move, 26)
        t = f.analyze_move_timing(move)
        assert t['first_active'] == 26.0
        assert t['active_end'] == 31.0
        assert t['interrupt_frame'] == 39.0
        assert t['script_end'] == 51.0
        assert t['recovery'] == 20.0
        assert len(f.archive.raw) == original_size
    finally:
        td.cleanup()


def test_set_active_end_and_recovery_milestones():
    td, f = _falcon_copy()
    try:
        move = next(a for a in f.animations if a.action_name == 'SpecialN')
        f.set_active_end_frame(move, 55)
        t = f.analyze_move_timing(move)
        assert t['first_active'] == 52.0
        assert t['active_end'] == 55.0
        assert t['script_end'] == 75.0
        assert t['recovery'] == 20.0
        f.set_script_end_frame(move, 65)
        t = f.analyze_move_timing(move)
        assert t['script_end'] == 65.0
        assert t['recovery'] == 10.0
    finally:
        td.cleanup()


def test_set_interrupt_frame_only_moves_interrupt_anchor_region():
    td, f = _falcon_copy()
    try:
        move = next(a for a in f.animations if a.action_name == 'SpecialN')
        f.set_interrupt_frame(move, 60)
        t = f.analyze_move_timing(move)
        assert t['interrupt_frame'] == 60.0
        # The later absolute frame-77 anchor is intentionally preserved.
        assert t['script_end'] == 77.0
    finally:
        td.cleanup()
