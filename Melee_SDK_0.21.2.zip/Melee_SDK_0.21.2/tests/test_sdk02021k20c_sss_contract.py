import json
import zipfile
from pathlib import Path

from sdk import adventure_probe as ap
from sdk import slippi_adventure_entry_hardening as entry
from sdk import slippi_coop_stage_page as sp
from sdk.dol_patch import DOLImage
from sdk.package_import import import_stage_package
from sdk.stage_select_pages import (
    PAD_DPAD_DOWN, PAD_DPAD_UP, StagePage, StagePageSet,
)
import sdk.package_import as pkg
import sdk.workspace as ws
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]
R13 = 0x80400000


class DummyStage:
    def __init__(self, source):
        self.source = source
    def validate(self):
        return None


def _project(tmp_path, monkeypatch):
    monkeypatch.setattr(ws, 'StageDAT', DummyStage)
    monkeypatch.setattr(pkg, 'StageDAT', DummyStage)
    for name in ('Original', 'Working', 'Build'):
        (tmp_path / name).mkdir()
    data = b'valid donor stage bytes'
    (tmp_path / 'Original' / 'GrNBa.dat').write_bytes(data)
    (tmp_path / 'Working' / 'GrNBa.dat').write_bytes(data)
    manifest = {
        'resources': [{'filename': 'GrNBa.dat', 'source_relative': 'disc', 'sha256': 'x', 'size': len(data)}],
        'fighters': [],
        'stages': [{'filename': 'GrNBa.dat', 'display_name': 'Battlefield', 'source_relative': 'disc'}],
    }
    (tmp_path / ws.MANIFEST_NAME).write_text(json.dumps(manifest), encoding='utf-8')
    return ws.MeleeProject(tmp_path)


def test_stage_page_json_cannot_remap_reserved_dpad_controls():
    raw = StagePageSet([StagePage('retail', 'Retail', builtin_retail=True)]).to_dict()
    raw['page_up_mask'] = 0x1234
    raw['page_down_mask'] = 0x5678
    loaded = StagePageSet.from_dict(raw)
    assert loaded.page_up_mask == PAD_DPAD_UP == 0x0008
    assert loaded.page_down_mask == PAD_DPAD_DOWN == 0x0004
    saved = loaded.to_dict()
    assert saved['navigation_contract']['policy'] == 'sdk-forced'


def test_custom_stage_import_rebuilds_pages_and_forces_navigation(tmp_path, monkeypatch):
    project = _project(tmp_path, monkeypatch)
    project.manifest['stage_select_pages'] = StagePageSet([
        StagePage('retail', 'Retail', builtin_retail=True)
    ]).to_dict()
    project.manifest['stage_select_pages']['page_up_mask'] = 0x1111
    project.manifest['stage_select_pages']['page_down_mask'] = 0x2222
    project.save_manifest()

    package = tmp_path / 'custom_stage.zip'
    with zipfile.ZipFile(package, 'w') as z:
        z.writestr('GrMy.dat', b'custom stage bytes')
    result = import_stage_package(project, package, as_new=True, new_filename='GrMy.dat')
    assert result['mode'] == 'new_stage'

    raw = json.loads(project.manifest_path.read_text(encoding='utf-8'))['stage_select_pages']
    assert raw['page_up_mask'] == PAD_DPAD_UP
    assert raw['page_down_mask'] == PAD_DPAD_DOWN
    assert any(e.get('stage_filename') == 'GrMy.dat'
               for page in raw['pages'] for e in page.get('entries', []))


def test_every_project_build_reasserts_navigation_contract(tmp_path, monkeypatch):
    project = _project(tmp_path, monkeypatch)
    raw = StagePageSet([StagePage('retail', 'Retail', builtin_retail=True)]).to_dict()
    raw['page_up_mask'] = 0
    raw['page_down_mask'] = 0
    project.manifest['stage_select_pages'] = raw
    project.save_manifest()
    project.build()
    persisted = json.loads(project.manifest_path.read_text(encoding='utf-8'))['stage_select_pages']
    assert persisted['page_up_mask'] == PAD_DPAD_UP
    assert persisted['page_down_mask'] == PAD_DPAD_DOWN


def test_two_page_runtime_payload_stays_below_k20b_budget():
    dol = DOLImage((ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    row = sp.install(
        dol, 8,
        canonical_valid_addr=0x804F0000,
        canonical_local_addr=0x804F0001,
        canonical_remote_addr=0x804F0002,
        canonical_trace_addr=0x804F0003,
    )
    # K20 was 0x900 and K20B was 0x480. Removing the canned duplicate Page 3
    # must not grow back toward the low-arena ceiling.
    assert row['section']['size'] < 0x480
    assert row['page3_stage_mask'] == 0
    assert row['canned_page3_removed'] is True


def test_retired_hf21_scratch_is_only_accessor_capacity():
    blob = ap._retired_trace_scratch_wrapper(0x80402000, 0x80402100)
    assert len(blob) == ap.RETIRED_TRACE_SCRATCH_SIZE == 0x28
    assert len(entry.RETAIL_ACCESSOR) + len(entry.MARKER) == 0x28


def _run_nav(page, trigger):
    base = 0x804F7000
    tramp = 0x804F6000
    render = 0x804F6800
    state = 0x804F6500
    blob = sp.build_frame_wrapper(base, tramp, state_addr=state, render_addr=render)
    mem = {}
    put(mem, sp.GM_CURRENT_MODE_ADDR, sp.GM_ONLINE, 1)
    put(mem, (R13 + sp.OFST_R13_ONLINE_MODE) & 0xFFFFFFFF, sp.ONLINE_MODE_DIRECT, 1)
    put(mem, state + sp.S_PAGE, page, 1)
    put(mem, sp.PAD_STATUS + sp.PAD_TRIGGER, trigger, 4)
    calls = []
    def render_fn(regs, _mem):
        calls.append(regs[3])
    result = execute(blob, base, mem=mem, initial_regs={13: R13},
                     callees={render: render_fn}, stop_targets={tramp})
    assert result['target'] == tramp
    return calls


def test_runtime_navigation_contract_is_two_page_down_and_up():
    assert _run_nav(0, PAD_DPAD_DOWN) == [1]
    assert _run_nav(1, PAD_DPAD_DOWN) == []
    assert _run_nav(1, PAD_DPAD_UP) == [0]
    assert _run_nav(0, PAD_DPAD_UP) == []


def test_compact_renderer_preserves_two_page_semantics_instruction_level():
    base = 0x804F7000
    state = 0x804F6500
    blob = sp.build_render_page(base, state_addr=state, canonical_valid_addr=0x804F6400)
    mem = {}
    for i in range(sp.STAGE_ROW_COUNT):
        row = sp.STAGE_TABLE + i * sp.STAGE_ROW_SIZE
        put(mem, row, 0x81000000 + i * 4, 4)
        put(mem, row + sp.ROW_X8, 2, 1)
        put(mem, row + sp.ROW_STKIND, i, 1)
    visual = []
    def shown(regs, _mem):
        visual.append(('show', regs[3]))
    def hidden(regs, _mem):
        visual.append(('hide', regs[3]))

    # Co-op page exposes only slot 27 and never rewrites its retail StKind.
    execute(blob, base, mem=mem, initial_regs={3: 1},
            callees={sp.HSD_JOBJ_CLEAR_FLAGS_ALL: shown, sp.HSD_JOBJ_SET_FLAGS_ALL: hidden})
    for i in range(sp.STAGE_ROW_COUNT):
        row = sp.STAGE_TABLE + i * sp.STAGE_ROW_SIZE
        assert get(mem, row + sp.ROW_X8, 1) == (2 if i == sp.COOP_TILE_SLOT else 0)
        assert get(mem, row + sp.ROW_STKIND, 1) == i
    assert get(mem, state + sp.S_PAGE, 1) == 1
    assert get(mem, state + sp.S_SAVED, 1) == 1

    # Returning to Default restores the exact captured retail bytes.
    execute(blob, base, mem=mem, initial_regs={3: 0},
            callees={sp.HSD_JOBJ_CLEAR_FLAGS_ALL: shown, sp.HSD_JOBJ_SET_FLAGS_ALL: hidden})
    for i in range(sp.STAGE_ROW_COUNT):
        row = sp.STAGE_TABLE + i * sp.STAGE_ROW_SIZE
        assert get(mem, row + sp.ROW_X8, 1) == 2
        assert get(mem, row + sp.ROW_STKIND, 1) == i
    assert get(mem, state + sp.S_PAGE, 1) == 0
    assert get(mem, state + sp.S_SAVED, 1) == 0



def _synthetic_mnslmap_archive():
    """Archive with no *_image publics: 30 icon + 30 category + 30 name textures."""
    import struct
    fams=[(64,64,5),(256,32,3),(384,64,3)]
    n=sum(30 for _ in fams)
    ref_bytes=n*4
    desc_base=(ref_bytes+3)&~3
    desc_bytes=n*0x18
    tex_base=(desc_base+desc_bytes+0x1F)&~0x1F
    data=bytearray(tex_base)
    rel=[]; records=[]; idx=0; tex_cursor=tex_base
    for fam,(w,h,fmt) in enumerate(fams):
        size=__import__('sdk.stage_assets',fromlist=['texture_level_size']).texture_level_size(w,h,fmt)
        for slot in range(30):
            ref=idx*4; desc=desc_base+idx*0x18
            struct.pack_into('>I',data,ref,desc); rel.append(ref)
            image=tex_cursor; tex_cursor+=size
            if len(data)<tex_cursor: data.extend(b'\0'*(tex_cursor-len(data)))
            struct.pack_into('>IHHIIff',data,desc,image,w,h,fmt,0,0.0,0.0); rel.append(desc)
            # distinct nonzero baseline so exact patched slots are easy to verify
            data[image:image+size]=bytes([(slot+fam+1)&0xFF])*size
            records.append((fam,slot,image,size))
            idx+=1
    header_size=0x20
    file_size=header_size+len(data)+len(rel)*4
    hdr=bytearray(0x20)
    struct.pack_into('>5I',hdr,0,file_size,len(data),len(rel),0,0)
    hdr[0x14:0x18]=b'HSD0'
    reloc=b''.join(struct.pack('>I',x) for x in rel)
    return bytes(hdr)+bytes(data)+reloc,records


def test_mnslmap_visual_patch_uses_relocations_and_is_strict(tmp_path):
    from sdk.sss_visual_qol import patch_mnslmap_bytes
    raw, records = _synthetic_mnslmap_archive()
    icon=ROOT/'assets'/'sss_qol'/'coop_adventure_icon_source.png'
    patched, rep = patch_mnslmap_bytes(raw,icon,strict=True)
    assert rep['icon_patched'] is True
    assert rep['special_mode_patched'] is True
    assert rep['coop_adventure_patched'] is True
    assert rep['dpad_up_figure_embedded'] is True
    assert rep['dpad_down_figures_embedded'] == 29
    assert rep['third_party_image_dependency'] is False
    assert rep['canned_page3_removed'] is True
    # All three physical slot-27 assets changed even though the archive has no publics.
    data_start=0x20
    for fam in range(3):
        _,_,off,size=next(r for r in records if r[0]==fam and r[1]==27)
        assert patched[data_start+off:data_start+off+size] != raw[data_start+off:data_start+off+size]
    # Icon/category slot 26 remain retail. The stage-name family is intentionally
    # augmented with the D-Pad Down -> Co-op page cue on Default.
    for fam in (0,1):
        _,_,prev,size2=next(r for r in records if r[0]==fam and r[1]==26)
        assert patched[data_start+prev:data_start+prev+size2] == raw[data_start+prev:data_start+prev+size2]
    _,_,prev,size2=next(r for r in records if r[0]==2 and r[1]==26)
    assert patched[data_start+prev:data_start+prev+size2] != raw[data_start+prev:data_start+prev+size2]
