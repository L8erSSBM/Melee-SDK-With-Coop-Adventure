from sdk.ppc import encode_branch, decode_branch
from sdk.additional_content import AdditionalContentProfile, full_dlc_profile, vanilla_character_only_profile
from sdk.dol_patch import DOLImage
from sdk.runtime_hook import RuntimeHookInstaller, HookSite


def _synthetic_dol():
    raw=bytearray(0x300)
    # text0 file 0x100 -> VA 0x80004000, size 0x40
    raw[0:4]=(0x100).to_bytes(4,'big')
    raw[0x48:0x4c]=(0x80004000).to_bytes(4,'big')
    raw[0x90:0x94]=(0x40).to_bytes(4,'big')
    raw[0x100:0x140]=b'\x60\x00\x00\x00'*16
    # BSS intentionally low enough that allocator chooses after it.
    raw[0xD8:0xDC]=(0x80005000).to_bytes(4,'big')
    raw[0xDC:0xE0]=(0x100).to_bytes(4,'big')
    return DOLImage(raw)


def test_ppc_relative_branch_roundtrip():
    raw=encode_branch(0x80100000,0x80400020)
    d=decode_branch(0x80100000,raw)
    assert d['target']==0x80400020
    assert not d['link'] and not d['absolute']


def test_additional_content_keeps_character_only_build_vanilla():
    p=vanilla_character_only_profile()
    assert p.enabled==[]
    plan=p.build_plan()
    assert plan['vanilla_isolation']['fighter_edits_require_additional_content'] is False


def test_additional_content_dependencies_are_explicit():
    try:
        AdditionalContentProfile('bad',['coop_adventure']).validate()
    except ValueError as e:
        assert 'requires stage_hub' in str(e)
    else:
        raise AssertionError('expected dependency failure')
    p=AdditionalContentProfile('ok',['coop_adventure']).with_dependencies()
    assert set(p.enabled)=={'coop_adventure','stage_hub'}
    full_dlc_profile().validate()


def test_transparent_runtime_hook_replays_instruction_and_returns():
    dol=_synthetic_dol()
    site=0x80004000
    expected=dol.read_at_address(site,4)
    m=RuntimeHookInstaller(dol).install_transparent_hooks([HookSite('test',site,expected)],flags=1)
    h=m['hooks'][0]
    assert decode_branch(site,bytes.fromhex(h['site_branch']))['target']==h['stub_address']
    assert dol.read_at_address(h['stub_address'],4)==expected
    assert decode_branch(h['stub_address']+4,dol.read_at_address(h['stub_address']+4,4))['target']==site+4
    assert dol.read_at_address(m['section']['address'],8)==b'MSDKRT29'


def test_real_hook_site_order_matches_phase28_contract():
    from sdk.adventure_runtime import RUNTIME_TOUCHPOINTS
    assert [x.symbol for x in RUNTIME_TOUCHPOINTS] == [
        'gm_8017CE34','gm_8017D7AC','gm_8017E7A0','gm_801B4064','gm_801B42E8','gm_801B4350']
