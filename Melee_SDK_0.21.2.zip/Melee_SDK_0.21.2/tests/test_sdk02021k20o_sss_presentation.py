from pathlib import Path
import pytest
from sdk import slippi_coop_stage_page as sp
from sdk.sss_visual_qol import patch_mnslmap_bytes, _load_png_rgba, _public_root, _iter_matanim_tables, _read_image_desc
from sdk.melee_dat import HSDArchive

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'/'sss_qol'

def _bounds(im):
    pts=[(i%im.width,i//im.width) for i,p in enumerate(im.pixels) if p[3]>64]
    xs=[x for x,_ in pts]; ys=[y for _,y in pts]
    return min(xs),min(ys),max(xs),max(ys)

def test_contextual_footer_alignment():
    down=_load_png_rgba(ASSETS/'sss_nav_default_down.png')
    up=_load_png_rgba(ASSETS/'sss_nav_page2_up.png')
    assert down.size==(232,16) and up.size==(232,16)
    db=_bounds(down); ub=_bounds(up)
    assert db[0] > 120 and db[2] >= 228   # PAGE 2 lives on the right
    assert ub[0] <= 4 and ub[2] < 110     # DEFAULT lives on the left
    assert down.pixels != up.pixels

def test_title_fits_stock_surface():
    title=_load_png_rgba(ASSETS/'coop_adventure_title_only.png')
    assert title.size==(224,56)
    b=_bounds(title)
    assert 0 <= b[0] < b[2] < 224
    assert 0 <= b[1] < b[3] < 56

def test_runtime_budget_stays_at_k20n_size():
    base=0x804F0000; state=base
    rec={'target_desc':0x959BC,'default_image':0x6A720,'coop_image':0x98700,'kind':'footer'}
    cursor=base+sp.STATE_SIZE
    def add(fn,align=4):
        nonlocal cursor
        cursor=(cursor+align-1)&~(align-1); a=cursor; cursor+=len(fn(a)); return a
    et=add(lambda a:sp.PROLOGUE_EXPECTED+sp.encode_branch(a+4,sp.ONENTER_HOOK+4))
    ft=add(lambda a:sp.PROLOGUE_EXPECTED+sp.encode_branch(a+4,sp.ONFRAME_HOOK+4))
    ct=add(lambda a:sp.STAGE_COMMIT_EXPECTED+sp.encode_branch(a+4,sp.STAGE_COMMIT_HOOK+4))
    rd=add(lambda a:sp.build_render_page(a,state_addr=state,canonical_valid_addr=base+0x1000,visual_models_offset=0x10,footer_record=rec))
    dr=add(lambda a:sp.build_restore_descriptor_leaf(a,state_addr=state))
    cap=add(lambda a:sp.build_capture_canonical(a,canonical_valid_addr=base+0x1000,canonical_local_addr=base+0x1001,canonical_remote_addr=base+0x1002,canonical_trace_addr=base+0x1003))
    add(lambda a:sp.build_enter_wrapper(a,et,state_addr=state,descriptor_restore_addr=dr))
    add(lambda a:sp.build_frame_wrapper(a,ft,state_addr=state,render_addr=rd))
    add(lambda a:sp.build_stage_commit_wrapper(a,ct,state_addr=state,descriptor_restore_addr=dr,capture_addr=cap))
    assert ((cursor-base+31)&~31) <= 0x4C0

def test_retail_special_frames_are_not_permanently_repurposed():
    fixture=Path('/mnt/data/MnSlMap.usd')
    if not fixture.is_file():
        pytest.skip('stock MnSlMap.usd fixture not present in this environment')
    raw=fixture.read_bytes()
    patched,rep=patch_mnslmap_bytes(raw,ASSETS/'coop_adventure_icon_source.png',strict=True)
    assert rep['selection_contract']['retail_yoshi_island_n64_preserved'] is True
    old=HSDArchive(raw); new=HSDArchive(patched)
    def tables(arc):
        root=_public_root(arc,'MnSelectStageDataTable'); models=root+0x10
        mat=arc.data_u32(models+0x20+8)
        return list(_iter_matanim_tables(arc,mat))
    ots,nts=tables(old),tables(new)
    assert len(ots)==len(nts)
    for ot,nt in zip(ots,nts):
        assert ot['count']==nt['count']
        for i in range(min(len(ot['entries']),len(nt['entries']))):
            if not ot['entries'][i] or not nt['entries'][i]:
                continue
            ro=_read_image_desc(old,ot['entries'][i]); rn=_read_image_desc(new,nt['entries'][i])
            assert old.data_bytes(ro['image'],ro['size']) == new.data_bytes(rn['image'],rn['size'])
