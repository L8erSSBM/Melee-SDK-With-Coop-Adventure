from sdk.adventure_probe import (
    _static_fighter_spawn_slot_wrapper,
    STATIC_FIGHTER_SPAWN_SLOT_HOOK,
    PLAYER_GET_ENTITY,
    PLAYER_LOAD_COORDS,
    FTLIB_GET_CUR_POS,
)
from sdk.ppc import decode_branch
from hf29d_ppc import execute, put

BASE = 0x804F1800
OWNER = 0x804F0C20
VEC = 0x817FEF00
GOBJ0 = 0x80450000
GOBJ1 = 0x80451000


def _calls(blob):
    out=[]
    for off in range(0, len(blob), 4):
        raw=blob[off:off+4]
        try:
            d=decode_branch(BASE+off, raw)
        except ValueError:
            continue
        if d['link']:
            out.append(d['target'])
    return out


def test_human_slots_keep_retail_static_fallback_path():
    blob = _static_fighter_spawn_slot_wrapper(BASE, OWNER)
    for slot in (0, 1):
        result = execute(blob, BASE, initial_regs={28: slot, 4: VEC},
                         stop_targets=(STATIC_FIGHTER_SPAWN_SLOT_HOOK + 4,
                                       PLAYER_GET_ENTITY, FTLIB_GET_CUR_POS))
        assert result['target'] == STATIC_FIGHTER_SPAWN_SLOT_HOOK + 4
        assert result['regs'][3] == slot


def test_static_cpu_fallback_resolves_live_control_owner_gobj_then_cur_pos():
    blob = _static_fighter_spawn_slot_wrapper(BASE, OWNER)
    assert PLAYER_GET_ENTITY in _calls(blob)
    assert FTLIB_GET_CUR_POS in _calls(blob)
    assert PLAYER_LOAD_COORDS not in _calls(blob)

    for owner, gobj in ((0, GOBJ0), (1, GOBJ1)):
        for slot in (2, 3, 4, 5):
            mem = {}; put(mem, OWNER, owner, 1)
            seen=[]
            def player_get(regs, mem):
                seen.append(('entity', regs[3]))
                regs[3]=gobj
            def live_pos(regs, mem):
                seen.append(('cur_pos', regs[3], regs[4]))
                assert regs[3] == gobj
                assert regs[4] == VEC
            result = execute(
                blob, BASE, mem=mem, initial_regs={28: slot, 4: VEC},
                callees={PLAYER_GET_ENTITY: player_get, FTLIB_GET_CUR_POS: live_pos},
                stop_targets=(STATIC_FIGHTER_SPAWN_SLOT_HOOK + 0x0C,))
            assert result['target'] == STATIC_FIGHTER_SPAWN_SLOT_HOOK + 0x0C
            assert seen == [('entity', owner), ('cur_pos', gobj, VEC)]


def test_missing_live_owner_entity_fails_closed_to_retail_fallback():
    blob = _static_fighter_spawn_slot_wrapper(BASE, OWNER)
    mem = {}; put(mem, OWNER, 1, 1)
    def missing(regs, mem):
        regs[3]=0
    result = execute(blob, BASE, mem=mem, initial_regs={28: 3, 4: VEC},
                     callees={PLAYER_GET_ENTITY: missing},
                     stop_targets=(STATIC_FIGHTER_SPAWN_SLOT_HOOK + 4,
                                   FTLIB_GET_CUR_POS))
    assert result['target'] == STATIC_FIGHTER_SPAWN_SLOT_HOOK + 4
    assert result['regs'][3] == 3


def test_invalid_control_owner_clamps_to_p1_live_entity():
    blob = _static_fighter_spawn_slot_wrapper(BASE, OWNER)
    mem = {}; put(mem, OWNER, 7, 1)
    seen=[]
    def player_get(regs, mem):
        seen.append(regs[3]); regs[3]=GOBJ0
    def live_pos(regs, mem):
        pass
    result = execute(blob, BASE, mem=mem, initial_regs={28: 2, 4: VEC},
                     callees={PLAYER_GET_ENTITY: player_get, FTLIB_GET_CUR_POS: live_pos},
                     stop_targets=(STATIC_FIGHTER_SPAWN_SLOT_HOOK + 0x0C,))
    assert result['target'] == STATIC_FIGHTER_SPAWN_SLOT_HOOK + 0x0C
    assert seen == [0]



def test_hook_site_is_retail_marker_ff_fallback_not_explicit_marker_path():
    from pathlib import Path
    from sdk.dol_patch import DOLImage
    root=Path(__file__).resolve().parents[1]
    d=DOLImage(root/'Build'/'historical'/'HF29G_GATEWAY_SCOPED_COOP_GAMEOVER_RETURN.dol')
    # lbz marker; extsb; cmpwi -1; bne explicit-marker path; then fallback
    # mr r3,r28 / addi r4,sp,0x18 / bl Stage_80224E64.
    assert d.read_at_address(0x8016E47C, 0x1C) == bytes.fromhex(
        '881e003b7c0007742c00ffff40820014'
        '387c000038810018480b69d1')


def test_sdk0209_installer_dummy_sizing_uses_fixed_slippi_guard_without_final_addresses():
    """Regression: sizing must not depend on final runtime section addresses.

    0.20.9 no longer installs the 0.20.6 static-fighter anchor wrapper; its
    reserved payload slot now contains the Adventure-only Slippi spawn guard.
    """
    import inspect
    from sdk.adventure_probe import install_phase30_coop_spawn_probe

    src = inspect.getsource(install_phase30_coop_spawn_probe)
    assert "dummy_static_spawn=_adventure_slippi_spawn_guard_wrapper(0x80400E80)" in src
    assert "dummy_static_spawn=_static_fighter_spawn_slot_wrapper" not in src
