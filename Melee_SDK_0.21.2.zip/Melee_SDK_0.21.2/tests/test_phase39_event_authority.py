from sdk.adventure_probe import (
    _ground_event_either_human_wrapper,
    GROUND_EVENT_SCAN_HOOK,
    GROUND_EVENT_SCAN_EXPECTED,
    STAGE_EVENT_FLAGS_ADDR,
    STAGE_EVENT_RESULT_A_ADDR,
    STAGE_EVENT_RESULT_B_ADDR,
    PLAYER_GET_ENTITY,
)
from sdk.additional_content import FEATURE_BY_KEY, FEATURES
from sdk.ppc import decode_branch, li


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def test_phase39_feature_registry():
    f = FEATURE_BY_KEY['coop_either_human_events']
    assert f.dependencies == ('coop_adventure',)
    assert not f.experimental
    assert len(FEATURES) == 15


def test_phase39_event_wrapper_queries_both_campaign_entities_and_restores_control():
    base = 0x804E6000
    trampoline = 0x804E5F00
    owner = 0x804E0020
    blob = _ground_event_either_human_wrapper(base, trampoline, owner)
    words = _words(blob)
    assert li(3, 0) in words
    assert li(3, 1) in words
    # The wrapper calls Player_GetEntity for each physical campaign slot and
    # the retail trigger scanner trampoline for each instantiated human.
    targets = []
    for i, w in enumerate(words):
        if (int.from_bytes(w, 'big') >> 26) == 18:
            d = decode_branch(base + i*4, w)
            if d['link']:
                targets.append(d['target'])
    assert targets.count(PLAYER_GET_ENTITY) >= 2
    assert targets.count(trampoline) >= 2


def test_phase39_ground_event_addresses_are_source_grounded():
    assert GROUND_EVENT_SCAN_HOOK == 0x801C0C2C
    assert GROUND_EVENT_SCAN_EXPECTED == bytes.fromhex('7c0802a6')
    assert STAGE_EVENT_FLAGS_ADDR == 0x8049E754
    assert STAGE_EVENT_RESULT_A_ADDR == 0x8049EDDC
    assert STAGE_EVENT_RESULT_B_ADDR == 0x8049EDE8
