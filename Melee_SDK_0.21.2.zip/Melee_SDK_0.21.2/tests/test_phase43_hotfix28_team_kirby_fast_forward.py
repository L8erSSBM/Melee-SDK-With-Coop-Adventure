"""HF28 paced Team-Kirby fast-forward tests."""
from __future__ import annotations

import json
import struct
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, encode_branch
from sdk import team_kirby_fast_forward as hf

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804E3000
HF27 = 0x804E0EA0
OLD = 0x804DF980
REQ = 0x804E2200
LATCHES = (0x804E2201,0x804E2202,0x804E2203,0x804E2204)
REQCNT = 0x804E2208
DRIVECNT = 0x804E220C
RECYCLECNT = 0x804E2210
COMPLETECNT = 0x804E2214
VEC = 0x804DFAC0
SENTINEL = 0x81234560


def put(mem, addr, value, size=4):
    raw=int(value & ((1 << (size*8))-1)).to_bytes(size,'big')
    for i,b in enumerate(raw): mem[addr+i]=b


def get(mem, addr, size=4):
    return int.from_bytes(bytes(mem.get(addr+i,0) for i in range(size)),'big')


def run(*, mem=None, state=0x23, p0_button=0, p0_trigger=0,
        p1_button=0, p1_trigger=0, complete=0, active=1,
        player_states=None, flags=None, stocks=None, entities=None):
    blob=hf.wrapper(BASE,hf27_stub=HF27,request_state_addr=REQ,
                    latch_addrs=LATCHES,request_counter_addr=REQCNT,
                    drive_counter_addr=DRIVECNT,recycle_counter_addr=RECYCLECNT,
                    complete_counter_addr=COMPLETECNT,offscreen_vec_addr=VEC)
    mem={} if mem is None else mem
    put(mem,hf.ADVENTURE_MODE_ADDR,4,1); put(mem,hf.ADVENTURE_STATE_ADDR,state,1)
    for idx,(button,trigger) in enumerate(((p0_button,p0_trigger),(p1_button,p1_trigger))):
        pad=hf.HSD_PAD_COPY_STATUS+hf.PAD_STATUS_STRIDE*idx
        put(mem,pad+hf.PAD_BUTTON_OFF,button); put(mem,pad+hf.PAD_TRIGGER_OFF,trigger)
    regs=[0]*32; regs[1]=0x817FF000
    lr=SENTINEL; cr={2:False,30:False}; pc=BASE; positions=[]
    player_states=dict(player_states or {}); flags=dict(flags or {})
    stocks=dict(stocks or {}); entities=dict(entities or {})

    def s16(x): return x-0x10000 if x&0x8000 else x
    def signed32(x): return x-0x100000000 if x&0x80000000 else x

    for _ in range(8000):
        if pc in (HF27,SENTINEL):
            return {'target':pc,'mem':mem,'positions':positions,'regs':regs}
        retail=(hf.EVENT_ENEMY_IS_COMPLETE,hf.EVENT_ENEMY_IS_ACTIVE,
                hf.PLAYER_GET_PLAYER_STATE,hf.PLAYER_GET_FLAGS_BIT1,
                hf.PLAYER_GET_STOCKS,hf.PLAYER_GET_ENTITY,hf.PLAYER_SET_POSITION)
        if pc in retail:
            slot=regs[3]
            if pc==hf.EVENT_ENEMY_IS_COMPLETE: regs[3]=complete
            elif pc==hf.EVENT_ENEMY_IS_ACTIVE: regs[3]=active
            elif pc==hf.PLAYER_GET_PLAYER_STATE: regs[3]=player_states.get(slot,0)
            elif pc==hf.PLAYER_GET_FLAGS_BIT1: regs[3]=flags.get(slot,0)
            elif pc==hf.PLAYER_GET_STOCKS: regs[3]=stocks.get(slot,0)
            elif pc==hf.PLAYER_GET_ENTITY: regs[3]=entities.get(slot,0)
            elif pc==hf.PLAYER_SET_POSITION: positions.append((slot,regs[4]))
            pc=lr; continue
        if not BASE <= pc < BASE+len(blob): raise AssertionError(hex(pc))
        w=struct.unpack_from('>I',blob,pc-BASE)[0]; op=w>>26; nxt=pc+4
        rt=(w>>21)&31; ra=(w>>16)&31; imm=s16(w&0xffff)
        if op==14: regs[rt]=((regs[ra] if ra else 0)+imm)&0xffffffff
        elif op==15: regs[rt]=((regs[ra] if ra else 0)+(imm<<16))&0xffffffff
        elif op==32: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,4)
        elif op==34: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,1)
        elif op==36: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt],4)
        elif op==37:
            regs[ra]=(regs[ra]+imm)&0xffffffff; put(mem,regs[ra],regs[rt],4)
        elif op==38: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt],1)
        elif op==28:
            regs[ra]=regs[rt] & (w&0xffff); cr[2]=(regs[ra]==0)
        elif op==11:
            av,bv=signed32(regs[ra]),imm; cr[30]=(av==bv)
        elif op==16:
            bd=w&0xfffc
            if bd&0x8000: bd-=0x10000
            bo,bi=(w>>21)&31,(w>>16)&31; bit=cr.get(bi,False)
            if bo==20 or (bo==12 and bit) or (bo==4 and not bit): nxt=(pc+bd)&0xffffffff
        elif op==18:
            info=decode_branch(pc,w.to_bytes(4,'big'))
            if info['link']: lr=(pc+4)&0xffffffff
            nxt=info['target']
        elif op==31:
            if (w & 0xFC1FFFFF)==0x7C0802A6: regs[rt]=lr
            elif (w & 0xFC1FFFFF)==0x7C0803A6: lr=regs[rt]
            else: raise AssertionError(f'op31 {w:08x}')
        elif w==0x4E800020: nxt=lr
        else: raise AssertionError(f'unsupported {w:08x} @ {pc:08x}')
        pc=nxt
    raise AssertionError('wrapper did not terminate')


def chord(): return hf.PAD_BUTTON_L,hf.PAD_BUTTON_DDOWN


def live_env():
    return dict(player_states={2:2,3:2,4:2},flags={2:1,3:1,4:1},
                stocks={2:1,3:1,4:1},entities={2:0x90002000,3:0x90003000,4:0x90004000})


def test_down_latches_and_touches_each_active_generation_once():
    b,t=chord(); r=run(p0_button=b,p0_trigger=t,**live_env())
    assert r['target']==SENTINEL
    assert get(r['mem'],REQ,1)==1 and get(r['mem'],REQCNT)==1
    assert [s for s,_ in r['positions']]==[2,3,4]
    assert [get(r['mem'],x,1) for x in LATCHES]==[1,1,1,0]
    assert get(r['mem'],DRIVECNT)==3

    # Still in KO/death lifecycle: absolutely no repeated position writes.
    r2=run(mem=r['mem'],**live_env())
    assert r2['positions']==[]
    assert get(r2['mem'],DRIVECNT)==3


def test_slot_must_retire_to_zero_before_replacement_can_be_driven():
    b,t=chord(); r=run(p0_button=b,p0_trigger=t,**live_env())
    # Retail fully retires slot 2. HF28 clears its latch but deliberately does
    # not touch a replacement in that same helper invocation.
    env=live_env(); env['player_states'][2]=0; env['stocks'][2]=0; env['entities'][2]=0
    r2=run(mem=r['mem'],**env)
    assert r2['positions']==[]
    assert get(r2['mem'],LATCHES[0],1)==0
    assert get(r2['mem'],RECYCLECNT)==1

    # On a later frame retail has installed the replacement generation.
    env=live_env(); r3=run(mem=r2['mem'],**env)
    assert [s for s,_ in r3['positions']]==[2]
    assert get(r3['mem'],LATCHES[0],1)==1
    assert get(r3['mem'],DRIVECNT)==4


def test_only_state2_flagged_stocked_entity_is_touched():
    b,t=chord(); r=run(p0_button=b,p0_trigger=t,
        player_states={2:1,3:2,4:2,5:2}, flags={2:1,3:0,4:1,5:1},
        stocks={2:1,3:1,4:0,5:1}, entities={2:1,3:1,4:1,5:0})
    assert r['positions']==[]
    assert get(r['mem'],DRIVECNT)==0


def test_retail_complete_stops_without_forcing_match_termination():
    mem={}; put(mem,REQ,1,1)
    for x in LATCHES: put(mem,x,1,1)
    r=run(mem=mem,complete=1,active=0)
    assert r['target']==SENTINEL
    assert get(r['mem'],REQ,1)==0
    assert [get(r['mem'],x,1) for x in LATCHES]==[0,0,0,0]
    assert get(r['mem'],COMPLETECNT)==1
    assert r['positions']==[]


def test_non_team_kirby_delegates_hf27_and_clears_stale_state():
    mem={}; put(mem,REQ,1,1)
    for x in LATCHES: put(mem,x,1,1)
    r=run(mem=mem,state=0x22)
    assert r['target']==HF27
    assert get(r['mem'],REQ,1)==0
    assert [get(r['mem'],x,1) for x in LATCHES]==[0,0,0,0]


def test_wrapper_has_no_direct_match_terminate_or_event_counter_writes():
    blob=hf.wrapper(BASE,hf27_stub=HF27,request_state_addr=REQ,latch_addrs=LATCHES,
                    request_counter_addr=REQCNT,drive_counter_addr=DRIVECNT,
                    recycle_counter_addr=RECYCLECNT,complete_counter_addr=COMPLETECNT,
                    offscreen_vec_addr=VEC)
    targets=[]
    for off in range(0,len(blob),4):
        raw=blob[off:off+4]
        if int.from_bytes(raw,'big')>>26==18:
            targets.append(decode_branch(BASE+off,raw)['target'])
    for target in (hf.PLAYER_GET_PLAYER_STATE,hf.PLAYER_GET_FLAGS_BIT1,
                   hf.PLAYER_GET_STOCKS,hf.PLAYER_GET_ENTITY,hf.PLAYER_SET_POSITION,
                   hf.EVENT_ENEMY_IS_COMPLETE,hf.EVENT_ENEMY_IS_ACTIVE,HF27):
        assert target in targets
    # No fighter destroy, event cleanup, results init, or match-end helper calls.
    assert 0x80031EBC not in targets
    assert 0x8016A164 not in targets
    assert 0x80180630 not in targets


def test_hf27_dol_upgrade_is_contained_to_entry_plus_append(tmp_path):
    src=ROOT/'Build'/'start.dol'
    # At package creation this starts as HF27. If this test is running against
    # the already-upgraded HF28 Build/start.dol, reconstruct HF27 by stripping
    # the final append and restoring HF27's shortcut branch.
    raw=bytearray(src.read_bytes()); dcur=DOLImage(raw)
    marker_off=raw.find(b'HF28TKFF')
    manifest27=json.loads((ROOT/'Build'/'HF27_runtime_manifest.json').read_text())
    old=manifest27['team_kirby_test_warp']['shortcut_entry']
    hf27_stub=manifest27['team_kirby_test_warp']['shortcut_stub']
    sec=next(s for s in dcur.sections if s.kind=='data' and s.index==8)
    if marker_off>0:
        old_size=marker_off-sec.file_offset
        struct.pack_into('>I',raw,0xAC+8*4,old_size)
        entry_off=sec.file_offset+(old-sec.address)
        raw[entry_off:entry_off+4]=encode_branch(old,hf27_stub)
        del raw[marker_off:]
    before=bytes(raw); d=DOLImage(before); sec=next(s for s in d.sections if s.kind=='data' and s.index==8)
    entry_off=sec.file_offset+(old-sec.address)
    result=hf.install(d,8,old_shortcut_addr=old,hf27_stub=hf27_stub,offscreen_vec_addr=VEC)
    dst=tmp_path/'hf28.dol'; d.save_as(dst); after=dst.read_bytes(); d2=DOLImage(dst)
    assert d2.read_at_address(result['section']['address'],8)==b'HF28TKFF'
    assert decode_branch(old,d2.read_at_address(old,4))['target']==result['stub_address']
    diffs=[i for i,(a,b) in enumerate(zip(before,after[:len(before)])) if a!=b]
    allowed=set(range(entry_off,entry_off+4)) | set(range(0xAC+8*4,0xAC+8*4+4))
    assert set(diffs)<=allowed
