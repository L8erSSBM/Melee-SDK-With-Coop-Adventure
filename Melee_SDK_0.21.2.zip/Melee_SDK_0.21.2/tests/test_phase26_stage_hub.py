from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

from sdk.stage_select_pages import (
    build_project_page_set, runtime_plan, visual_manifest, mode_dispatch_contract,
    PRIMARY_STAGE_SLOTS, MODE_SLOTS, RETAIL_SLOT_SKINS, StagePageSet,
)


def _project(count=3):
    resources=[]; stages=[]
    for i in range(count):
        fn=f'GrX{i}.dat'
        resources.append({'filename':fn,'source_relative':'<authored>','authored_new':True})
        stages.append(SimpleNamespace(filename=fn,display_name=f'Custom {i}'))
    return SimpleNamespace(manifest={'resources':resources},stages=stages)


def test_sparse_first_custom_page_uses_requested_bottom_row():
    pages=build_project_page_set(_project(3))
    p=pages.pages[1]
    stages=[e for e in p.entries if e.kind=='stage']
    by_title={e.title:e for e in stages}
    assert by_title['Custom 0'].grid_slot == 24  # Battlefield
    assert by_title['Custom 1'].grid_slot == 26  # Dream Land
    assert by_title['Custom 2'].grid_slot == 25  # Final Destination
    assert {e.grid_slot for e in p.entries if e.kind=='mode'} == set(MODE_SLOTS)
    assert all(RETAIL_SLOT_SKINS[e.preview_slot]['model_group']=='x20' for e in p.entries)


def test_custom_page_stays_sparse_until_needed():
    pages=build_project_page_set(_project(4))
    p=pages.pages[1]
    stage_slots=[e.grid_slot for e in p.entries if e.kind=='stage']
    assert set(PRIMARY_STAGE_SLOTS).issubset(set(stage_slots))
    assert 0 in stage_slots  # first overflow uses the regular x40 grid


def test_runtime_plan_has_indicator_animation_and_direct_coop_dispatch():
    pages=build_project_page_set(_project(2))
    plan=runtime_plan(pages)
    assert plan['page_indicator']['enabled'] is True
    assert plan['page_switch']['transition']['style']=='retail-icon-pulse'
    assert plan['mode_dispatch']['coop_adventure']['entry_scene'].startswith('retail Adventure')
    assert 'gm_8017CE34' in plan['mode_dispatch']['coop_adventure']['runtime_touchpoints']
    assert any(x['launch_action']=='launch_coop_adventure' for x in plan['mode_launchers'])


def test_visual_manifest_uses_retail_skin_until_thumbnail_assigned():
    pages=build_project_page_set(_project(1))
    vm=visual_manifest(pages)
    tiles=vm['pages'][1]['tiles']
    stage=next(x for x in tiles if x['kind']=='stage')
    assert stage['visual_source']=='retail-slot-skin'
    assert stage['retail_skin_name']=='Battlefield'
    e=next(e for e in pages.pages[1].entries if e.kind=='stage')
    e.thumbnail_path='thumb.png'
    vm2=visual_manifest(pages)
    stage2=next(x for x in vm2['pages'][1]['tiles'] if x['kind']=='stage')
    assert stage2['visual_source']=='custom-thumbnail'


def test_v1_pages_still_load():
    raw={'format':'melee-sdk-stage-pages-v1','wrap_pages':True,'page_up_mask':8,'page_down_mask':4,'pages':[
        {'page_id':'retail','title':'Retail','builtin_retail':True,'entries':[]},
        {'page_id':'custom','title':'Custom','entries':[{'entry_id':'s:a','title':'A','kind':'stage','stage_filename':'GrXa.dat','preview_slot':24,'enabled':True,'notes':''}]}
    ]}
    p=StagePageSet.from_dict(raw)
    assert p.pages[1].entries[0].grid_slot==24


def test_mode_dispatch_contract_is_not_fake_stage_launch():
    c=mode_dispatch_contract()['coop_adventure']
    assert c['type']=='mode'
    assert c['launch_action']=='launch_coop_adventure'
    assert 'do not convert' in c['resource_policy']
