from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
BUILD = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')


def test_static_fallback_remains_exact_retail():
    assert "STATIC_FIGHTER_SPAWN_SLOT_HOOK = 0x8016E48C" in SRC
    assert "dol.patch_at_address(STATIC_FIGHTER_SPAWN_SLOT_HOOK" not in SRC


def test_slippi_spawn_guard_hooks_immediately_before_runtime_site():
    assert "MULTISLOT_POST_COORD_HOOK = 0x8016E50C" in SRC
    assert "MULTISLOT_POST_COORD_EXPECTED = bytes.fromhex('4bec425d')" in SRC
    assert "MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE = 0x8016E510" in SRC
    assert "MULTISLOT_RETAIL_CONTINUE = 0x8016E514" in SRC
    assert "dol.patch_at_address(MULTISLOT_POST_COORD_HOOK" in SRC


def test_adventure_path_executes_retail_teamflag_and_skips_slippi_site():
    from sdk.adventure_probe import (
        _adventure_slippi_spawn_guard_wrapper,
        MULTISLOT_RETAIL_TEAMFLAG_OFFSET,
    )
    blob = _adventure_slippi_spawn_guard_wrapper(0x80400E80)
    # lbz r0,0x24D0(r31) == exact retail instruction displaced from 0x8016E510.
    assert bytes.fromhex('881f24d0') in blob
    assert MULTISLOT_RETAIL_TEAMFLAG_OFFSET == 0x24D0
    # Layout stays fixed so later validated runtime blobs do not move.
    assert len(blob) == 144


def test_non_adventure_contract_preserves_slippi_runtime_site():
    assert 'Non-Adventure: recreate original LR and return to the real site' in SRC
    assert "ProbeHook('adventure_slippi_spawn_normalizer_bypass'" in SRC
    assert 'non-Adventure returns to 0x8016E510 so Slippi runtime spawn normalization remains active' in SRC


def test_builder_branding_is_0209():
    assert 'MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in BUILD
    assert '_MeleeSDK_0.20.18.iso' in BUILD
    assert "'sdk_version':'0.20.18'" in SRC


def test_wrapper_runtime_contract_adventure_skips_slippi_but_keeps_original_bl_lr():
    from sdk.adventure_probe import (
        _adventure_slippi_spawn_guard_wrapper,
        MULTISLOT_POSITION_COMMIT,
        MULTISLOT_RETAIL_CONTINUE,
        MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE,
    )
    from hf29d_ppc import execute, put
    base = 0x80400E80
    mem = {}
    put(mem, 0x80479D30, 4, 1)  # GM_ADVENTURE
    put(mem, 0x812024D0, 0x5A, 1)  # r31 + 0x24D0
    seen = []
    def commit(regs, mem):
        seen.append((regs[3], regs[4]))
    result = execute(
        _adventure_slippi_spawn_guard_wrapper(base), base,
        mem=mem, initial_regs={3: 2, 4: 0x817FEF00, 31: 0x81200000},
        callees={MULTISLOT_POSITION_COMMIT: commit},
        stop_targets=(MULTISLOT_RETAIL_CONTINUE, MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE),
    )
    assert seen == [(2, 0x817FEF00)]
    assert result['target'] == MULTISLOT_RETAIL_CONTINUE
    assert result['regs'][0] == 0x5A
    assert result['lr'] == MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE


def test_wrapper_runtime_contract_non_adventure_returns_to_slippi_site():
    from sdk.adventure_probe import (
        _adventure_slippi_spawn_guard_wrapper,
        MULTISLOT_POSITION_COMMIT,
        MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE,
    )
    from hf29d_ppc import execute, put
    base = 0x80400E80
    mem = {}
    put(mem, 0x80479D30, 2, 1)  # non-Adventure
    seen = []
    def commit(regs, mem):
        seen.append((regs[3], regs[4]))
    result = execute(
        _adventure_slippi_spawn_guard_wrapper(base), base,
        mem=mem, initial_regs={3: 1, 4: 0x817FEF00, 31: 0x81200000},
        callees={MULTISLOT_POSITION_COMMIT: commit},
        stop_targets=(MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE,),
    )
    assert seen == [(1, 0x817FEF00)]
    assert result['target'] == MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE
    assert result['lr'] == MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE
