from pathlib import Path

from sdk import adventure_probe as a
from sdk import team_kirby_retail_warp as warp
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]


def test_new_retail_hook_bytes_match_historical_dol():
    dol = DOLImage((ROOT/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    assert dol.read_at_address(a.STAFFROLL_SHOT_NODE8_LOOKUP_CALL,4) == a.STAFFROLL_SHOT_NODE8_LOOKUP_EXPECTED
    assert dol.read_at_address(a.STAFFROLL_SCENE_EXIT_HOOK,4) == a.STAFFROLL_SCENE_EXIT_EXPECTED


def test_p2_shot_node8_uses_clone_child_not_clone_relative_index():
    base=0x804F7000; pass_addr=0x804F6800; ptr_addr=pass_addr+4
    out_ptr=0x817FEF00; retail_node8=0x81230080; p2_root=0x81240000; p2_node8=0x81240100
    blob=a._staffroll_p2_shot_node8_lookup_wrapper(base,pass_addr,ptr_addr)

    def retail_lookup(regs,mem):
        assert regs[5] == 8
        put(mem,regs[4],retail_node8,4)

    mem={}; put(mem,pass_addr,1,1); put(mem,ptr_addr,p2_root,4); put(mem,p2_root+0x10,p2_node8,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000,4:out_ptr,5:8,6:0xFFFFFFFF},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert get(mem,out_ptr,4) == p2_node8

    mem={}; put(mem,pass_addr,0,1); put(mem,ptr_addr,p2_root,4); put(mem,p2_root+0x10,p2_node8,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000,4:out_ptr,5:8,6:0xFFFFFFFF},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert get(mem,out_ptr,4) == retail_node8

    # Missing clone child must safely preserve the retail result.
    mem={}; put(mem,pass_addr,1,1); put(mem,ptr_addr,p2_root,4); put(mem,p2_root+0x10,0,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000,4:out_ptr,5:8,6:0xFFFFFFFF},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert get(mem,out_ptr,4) == retail_node8


def test_terminal_guard_retires_p2_before_retail_teardown_and_leaves_onexit_retail():
    base=0x804F7200; active=0x804F6800; pass_addr=active+1
    assembly_addr=active+4; cursor_addr=active+8; diag=active+12
    blob=a._staffroll_dual_lens_proc(base,active,pass_addr,assembly_addr,cursor_addr,diag)
    calls=[]
    def retail_proc(regs,mem):
        calls.append(get(mem,pass_addr,1))

    mem={}; put(mem,active,1,1); put(mem,assembly_addr,0x81230000,4); put(mem,cursor_addr,0x81240000,4)
    put(mem,a.STAFFROLL_TIMELINE_COUNTER_ADDR,a.STAFFROLL_INTERACTIVE_END_FRAME,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000},callees={a.STAFFROLL_RETAIL_PROC:retail_proc})
    assert calls == [0]
    assert get(mem,assembly_addr,4) == 0
    assert get(mem,cursor_addr,4) == 0
    assert get(mem,pass_addr,1) == 0
    assert get(mem,diag,1) == 0xC1


def test_current_installer_patches_both_shot_lookups_and_leaves_onexit_retail():
    src=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    assert 'STAFFROLL_SHOT_NODE5_LOOKUP_CALL,credits_shot5_branch' in src
    assert 'STAFFROLL_SHOT_NODE8_LOOKUP_CALL,credits_shot8_branch' in src
    assert 'dol.patch_at_address(STAFFROLL_SCENE_EXIT_HOOK' not in src
    assert '_staffroll_p2_shot_node5_lookup_wrapper' in src
    assert '_staffroll_p2_shot_node8_lookup_wrapper' in src

def test_bowser_warp_target_is_fight_state_and_preserves_historical_default():
    assert warp.TEAM_KIRBY_FIGHT_STATE == 0x23
    assert warp.BOWSER_FIGHT_STATE == 0x59

    base=0x804F7600; flag=0x804F7400; applied=flag+4
    blob=warp.routing_wrapper(base,warp_flag_addr=flag,applied_counter_addr=applied,target_state=warp.BOWSER_FIGHT_STATE)
    mem={}; put(mem,flag,1,1); put(mem,warp.ADVENTURE_NEXT_STATE_ADDR,0x03,1)
    put(mem,warp.ADVENTURE_STATE_ADDR,0x01,1)
    result=execute(blob,base,mem=mem,initial_regs={31:0x80479D30},stop_targets=(warp.ROUTING_RETURN,))
    assert result['target'] == warp.ROUTING_RETURN
    # Routing engine stores target+1.
    assert get(mem,warp.ADVENTURE_NEXT_STATE_ADDR,1) == 0x5A
    assert get(mem,flag,1) == 0
    assert get(mem,applied,4) == 1

    historical=warp.routing_wrapper(base,warp_flag_addr=flag,applied_counter_addr=applied)
    mem={}; put(mem,flag,1,1); put(mem,warp.ADVENTURE_NEXT_STATE_ADDR,0x03,1); put(mem,warp.ADVENTURE_STATE_ADDR,1,1)
    execute(historical,base,mem=mem,initial_regs={31:0x80479D30},stop_targets=(warp.ROUTING_RETURN,))
    assert get(mem,warp.ADVENTURE_NEXT_STATE_ADDR,1) == 0x24


def test_current_adventure_installer_selects_bowser_target():
    src=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    assert 'from .team_kirby_retail_warp import BOWSER_FIGHT_STATE' in src
    assert 'target_state=BOWSER_FIGHT_STATE' in src
