from sdk import slippi_adventure_netplay_bridge as nb
from tests.hf29d_ppc import execute, get, put

R13=0x80400000
BASE=0x804FC000
STATE=0x804F6800
PENDING=0x804F6700
ACTIVE=0x804F6701
PATCH=0x804FD100

def _seed(mem):
    put(mem,STATE+nb.S_PHASE,nb.PHASE_TRANSITION,1)
    put(mem,STATE+nb.S_LOCAL_INDEX,0,1)
    put(mem,STATE+nb.S_ARM_ONLINE_INDEX,1,1)
    put(mem,STATE+nb.S_ARM_INPUT_SOURCE_INDEX,0,1)
    put(mem,PENDING,0,1); put(mem,ACTIVE,1,1)
    put(mem,nb.GM_SCENE_WORD_ADDR,0x04000002,4)

def test_k10_removes_k9_global_scene_shadow_to_restore_adventure_presentation_barrier():
    mem={}; _seed(mem)
    blob=nb.build_exi_wrapper(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,patch_table_addr=PATCH)
    req=0x81201000; put(mem,req,nb.ONLINE_INPUTS,1)
    r=execute(blob,BASE,mem=mem,initial_regs={3:req,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert r['target']==nb.SLIPPI_EXI_TRANSFER
    assert get(mem,nb.GM_SCENE_WORD_ADDR,4)==0x04000002
    assert get(mem,STATE+nb.S_SCENE_SHADOW_ACTIVE,1)==0

def test_k10_transition_does_not_zero_sscb_or_prediction_ring():
    mem={}; _seed(mem)
    for i in range(0xDF,0x3A0): put(mem,nb.STABLE_ODB+i,(i*7+3)&0xff,1)
    for i in range(nb.SSCB_SIZE): put(mem,nb.STABLE_SSCB+i,(i*5+1)&0xff,1)
    odb=bytes(get(mem,nb.STABLE_ODB+i,1) for i in range(0xDF,0x3A0))
    sscb=bytes(get(mem,nb.STABLE_SSCB+i,1) for i in range(nb.SSCB_SIZE))
    blob=nb.build_exi_wrapper(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,patch_table_addr=PATCH)
    req=0x81201000; put(mem,req,nb.ONLINE_INPUTS,1)
    execute(blob,BASE,mem=mem,initial_regs={3:req,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert bytes(get(mem,nb.STABLE_ODB+i,1) for i in range(0xDF,0x3A0))==odb
    assert bytes(get(mem,nb.STABLE_SSCB+i,1) for i in range(nb.SSCB_SIZE))==sscb

def test_k10_physical_port1_remains_independent_from_logical_player():
    mem={}; _seed(mem)
    put(mem,STATE+nb.S_LOCAL_INDEX,1,1)
    put(mem,STATE+nb.S_ARM_ONLINE_INDEX,0,1)
    put(mem,STATE+nb.S_ARM_INPUT_SOURCE_INDEX,0,1)
    blob=nb.build_exi_wrapper(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,patch_table_addr=PATCH)
    req=0x81201000; put(mem,req,nb.ONLINE_INPUTS,1)
    execute(blob,BASE,mem=mem,initial_regs={3:req,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert get(mem,nb.STABLE_ODB+nb.ODB_LOCAL_PLAYER_INDEX,1)==1
    assert get(mem,nb.STABLE_ODB+nb.ODB_ONLINE_PLAYER_INDEX,1)==0
    assert get(mem,nb.STABLE_ODB+nb.ODB_INPUT_SOURCE_INDEX,1)==0
