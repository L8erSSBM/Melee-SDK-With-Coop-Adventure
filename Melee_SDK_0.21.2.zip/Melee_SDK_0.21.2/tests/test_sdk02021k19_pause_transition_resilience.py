from sdk import slippi_adventure_netplay_bridge as nb


def test_k19_enables_pause_pair_but_not_match_end_or_teams_aux_hooks():
    enabled={g.name for g in nb.ACTIVE_GUARDS}
    assert {'init_client_pause','prevent_pause_stranding'} <= enabled
    assert {'report_no_contest_lras','lgl_game_end_message','customize_lras_message','teams_prevent_dead_stranding'}.isdisjoint(enabled)
    assert len(nb.ACTIVE_GUARDS)==14
    assert len(nb.AUX_SCENE_GUARDS)==4


def test_k19_cleanup_has_online_major_scene_fence():
    blob=nb.build_exi_wrapper(0x804F2000, pending_addr=0x804F1000,
        active_addr=0x804F1001, state_addr=0x804F1100,
        snapshot_table_addr=None, patch_table_addr=0x804F3000,
        prime_addr=None, snapshot_addr=None)
    # The cleanup path now reads gm scene-controller 0x80479D30 and compares
    # the current major byte with Online major 8 before restoring patches.
    assert nb.GM_SCENE_WORD_ADDR.to_bytes(4,'big') not in blob  # address is emitted as lis/lbz, not literal data
    assert b'\x3d\x80\x80\x48' in blob  # lis r12,0x8048
    assert b'\x2f\x8b\x00\x08' in blob or b'\x2f\x0b\x00\x08' in blob or b'\x2c\x0b\x00\x08' in blob
