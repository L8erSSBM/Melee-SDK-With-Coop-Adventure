from __future__ import annotations

import hashlib
import json
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from sdk import adventure_gateway_scope as scope

ROOT = Path(__file__).resolve().parents[1]


def _manifest():
    return json.loads((ROOT / 'Build' / 'HF29G_runtime_manifest.json').read_text())


def _hf29f_dol():
    return ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol'


def _hf29g_dol():
    return ROOT / 'Build' / 'historical' / 'HF29G_GATEWAY_SCOPED_COOP_GAMEOVER_RETURN.dol'


def test_hf29g_source_installer_reproduces_packaged_dol_byte_for_byte():
    m = json.loads((ROOT / 'Build' / 'HF29F_runtime_manifest.json').read_text())
    d = DOLImage(_hf29f_dol())
    pending = m['probe_section']['address'] + 0x2E
    result = scope.install(d, m['probe_section']['index'], gateway_pending_addr=pending)
    assert result['marker'] == 'HF29GSCP'
    assert bytes(d.raw) == _hf29g_dol().read_bytes()


def test_gateway_scope_manifest_and_active_state_contract():
    m = _manifest()
    s = m['adventure_gateway_scope']
    assert m['format'].endswith('hf29g-gateway-scoped-gameover-return')
    assert s['marker'] == 'HF29GSCP'
    assert s['scope'].startswith('gateway sentinel + two Humans only')
    assert s['gateway_pending_address'] == m['probe_section']['address'] + 0x2E
    active = s['gateway_coop_active_address']
    assert s['section']['address'] <= active < s['section']['address'] + s['section']['size']
    assert len(s['guarded_hooks']) == len(scope.CORE_GUARDS) == 24


def test_all_behavior_guards_replace_hf29f_sites_and_keep_old_targets_recorded():
    d = DOLImage(_hf29g_dol())
    m = _manifest()['adventure_gateway_scope']
    rows = {row['site_address']: row for row in m['guarded_hooks']}
    assert set(rows) == {spec.site for spec in scope.CORE_GUARDS}
    for spec in scope.CORE_GUARDS:
        row = rows[spec.site]
        raw = d.read_at_address(spec.site, 4)
        dec = decode_branch(spec.site, raw)
        assert dec['target'] == row['guard_stub']
        assert dec['link'] == row['site_link']
        assert row['retail_instruction'] == spec.retail.hex()
        # HF29G composes over the proven handler instead of replacing it.
        assert row['hf29f_target'] != row['guard_stub']


def test_onload_captures_scope_before_existing_gateway_wrapper():
    d = DOLImage(_hf29g_dol())
    row = _manifest()['adventure_gateway_scope']['onload_hook']
    dec = decode_branch(scope.ADVENTURE_ONLOAD, d.read_at_address(scope.ADVENTURE_ONLOAD, 4))
    assert dec['link'] is False
    assert dec['target'] == row['scope_stub']
    # The old Phase-43 gateway OnLoad wrapper is still the downstream target.
    assert row['previous_target'] != row['scope_stub']


def test_game_over_is_origin_return_only_for_active_gateway_coop():
    d = DOLImage(_hf29g_dol())
    hf29f = DOLImage(_hf29f_dol())
    row = _manifest()['adventure_gateway_scope']['game_over']

    # HF29F / retail path was the genuine Adventure Game Over state selector.
    assert hf29f.read_at_address(scope.GAME_OVER_STATE_CALL, 4) == scope.GAME_OVER_STATE_EXPECTED
    assert decode_branch(scope.GAME_OVER_STATE_CALL, scope.GAME_OVER_STATE_EXPECTED)['target'] == scope.GM_SET_NEXT_GAME_MODE_STATE_ID

    # HF29G sends that call through the active-scope wrapper.
    dec = decode_branch(scope.GAME_OVER_STATE_CALL, d.read_at_address(scope.GAME_OVER_STATE_CALL, 4))
    assert dec['link'] is True
    assert dec['target'] == row['scope_stub']
    assert 'Continue untouched' in row['inactive_behavior']
    assert 'prev_mode' in row['active_behavior']


def test_hf29f_origin_rewrite_is_now_explicitly_coop_scoped():
    d = DOLImage(_hf29g_dol())
    rows = _manifest()['adventure_gateway_scope']['origin_return_guards']
    assert [r['site_address'] for r in rows] == [
        scope.ABORT_RETURN_CALL,
        scope.CSS_CANCEL_RETURN_CALL,
        scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL,
    ]
    for row in rows:
        dec = decode_branch(row['site_address'], d.read_at_address(row['site_address'], 4))
        assert dec['link'] is True
        assert dec['target'] == row['guard_stub']


def test_hf29g_binary_containment_relative_to_hf29f():
    old = _hf29f_dol().read_bytes()
    new = _hf29g_dol().read_bytes()
    m = _manifest()['adventure_gateway_scope']
    assert len(new) > len(old)
    assert new[m['section']['file_offset']:m['section']['file_offset'] + 8] == b'HF29GSCP'

    # Inside the old binary, only the DOL section-size field and the explicit
    # dispatch sites may change. All proven HF29E/F handler bodies stay intact.
    d = DOLImage(_hf29g_dol())
    changed = {i for i, (a, b) in enumerate(zip(old, new)) if a != b}
    allowed = set(range(0xCE, 0xD0))
    sites = [scope.ADVENTURE_ONLOAD, scope.GAME_OVER_STATE_CALL]
    sites += [x.site for x in scope.CORE_GUARDS]
    sites += [scope.ABORT_RETURN_CALL, scope.CSS_CANCEL_RETURN_CALL,
              scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL]
    for site in sites:
        off = d.file_offset_for_address(site, 4)
        allowed.update(range(off, off + 4))
    assert changed <= allowed


def test_packaged_hash_matches_manifest():
    raw = _hf29g_dol().read_bytes()
    m = _manifest()
    assert hashlib.sha1(raw).hexdigest() == m['output_sha1']
    assert hashlib.sha256(raw).hexdigest() == m['output_sha256']
    assert len(raw) == m['output_size']
