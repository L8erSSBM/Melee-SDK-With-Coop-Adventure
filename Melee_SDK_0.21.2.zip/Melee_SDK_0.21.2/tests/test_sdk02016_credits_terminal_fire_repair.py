from pathlib import Path

from sdk import adventure_probe as a
from sdk.dol_patch import DOLImage
from sdk.ppc import li, lwz
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]


def test_both_staffroll_shot_lookup_bytes_match_historical_dol():
    dol = DOLImage((ROOT/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    assert dol.read_at_address(a.STAFFROLL_SHOT_NODE5_LOOKUP_CALL,4) == a.STAFFROLL_SHOT_NODE5_LOOKUP_EXPECTED
    assert dol.read_at_address(a.STAFFROLL_SHOT_NODE8_LOOKUP_CALL,4) == a.STAFFROLL_SHOT_NODE8_LOOKUP_EXPECTED
    assert dol.read_at_address(a.STAFFROLL_SCENE_EXIT_HOOK,4) == a.STAFFROLL_SCENE_EXIT_EXPECTED


def test_p2_node5_fire_lookup_substitutes_complete_shooter_root_only_on_p2_pass():
    base=0x804F8000; pass_addr=0x804F7800; assembly_addr=pass_addr+4
    out_ptr=0x817FEF00; retail_node5=0x81230050; p2_node5=0x81240050
    blob=a._staffroll_p2_shot_node5_lookup_wrapper(base,pass_addr,assembly_addr)

    def retail_lookup(regs,mem):
        assert regs[5] == 5
        put(mem,regs[4],retail_node5,4)

    mem={}; put(mem,pass_addr,1,1); put(mem,assembly_addr,p2_node5,4)
    execute(blob,base,mem=mem,initial_regs={4:out_ptr,5:5},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert get(mem,out_ptr,4) == p2_node5

    mem={}; put(mem,pass_addr,0,1); put(mem,assembly_addr,p2_node5,4)
    execute(blob,base,mem=mem,initial_regs={4:out_ptr,5:5},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert get(mem,out_ptr,4) == retail_node5


def test_setup_targets_node5_and_derives_cursor_as_child_then_next():
    base=0x804F8200
    blob=a._staffroll_setup_proc_wrapper(
        base,0x804F7800,0x804F7801,0x804F7804,0x804F7808,0x804F8100
    )
    words=[blob[i:i+4] for i in range(0,len(blob),4)]
    assert li(5,5) in words
    # clone5->child(node6)->next(node7)
    assert lwz(10,0x10,11) in words
    assert lwz(10,0x08,10) in words


def test_terminal_frame_skips_p2_pass_clears_sdk_state_and_runs_one_retail_pass():
    base=0x804F8400; active=0x804F7900; pass_addr=active+1
    assembly_addr=active+4; cursor_addr=active+8; diag=active+12
    blob=a._staffroll_dual_lens_proc(base,active,pass_addr,assembly_addr,cursor_addr,diag)
    calls=[]
    def retail_proc(regs,mem):
        calls.append(get(mem,pass_addr,1))

    for frame in (a.STAFFROLL_INTERACTIVE_END_FRAME,4744,4746):
        calls.clear(); mem={}
        put(mem,active,1,1); put(mem,assembly_addr,0x81230000,4); put(mem,cursor_addr,0x81240000,4)
        put(mem,a.STAFFROLL_TIMELINE_COUNTER_ADDR,frame,4)
        execute(blob,base,mem=mem,initial_regs={3:0x81200000},callees={a.STAFFROLL_RETAIL_PROC:retail_proc})
        assert calls == [0]
        assert get(mem,assembly_addr,4) == 0
        assert get(mem,cursor_addr,4) == 0
        assert get(mem,pass_addr,1) == 0
        assert get(mem,diag,1) == 0xC1


def test_preterminal_frame_still_runs_p2_then_p1():
    base=0x804F8600; active=0x804F7A00; pass_addr=active+1
    assembly_addr=active+4; cursor_addr=active+8; diag=active+12
    blob=a._staffroll_dual_lens_proc(base,active,pass_addr,assembly_addr,cursor_addr,diag)
    calls=[]
    def retail_proc(regs,mem):
        calls.append(get(mem,pass_addr,1))
    mem={}; put(mem,active,1,1); put(mem,assembly_addr,0x81230000,4); put(mem,cursor_addr,0x81240000,4)
    put(mem,a.STAFFROLL_TIMELINE_COUNTER_ADDR,a.STAFFROLL_INTERACTIVE_END_FRAME-1,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000},callees={a.STAFFROLL_RETAIL_PROC:retail_proc})
    assert calls == [1,0]
    assert get(mem,assembly_addr,4) == 0x81230000
    assert get(mem,cursor_addr,4) == 0x81240000
    assert get(mem,diag,1) == 0


def test_current_installer_hooks_node5_and_node8_but_not_staffroll_onexit():
    src=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    assert 'dol.patch_at_address(STAFFROLL_SHOT_NODE5_LOOKUP_CALL,credits_shot5_branch' in src
    assert 'dol.patch_at_address(STAFFROLL_SHOT_NODE8_LOOKUP_CALL,credits_shot8_branch' in src
    assert 'dol.patch_at_address(STAFFROLL_SCENE_EXIT_HOOK' not in src
    assert "'terminal_frame':STAFFROLL_INTERACTIVE_END_FRAME" in src
    assert "'sdk_version':'0.20.18'" in src
