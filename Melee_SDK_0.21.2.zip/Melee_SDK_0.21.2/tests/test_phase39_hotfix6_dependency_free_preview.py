from pathlib import Path
import builtins
import struct

from sdk.stage_preview import _Raster


def test_builtin_png_writer_emits_valid_png(tmp_path):
    out = tmp_path / 'preview.png'
    r = _Raster(32, 24)
    r.line(0, 0, 31, 23, (0, 0, 0), 2)
    r.disc(16, 12, 4, (30, 170, 80))
    r.save_png(out)
    data = out.read_bytes()
    assert data.startswith(b'\x89PNG\r\n\x1a\n')
    assert b'IHDR' in data and b'IDAT' in data and data.endswith(b'IEND\xaeB`\x82')
    assert struct.unpack('>II', data[16:24]) == (32, 24)


def test_stage_preview_source_no_longer_requires_pillow_message():
    src = Path(__file__).parents[1] / 'sdk' / 'stage_preview.py'
    text = src.read_text(encoding='utf-8')
    assert 'Draft PNG preview requires Pillow' not in text
    assert '_render_dependency_free' in text
