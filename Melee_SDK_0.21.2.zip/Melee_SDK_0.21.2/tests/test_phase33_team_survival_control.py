from pathlib import Path

from sdk.adventure_probe import (
    _respawn_platform_wrapper, _team_stock_wrapper,
    FFA_P1_STOCK_HOOK, FFA_P1_STOCK_EXPECTED,
    TEAM_P1_STOCK_HOOK, TEAM_P1_STOCK_EXPECTED,
    PLAYER_GET_STOCKS, PLAYER_GET_P1_STOCK,
    GAME_CAMERA_OWNER_SLOT, install_phase30_coop_spawn_probe,
)
from sdk.ppc import decode_branch, li


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def _direct_calls(base, raw):
    out=[]
    for i,w in enumerate(_words(raw)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            d=decode_branch(base+i*4,w)
            if d['link']:
                out.append(d['target'])
    return out


def test_phase33_source_grounded_p1_stock_callsites():
    assert FFA_P1_STOCK_HOOK == 0x8016BFA0
    assert FFA_P1_STOCK_EXPECTED.hex() == '4bec7cad'
    assert decode_branch(FFA_P1_STOCK_HOOK, FFA_P1_STOCK_EXPECTED)['target'] == PLAYER_GET_P1_STOCK
    assert TEAM_P1_STOCK_HOOK == 0x8016C0F4
    assert TEAM_P1_STOCK_EXPECTED.hex() == '4bec7b59'
    assert decode_branch(TEAM_P1_STOCK_HOOK, TEAM_P1_STOCK_EXPECTED)['target'] == PLAYER_GET_P1_STOCK


def test_phase33_team_stock_wrapper_queries_both_humans_and_preserves_retail():
    base=0x804DF600
    raw=_team_stock_wrapper(base, 0x804DF020)
    calls=_direct_calls(base,raw)
    assert calls.count(PLAYER_GET_STOCKS) == 3  # P1; P2 fallback; P2 elimination check
    assert calls.count(PLAYER_GET_P1_STOCK) == 1  # non-Adventure retail path
    assert li(3,0) in _words(raw)
    assert li(3,1) in _words(raw)


def test_phase33_respawn_control_can_handoff_both_directions():
    base=0x804DF400
    raw=_respawn_platform_wrapper(base, 0x804DF020)
    words=_words(raw)
    assert li(11,1) in words  # P1 dies -> P2 owns Control
    assert li(11,0) in words  # P2 dies -> P1 owns Control
    assert GAME_CAMERA_OWNER_SLOT == 0x80452F2C


def test_phase33_install_patches_both_outcome_checks(tmp_path):
    clean=Path('/mnt/data/main.dol')
    if not clean.exists():
        return
    out=tmp_path/'phase33.dol'
    m=install_phase30_coop_spawn_probe(clean, Path('data/runtime_symbols_GALE01.txt'), out)
    hooks={x['name']:x for x in m['hooks']}
    assert hooks['ffa_team_stock_outcome']['stub_address'] == hooks['team_team_stock_outcome']['stub_address']
    assert m['probe_contract']['live_team_elimination'] == 'game_over_only_when_p1_and_p2_stocks_are_zero'
    assert m['probe_contract']['camera_control']['initial_owner'] == 0
