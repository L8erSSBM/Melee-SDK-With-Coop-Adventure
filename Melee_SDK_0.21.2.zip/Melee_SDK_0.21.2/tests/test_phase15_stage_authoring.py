import math
import struct

from sdk.stage import StageDAT


def archive_from_data(data, relocs, publics):
    sym = bytearray(); pairs=[]
    for off,name in publics:
        so=len(sym); sym += name.encode('ascii')+b'\0'; pairs.append((off,so))
    meta=b''.join(struct.pack('>I',r) for r in relocs)
    meta+=b''.join(struct.pack('>II',*x) for x in pairs)
    body=bytes(data)+meta+bytes(sym)
    header=bytearray(0x20); struct.pack_into('>5I',header,0,0x20+len(body),len(data),len(relocs),len(pairs),0); header[0x14:0x18]=b'0011'
    return bytes(header)+body


def make_marker_stage():
    data=bytearray(0x500)
    # coll_data minimal, two verts and one floor line, one joint
    struct.pack_into('>IiIi10hIiI',data,0x00,0x80,2,0xA0,1,0,1,1,0,1,0,1,0,0,0,0xC0,1,0)
    struct.pack_into('>4f',data,0x80,-10,0,10,0)
    struct.pack_into('>HHhhhhHH',data,0xA0,0,1,-1,-1,-1,-1,1,0x0203)
    struct.pack_into('>10h4f2h',data,0xC0,0,1,1,0,1,0,1,0,0,0,-10,-1,10,1,0,2)
    # map_head @ 0x100: marker entry table @0x140, one entry.
    struct.pack_into('>Ii',data,0x100,0x140,1)
    # entry: root joint @0x180, pair table @0x280, five marker pairs
    struct.pack_into('>IIi',data,0x140,0x180,0x280,5)
    # Joint tree: root has child chain of five markers. Root translation 10,20.
    def joint(off, child=0, nxt=0, pos=(0,0,0), scale=(1,1,1), rot=(0,0,0)):
        struct.pack_into('>IIII',data,off,0,0,child,nxt)
        struct.pack_into('>3f',data,off+0x14,*rot); struct.pack_into('>3f',data,off+0x20,*scale); struct.pack_into('>3f',data,off+0x2C,*pos)
    root=0x180; nodes=[0x1C0,0x200,0x240,0x300,0x340]
    joint(root,child=nodes[0],pos=(10,20,0))
    for i,off in enumerate(nodes): joint(off,nxt=(nodes[i+1] if i+1<len(nodes) else 0),pos=((i-2)*50,(i%2)*40,0))
    # Preorder root=0; child siblings are 1..5. IDs camera center/range/blast.
    for i,mid in enumerate((0x94,0x95,0x96,0x97,0x98)):
        struct.pack_into('>hh',data,0x280+i*4,i+1,mid)
    # GroundParam @0x400
    struct.pack_into('>f',data,0x400,1.0); struct.pack_into('>I',data,0x44C,0); struct.pack_into('>Ii',data,0x4B0,0,0)
    relocs=[0x00,0x08,0x24,0x100,0x140,0x144,root+8]
    for i,off in enumerate(nodes[:-1]): relocs.append(off+0x0C)
    return archive_from_data(data,relocs,[(0,'coll_data'),(0x100,'map_head'),(0x400,'grGroundParam')])


def test_jobj_marker_resolution_and_world_coordinates():
    st=StageDAT(make_marker_stage())
    ms={m.marker_id:m for m in st.markers()}
    assert set((0x94,0x95,0x96,0x97,0x98)).issubset(ms)
    # Camera center child local -100,0 under root +10,+20.
    assert abs(ms[0x94].world_x - (-90)) < 1e-6
    assert abs(ms[0x94].world_y - 20) < 1e-6
    before=len(st.bytes())
    st.set_marker_world(0x94, 5, 6)
    m=[m for m in st.markers() if m.marker_id==0x94][0]
    assert abs(m.world_x-5)<1e-5 and abs(m.world_y-6)<1e-5
    assert len(st.bytes())==before


def test_camera_and_blast_bounds_derive_from_runtime_marker_formula():
    st=StageDAT(make_marker_stage())
    st.set_camera_bounds(center_x=0,center_y=0,left=-180,right=180,bottom=-70,top=130)
    st.set_blast_bounds(left=-250,right=250,bottom=-120,top=210)
    b=st.camera_blast_bounds()
    assert b['camera']=={'center_x':0.0,'center_y':0.0,'left':-180.0,'right':180.0,'bottom':-70.0,'top':130.0}
    assert b['blast']=={'left':-250.0,'right':250.0,'bottom':-120.0,'top':210.0}


def test_collision_surface_flags_are_editable_without_touching_geometry():
    st=StageDAT(make_marker_stage())
    before=st.vertices()
    s=st.line_surface(0)
    assert s['category']=='Floor' and s['kind']=='Floor'
    assert s['material_id']==3 and s['ledge'] is True
    st.set_line_surface(0,material_id=17,platform=True,ledge=False,dynamic_platform_source=True)
    s=st.line_surface(0)
    assert s['material_id']==17 and s['platform'] and not s['ledge'] and s['dynamic_platform_source']
    assert st.vertices()==before


def test_collision_joint_translation_moves_owned_vertex_range_and_bounds():
    st=StageDAT(make_marker_stage())
    j=st.map_joints()[0]
    assert j['vtx_start']==0 and j['vtx_count']==2
    st.translate_joint_vertices(0,5,-3)
    assert st.vertices()==[(-5.0,-3.0),(15.0,-3.0)]
    j=st.map_joints()[0]
    assert j['left_bound']==-5.0 and j['right_bound']==15.0


def test_structural_collision_segment_insertion_updates_indices_and_ranges():
    st=StageDAT(make_marker_stage())
    before=len(st.bytes())
    r=st.add_collision_segment(joint_index=0,category='Floor',x0=-4,y0=8,x1=4,y1=8,
                               material_id=7,platform=True,ledge=True)
    assert r['new_vertex_count']==4 and r['new_line_count']==2
    assert st.vertices()==[(-10.0,0.0),(10.0,0.0),(-4.0,8.0),(4.0,8.0)]
    assert st.collision_summary().floor_count==2
    ln=st.lines()[1]
    assert (ln['v0'],ln['v1'])==(2,3)
    surf=st.line_surface(1)
    assert surf['material_id']==7 and surf['platform'] and surf['ledge']
    j=st.map_joints()[0]
    assert j['floor_count']==2 and j['vtx_count']==4 and j['top_bound']==8.0
    assert len(st.bytes())>before
    assert st.validate()['status']=='PASS'
