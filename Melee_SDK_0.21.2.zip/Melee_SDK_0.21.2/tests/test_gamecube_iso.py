from pathlib import Path
import hashlib

import sdk.gamecube_iso as gciso
from sdk.gamecube_iso import GameCubeISO, fresh_rebuild, quick_update, verify_melee_102


def make_fake_iso(path: Path, payload: bytes = b'ABCD') -> None:
    size = 0x5000
    data = bytearray(size)
    data[:6] = b'GALE01'
    fst_off = 0x1000
    file_off = 0x3000
    # Header pointers.
    data[0x420:0x424] = (0x2000).to_bytes(4, 'big')
    data[0x424:0x428] = fst_off.to_bytes(4, 'big')
    # Minimal valid DOL at 0x2000: one 4-byte text section at file offset 0x100.
    dol = bytearray(0x104)
    dol[0x00:0x04] = (0x100).to_bytes(4, 'big')
    dol[0x90:0x94] = (4).to_bytes(4, 'big')
    dol[0x100:0x104] = b'DOL!'
    data[0x2000:0x2000+len(dol)] = dol
    # FST: root + one file entry + string table "PlFx.dat\0".
    fst = bytearray()
    fst += (0x01000000).to_bytes(4, 'big') + (0).to_bytes(4, 'big') + (2).to_bytes(4, 'big')
    fst += (0).to_bytes(4, 'big') + file_off.to_bytes(4, 'big') + len(payload).to_bytes(4, 'big')
    fst += b'PlFx.dat\0'
    data[0x428:0x42C] = len(fst).to_bytes(4, 'big')
    data[fst_off:fst_off+len(fst)] = fst
    data[file_off:file_off+len(payload)] = payload
    path.write_bytes(data)


def test_fst_lookup_and_exact_patch(tmp_path):
    iso_path = tmp_path / 'base.iso'
    make_fake_iso(iso_path)
    iso = GameCubeISO(iso_path)
    ent = iso.find_file('PlFx.dat')
    assert ent.offset == 0x3000
    assert iso.read_file(ent) == b'ABCD'
    replacement = tmp_path / 'PlFx.dat'
    replacement.write_bytes(b'WXYZ')
    iso.replace_file_exact('PlFx.dat', replacement)
    assert GameCubeISO(iso_path).read_file(GameCubeISO(iso_path).find_file('PlFx.dat')) == b'WXYZ'


def test_rejects_resized_replacement(tmp_path):
    iso_path = tmp_path / 'base.iso'
    make_fake_iso(iso_path)
    replacement = tmp_path / 'PlFx.dat'
    replacement.write_bytes(b'TOO-LONG')
    try:
        GameCubeISO(iso_path).replace_file_exact('PlFx.dat', replacement)
    except ValueError as e:
        assert 'exact-size' in str(e)
    else:
        raise AssertionError('resized replacement should be rejected')


def test_fresh_and_quick_update_restore_reverted_files(tmp_path):
    clean = tmp_path / 'clean.iso'
    out = tmp_path / 'test.iso'
    build = tmp_path / 'Build'
    build.mkdir()
    make_fake_iso(clean, b'ABCD')
    (build / 'PlFx.dat').write_bytes(b'WXYZ')

    fresh_rebuild(clean, out, build, verify_hash=False)
    iso = GameCubeISO(out)
    assert iso.read_file(iso.find_file('PlFx.dat')) == b'WXYZ'

    # Removing the file from Build simulates reverting the character to Original.
    (build / 'PlFx.dat').unlink()
    quick_update(clean, out, build, verify_hash=False)
    iso = GameCubeISO(out)
    assert iso.read_file(iso.find_file('PlFx.dat')) == b'ABCD'



def test_verify_hashes_embedded_dol_not_entire_iso(tmp_path, monkeypatch):
    clean = tmp_path / 'clean.iso'
    make_fake_iso(clean)
    iso = GameCubeISO(clean)
    with clean.open('rb') as f:
        f.seek(iso.dol_offset)
        dol_bytes = f.read(iso.dol_size())
    expected_dol_sha1 = hashlib.sha1(dol_bytes).hexdigest()
    whole_iso_sha1 = hashlib.sha1(clean.read_bytes()).hexdigest()
    assert expected_dol_sha1 != whole_iso_sha1

    monkeypatch.setattr(gciso, 'GALE01_102_DOL_SHA1', expected_dol_sha1)
    result = verify_melee_102(clean, full_hash=True)
    assert result['canonical'] is True
    assert result['dol_sha1'] == expected_dol_sha1
    assert result['sha1'] == expected_dol_sha1


def test_main_dol_hash_changes_when_dol_changes(tmp_path):
    a = tmp_path / 'a.iso'; b = tmp_path / 'b.iso'
    make_fake_iso(a); make_fake_iso(b)
    # Change only the embedded DOL payload, not the game ID/FST layout.
    with b.open('r+b') as f:
        f.seek(0x2000 + 0x100)
        f.write(b'ALT!')
    assert GameCubeISO(a).sha1_dol() != GameCubeISO(b).sha1_dol()

def test_xdelta_package_wrapper_generation(tmp_path):
    from sdk.gamecube_iso import export_xdelta_package
    clean = tmp_path / 'clean.iso'
    modded = tmp_path / 'modded.iso'
    make_fake_iso(clean)
    make_fake_iso(modded, b'WXYZ')
    tool = tmp_path / 'xdelta3'
    tool.write_text('#!/usr/bin/env python3\nimport pathlib,sys\npathlib.Path(sys.argv[-1]).write_bytes(b"FAKEPATCH")\n')
    tool.chmod(0o755)
    pkg = tmp_path / 'pkg'
    result = export_xdelta_package(clean, modded, pkg, xdelta3=tool, verify_hash=False)
    assert Path(result['patch']).read_bytes() == b'FAKEPATCH'
    bat = (pkg / 'Apply_Patch.bat').read_text()
    assert 'xdelta3.exe' in bat
    assert '-d -s' in bat
    assert 'MeleeMod.xdelta' in bat
    assert (pkg / 'patch_manifest.json').exists()
    assert (pkg / 'README.txt').exists()


def test_repacker_can_insert_new_root_fst_file(tmp_path):
    clean=tmp_path/'clean.iso'; out=tmp_path/'out.iso'; make_fake_iso(clean,b'ABCD')
    new=tmp_path/'GrMy.dat'; new.write_bytes(b'NEW-STAGE-PAYLOAD')
    result=GameCubeISO(clean).repack_files(out,{},additions={'GrMy.dat':new})
    iso=GameCubeISO(out)
    assert iso.read_file(iso.find_file('GrMy.dat'))==b'NEW-STAGE-PAYLOAD'
    assert result['fst_entries_new']==result['fst_entries_old']+1
    assert result['additions'][0]['added'] is True


def test_repacker_accepts_resized_dol_and_new_file_together(tmp_path):
    clean=tmp_path/'clean.iso'; out=tmp_path/'out.iso'; make_fake_iso(clean,b'ABCD')
    iso=GameCubeISO(clean)
    dol=tmp_path/'start.dol'; iso.extract_dol(dol)
    from sdk.dol_patch import DOLImage
    d=DOLImage(dol); d.add_data_section(b'EXTRA-DOL-DATA'); d.save_as(dol)
    new=tmp_path/'GrMy.dat'; new.write_bytes(b'STAGE')
    result=iso.repack_files(out,{},additions={'GrMy.dat':new},dol_replacement=dol)
    assert result['dol_resized'] is True
    assert GameCubeISO(out).dol_size()==dol.stat().st_size
    assert GameCubeISO(out).read_file(GameCubeISO(out).find_file('GrMy.dat'))==b'STAGE'


def make_melee_like_tight_dol_iso(path: Path, payload: bytes = b"ABCD") -> None:
    """Synthetic layout matching GALE01's DOL->FST ordering/tiny gap."""
    size = 0x9000
    data = bytearray(size)
    data[:6] = b"GALE01"
    dol_off = 0x1000
    # DOL occupies 0x104 bytes, then only a 0x20-byte gap before the FST.
    fst_off = dol_off + 0x104 + 0x20
    file_off = 0x6000
    data[0x420:0x424] = dol_off.to_bytes(4, "big")
    data[0x424:0x428] = fst_off.to_bytes(4, "big")
    dol = bytearray(0x104)
    dol[0x00:0x04] = (0x100).to_bytes(4, "big")
    dol[0x48:0x4C] = (0x80003100).to_bytes(4, "big")
    dol[0x90:0x94] = (4).to_bytes(4, "big")
    dol[0x100:0x104] = b"DOL!"
    data[dol_off:dol_off+len(dol)] = dol
    fst = bytearray()
    fst += (0x01000000).to_bytes(4, "big") + (0).to_bytes(4, "big") + (2).to_bytes(4, "big")
    fst += (0).to_bytes(4, "big") + file_off.to_bytes(4, "big") + len(payload).to_bytes(4, "big")
    fst += b"PlFx.dat\0"
    data[0x428:0x42C] = len(fst).to_bytes(4, "big")
    data[0x42C:0x430] = len(fst).to_bytes(4, "big")
    data[fst_off:fst_off+len(fst)] = fst
    data[file_off:file_off+len(payload)] = payload
    path.write_bytes(data)


def test_repacker_relocates_fst_when_resized_dol_overlaps_it(tmp_path):
    clean = tmp_path / "tight.iso"
    out = tmp_path / "out.iso"
    make_melee_like_tight_dol_iso(clean)
    iso = GameCubeISO(clean)
    original_fst = iso.fst_offset
    dol = tmp_path / "start.dol"
    iso.extract_dol(dol)
    # Grow the DOL enough to cross the 0x20-byte retail-style gap.
    from sdk.dol_patch import DOLImage
    image = DOLImage(dol)
    image.add_data_section(b"X" * 0x80)
    image.save_as(dol)
    assert iso.dol_offset + dol.stat().st_size > original_fst

    result = iso.repack_files(out, {}, dol_replacement=dol)
    rebuilt = GameCubeISO(out)
    assert rebuilt.fst_offset >= iso.dol_offset + dol.stat().st_size
    assert rebuilt.fst_offset != original_fst
    with out.open("rb") as f:
        f.seek(iso.dol_offset)
        assert f.read(dol.stat().st_size) == dol.read_bytes()
    assert rebuilt.read_file(rebuilt.find_file("PlFx.dat")) == b"ABCD"
    assert result["dol_resized"] is True
