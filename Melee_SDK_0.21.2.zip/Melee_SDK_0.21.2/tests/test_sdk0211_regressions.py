import pytest
from pathlib import Path
from sdk import standalone_stage_runtime as sr, slippi_direct_gateway as dg
from tests.hf29d_ppc import execute, put, get, SENTINEL

BASE=0x804F0000
MARKER=0x804F1100
SELECTOR=0x804F1200
RETAIL=0x801B4064
SCENE=0x803DE200
R13=0x804DB6A0


def _clobber(regs):
    for r in range(3,13): regs[r]=0xBAD00000+r


def test_full_coop_marker_never_uses_standalone_exit_and_never_changes_selector():
    mem={}
    put(mem,MARKER,0xA5,1); put(mem,SCENE,1,1)
    put(mem,R13+sr.OFST_R13_ISWINNER,1,1); put(mem,R13+sr.OFST_R13_CHOSESTAGE,1,1)
    out=execute(sr.exit_scene(BASE,MARKER,RETAIL,SELECTOR),BASE,mem=mem,
                initial_regs={3:SCENE,13:R13},stop_targets=(RETAIL,0x801B4408))
    assert out['target']==RETAIL
    assert get(mem,R13+sr.OFST_R13_ISWINNER,1)==1
    assert get(mem,R13+sr.OFST_R13_CHOSESTAGE,1)==1


@pytest.mark.parametrize('role',[0,1,0xFF])
def test_standalone_exit_restores_precarrier_direct_role_and_resets_chosestage(role):
    mem={}
    put(mem,MARKER,0xA6,1); put(mem,SCENE,1,1)
    put(mem,SELECTOR+sr.SELECTOR_ROLE_OFFSET,role,1)
    put(mem,R13+sr.OFST_R13_ISWINNER,0,1); put(mem,R13+sr.OFST_R13_CHOSESTAGE,1,1)
    out=execute(sr.exit_scene(BASE,MARKER,RETAIL,SELECTOR),BASE,mem=mem,
                initial_regs={3:SCENE,13:R13},stop_targets=(RETAIL,0x801B4408))
    assert out['target']==0x801B4408
    assert get(mem,R13+sr.OFST_R13_ISWINNER,1)==role
    assert get(mem,R13+sr.OFST_R13_CHOSESTAGE,1)==0


def test_direct_carrier_snapshots_local_stage_picker_role_before_retail_preload():
    state=0x804F2000; pending=0x804F2100; p1=0x804F2110; p2=p1+8
    main=0x804F3000; match=main+dg.DIRECT_MATCH_DATA_OFFSET
    mem={}
    put(mem,dg.GM_CURRENT_MODE_ADDR,dg.GM_ONLINE,1)
    put(mem,R13+dg.OFST_R13_ONLINE_MODE,dg.ONLINE_MODE_DIRECT,1)
    put(mem,R13+dg.OFST_R13_GM_MAINLIB,main)
    put(mem,match+dg.DIRECT_STAGE_LOW_BYTE,dg.CARRIER_STAGE,1)
    put(mem,match+dg.P1+dg.PLAYER_TYPE,0,1); put(mem,match+dg.P2+dg.PLAYER_TYPE,0,1)
    put(mem,R13+dg.OFST_R13_ISWINNER,0,1); put(mem,R13+dg.OFST_R13_CHOSESTAGE,1,1)
    for off,val in ((dg.P1+dg.CKIND,2),(dg.P2+dg.CKIND,3)):
        put(mem,match+off,val,1)
    code=dg.build_wrapper(BASE,RETAIL,state_addr=state,gateway_pending_addr=pending,
        p1_ckind_addr=p1,p1_color_addr=p1+1,p1_subcolor_addr=p1+2,p1_nametag_addr=p1+3,
        p2_identity_valid_addr=pending+1,p2_ckind_addr=p2,p2_color_addr=p2+1,
        p2_subcolor_addr=p2+2,p2_nametag_addr=p2+3,netplay_arm_addr=BASE+0x700)
    execute(code,BASE,mem=mem,initial_regs={13:R13},callees={RETAIL:lambda r,m:None})
    assert get(mem,state+dg.S_SELECTOR_ROLE,1)==0
    assert get(mem,state+dg.S_SELECTOR_CHOSE,1)==1


def test_race_adapter_does_not_tail_into_hyrule_adventure_enter_callback():
    # Marker AB is Race to the Finish. The custom setup must become the whole
    # enter callback; tailing RETAIL is what overwrote it with Adventure Hyrule.
    start=0x80472000; adv=0x80490000; mem={}
    put(mem,MARKER,0xAB,1)
    mem.update({sr.NO_ENEMIES+i:0x21 for i in range(3)})
    def enter(r,m): _clobber(r); r[3]=start
    def data(r,m): _clobber(r); r[3]=adv
    def setup(r,m):
        m.update({start+i:0 for i in range(0x138)})
        _clobber(r)
    out=execute(sr.prepare(BASE,MARKER,RETAIL),BASE,mem=mem,
        initial_regs={3:SCENE,29:29,30:30,31:31},
        callees={0x801A427C:enter,0x8017E424:data,0x8017CE34:setup,0x8016F088:lambda r,m:_clobber(r)},
        stop_targets=(RETAIL,))
    assert out['target']==SENTINEL
    assert get(mem,adv+8,1)==0x80 and get(mem,adv+9,1)==2


def test_source_install_leaves_common_state_exit_instruction_unpatched():
    text=Path('sdk/standalone_stage_runtime.py').read_text()
    assert "dol.patch_at_address(0x801A413C" not in text
    assert "retail common state-exit instruction" in text
