from sdk.adventure_probe import _staffroll_dual_pad_wrapper
from sdk.ppc import lis, lbz


def _addr_parts(addr: int):
    lo = addr & 0xFFFF
    signed_lo = lo - 0x10000 if lo & 0x8000 else lo
    hi = ((addr - signed_lo) >> 16) & 0xFFFF
    return hi, signed_lo


def test_hotfix2_staffroll_wrapper_accepts_campaign_valid_gate():
    base = 0x804E7000
    campaign_valid = 0x804E0021
    blob = _staffroll_dual_pad_wrapper(base, campaign_valid)
    hi, lo = _addr_parts(campaign_valid)
    # The cross-scene campaign-valid byte must be consulted. This is what
    # extends the shared controller selector beyond scenes whose mode byte is
    # literally GM_ADVENTURE.
    assert lis(12, hi) in [blob[i:i+4] for i in range(0, len(blob), 4)]
    assert lbz(11, lo, 12) in [blob[i:i+4] for i in range(0, len(blob), 4)]
    # HF5 merges P2 into P1's logical stream instead of selecting an owner.
    assert bytes.fromhex('38600000') in blob  # li r3,0 merged logical pad
    assert bytes.fromhex('38600001') not in blob
    assert bytes.fromhex('3c60804a') in blob  # lis r3,0x804a retail path


def test_hotfix2_wrapper_still_supports_retail_only_construction():
    blob = _staffroll_dual_pad_wrapper(0x804E7400, None)
    assert bytes.fromhex('38600000') in blob
    assert bytes.fromhex('38600001') not in blob
    assert bytes.fromhex('3c60804a') in blob
