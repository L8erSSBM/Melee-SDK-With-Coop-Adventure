"""Validation tests for the known Fox pipeline.

Set MELEE_FIGHTER_DIR to the folder containing PlFx.dat and PlFxAJ.dat.
Without that environment variable the binary-fixture tests are skipped by pytest.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path

from sdk.melee_dat import FighterDAT, decode_hitbox, encode_hitbox

FIGHTER_DIR = Path(os.environ['MELEE_FIGHTER_DIR']) if os.environ.get('MELEE_FIGHTER_DIR') else None
FOX = FIGHTER_DIR / 'PlFx.dat' if FIGHTER_DIR else None
FOX_AJ = FIGHTER_DIR / 'PlFxAJ.dat' if FIGHTER_DIR else None


def _fixture_available():
    return bool(FOX and FOX.exists() and FOX_AJ and FOX_AJ.exists())


def test_hitbox_codec_roundtrip():
    words = [0x2C006807, 0x05280000, 0x00000000, 0xB4990013, 0x0500010B]
    h = decode_hitbox(words)
    assert h['damage'] == 7
    assert h['angle'] == 361
    assert encode_hitbox(h, words) == words


def test_fox_fixture_pipeline():
    if not _fixture_available():
        return
    f = FighterDAT(FOX)
    assert f.fighter_name == 'Fox'
    assert f.anim_count == 327
    attrs = f.common_attributes()
    assert abs(attrs['weight']['value'] - 75.0) < 1e-6
    assert abs(attrs['gravity']['value'] - 0.23) < 1e-5
    assert abs(attrs['landingairf_lag']['value'] - 22.0) < 1e-6

    r = f.validate_animation_archive(FOX_AJ)
    assert r['errors'] == []
    assert r['valid_chunks'] > 200

    fair = [m for m in f.find_moves('AttackAirF') if m.action_name == 'AttackAirF'][0]
    hbs = f.hitboxes_for_animation(fair)
    h0 = hbs[0]['hitbox']
    assert h0['damage'] == 7
    assert h0['angle'] == 361
    assert h0['knockback_growth'] == 100
    assert h0['base_knockback'] == 10
    assert abs(h0['size'] - 5.15625) < 1e-9

    original = FOX.read_bytes()
    off = hbs[0]['offset']
    f.set_hitbox(off, {'damage': 8})
    f.set_hitbox(off, {'damage': 7})
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / 'PlFx.dat'
        f.save_as(out)
        assert out.read_bytes() == original

    cattrs = f.character_attributes()
    assert abs(cattrs['blaster_velocity']['value'] - 7.0) < 1e-6
    assert abs(cattrs['illusion_gravity_delay']['value'] - 15.0) < 1e-6
