from pathlib import Path
from sdk.adventure_probe import (
    _adventure_hud_capacity_wrapper, _staffroll_dual_pad_wrapper,
    ADVENTURE_HUD_INIT_HOOK, ADVENTURE_HUD_INIT_EXPECTED,
    STAFFROLL_PAD_INDEX_HOOK, STAFFROLL_PAD_INDEX_EXPECTED,
    install_phase30_coop_spawn_probe,
)
from sdk.additional_content import FEATURE_BY_KEY
from sdk.ppc import decode_branch

ROOT=Path(__file__).resolve().parents[1]
CLEAN=Path('/mnt/data/main.dol')
SYMS=ROOT/'data/runtime_symbols_GALE01.txt'

def test_hud_wrapper_exposes_all_slots_without_replacing_slot_filter():
    blob=_adventure_hud_capacity_wrapper(0x80401000)
    assert b'\x38\x60\x00\x06' in blob  # li r3,6
    assert len(blob) >= 20

def test_credits_wrapper_merges_both_pads_and_keeps_retail_accessor():
    blob=_staffroll_dual_pad_wrapper(0x80401200)
    assert b'\x38\x60\x00\x00' in blob  # merged stream returns P1 logical pad
    assert b'\x38\x60\x00\x01' not in blob  # no first-active P2 ownership selector
    assert b'\x3c\x60\x80\x4a' in blob  # retail selected-pad fallback path

def test_phase38_feature_registry():
    f=FEATURE_BY_KEY['coop_dual_credits']
    assert f.dependencies == ('coop_adventure',)
    assert not f.experimental

def test_phase38_canonical_install(tmp_path):
    if not CLEAN.is_file():
        return
    out=tmp_path/'p38.dol'
    m=install_phase30_coop_spawn_probe(CLEAN,SYMS,out,scene_revive=True)
    hooks={h['name']:h for h in m['hooks']}
    assert 'adventure_hud_capacity' in hooks
    assert 'dual_player_credits_input' in hooks
    assert m['probe_contract']['hud_capacity']['adventure_capacity']==6
    assert m['probe_contract']['dual_player_credits'] is True
    assert decode_branch(ADVENTURE_HUD_INIT_HOOK, bytes.fromhex(hooks['adventure_hud_capacity']['site_branch']))['target']==hooks['adventure_hud_capacity']['stub_address']
    assert decode_branch(STAFFROLL_PAD_INDEX_HOOK, bytes.fromhex(hooks['dual_player_credits_input']['site_branch']))['target']==hooks['dual_player_credits_input']['stub_address']
