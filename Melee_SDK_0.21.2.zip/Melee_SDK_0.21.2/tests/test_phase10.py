from pathlib import Path
import os, math
from sdk.character_schemas import CHARACTER_ATTR_SCHEMAS
from sdk.melee_dat import FighterDAT, EVENT_NAMES

PLAYABLE_INTERNAL = {
    'Mario','Drmario','Luigi','Koopa','Peach','Yoshi','Donkey','Captain','Ganon',
    'Falco','Fox','Ness','Popo','Nana','Kirby','Samus','Zelda','Seak','Link','Clink',
    'Pichu','Pikachu','Purin','Mewtwo','Gamewatch','Mars','Emblem'
}

def test_all_playable_entities_have_semantic_schema():
    assert PLAYABLE_INTERNAL <= set(CHARACTER_ATTR_SCHEMAS)
    assert all(CHARACTER_ATTR_SCHEMAS[n] for n in PLAYABLE_INTERNAL)

def test_corrected_high_opcode_names():
    expected = {
        54:'Footstep SFX / GFX', 55:'Spawn Fighter Effect / SFX',
        56:'Start Smash Charge', 57:'Set Smash Vibration', 58:'Create Wind Effect'
    }
    for op,name in expected.items(): assert EVENT_NAMES[op] == name

def test_remaining_five_real_dat_fields_roundtrip():
    root = Path(os.environ['MELEE_FIGHTER_DIR']) if os.environ.get('MELEE_FIGHTER_DIR') else None
    if not root: return
    files={'Koopa':'Kp','Seak':'Sk','Popo':'Pp','Nana':'Nn','Samus':'Ss','Zelda':'Zd'}
    for name,prefix in files.items():
        f=FighterDAT(root/f'Pl{prefix}.dat')
        attrs=f.character_attributes(); original=bytes(f.archive.raw)
        assert attrs, name
        for key,v in attrs.items():
            if isinstance(v['value'],float): assert math.isfinite(v['value']), (name,key,v['value'])
            f.set_character_attribute(key,v['value'])
        assert bytes(f.archive.raw)==original, name

def test_semantic_event_decoder_on_real_roster():
    root = Path(os.environ['MELEE_FIGHTER_DIR']) if os.environ.get('MELEE_FIGHTER_DIR') else None
    if not root: return
    wanted={14,19,28,31,36,37,40,41,42,44,46,48,50,51,52,53,54,55,56,57,58}
    seen=set()
    for p in root.glob('Pl??.dat'):
        try: f=FighterDAT(p)
        except Exception: continue
        for a in f.animations:
            for ev in f.parse_script(a):
                if ev['opcode'] in wanted:
                    # Some opcodes are absent in vanilla playable scripts; when present,
                    # the decoder must expose structured parameters without crashing.
                    assert 'event_details' in ev, (p.name,a.action_name,ev['opcode'])
                    seen.add(ev['opcode'])
    assert {14,19,28,31,36,37,40,41,42,46,50,51,52,53,54,55,56,58} <= seen
