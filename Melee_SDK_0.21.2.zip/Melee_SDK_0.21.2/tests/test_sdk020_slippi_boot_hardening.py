from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, lbz, lis
from sdk import slippi_boot_hardening as harden
from sdk.adventure_gateway_scope import CURRENT_MODE, _addr_parts

ROOT = Path(__file__).resolve().parents[1]
HF29G_DOL = ROOT / 'Build' / 'historical' / 'HF29G_GATEWAY_SCOPED_COOP_GAMEOVER_RETURN.dol'
HF29G_MANIFEST = ROOT / 'Build' / 'HF29G_runtime_manifest.json'
SDK020_MANIFEST = ROOT / 'Build' / 'SDK020_runtime_manifest.json'
SDK020_DOL = ROOT / 'Build' / 'historical' / 'SDK020_BOOT_ISOLATION.dol'


def _hf29g():
    return json.loads(HF29G_MANIFEST.read_text())


def _sdk020():
    return json.loads(SDK020_MANIFEST.read_text())


def test_sdk020_source_upgrader_reproduces_packaged_dol_byte_for_byte(tmp_path):
    m = _hf29g()
    d = DOLImage(HF29G_DOL)
    result = harden.install(
        d, m['probe_section']['index'], gateway_scope=m['adventure_gateway_scope'],
        legacy_trace_hooks=m['icies_teardown_trace_hooks'])
    assert result['marker'] == 'MSDK020S'
    assert bytes(d.raw) == SDK020_DOL.read_bytes()


def test_all_hf29g_behavior_sites_now_point_to_mode_first_guards():
    d = DOLImage(SDK020_DOL)
    s = _sdk020()['slippi_boot_hardening']
    assert len(s['mode_first_guards']) == 24
    for row in s['mode_first_guards']:
        dec = decode_branch(row['site_address'], d.read_at_address(row['site_address'], 4))
        assert dec['target'] == row['mode_first_guard']
        assert dec['link'] == row['site_link']
        assert row['hf29ef_active_target'] != row['mode_first_guard']


def test_mode_first_guards_read_retail_mode_before_sdk_active_byte():
    d = DOLImage(SDK020_DOL)
    s = _sdk020()['slippi_boot_hardening']
    active = s['gateway_coop_active_address']
    mode_hi, mode_lo = _addr_parts(CURRENT_MODE)
    active_hi, active_lo = _addr_parts(active)
    mode_load = lis(12, mode_hi) + lbz(11, mode_lo, 12)
    active_load = lis(12, active_hi) + lbz(11, active_lo, 12)
    for row in s['mode_first_guards']:
        blob = d.read_at_address(row['mode_first_guard'], 0x60)
        mi = blob.find(mode_load)
        ai = blob.find(active_load)
        assert mi >= 0, row['name']
        assert ai > mi, row['name']
        # The first conditional branch after the retail mode comparison must
        # occur before the active-byte load, so non-Adventure can escape first.
        branch_found = False
        for off in range(mi + len(mode_load), ai, 4):
            word = struct.unpack('>I', blob[off:off+4])[0]
            if word >> 26 == 16:
                branch_found = True
                break
        assert branch_found, row['name']


def test_hf21_global_scene_trace_hooks_are_retired_to_exact_retail():
    d = DOLImage(SDK020_DOL)
    retired = _sdk020()['slippi_boot_hardening']['retired_hf21_scene_trace_hooks']
    assert len(retired) == 6
    for row in retired:
        assert d.read_at_address(row['site_address'], 4).hex() == row['restored_retail_instruction']


def test_hf29g_adventure_handlers_and_origin_routing_are_not_rewritten():
    old = DOLImage(HF29G_DOL)
    new = DOLImage(SDK020_DOL)
    m = _hf29g()
    s = _sdk020()['slippi_boot_hardening']
    # Existing proven active handler entry words remain byte-identical.
    for row in s['mode_first_guards']:
        target = row['hf29ef_active_target']
        assert new.read_at_address(target, 16) == old.read_at_address(target, 16)
    # HF29G OnLoad, Game Over and origin-return wrappers are not changed.
    scope = m['adventure_gateway_scope']
    sites = [scope['onload_hook']['site_address'], scope['game_over']['site_address']]
    sites.extend(x['site_address'] for x in scope['origin_return_guards'])
    for site in sites:
        assert new.read_at_address(site, 4) == old.read_at_address(site, 4)


def test_sdk_runtime_starts_at_stock_slippi_static_backup_boundary():
    m = _sdk020()['slippi_boot_hardening']
    assert m['slippi_static_backup_end'] == 0x804DEC00
    assert m['runtime_section_address'] == 0x804DEC00
    outside = m['mutable_addresses_outside_stock_slippi_static_backup']
    assert outside
    assert all(addr >= 0x804DEC00 for addr in outside.values())
    assert 'gateway_coop_active' in outside


def test_sdk020_binary_containment_relative_to_validated_hf29g():
    old = HF29G_DOL.read_bytes()
    new = SDK020_DOL.read_bytes()
    d = DOLImage(SDK020_DOL)
    s = _sdk020()['slippi_boot_hardening']
    assert len(new) > len(old)
    assert new[s['section']['file_offset']:s['section']['file_offset']+8] == b'MSDK020S'

    # Within the old file only section-size metadata, the 24 dispatch sites,
    # and the 6 retired diagnostic hook sites are allowed to differ.
    changed = {i for i, (a, b) in enumerate(zip(old, new)) if a != b}
    allowed = set(range(0xCE, 0xD0))
    for row in s['mode_first_guards']:
        off = d.file_offset_for_address(row['site_address'], 4)
        allowed.update(range(off, off + 4))
    for row in s['retired_hf21_scene_trace_hooks']:
        off = d.file_offset_for_address(row['site_address'], 4)
        allowed.update(range(off, off + 4))
    assert changed <= allowed


def test_packaged_sdk020_hash_matches_manifest():
    raw = SDK020_DOL.read_bytes()
    m = _sdk020()
    assert m['sdk_version'] == '0.20.0'
    assert m['format'] == 'melee-character-sdk-0.20.0-slippi-boot-isolation'
    assert hashlib.sha1(raw).hexdigest() == m['output_sha1']
    assert hashlib.sha256(raw).hexdigest() == m['output_sha256']
    assert len(raw) == m['output_size']
