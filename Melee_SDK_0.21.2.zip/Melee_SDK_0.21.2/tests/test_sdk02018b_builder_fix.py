from pathlib import Path

from sdk import slippi_memory_layout as layout
from sdk import slippi_adventure_netplay_bridge as bridge
from sdk.dol_patch import DOLImage
from sdk.ppc import encode_branch

ROOT = Path(__file__).resolve().parents[1]


def test_runtime_reservation_restored_to_original_16k_without_moving_base():
    assert layout.SDK_RUNTIME_BASE == 0x804F0C00
    assert layout.SDK_RUNTIME_LIMIT == 0x804F4C00
    assert layout.SDK_RUNTIME_LIMIT - layout.SDK_RUNTIME_BASE == 0x4000
    assert layout.RETAIL_MAIN_STACK == (0x804DEC00, 0x804EEC00)
    assert layout.RETAIL_DEBUG_STACK == (0x804EEC00, 0x804F0C00)


def test_current_runtime_plus_compact_bridge_and_arena_wrapper_fit_original_window(tmp_path):
    # Build/start.dol is the preserved 0.20.17 runtime fixture. It already has
    # the old arena wrapper appended, so this is slightly MORE conservative
    # than a fresh rebuild: we keep those 32 old bytes, append the compact
    # 0.20.19 bridge, restore the two OSInit callsites to their retail targets,
    # then append the restored 16 KiB arena-floor wrapper.
    old = ROOT / 'Build' / 'start.dol'
    dol = DOLImage(old)
    runtime = next(s for s in dol.sections if s.address == layout.SDK_RUNTIME_BASE)
    runtime_index = runtime.index

    result = bridge.install(
        dol, runtime_index,
        gateway_pending_addr=layout.SDK_RUNTIME_BASE + 0x100,
        gateway_active_addr=layout.SDK_RUNTIME_BASE + 0x101,
    )
    assert result['section']['address'] >= layout.SDK_RUNTIME_BASE

    for site in layout.OS_INIT_ARENA_LO_CALLS:
        # The fixture has the old wrapper branch installed. Restore only the
        # exact retail OSSetArenaLo call expected by install_arena_reservation.
        dol.patch_at_address(
            site,
            encode_branch(site, layout.OS_SET_ARENA_LO, link=True),
        )

    reservation = layout.install_arena_reservation(dol, runtime_index)
    runtime = next(s for s in dol.sections if s.address == layout.SDK_RUNTIME_BASE)
    assert runtime.end_address <= layout.SDK_RUNTIME_LIMIT
    assert reservation['arena_floor'] == 0x804F4C00
