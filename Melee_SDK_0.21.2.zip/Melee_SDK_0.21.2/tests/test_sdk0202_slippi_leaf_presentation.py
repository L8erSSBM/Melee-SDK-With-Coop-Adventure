from __future__ import annotations

import hashlib, json, struct
from pathlib import Path
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, li, lis, stb
from sdk import slippi_adventure_entry_leaf as leaf

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'Build'/'historical'/'SDK021_SLIPPI_ADVENTURE_ENTRY.dol'
NEW=ROOT/'Build'/'historical'/'SDK022_SLIPPI_ADVENTURE_TRACE.dol'
MAN=ROOT/'Build'/'SDK022_runtime_manifest.json'


def _m(): return json.loads(MAN.read_text())


def test_sdk0202_manifest_and_runtime_evidence():
    m=_m(); s=m['slippi_adventure_entry_leaf']
    assert m['sdk_version']=='0.20.2'
    assert m['format']=='melee-character-sdk-0.20.2-slippi-adventure-trace'
    assert s['marker']=='MSDK022T'
    assert s['presentation_wrapper']==0x804DFB60
    assert s['helper_calls']==0
    assert s['p2_start_word']==0x804C210C
    assert s['trace_stage_address']==0x804DEC98
    assert s['presentation_states']==list(leaf.ADVENTURE_PRESENTATION_STATES)
    assert set(s['trace_stages'])=={'0x21','0x22','0x23','0x24','0x25'}


def test_leaf_wrapper_matches_generator_and_exactly_fills_original_slot():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_leaf']; base=s['presentation_wrapper']
    expected=leaf.build_leaf_wrapper(base,s['trace_stage_address'])
    assert len(expected)==s['wrapper_size']==s['wrapper_capacity']==0x140
    assert d.read_at_address(base,len(expected))==expected


def test_leaf_has_no_branch_link_or_external_sdk_helper_calls():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_leaf']; base=s['presentation_wrapper']
    raw=d.read_at_address(base,s['wrapper_size'])
    for off in range(0,len(raw),4):
        word=struct.unpack('>I',raw[off:off+4])[0]
        assert not ((word >> 26)==18 and (word & 1))
        assert not ((word >> 26)==16 and (word & 1))


def test_leaf_begins_with_trace_then_exact_retail_accessor_semantics_inline():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_leaf']; base=s['presentation_wrapper']
    # addi r6,r3,0; lis r8,0x804E; li r7,0x21; stb r7,-0x1368(r8)
    assert d.read_at_address(base,16)==(
        bytes.fromhex('38c30000') + lis(8,0x804E) + li(7,leaf.TRACE_STAGE_ENTRY) + stb(7,-0x1368,8)
    )
    retail7=bytes.fromhex(
        '5460063e' '1c000030' '3c608048' '38639c30'
        '7c830214' '80640008' '8084000c'
    )
    assert d.read_at_address(base+16,len(retail7))==retail7


def test_all_five_breadcrumb_stage_values_are_emitted():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_leaf']; base=s['presentation_wrapper']
    raw=d.read_at_address(base,s['wrapper_size'])
    for value in leaf.TRACE_STAGES:
        assert li(7,value) in [raw[i:i+4] for i in range(0,len(raw),4)]
    assert raw.count(stb(7,-0x1368,8)) == 5


def test_old_0201_helper_paths_are_not_referenced_by_live_leaf():
    d=DOLImage(NEW); m=_m(); s=m['slippi_adventure_entry_leaf']; old=m['slippi_adventure_entry_hardening']
    base=s['presentation_wrapper']
    for a in range(base, base+s['wrapper_capacity'], 4):
        raw=d.read_at_address(a,4)
        try: dec=decode_branch(a,raw)
        except Exception: continue
        assert dec['target'] != old['safe_retail_accessor_copy']
        assert dec['target'] != old['old_clobbered_trampoline']


def test_binary_delta_from_0201_is_only_presentation_wrapper_slot():
    old=OLD.read_bytes(); new=NEW.read_bytes(); d=DOLImage(NEW); s=_m()['slippi_adventure_entry_leaf']
    assert len(old)==len(new)
    changed={i for i,(a,b) in enumerate(zip(old,new)) if a!=b}
    off=d.file_offset_for_address(s['presentation_wrapper'],s['wrapper_capacity'])
    allowed=set(range(off,off+s['wrapper_capacity']))
    assert changed
    assert changed<=allowed


def test_manifest_hash_matches_candidate():
    raw=NEW.read_bytes(); m=_m()
    assert hashlib.sha256(raw).hexdigest()==m['output_sha256']
