import struct

from sdk.event_match import EventMatchArchive, PKIND_HUMAN, PKIND_CPU, CHKIND_NONE


def make_event_archive():
    data=bytearray(0x4CC)
    event=0x100; evinit=0x200; players=[0x240,0x260,0x280]
    data[event]=0                    # ordinary event
    data[event+1]=0x60              # three runtime player slots
    struct.pack_into('>I',data,event+8,evinit)
    for i,p in enumerate(players): struct.pack_into('>I',data,event+0x14+i*4,p)
    # rules: match-kind-ish bits preserved, teams on, stage 0x00CA, speed 1.0
    data[evinit]=0x2B; data[evinit+1]=0x80; data[evinit+2]=1; data[evinit+3]=2
    struct.pack_into('>H',data,evinit+6,0x00CA); struct.pack_into('>I',data,evinit+8,180)
    struct.pack_into('>f',data,evinit+0x20,1.0); struct.pack_into('>f',data,evinit+0x24,1.0)
    # P1 human variable, P2/P3 CPU
    for i,p in enumerate(players):
        data[p]=CHKIND_NONE if i==0 else (1+i)
        data[p+1]=0 if i==0 else 1; data[p+2]=2; data[p+6]=0 if i==0 else 1; data[p+0xA]=5
        struct.pack_into('>H',data,p+0xE,0)
        struct.pack_into('>f',data,p+0x10,1.0); struct.pack_into('>f',data,p+0x14,1.0); struct.pack_into('>f',data,p+0x18,1.0)
    root=0x400
    for i in range(51): struct.pack_into('>I',data,root+i*4,event)
    symbols=b'sqEventInitDataLevelTbl\0'
    nr=0; np=1; ne=0
    size=0x20+len(data)+8+len(symbols)
    hdr=struct.pack('>5I',size,len(data),nr,np,ne)+b'HSD0'+bytes(8)
    return bytes(hdr+data+struct.pack('>II',root,0)+symbols)


def test_event_archive_parses_source_confirmed_fields():
    a=EventMatchArchive(make_event_archive())
    assert len(a.events())==51
    e=a.event(0)
    assert e.rules.stage_kind==0xCA
    assert e.rules.time_limit==180
    assert e.rules.game_speed==1.0
    assert len(e.players)==3
    assert e.players[0].slot_type==PKIND_HUMAN
    assert e.players[1].slot_type==PKIND_CPU


def test_duo_conversion_is_exact_size_and_preserves_opaque_rules():
    raw=make_event_archive(); a=EventMatchArchive(raw)
    ev=a.event(0); rules_before=a.archive.data_bytes(ev.rules.offset,0x28)
    size_before=len(a.archive.raw)
    out=a.make_duo_coop(0,p2_character_kind=1,cpu_level=8,stocks=4)
    assert out['runtime_player_count']==3
    assert len(a.archive.raw)==size_before
    e=a.event(0)
    assert e.players[0].slot_type==PKIND_HUMAN
    assert e.players[0].character_kind==CHKIND_NONE
    assert e.players[1].slot_type==PKIND_HUMAN
    assert e.players[1].character_kind==1
    assert e.players[1].team==0
    assert e.players[2].slot_type==PKIND_CPU
    assert e.players[2].team==1
    assert e.players[2].cpu_level==8
    assert e.rules.is_teams==1
    # Bytes not targeted by make_duo_coop stay unchanged.
    rules_after=a.archive.data_bytes(e.rules.offset,0x28)
    for i in range(0x28):
        if i in (1,2): continue  # friendly-fire bit and teams byte can change
        assert rules_after[i]==rules_before[i]


def test_bonus_and_two_player_events_refuse_unsafe_duo_conversion():
    a=EventMatchArchive(make_event_archive())
    eoff=a._event_offset(0)
    a._write_u8(eoff,1)
    try:
        a.make_duo_coop(0,p2_character_kind=1)
    except ValueError as exc:
        assert 'ordinary event kind 0' in str(exc)
    else:
        raise AssertionError('bonus event should be rejected')
