import struct
from pathlib import Path

import sdk.adventure_probe as ap
from sdk.ppc import decode_branch


def _blob(enter=None, ret=None):
    return ap._scene_transition_trace_wrapper(
        0x80420000, 0x8041F000,
        terminal_guard_addr=0x8040002F,
        last_addr=0x80400038,
        flags_lo_addr=0x80400039,
        flags_hi_addr=0x8040003C,
        state_addr=0x8040003A,
        prev_state_addr=0x8040003B,
        enter_code=enter,
        return_code=ret,
    )


def _branch_targets(blob, base=0x80420000):
    out=[]
    for off in range(0, len(blob)-3, 4):
        word=struct.unpack_from('>I',blob,off)[0]
        if word >> 26 != 18:
            continue
        out.append(decode_branch(base+off,blob[off:off+4]))
    return out


def test_hf21_scene_boundaries_are_source_grounded_addresses():
    assert ap.SCENE_EXIT_REQUEST_HOOK == 0x801A4B60
    assert ap.SCENE_EXIT_REQUEST_ALT_HOOK == 0x801A4B74
    assert ap.SCENE_INIT_HOOK == 0x801A4BD4
    assert ap.SCENE_LOOP_HOOK == 0x801A4D34
    assert ap.VS_SCENE_EXIT_HOOK == 0x8016E9C8
    assert ap.RESULTS_SCENE_ENTER_HOOK == 0x80177368


def test_hf21_wrapper_requires_checkpoint():
    try:
        _blob()
    except ValueError as e:
        assert 'enter and/or return' in str(e)
    else:
        raise AssertionError('missing checkpoint must fail')


def test_hf21_wrapper_rejects_non_e_checkpoint():
    try:
        _blob(0xD5,None)
    except ValueError as e:
        assert 'E0..EF' in str(e)
    else:
        raise AssertionError('non-E checkpoint must fail')


def test_hf21_wrapper_calls_retail_trampoline_once():
    targets=_branch_targets(_blob(0xE3,0xE4))
    calls=[x for x in targets if x['link']]
    assert len(calls) == 1
    assert calls[0]['target'] == 0x8041F000


def test_hf21_wrapper_preserves_r3_r4_and_original_lr():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _scene_transition_trace_wrapper'):src.index('def _teardown_trace_wrapper')]
    assert 'stw(3,0x08,1)' in fn and 'stw(4,0x0C,1)' in fn
    assert 'lwz(3,0x08,1)' in fn and 'lwz(4,0x0C,1)' in fn
    assert 'mflr(0)' in fn and 'mtlr(0)' in fn and 'blr()' in fn


def test_hf21_trace_is_terminal_guard_gated_and_diagnostic_only():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _scene_transition_trace_wrapper'):src.index('def _teardown_trace_wrapper')]
    assert 'terminal_guard_addr' in fn and 'cmpwi(11,1,crf=7)' in fn
    for forbidden in ('PLAYER_DESTROY_ENTITIES','PLAYER_CLEAR_ENTITY_REF','PLAYER_MATCH_END_HOOK','PLAYER_GET_ENTITY'):
        assert forbidden not in fn


def test_hf21_checkpoint_persists_bitmap_and_state_history():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _emit_transition_checkpoint'):src.index('def _scene_transition_trace_wrapper')]
    assert 'ori(11, 11, flag_mask)' in fn
    assert 'GM_CURRENT_STATE_ADDR' in fn
    assert 'prev_state_addr' in fn and 'state_addr' in fn


def test_hf21_checkpoint_map_matches_transition_order():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    for text in (
        '_trace_pair(SCENE_EXIT_REQUEST_HOOK,trace_exit_trampoline_addr,trace_exit_wrapper_addr,0xE0,None)',
        '_trace_pair(SCENE_EXIT_REQUEST_ALT_HOOK,trace_alt_trampoline_addr,trace_alt_wrapper_addr,0xE1,None)',
        '_trace_pair(SCENE_LOOP_HOOK,trace_loop_trampoline_addr,trace_loop_wrapper_addr,0xE9,0xE2)',
        '_trace_pair(VS_SCENE_EXIT_HOOK,trace_vs_exit_trampoline_addr,trace_vs_exit_wrapper_addr,0xE3,0xE4)',
        '_trace_pair(SCENE_INIT_HOOK,trace_init_trampoline_addr,trace_init_wrapper_addr,0xE5,0xE6)',
        '_trace_pair(RESULTS_SCENE_ENTER_HOOK,trace_results_trampoline_addr,trace_results_wrapper_addr,0xE7,0xE8)',
    ):
        assert text in src


def test_hf21_marker_and_header_bytes_are_persistent():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert "payload[0x34:0x38]=b'KTDG'" in src
    assert 'payload[0x38]=0' in src
    assert 'payload[0x39]=0' in src
    assert 'payload[0x3A]=0' in src
    assert 'payload[0x3B]=0' in src
    assert 'payload[0x3C]=0' in src


def test_hf21_trace_bytes_reset_only_on_new_campaign_reset_path():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert 'transition_last_addr,transition_flags_lo_addr,transition_state_addr,transition_prev_state_addr,transition_flags_hi_addr' in src
    # Marker is static signature, not part of the mutable reset list.
    reset_line=[x for x in src.splitlines() if 'extra_reset_addrs=(icies_teardown_guard_addr' in x][0]
    assert 'transition_last_addr' in reset_line and '0x34' not in reset_line


def test_hf21_dynamically_captures_and_guards_displaced_instructions():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert 'transition_trace_expected = ({addr: dol.read_at_address(addr, 4)' in src
    assert 'opcode in (16, 18)' in src
    assert 'non-relocatable branch' in src
    assert 'expected=transition_trace_expected[hook]' in src


def test_hf21_trampolines_resume_at_hook_plus_four():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    fn=src[src.index('def _trace_pair'):src.index('trace_exit_trampoline,trace_exit_wrapper')]
    assert 'displaced=transition_trace_expected[hook]' in fn
    assert 'encode_branch(trampoline_addr+4,hook+4)' in fn


def test_hf21_layout_has_all_six_trace_pairs_and_size_guards():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    for name in ('trace_exit','trace_alt','trace_loop','trace_vs_exit','trace_init','trace_results'):
        assert f'dummy_{name}_tramp' in src
        assert f'{name}_trampoline_addr' in src
        assert f'{name}_wrapper_addr' in src
    assert 'HF21 transition trace sizing mismatch' in src
    assert 'Adventure payload blob overlap:' in src


def test_hf21_keeps_hf20_guard_in_place_without_broadening_it():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    assert 'FN_BONUS_FIGHTER_HOOK = 0x80039618' in src
    assert 'bonus_wrapper=_team_kirby_bonus_guard_wrapper' in src
    assert 'D0..D5' in src
    assert 'No fighter, GObj, MatchEnd, scene' in src


def test_hf21_trace_hooks_are_manifested():
    src=Path(ap.__file__).read_text(encoding='utf-8')
    for label in (
        'hf21_scene_exit_request','hf21_scene_alt_exit_request','hf21_scene_loop',
        'hf21_vs_scene_exit','hf21_scene_init','hf21_results_scene_enter',
    ):
        assert label in src
    # SDK 0.20 retires these diagnostic hooks from the live binary while
    # retaining the historical trace metadata for reproducibility.
    assert "'retired_icies_teardown_trace_hooks':(trace_hooks if slippi_boot_hardening else [])" in src
