from pathlib import Path
import tempfile

from sdk.melee_dat import FighterDAT
from sdk.ui_metadata import category_for_attr
from sdk.character_schemas import CHARACTER_ATTR_SCHEMAS

FIX = Path('/mnt/data/fighters_extract/Melee_Fighters')


def test_common_attribute_groups_are_separated():
    assert category_for_attr('dash_max_velocity') == 'Ground Movement'
    assert category_for_attr('jump_v_initial_velocity') == 'Jump'
    assert category_for_attr('gravity') == 'Air Physics'
    assert category_for_attr('landingairf_lag') == 'Landing'


def test_captain_schema_is_present_and_reads_real_dat():
    assert 'Captain' in CHARACTER_ATTR_SCHEMAS
    f = FighterDAT(FIX / 'PlCa.dat')
    attrs = f.character_attributes()
    assert abs(attrs['specialn_vel_x']['value'] - 1.95) < 1e-5
    assert abs(attrs['specials_grav']['value'] - 0.05) < 1e-5
    assert abs(attrs['specialhi_landing_lag']['value'] - 30.0) < 1e-5


def test_timer_edit_and_script_scaling_are_in_place():
    original = (FIX / 'PlCa.dat').read_bytes()
    with tempfile.TemporaryDirectory() as td:
        p = Path(td) / 'PlCa.dat'
        p.write_bytes(original)
        f = FighterDAT(p)
        move = next(a for a in f.animations if a.action_name == 'SpecialN')
        before = f.parse_script(move)
        hit_before = next(e for e in before if e.get('opcode') == 11)
        assert hit_before['frame'] == 52.0
        changes = f.scale_script_timing(move, 0.5)
        assert changes
        after = f.parse_script(move)
        hit_after = next(e for e in after if e.get('opcode') == 11)
        assert hit_after['frame'] == 26.0
        # Archive size is unchanged because only timer low bits are edited.
        assert len(f.archive.raw) == len(original)


def test_single_timer_edit_preserves_opcode():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    ev = next(e for e in f.parse_script(move) if e.get('opcode') == 2 and e.get('timer_value') == 52)
    result = f.set_timer_event(ev['offset'], 40)
    assert result['opcode'] == 2
    assert result['timer_value'] == 40
