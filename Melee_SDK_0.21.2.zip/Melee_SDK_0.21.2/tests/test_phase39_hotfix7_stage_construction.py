from sdk.stage import StageDAT
from sdk.stage_primitives import PRIMITIVE_BY_KEY, add_primitive, add_library_collision_line, compatible_joint_indices
from tests.test_phase15_stage_authoring import make_marker_stage


def test_builder_primitives_include_requested_architecture_types():
    for key in ('floor','slope','soft_platform','ledge_floor','right_wall','left_wall','ceiling'):
        assert key in PRIMITIVE_BY_KEY
    assert PRIMITIVE_BY_KEY['soft_platform'].platform is True
    assert PRIMITIVE_BY_KEY['slope'].category == 'Floor'
    assert PRIMITIVE_BY_KEY['ceiling'].category == 'Ceiling'


def test_add_slope_primitive_uses_structural_collision_writer():
    st=StageDAT(make_marker_stage())
    assert compatible_joint_indices(st,'Floor') == [0]
    r=add_primitive(st,'slope',joint_index=0,x0=-8,y0=0,x1=12,y1=9,material_id=5)
    assert r['primitive_key']=='slope'
    assert r['line_index']==1
    assert st.vertices()[-2:]==[(-8.0,0.0),(12.0,9.0)]
    surf=st.line_surface(1)
    assert surf['category']=='Floor' and surf['material_id']==5 and not surf['platform']
    assert st.validate()['status']=='PASS'


def test_add_soft_platform_creates_only_floor_collision_with_platform_flag():
    st=StageDAT(make_marker_stage())
    before=st.collision_summary()
    r=add_primitive(st,'soft_platform',joint_index=0,x0=-10,y0=12,x1=10,y1=12)
    after=st.collision_summary()
    assert after.floor_count==before.floor_count+1
    assert after.ceiling_count==before.ceiling_count
    assert after.left_wall_count==before.left_wall_count
    assert after.right_wall_count==before.right_wall_count
    assert st.line_surface(r['line_index'])['platform'] is True


def test_library_collision_copy_preserves_source_flags_and_transform():
    st=StageDAT(make_marker_stage())
    row={'index':77,'category':'Floor','p0':[-2.0,3.0],'p1':[6.0,7.0],
         'material_id':9,'platform':True,'ledge':True,'dynamic_platform_source':False}
    r=add_library_collision_line(st,row,joint_index=0,offset_x=10,offset_y=-1,scale_x=2,scale_y=0.5)
    assert r['library_copy'] is True and r['source_line_index']==77
    assert st.vertices()[-2:]==[(6.0,0.5),(22.0,2.5)]
    surf=st.line_surface(r['line_index'])
    assert surf['material_id']==9 and surf['platform'] and surf['ledge']
    assert st.validate()['status']=='PASS'


def test_ui_exposes_friendly_builder_and_keeps_advanced_editor():
    src=open('melee_sdk.py',encoding='utf-8').read()
    assert '+ Add Asset' in src
    assert 'Add Selected Collision to Stage…' in src
    assert 'Advanced Collision…' in src
    assert 'Undo Builder' in src
    assert 'open_stage_authoring_tools' in src
