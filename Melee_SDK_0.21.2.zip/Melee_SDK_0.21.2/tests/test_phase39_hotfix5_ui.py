from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'melee_sdk.py').read_text(encoding='utf-8')


def test_modern_theme_and_stage_builder_studio_are_present():
    assert 'def _apply_modern_theme(self):' in SRC
    assert "style.configure('Accent.TButton'" in SRC
    assert 'Stage Builder Studio — Architecture, Assets, Gameplay & Preview' in SRC


def test_new_stage_creation_defers_runtime_installation():
    start = SRC.index('def create_new_stage_wizard')
    end = SRC.index('def install_current_stage_as_new_slot', start)
    block = SRC[start:end]
    assert 'Install runtime slot' not in block
    assert 'Runtime installation is intentionally deferred.' in block
    assert 'Build / Test Stage…' in block


def test_build_test_flow_uses_recorded_donor_without_prompting_user():
    start = SRC.index('def install_current_stage_as_new_slot')
    end = SRC.index('def open_character_slot_lab', start)
    block = SRC[start:end]
    assert "src_rel.startswith('<authored from ')" in block
    assert "simpledialog.askstring('New runtime stage'" not in block
    assert 'Build / Test Stage — select clean GALE01 1.02 ISO' in block
