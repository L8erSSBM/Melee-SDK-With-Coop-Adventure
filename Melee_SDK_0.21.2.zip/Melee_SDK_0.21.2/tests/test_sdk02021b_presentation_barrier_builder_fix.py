from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_02021c_retires_outer_presentation_barrier_composition():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    # 0.20.21B still tried to put an additional wrapper at 0x801A36A0 and
    # therefore depended on which earlier guard owned that site.  0.20.21C
    # integrates Direct presentation authority into the existing active leaf.
    assert 'presentation_guard = next(' not in src
    assert 'install_slippi_presentation_barrier' not in src
    assert 'origin_addr=(adventure_gateway_scope[\'gateway_origin_address\']' in src
    assert "'integrated_into_leaf': True" in src


def test_builder_fix_keeps_runtime_version_02021():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.21'" in src
