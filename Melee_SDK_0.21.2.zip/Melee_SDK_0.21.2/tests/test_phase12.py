from pathlib import Path
from tempfile import TemporaryDirectory

from sdk.melee_dat import FighterDAT, analyze_figatree_archive, retime_figatree_archive

FIX = Path('/mnt/data/fighters_extract/Melee_Fighters')


def test_figatree_analysis_falcon_punch():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    aj = (FIX / 'PlCaAJ.dat').read_bytes()
    chunk = aj[move.anim_archive_offset:move.anim_archive_offset + move.anim_archive_size]
    info = analyze_figatree_archive(chunk)
    assert info['frames'] == 100.0
    assert info['track_count'] == 128
    assert info['wait_count'] == 1671


def test_figatree_retime_can_resize_archive_safely():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    aj = (FIX / 'PlCaAJ.dat').read_bytes()
    chunk = aj[move.anim_archive_offset:move.anim_archive_offset + move.anim_archive_size]
    new_chunk, result = retime_figatree_archive(chunk, 2.0)
    assert result['new_frames'] == 200.0
    assert result['new_size'] > result['old_size']
    check = analyze_figatree_archive(new_chunk)
    assert check['frames'] == 200.0
    assert check['track_count'] == 128


def test_script_assembler_can_grow_fighter_archive_and_reopen():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    before = len(f.parse_script(move))
    result = f.duplicate_event(move, 9)  # first Spawn Hitbox
    assert result['new_script_bytes'] == result['old_script_bytes'] + 20
    assert len(f.parse_script(f.animations[move.index])) == before + 1
    with TemporaryDirectory() as td:
        out = Path(td) / 'PlCa.dat'
        f.save_as(out)
        reopened = FighterDAT(out)
        assert len(reopened.parse_script(reopened.animations[move.index])) == before + 1


def test_add_hitbox_phase_creates_requested_active_window():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    f.add_hitbox_phase(move, 40, 3)
    timing = f.analyze_move_timing(f.animations[move.index])
    assert {'start': 40.0, 'end': 43.0} in timing['active_windows']
    assert {'start': 52.0, 'end': 57.0} in timing['active_windows']


def test_full_move_speed_retimes_script_and_actual_aj():
    f = FighterDAT(FIX / 'PlCa.dat')
    move = next(a for a in f.animations if a.action_name == 'SpecialN')
    aj = (FIX / 'PlCaAJ.dat').read_bytes()
    new_aj, result = f.retime_full_move(move, aj, 2.0)
    edited = f.animations[move.index]
    timing = f.analyze_move_timing(edited)
    assert timing['first_active'] == 26.0
    assert timing['script_end'] == 39.0
    chunk = new_aj[edited.anim_archive_offset:edited.anim_archive_offset + edited.anim_archive_size]
    info = analyze_figatree_archive(chunk)
    assert info['frames'] == 50.0
    assert result['script_timers_changed'] == 5
    with TemporaryDirectory() as td:
        ajp = Path(td) / 'PlCaAJ.dat'
        ajp.write_bytes(new_aj)
        validation = f.validate_animation_archive(ajp)
        assert validation['errors'] == []
        assert validation['valid_chunks'] == validation['checked_unique_chunks']
