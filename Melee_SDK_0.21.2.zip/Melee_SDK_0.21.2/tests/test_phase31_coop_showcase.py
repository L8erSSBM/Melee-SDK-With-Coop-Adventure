from pathlib import Path

from sdk.adventure_probe import (
    _respawn_platform_wrapper, _spawn_setup_stub,
    RESPAWN_PLATFORM_HOOK, RESPAWN_PLATFORM_EXPECTED,
    PLAYER_LOAD_COORDS, PLAYER_SET_SPAWN_PLATFORM_POS,
)
from sdk.iso_builder import BUILD_VARIANTS
from sdk.ppc import blr, decode_branch, lbz, ori, stb


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def _branches(base, raw):
    out=[]
    for i,w in enumerate(_words(raw)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            out.append(decode_branch(base+i*4,w))
    return out


def test_phase31_respawn_hook_matches_canonical_retail_call():
    assert RESPAWN_PLATFORM_HOOK == 0x80167248
    assert RESPAWN_PLATFORM_EXPECTED.hex() == '4becbb39'
    d=decode_branch(RESPAWN_PLATFORM_HOOK, RESPAWN_PLATFORM_EXPECTED)
    assert d['link'] is True
    assert d['target'] == PLAYER_SET_SPAWN_PLATFORM_POS


def test_phase31_respawn_wrapper_anchors_p2_to_p1_then_preserves_retail_call():
    base=0x804DF400
    raw=_respawn_platform_wrapper(base)
    calls=[x for x in _branches(base,raw) if x['link']]
    targets=[x['target'] for x in calls]
    assert PLAYER_LOAD_COORDS in targets
    assert PLAYER_SET_SPAWN_PLATFORM_POS in targets
    # Wrapper is entered through a BL and must return through the incoming LR.
    assert _words(raw)[-1] == blr()


def test_phase31_friendly_fire_is_opt_in_only():
    base=0x804DF000
    coop=_words(_spawn_setup_stub(base, friendly_fire=False))
    chaos=_words(_spawn_setup_stub(base, friendly_fire=True))
    ff_seq=[lbz(11,1,30), ori(11,11,1), stb(11,1,30)]
    assert not all(x in coop for x in ff_seq)
    assert all(x in chaos for x in ff_seq)
    assert len(chaos) == len(coop) + 3


def test_phase31_showcase_build_variants_are_exposed():
    assert 'coop_showcase' in BUILD_VARIANTS
    assert 'coop_chaos' in BUILD_VARIANTS
