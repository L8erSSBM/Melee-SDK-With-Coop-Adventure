from __future__ import annotations

import hashlib, json
from pathlib import Path
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from sdk import slippi_adventure_entry_hardening as h

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/'Build'/'historical'/'SDK020_BOOT_ISOLATION.dol'
NEW=ROOT/'Build'/'historical'/'SDK021_SLIPPI_ADVENTURE_ENTRY.dol'
MAN=ROOT/'Build'/'SDK021_runtime_manifest.json'


def _m(): return json.loads(MAN.read_text())


def test_runtime_evidence_addresses_map_to_presentation_hook():
    m=_m(); row=next(x for x in m['hooks'] if x['name']=='adventure_presentation_p2_start_mirror')
    assert row['stub_address']==0x804DFB60
    s=m['slippi_adventure_entry_hardening']
    assert s['old_clobbered_trampoline']==0x804DFB40
    assert s['retargeted_call_sites']==[0x804DFB70,0x804DFC60]


def test_presentation_calls_no_longer_target_clobbered_slot():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_hardening']
    for site in s['retargeted_call_sites']:
        dec=decode_branch(site,d.read_at_address(site,4))
        assert dec['link'] is True
        assert dec['target']==s['safe_retail_accessor_copy']
        assert dec['target']!=s['old_clobbered_trampoline']


def test_safe_copy_is_complete_retail_accessor_and_marker_follows():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_hardening']; a=s['safe_retail_accessor_copy']
    assert d.read_at_address(a,32)==h.RETAIL_ACCESSOR
    assert d.read_at_address(a+32,8)==h.MARKER


def test_old_trampoline_is_now_unreferenced_by_presentation_wrapper():
    d=DOLImage(NEW); s=_m()['slippi_adventure_entry_hardening']; base=s['presentation_wrapper']
    for a in range(base,base+0x140,4):
        try: dec=decode_branch(a,d.read_at_address(a,4))
        except Exception: continue
        assert not (dec and dec.get('link') and dec.get('target')==s['old_clobbered_trampoline'])


def test_binary_delta_from_020_is_narrow():
    old=OLD.read_bytes(); new=NEW.read_bytes(); d=DOLImage(NEW); s=_m()['slippi_adventure_entry_hardening']
    assert len(old)==len(new)
    changed={i for i,(a,b) in enumerate(zip(old,new)) if a!=b}
    allowed=set()
    for site in s['retargeted_call_sites']:
        off=d.file_offset_for_address(site,4); allowed.update(range(off,off+4))
    off=d.file_offset_for_address(s['safe_retail_accessor_copy'],40); allowed.update(range(off,off+40))
    assert changed<=allowed


def test_manifest_hash_matches_candidate():
    raw=NEW.read_bytes(); m=_m()
    assert m['sdk_version']=='0.20.1'
    assert m['format']=='melee-character-sdk-0.20.1-slippi-adventure-entry'
    assert hashlib.sha256(raw).hexdigest()==m['output_sha256']
