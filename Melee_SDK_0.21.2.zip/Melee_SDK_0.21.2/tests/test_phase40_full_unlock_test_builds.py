from pathlib import Path
import inspect

from sdk import adventure_probe
from sdk.iso_builder import build_test_iso

ROOT=Path(__file__).resolve().parents[1]


def test_unlock_query_sites_are_source_grounded_gale01_102():
    assert adventure_probe.GM_STAGE_UNLOCK_CHECK == 0x80164430
    assert adventure_probe.GM_ALL_STAGES_UNLOCKED == 0x80164600
    assert adventure_probe.GM_IS_CKIND_UNLOCKED == 0x80164840
    assert adventure_probe.GM_ALL_CHARACTERS_UNLOCKED == 0x80164ABC
    assert adventure_probe.GM_UNLOCK_ROSTER_MENU_CHECK == 0x80164B48
    assert adventure_probe.UNLOCK_QUERY_TRUE == bytes.fromhex('386000014e800020')


def test_unlock_all_is_explicit_opt_in_only():
    sig=inspect.signature(adventure_probe.install_phase30_coop_spawn_probe)
    assert sig.parameters['enable_unlock_all'].default is False
    sig2=inspect.signature(build_test_iso)
    assert sig2.parameters['unlock_all'].default is False


def test_phase40_full_unlock_bats_enable_only_test_query_override():
    cases={
        'BUILD_COOP_FULL_UNLOCK_TEST.bat': ('--variant coop_showcase', False, False),
        'BUILD_COOP_REVIVE_FULL_UNLOCK_TEST.bat': ('--variant coop_showcase', True, False),
        'BUILD_COOP_CHAOS_FULL_UNLOCK_TEST.bat': ('--variant coop_chaos', False, False),
        'BUILD_COOP_CHAOS_REVIVE_FULL_UNLOCK_TEST.bat': ('--variant coop_chaos', True, True),
    }
    for name,(variant,revive,shortcuts) in cases.items():
        text=(ROOT/'Regression Builds'/name).read_text(errors='replace')
        assert '--unlock-all' in text
        assert variant in text
        assert ('--scene-revive' in text) is revive
        assert ('--test-shortcuts' in text) is shortcuts
        assert 'Save unlock bits are NOT written' in text or name.startswith('BUILD_COOP_CHAOS')
