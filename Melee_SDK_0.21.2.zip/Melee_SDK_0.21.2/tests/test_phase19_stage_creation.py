import json
from pathlib import Path
import pytest
import sdk.workspace as ws

class DummyStage:
    def __init__(self, source):
        self.source=source
    def validate(self): return None

def make_project(tmp_path, monkeypatch):
    monkeypatch.setattr(ws,'StageDAT',DummyStage)
    for d in ('Original','Working','Build'): (tmp_path/d).mkdir()
    data=b'valid donor bytes'
    (tmp_path/'Original'/'GrNBa.dat').write_bytes(data)
    (tmp_path/'Working'/'GrNBa.dat').write_bytes(data)
    manifest={'resources':[{'filename':'GrNBa.dat','source_relative':'disc','sha256':'x','size':len(data)}],
              'fighters':[], 'stages':[{'filename':'GrNBa.dat','display_name':'Battlefield','source_relative':'disc'}]}
    (tmp_path/ws.MANIFEST_NAME).write_text(json.dumps(manifest))
    return ws.MeleeProject(tmp_path)

def test_phase19_new_stage_preflight_separates_donor_and_new_name(tmp_path,monkeypatch):
    p=make_project(tmp_path,monkeypatch)
    with pytest.raises(ValueError,match='Donor stage'):
        p.preflight_new_stage('GrXz.dat','GrXz.dat')
    # A valid new name is never looked up as though it were the donor.
    q=p.clone_stage_variant('GrNBa.dat','GrXz.dat','XZ Test')
    assert q.name=='GrXz.dat' and q.read_bytes()==b'valid donor bytes'
    assert p.stage_by_filename('GrXz.dat').display_name=='XZ Test'

def test_phase19_duplicate_new_name_is_rejected_before_write(tmp_path,monkeypatch):
    p=make_project(tmp_path,monkeypatch)
    p.clone_stage_variant('GrNBa.dat','GrXz.dat','XZ')
    with pytest.raises(ValueError,match='already exists'):
        p.preflight_new_stage('GrNBa.dat','GrXz.dat')
