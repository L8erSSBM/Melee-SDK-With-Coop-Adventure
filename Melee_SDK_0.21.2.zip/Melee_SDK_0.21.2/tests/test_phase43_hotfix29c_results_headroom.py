"""HF29C Icies Team-Kirby results-background omission tests."""
from __future__ import annotations

import hashlib
import json
import struct
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, encode_branch
from sdk import clear_screen_background_omit as hf
from sdk import clear_screen_memory as hf22

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804E3000
GUARD = 0x804DEC8F
COUNTER = 0x804E2FF0


def put(mem, addr, value, size=4):
    raw = int(value & ((1 << (size * 8)) - 1)).to_bytes(size, 'big')
    for i, b in enumerate(raw):
        mem[addr + i] = b


def get(mem, addr, size=4):
    return int.from_bytes(bytes(mem.get(addr + i, 0) for i in range(size)), 'big')


def execute(blob, base, *, mem=None, regs_init=None, stop_targets=()):
    mem = {} if mem is None else mem
    regs = [0] * 32
    if regs_init:
        for r, v in regs_init.items():
            regs[r] = v & 0xFFFFFFFF
    cr = {30: False}
    pc = base
    stop = set(stop_targets)

    def s16(x):
        return x - 0x10000 if x & 0x8000 else x

    def signed32(x):
        return x - 0x100000000 if x & 0x80000000 else x

    for _ in range(500):
        if pc in stop:
            return {'target': pc, 'mem': mem, 'regs': regs}
        if not base <= pc < base + len(blob):
            raise AssertionError(hex(pc))
        w = struct.unpack_from('>I', blob, pc - base)[0]
        op = w >> 26
        nxt = pc + 4
        rt = (w >> 21) & 31
        ra = (w >> 16) & 31
        imm = s16(w & 0xFFFF)
        if op == 14:  # addi
            regs[rt] = ((regs[ra] if ra else 0) + imm) & 0xFFFFFFFF
        elif op == 15:  # lis/addis
            regs[rt] = ((regs[ra] if ra else 0) + (imm << 16)) & 0xFFFFFFFF
        elif op == 32:  # lwz
            regs[rt] = get(mem, (regs[ra] + imm) & 0xFFFFFFFF, 4)
        elif op == 34:  # lbz
            regs[rt] = get(mem, (regs[ra] + imm) & 0xFFFFFFFF, 1)
        elif op == 36:  # stw
            put(mem, (regs[ra] + imm) & 0xFFFFFFFF, regs[rt], 4)
        elif op == 11:  # cmpwi
            cr[30] = signed32(regs[ra]) == imm
        elif op == 16:  # bc
            bd = w & 0xFFFC
            if bd & 0x8000:
                bd -= 0x10000
            bo, bi = (w >> 21) & 31, (w >> 16) & 31
            bit = cr.get(bi, False)
            take = bo == 20 or (bo == 12 and bit) or (bo == 4 and not bit)
            if take:
                nxt = (pc + bd) & 0xFFFFFFFF
        elif op == 18:  # b/bl
            nxt = decode_branch(pc, w.to_bytes(4, 'big'))['target']
        else:
            raise AssertionError(f'unsupported {w:08x} @ {pc:08x}')
        pc = nxt
    raise AssertionError('wrapper did not terminate')


def exact_mem(*, mode=hf.GM_ADVENTURE, state=hf.TEAM_KIRBY_FIGHT_STATE, guard=1):
    mem = {}
    put(mem, hf.ADVENTURE_MODE_ADDR, mode, 1)
    put(mem, hf.ADVENTURE_STATE_ADDR, state, 1)
    put(mem, GUARD, guard, 1)
    return mem


def exact_regs(**overrides):
    regs = {4: 640, 5: 480, 6: 5, 7: 0}
    regs.update(overrides)
    return regs


def test_exact_verified_path_omits_background_and_counts():
    blob = hf.wrapper(BASE, GUARD, COUNTER)
    mem = exact_mem()
    put(mem, COUNTER, 7)
    r = execute(blob, BASE, mem=mem, regs_init=exact_regs(),
                stop_targets=(hf.BACKGROUND_CONTINUE, hf.ALLOC_RETAIL))
    assert r['target'] == hf.BACKGROUND_CONTINUE
    assert get(mem, COUNTER) == 8


def test_nonterminal_or_non_team_kirby_paths_tail_enter_retail():
    blob = hf.wrapper(BASE, GUARD, COUNTER)
    for mem in (
        exact_mem(guard=0),
        exact_mem(state=0x22),
        exact_mem(mode=0),
    ):
        r = execute(blob, BASE, mem=mem, regs_init=exact_regs(),
                    stop_targets=(hf.BACKGROUND_CONTINUE, hf.ALLOC_RETAIL))
        assert r['target'] == hf.ALLOC_RETAIL
        assert get(mem, COUNTER) == 0


def test_nonmatching_image_signature_stays_retail():
    blob = hf.wrapper(BASE, GUARD, COUNTER)
    for reg, value in ((4, 320), (5, 240), (6, 4), (7, 1)):
        regs = exact_regs(); regs[reg] = value
        mem = exact_mem()
        r = execute(blob, BASE, mem=mem, regs_init=regs,
                    stop_targets=(hf.BACKGROUND_CONTINUE, hf.ALLOC_RETAIL))
        assert r['target'] == hf.ALLOC_RETAIL
        assert get(mem, COUNTER) == 0


def test_installer_changes_only_retail_allocation_call_plus_append(tmp_path):
    # Reconstruct the shipped HF29 baseline from the current HF29C DOL by
    # removing HF29C; then reinstall and require byte identity.
    # This reconstruction checks the archived HF29C artifact. Current HF29D
    # containment is checked separately in test_hf29d_pool_packing.py.
    start = ROOT / 'Build' / 'historical' / 'HF29C.dol'
    manifest = json.loads((ROOT / 'Build' / 'HF29C_runtime_manifest.json').read_text())
    raw = bytearray(start.read_bytes())
    d = DOLImage(raw)
    guard = manifest['probe_section']['address'] + 0x2F
    patch = manifest['clear_screen_background_omit']

    # Paired HF22 capture/display hooks are gone; only allocation is redirected.
    assert d.read_at_address(hf22.COPY_SITE, 4) == encode_branch(hf22.COPY_SITE, hf22.COPY_RETAIL, link=True)
    assert d.read_at_address(hf22.DRAW_SITE, 4) == encode_branch(hf22.DRAW_SITE, hf22.DRAW_RETAIL, link=True)
    assert decode_branch(hf.ALLOC_SITE, d.read_at_address(hf.ALLOC_SITE, 4))['target'] == patch['stub_address']

    marker_off = raw.find(b'HF29CBGO')
    assert marker_off >= 0
    sec = next(s for s in d.sections if s.kind == 'data' and s.index == 8)
    base_size = marker_off - sec.file_offset - patch['section']['padding']
    off = d.file_offset_for_address(hf.ALLOC_SITE, 4)
    raw[off:off + 4] = encode_branch(hf.ALLOC_SITE, hf.ALLOC_RETAIL, link=True)
    struct.pack_into('>I', raw, 0xAC + 8 * 4, base_size)
    del raw[sec.file_offset + base_size:]

    assert hashlib.sha1(raw).hexdigest() == manifest['hf29c_results_headroom']['base_sha1']
    assert hashlib.sha256(raw).hexdigest() == manifest['hf29c_results_headroom']['base_sha256']

    rebuilt = DOLImage(raw)
    result = hf.install(rebuilt, 8, guard)
    out = tmp_path / 'hf29c.dol'
    rebuilt.save_as(out)
    assert result['marker'] == 'HF29CBGO'
    assert out.read_bytes() == start.read_bytes()


def test_packaged_dol_contains_only_new_results_guard_not_hf22_hf28_stack():
    raw = (ROOT / 'Build' / 'start.dol').read_bytes()
    assert b'HF29CBGO' in raw
    assert b'HF29TKRW' in raw
    for marker in (
        b'HF22CLEAR', b'HF23FXMG', b'HF24CLSK', b'HF25ECLR',
        b'HF26TKFC', b'HF27TKWP', b'HF28TKFF',
    ):
        assert marker not in raw
