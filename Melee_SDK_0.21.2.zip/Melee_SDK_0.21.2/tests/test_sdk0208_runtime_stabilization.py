from pathlib import Path
import inspect

from sdk import adventure_probe
from sdk import adventure_gateway_scope as scope
from sdk.dol_patch import DOLImage
from sdk.ppc import encode_branch
import sdk.team_kirby_pool_packing as pool

ROOT = Path(__file__).resolve().parents[1]


def test_current_pool_packer_remains_team_kirby_only():
    src = inspect.getsource(pool.wrapper)
    assert '(MODE, 4), (STATE, 0x23)' in src
    assert not hasattr(pool, 'install_current')


def test_current_builder_uses_gover_to_adventure_bridge_plus_final_origin_guard():
    src = inspect.getsource(adventure_probe.install_phase30_coop_spawn_probe)
    assert 'completion_retail_rollback' in src
    assert 'POST_STAFFROLL_RETURN_RETAIL' in src
    assert 'requires guarded GOver completion bridge' in src
    assert 'requires captured-origin completion wrapper' in src
    assert 'final Adventure state-commit wrapper' in src


def test_current_completion_policy_is_builder_owned_not_reference_dol_owned():
    src = inspect.getsource(adventure_probe.install_phase30_coop_spawn_probe)
    assert 'staffroll_installed = dol.read_at_address(POST_STAFFROLL_RETURN_CALL, 4)' in src
    assert 'coming_soon_installed = dol.read_at_address(CAMPAIGN_COMPLETE_SET_PENDING_CALL, 4)' in src
    assert 'successful_completion_bridge' in src
    assert 'requires captured-origin completion wrapper' in src


def test_packaged_dol_keeps_static_cpu_spawn_site_retail():
    d = DOLImage(ROOT / 'Build/start.dol')
    assert d.read_at_address(0x8016E48C, 4) == bytes.fromhex('387c0000')
