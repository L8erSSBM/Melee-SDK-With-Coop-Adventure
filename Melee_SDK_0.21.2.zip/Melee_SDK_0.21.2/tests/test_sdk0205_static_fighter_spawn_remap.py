from sdk.adventure_probe import (
    _spawn_setup_stub,
    STATIC_FIGHTER_SPAWN_SLOT_HOOK,
    STATIC_FIGHTER_SPAWN_SLOT_EXPECTED,
    CPU_SLOT2_INIT_OFFSET,
    CPU_SLOT3_INIT_OFFSET,
)
from sdk.adventure_gateway_scope import ACTIVE_GUARDS, CORE_GUARDS
from sdk.ppc import addi


def _words(raw: bytes):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def test_sdk0205_static_spawn_site_remains_gateway_scope_guarded():
    # 0.20.6 reuses the same central retail site but replaces the failed
    # slot-1 marker policy with live encounter anchoring.
    assert len(CORE_GUARDS) == 24
    spec = next(x for x in ACTIVE_GUARDS if x.name == 'static_fighter_spawn_slot_remap')
    assert spec.site == STATIC_FIGHTER_SPAWN_SLOT_HOOK
    assert spec.retail == STATIC_FIGHTER_SPAWN_SLOT_EXPECTED
    assert STATIC_FIGHTER_SPAWN_SLOT_EXPECTED == addi(3, 28, 0)


def test_sdk0205_corneria_playerinit_special_case_stays_removed():
    # The failed 0.20.4 PlayerInitData-byte special case must not return.
    words = _words(_spawn_setup_stub(0x804F1800))
    from sdk.ppc import stb
    assert stb(11, CPU_SLOT2_INIT_OFFSET + 0x05, 30) not in words
    assert stb(11, CPU_SLOT3_INIT_OFFSET + 0x05, 30) not in words
