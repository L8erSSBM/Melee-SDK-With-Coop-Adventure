from sdk.ppc import addi, cmpwi, encode_bc, lbz, li, lis, lwz, stb, stw, stwu
from sdk.adventure_probe import (
    _spawn_setup_stub, _spawn_gate_stub, _singleplayer_p2_loader_stub,
    PLAYER_INIT_SIZE, P1_INIT_OFFSET, P2_INIT_OFFSET, P2_SETUP_HOOK, SPAWN_GATE_HOOK, SPAWN_MULTIPLAYER_TARGET,
    GM_CURRENT_MODE_ADDR, GM_ADVENTURE, SINGLEPLAYER_P2_LOADER_HOOK, PLAYER_INIT_APPLY,
)
from sdk.ppc import decode_branch


def _words(raw):
    return [raw[i:i+4] for i in range(0,len(raw),4)]


def test_phase30_ppc_basic_encoders_match_known_opcodes():
    assert GM_CURRENT_MODE_ADDR == 0x80479D30
    assert GM_ADVENTURE == 4
    assert lis(12,0x8048).hex()=='3d808048'
    assert lbz(0,-0x62D0,12).hex()=='880c9d30'
    assert cmpwi(0,4,crf=7).hex()=='2f800004'
    assert stwu(1,-0x20,1).hex()=='9421ffe0'
    assert stw(11,0x24,1).hex()=='91610024'
    assert lwz(11,0x24,1).hex()=='81610024'
    assert stb(11,0x85,30).hex()=='997e0085'
    assert li(28,2).hex()=='3b800002'


def test_spawn_setup_stub_clones_playerinitdata_without_unsafe_retail_call():
    base=0x804DF000; raw=_spawn_setup_stub(base); words=_words(raw)
    calls=[]; branches=[]
    for i,w in enumerate(words):
        if (int.from_bytes(w,'big')>>26)==18:
            d=decode_branch(base+i*4,w); (calls if d['link'] else branches).append(d)
    # StartMeleeData setup itself is a source-grounded 0x24-byte clone.
    assert calls == []
    assert PLAYER_INIT_SIZE == 0x24
    for off in range(0,PLAYER_INIT_SIZE,4):
        assert lwz(11,P1_INIT_OFFSET+off,30) in words
        assert stw(11,P2_INIT_OFFSET+off,30) in words
    assert stb(11,P2_INIT_OFFSET+0x01,30) in words
    assert stb(11,P2_INIT_OFFSET+0x04,30) in words
    assert stb(11,P2_INIT_OFFSET+0x05,30) in words
    assert sum(x['target']==P2_SETUP_HOOK+4 for x in branches)==2
    assert li(28,2) in words
    assert addi(28,3,1) in words

def test_spawn_gate_stub_has_adventure_force_path_and_retail_fallthrough():
    base=0x804DF100; raw=_spawn_gate_stub(base); words=_words(raw)
    targets=[]
    for i,w in enumerate(words):
        if (int.from_bytes(w,'big')>>26)==18:
            targets.append(decode_branch(base+i*4,w)['target'])
    assert targets.count(SPAWN_MULTIPLAYER_TARGET)==2
    assert SPAWN_GATE_HOOK+4 in targets


def test_conditional_branch_encoder_short_range():
    raw=encode_bc(0x80001000,0x80001010,bo=4,bi=30)
    assert len(raw)==4
    assert int.from_bytes(raw,'big')>>26==16


def test_singleplayer_loader_stub_applies_p2_and_preserves_other_1p_modes():
    base=0x804DF200; raw=_singleplayer_p2_loader_stub(base); words=_words(raw)
    calls=[]; branches=[]
    for i,w in enumerate(words):
        if (int.from_bytes(w,'big')>>26)==18:
            d=decode_branch(base+i*4,w); (calls if d['link'] else branches).append(d)
    assert [x['target'] for x in calls] == [PLAYER_INIT_APPLY]
    assert li(3,1) in words
    assert addi(4,30,P2_INIT_OFFSET) in words
    assert li(31,2) in words
    assert li(31,1) in words
    assert SINGLEPLAYER_P2_LOADER_HOOK+4 in [x['target'] for x in branches]
