"""HF25 pre-terminal/forced Team-Kirby clear-screen fail-safe tests."""
import struct

import pytest

from sdk import early_clear_failsafe as ef
from sdk.ppc import decode_branch, encode_branch

BASE = 0x804E8000
HF24 = 0x804E09C0
GUARD = 0x804DEC8F
P1 = 0x804DEC8A
P2 = 0x804DEC86
COUNTER = 0x804E7F10


def put(memory, address, value, size=4):
    b = int(value & ((1 << (size*8))-1)).to_bytes(size, 'big')
    for i,x in enumerate(b): memory[address+i]=x


def get(memory,address,size=4):
    return int.from_bytes(bytes(memory.get(address+i,0) for i in range(size)),'big')


def run(*,mode=4,state=0x23,guard=0,p1=0x12,p2=0x0E,
        args=(0x80472D58,640,480,5,0),counter=0):
    mem={}
    put(mem,ef.ADVENTURE_MODE,mode,1); put(mem,ef.ADVENTURE_STATE,state,1)
    put(mem,GUARD,guard,1); put(mem,P1,p1,1); put(mem,P2,p2,1); put(mem,COUNTER,counter)
    regs=[0]*32
    for i,v in enumerate(args,3): regs[i]=v
    pc=BASE; relation=0
    blob=ef.wrapper(BASE,HF24,GUARD,P1,P2,COUNTER)
    def s16(v): return v-0x10000 if v&0x8000 else v
    def s32(v): return v-0x100000000 if v&0x80000000 else v
    def crbit(bi):
        if bi==28:return relation<0
        if bi==29:return relation>0
        if bi==30:return relation==0
        if bi==31:return False
        raise AssertionError(bi)
    for _ in range(1000):
        if pc in (HF24,ef.BACKGROUND_CONTINUE): return pc,regs,mem
        if not BASE<=pc<BASE+len(blob): raise AssertionError(hex(pc))
        w=struct.unpack_from('>I',blob,pc-BASE)[0]
        op=w>>26; rt=(w>>21)&31; ra=(w>>16)&31; imm=s16(w&0xffff); nxt=pc+4
        if op==14: regs[rt]=((regs[ra] if ra else 0)+imm)&0xffffffff
        elif op==15: regs[rt]=((regs[ra] if ra else 0)+(imm<<16))&0xffffffff
        elif op==34: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,1)
        elif op==32: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,4)
        elif op==36: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt])
        elif op==11:
            av,bv=s32(regs[ra]),imm; relation=-1 if av<bv else 1 if av>bv else 0
        elif op==16:
            bd=w&0xfffc
            if bd&0x8000: bd-=0x10000
            bo,bi=(w>>21)&31,(w>>16)&31
            take=bo==20 or (bo==12 and crbit(bi)) or (bo==4 and not crbit(bi))
            if take:nxt=(pc+bd)&0xffffffff
        elif op==18: nxt=decode_branch(pc,w.to_bytes(4,'big'))['target']
        else: raise AssertionError(f'unsupported {w:08x}')
        pc=nxt
    raise AssertionError('did not terminate')


def test_captured_hf24_failure_shape_skips_background():
    target,regs,mem=run(guard=0,p1=0x12,p2=0x0E)
    assert target==ef.BACKGROUND_CONTINUE
    assert tuple(regs[3:8])==(0x80472D58,640,480,5,0)
    assert get(mem,COUNTER)==1


def test_p1_icicies_is_also_covered():
    target,_,mem=run(p1=0x0E,p2=0x05)
    assert target==ef.BACKGROUND_CONTINUE and get(mem,COUNTER)==1


def test_normal_terminal_c1_delegates_to_hf24_unchanged():
    args=(0x80472D58,640,480,5,0)
    target,regs,mem=run(guard=1,args=args)
    assert target==HF24 and tuple(regs[3:8])==args and get(mem,COUNTER)==0


@pytest.mark.parametrize('kwargs',[{'mode':3},{'state':0x22},{'p1':0x12,'p2':0x05}])
def test_unrelated_paths_delegate_to_hf24(kwargs):
    args=(0x80472D58,640,480,5,0)
    target,regs,mem=run(**kwargs,args=args)
    assert target==HF24 and tuple(regs[3:8])==args and get(mem,COUNTER)==0


@pytest.mark.parametrize('args',[
    (0x80472D58,320,240,5,0),
    (0x80472D58,640,480,4,0),
    (0x80472D58,640,480,5,1),
])
def test_unexpected_allocation_signature_delegates(args):
    target,regs,mem=run(args=args)
    assert target==HF24 and tuple(regs[3:8])==args and get(mem,COUNTER)==0


def test_skip_counter_saturates():
    target,_,mem=run(counter=0xffffffff)
    assert target==ef.BACKGROUND_CONTINUE and get(mem,COUNTER)==0xffffffff


def test_install_requires_hf24_hook_before_mutating():
    class WrongDOL:
        def read_at_address(self,addr,size): return bytes(4)
    with pytest.raises(ValueError,match='expected HF24 allocation hook mismatch'):
        ef.install(WrongDOL(),8,terminal_guard=GUARD,p1_ckind_addr=P1,
                   p2_ckind_addr=P2,hf24_stub=HF24)
