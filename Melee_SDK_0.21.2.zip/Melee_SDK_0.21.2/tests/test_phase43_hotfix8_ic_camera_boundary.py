from pathlib import Path

from sdk.adventure_probe import _control_player_entity_wrapper


def test_hf10_retires_hf8_camera_boundary_cleanup():
    """HF9 savestate proved the camera boundary never reaches Icies repair."""
    base=0x80412000
    blob=_control_player_entity_wrapper(
        base, 0x80410020,
        p2_ckind_addr=0x80410026,
        icies_teardown_guard_addr=0x8041002F,
        icies_diag_addr=0x80410032,
    )
    # Back to the compact Control-owner accessor; no D1/D2/D3/etc repair bytes.
    assert len(blob) == 72
    for marker in range(0xD1, 0xD7):
        assert (0x39600000 | marker).to_bytes(4,'big') not in blob


def test_hf10_still_does_not_patch_team_kirby_enter_or_rules_x54():
    text=Path('sdk/adventure_probe.py').read_text(encoding='utf-8')
    assert 'do not patch gm_801B4B28' in text
    assert "teamkirby_match_end=b''" in text
    assert "teamkirby_enter_wrapper=b''" in text


def test_current_persistent_marker_is_kcdg():
    text=Path('sdk/adventure_probe.py').read_text(encoding='utf-8')
    assert "payload[0x34:0x38]=b'KTDG'" in text
    assert '0xC0' in text and '0xC1' in text
