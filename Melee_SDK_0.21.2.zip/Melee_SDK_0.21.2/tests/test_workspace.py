from __future__ import annotations

import os
import tempfile
from pathlib import Path

from sdk.melee_dat import FighterDAT
from sdk.workspace import MeleeProject, sha256_file

FIGHTER_DIR = Path(os.environ['MELEE_FIGHTER_DIR']) if os.environ.get('MELEE_FIGHTER_DIR') else None


def test_workspace_copy_edit_build_reset():
    if not FIGHTER_DIR or not (FIGHTER_DIR / 'PlFx.dat').exists():
        return
    source_fox = FIGHTER_DIR / 'PlFx.dat'
    source_hash_before = sha256_file(source_fox)
    with tempfile.TemporaryDirectory() as td:
        project = MeleeProject.create(FIGHTER_DIR, Path(td) / 'Project')
        assert len(project.fighters) >= 1
        assert project.changed_files() == []

        f = FighterDAT(project.working_fighter_path('Fox'))
        f.set_common_attribute('weight', 76)
        project.save_fighter(f)
        changed = project.changed_files()
        assert [x['filename'] for x in changed] == ['PlFx.dat']

        result = project.build()
        assert [x['filename'] for x in result['modified_files']] == ['PlFx.dat']
        assert (project.build_dir / 'PlFx.dat').exists()
        assert (project.build_dir / 'build_manifest.json').exists()

        project.reset_fighter('Fox')
        assert project.changed_files() == []

    # The source extraction must remain bit-identical.
    assert sha256_file(source_fox) == source_hash_before


def test_runtime_state_overrides_persist_and_build_manifest():
    if not FIGHTER_DIR or not (FIGHTER_DIR / 'PlFx.dat').exists():
        return
    with tempfile.TemporaryDirectory() as td:
        project = MeleeProject.create(FIGHTER_DIR, Path(td) / 'Project')
        assert project.fighter_state_override('Fox', 'force_metal') is False
        project.set_fighter_state_override('Fox', 'force_metal', True)
        assert project.fighter_state_override('Fox', 'force_metal') is True

        # Verify persistence by reopening the project.
        reopened = MeleeProject(project.root)
        assert reopened.fighter_state_override('Fox', 'force_metal') is True
        result = reopened.build()
        assert result['runtime_override_status'] == 'pending_code_patch'
        assert result['runtime_overrides']['Fox']['force_metal'] is True

        reopened.set_fighter_state_override('Fox', 'force_metal', False)
        assert reopened.fighter_state_override('Fox', 'force_metal') is False
