import struct
from sdk.dol_patch import DOLImage, SymbolMap


def make_dol():
    raw=bytearray(0x300)
    # text0 file 0x100 -> RAM 0x80001000, size 0x80
    struct.pack_into('>I',raw,0x00,0x100)
    struct.pack_into('>I',raw,0x48,0x80001000)
    struct.pack_into('>I',raw,0x90,0x80)
    # data0 file 0x200 -> RAM 0x80300000, size 0x40
    struct.pack_into('>I',raw,0x1C,0x200)
    struct.pack_into('>I',raw,0x64,0x80300000)
    struct.pack_into('>I',raw,0xAC,0x40)
    raw[0x110:0x114]=b'ABCD'
    raw[0x208:0x20C]=b'WXYZ'
    return bytes(raw)


def test_dol_virtual_address_mapping_and_guarded_patch():
    d=DOLImage(make_dol())
    assert d.read_at_address(0x80001010,4)==b'ABCD'
    r=d.patch_at_address(0x80001010,b'1234',expected=b'ABCD')
    assert r['file_offset']==0x110
    assert d.read_at_address(0x80001010,4)==b'1234'


def test_symbol_map_and_symbol_patch():
    sm=SymbolMap.from_text('foo = .text:0x80001010; // type:function size:0x10 scope:global\nbar = .bss:0x80400000; // type:object size:0x20')
    assert sm.require('foo').size==0x10
    d=DOLImage(make_dol())
    d.patch_symbol(sm,'foo',b'!!',expected=b'AB')
    assert d.read_at_address(0x80001010,4)==b'!!CD'
    try: d.patch_symbol(sm,'bar',b'X')
    except ValueError as e: assert 'BSS' in str(e)
    else: raise AssertionError('BSS patch should be rejected')


def test_symbol_patch_enforces_declared_size():
    sm=SymbolMap.from_text('foo = .text:0x80001010; // type:function size:0x4 scope:global')
    d=DOLImage(make_dol())
    try: d.patch_symbol(sm,'foo',b'12345')
    except ValueError as e: assert 'exceeds' in str(e)
    else: raise AssertionError('oversize symbol patch should fail')


def test_append_loader_backed_data_section_without_guessing_cave():
    d=DOLImage(make_dol())
    # Synthetic image has no BSS, so allocator chooses RAM after data0.
    row=d.add_data_section(b'CUSTOM-DATA')
    assert row['kind']=='data' and row['size']==11
    assert d.read_at_address(row['address'],11)==b'CUSTOM-DATA'
    assert any(s.kind=='data' and s.index==row['index'] and s.address==row['address'] for s in d.sections)
