from sdk import adventure_gateway_scope as scope
from sdk.ppc import decode_branch
from hf29d_ppc import execute, put, get

BASE = 0x804F2800
ACTIVE = 0x804F0D10
ORIGIN = 0x804F0D11


def test_staffroll_completion_wrapper_rewrites_only_active_adventure_gover_return():
    blob = scope._staffroll_completion_wrapper(BASE, active_addr=ACTIVE, origin_addr=ORIGIN)
    mem={}
    put(mem, ACTIVE, 1, 1)
    put(mem, ORIGIN, 2, 1)  # GM_VS
    put(mem, scope.CURRENT_MODE, scope.GM_ADVENTURE_GOVER, 1)
    result=execute(blob, BASE, mem=mem, initial_regs={3: scope.GM_ADVENTURE},
                   stop_targets=(scope.GM_SET_PENDING_GAME_MODE,))
    assert result['target'] == scope.GM_SET_PENDING_GAME_MODE
    assert result['regs'][3] == scope.GM_ADVENTURE
    assert get(result['mem'], ACTIVE, 1) == 1
    assert get(result['mem'], ORIGIN, 1) == 2


def test_staffroll_completion_wrapper_is_exact_retail_for_inactive_or_wrong_mode():
    blob = scope._staffroll_completion_wrapper(BASE, active_addr=ACTIVE, origin_addr=ORIGIN)
    for active, mode in ((0, scope.GM_ADVENTURE_GOVER), (1, scope.GM_ADVENTURE)):
        mem={}
        put(mem, ACTIVE, active, 1)
        put(mem, ORIGIN, 2, 1)
        put(mem, scope.CURRENT_MODE, mode, 1)
        result=execute(blob, BASE, mem=mem, initial_regs={3: scope.GM_ADVENTURE},
                       stop_targets=(scope.GM_SET_PENDING_GAME_MODE,))
        assert result['target'] == scope.GM_SET_PENDING_GAME_MODE
        assert result['regs'][3] == scope.GM_ADVENTURE
        assert get(result['mem'], ACTIVE, 1) == active
        assert get(result['mem'], ORIGIN, 1) == 2


def test_staffroll_completion_wrapper_bridges_active_gover_independent_of_retail_exit_data():
    blob = scope._staffroll_completion_wrapper(BASE, active_addr=ACTIVE, origin_addr=ORIGIN)
    # The GOver exit_data is exactly what sent completed co-op runs to 1P.
    # Active gateway completion must therefore replace that argument with
    # GM_ADVENTURE while preserving the captured origin for the later state-68 exit.
    for requested, origin in ((1, 2), (scope.GM_ADVENTURE, 2)):
        mem={}
        put(mem, ACTIVE, 1, 1)
        put(mem, ORIGIN, origin, 1)
        put(mem, scope.CURRENT_MODE, scope.GM_ADVENTURE_GOVER, 1)
        result=execute(blob, BASE, mem=mem, initial_regs={3: requested},
                       stop_targets=(scope.GM_SET_PENDING_GAME_MODE,))
        assert result['target'] == scope.GM_SET_PENDING_GAME_MODE
        assert result['regs'][3] == scope.GM_ADVENTURE
        assert get(result['mem'], ACTIVE, 1) == 1
        assert get(result['mem'], ORIGIN, 1) == origin


def test_current_sdk_gateway_install_adds_post_staffroll_hook_only_with_captured_origin():
    # Historical HF29G installation remains byte-for-byte compatible because
    # capture_origin=False does not touch the new GOver completion site.
    from pathlib import Path
    import json
    from sdk.dol_patch import DOLImage
    root=Path(__file__).resolve().parents[1]
    m=json.loads((root/'Build'/'HF29F_runtime_manifest.json').read_text())
    pending=m['probe_section']['address']+0x2E

    hist=DOLImage(root/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol')
    scope.install(hist, m['probe_section']['index'], gateway_pending_addr=pending)
    assert hist.read_at_address(scope.POST_STAFFROLL_RETURN_CALL,4) == scope.POST_STAFFROLL_RETURN_RETAIL

    current=DOLImage(root/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol')
    out=scope.install(current, m['probe_section']['index'], gateway_pending_addr=pending,
                      enable_sdk0205_extras=True, capture_origin=True)
    row=out['post_staffroll_completion']
    assert row is not None
    dec=decode_branch(scope.POST_STAFFROLL_RETURN_CALL,
                      current.read_at_address(scope.POST_STAFFROLL_RETURN_CALL,4))
    assert dec['link'] is True
    assert dec['target'] == row['scope_stub']


def test_retail_gover_completion_call_is_followed_by_new_mode_pending_transition():
    from pathlib import Path
    from sdk.dol_patch import DOLImage
    root=Path(__file__).resolve().parents[1]
    d=DOLImage(root/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol')
    assert d.read_at_address(scope.POST_STAFFROLL_RETURN_CALL,4) == scope.POST_STAFFROLL_RETURN_RETAIL
    branch=decode_branch(0x801BEF28, d.read_at_address(0x801BEF28,4))
    assert branch['target'] == 0x801BEF6C
    pending=decode_branch(0x801BEF6C, d.read_at_address(0x801BEF6C,4))
    assert pending['target'] == scope.GM_SET_NEW_GAME_MODE_PENDING
    assert pending['link'] is True
