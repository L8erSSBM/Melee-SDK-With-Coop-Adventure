from pathlib import Path
import struct

from sdk import slippi_adventure_netplay_bridge as n
from sdk import slippi_direct_gateway as d
from sdk.dol_patch import DOLImage
from tests.hf29d_ppc import execute, get, put, SENTINEL

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804F8000
STATE = 0x804F7000
PENDING = 0x804F6F00
ACTIVE = 0x804F6F01
R13 = 0x80400000
ODB = 0x80BF3960
TXB = 0x80BF4680
RXB = 0x80BF46C0
SSRB = 0x80BF4820
SSCB = 0x80BF4880


def seed_scope(mem, *, pending=0, active=0):
    put(mem, PENDING, pending, 1)
    put(mem, ACTIVE, active, 1)


def seed_odb(mem, *, local_index=0, online_index=None, input_source_index=0):
    # Slippi InitOnlinePlay stores local matchmaking index at byte 0 and remote
    # matchmaking index at byte 1. They are distinct in a normal 1v1.
    if online_index is None:
        online_index = 1 - local_index
    put(mem, (R13 + n.OFST_R13_ODB_ADDR) & 0xFFFFFFFF, ODB, 4)
    put(mem, ODB + n.ODB_LOCAL_PLAYER_INDEX, local_index, 1)
    put(mem, ODB + n.ODB_ONLINE_PLAYER_INDEX, online_index, 1)
    put(mem, ODB + n.ODB_INPUT_SOURCE_INDEX, input_source_index, 1)
    # These first two offsets are intentionally unaligned in Slippi's packed ODB.
    put(mem, ODB + n.ODB_TXB_ADDR, TXB, 4)
    put(mem, ODB + n.ODB_RXB_ADDR, RXB, 4)
    put(mem, ODB + n.ODB_SSRB_ADDR, SSRB, 4)
    put(mem, ODB + n.ODB_SSCB_ADDR, SSCB, 4)



def seed_arena(mem, arena_hi=0x81829800):
    put(mem, (R13 + n.OFST_R13_ARENA_HI) & 0xFFFFFFFF, arena_hi, 4)
    return arena_hi


def seed_live_slippi_words(mem):
    for spec in n.GUARDS:
        put(mem, spec.site, int.from_bytes(spec.expected, 'big'), 4)
    put(mem, n.SLIPPI_EXI_VENEER, int.from_bytes(n.SLIPPI_EXI_VENEER_EXPECTED, 'big'), 4)


def test_guard_table_targets_decode_to_observed_bne_destinations():
    assert len(n.GUARDS) == 18
    for spec in n.GUARDS:
        w = int.from_bytes(spec.expected, 'big')
        assert w >> 26 == 16
        assert spec.expected[0] == 0x40
        assert spec.target != spec.site + 4


def test_guard_shim_allows_scope_but_preserves_original_cr0_branch_result():
    from sdk.ppc import li, cmpwi, encode_branch
    spec = next(g for g in n.GUARDS if g.name == 'trigger_send_input')
    shim_base = BASE + 0x100
    blob = n.build_guard_shim(shim_base, spec, pending_addr=PENDING, active_addr=ACTIVE, state_addr=STATE)
    prefix_base = BASE

    def run(*, scoped, compared_value):
        mem = {}
        put(mem, STATE + n.S_SESSION_SCOPE, scoped, 1)
        # Recreate the cmpwi immediately preceding the live Slippi branch so CR0
        # arrives at the shim exactly as it does in-game.
        prefix = li(5, compared_value) + cmpwi(5, 0) + encode_branch(prefix_base + 8, shim_base)
        return execute(prefix, prefix_base, mem=mem, extra_code=[(shim_base, blob)],
                       stop_targets={spec.site + 4, spec.target})

    assert run(scoped=1, compared_value=1)['target'] == spec.site + 4
    assert run(scoped=0, compared_value=0)['target'] == spec.site + 4
    assert run(scoped=0, compared_value=1)['target'] == spec.target

def test_memfree_guard_protects_only_captured_session_allocations_while_scoped():
    blob = n.build_free_wrapper(BASE, pending_addr=PENDING, active_addr=ACTIVE, state_addr=STATE)
    mem = {}
    put(mem, STATE + n.S_PHASE, n.PHASE_TRANSITION, 1)
    put(mem, STATE + n.S_ODB, n.STABLE_ODB, 4)
    r = execute(blob, BASE, mem=mem, initial_regs={3: n.STABLE_ODB})
    assert r['target'] == SENTINEL

    mem = {}
    put(mem, STATE + n.S_PHASE, n.PHASE_TRANSITION, 1)
    put(mem, STATE + n.S_ODB, ODB, 4)
    other = 0x81234560
    r = execute(blob, BASE, mem=mem, initial_regs={3: other}, stop_targets={n.HSD_MEM_FREE + 4})
    assert r['target'] == n.HSD_MEM_FREE + 4
    assert get(mem, STATE + n.S_FREE_SKIP_COUNT, 4) == 0

    mem = {}
    put(mem, STATE + n.S_SESSION_SCOPE, 0, 1)
    put(mem, STATE + n.S_ODB, ODB, 4)
    r = execute(blob, BASE, mem=mem, initial_regs={3: ODB}, stop_targets={n.HSD_MEM_FREE + 4})
    assert r['target'] == n.HSD_MEM_FREE + 4


def test_exi_filter_blocks_ba_and_defers_adventure_exit_to_live_b0():
    blob = n.build_exi_wrapper(BASE, pending_addr=PENDING, active_addr=ACTIVE, state_addr=STATE)
    command = 0x80410000

    # Campaign-scoped BA is blocked.
    mem = {}
    put(mem, STATE + n.S_PHASE, n.PHASE_TRANSITION, 1)
    put(mem, PENDING, 1, 1)
    put(mem, command, n.CLEANUP_CONNECTIONS, 1)
    r = execute(blob, BASE, mem=mem, initial_regs={3: command}, stop_targets={n.SLIPPI_EXI_TRANSFER})
    assert r['target'] == SENTINEL
    assert r['regs'][3] == 0

    # 0x39 is replay metadata, not connection cleanup; J forwards it.
    mem = {}
    put(mem, STATE + n.S_PHASE, n.PHASE_TRANSITION, 1)
    put(mem, PENDING, 1, 1)
    put(mem, command, n.GAME_END, 1)
    r = execute(blob, BASE, mem=mem, initial_regs={3: command}, stop_targets={n.SLIPPI_EXI_TRANSFER})
    assert r['target'] == n.SLIPPI_EXI_TRANSFER

    # Live B0 while pending raises the deferred scene-exit flag and still forwards.
    mem = {}
    put(mem, STATE + n.S_PHASE, n.PHASE_TRANSITION, 1)
    put(mem, PENDING, 1, 1)
    put(mem, command, n.ONLINE_INPUTS, 1)
    r = execute(blob, BASE, mem=mem, initial_regs={3: command}, stop_targets={n.SLIPPI_EXI_TRANSFER})
    assert r['target'] == n.SLIPPI_EXI_TRANSFER
    assert get(mem, n.GM_SCENE_EXIT_FLAG_ADDR, 4) == 1


def test_k10_keeps_core_rollback_and_audio_helpers_alive_without_teams_spoof():
    names = {g.name for g in n.ACTIVE_GUARDS}
    assert len(n.ACTIVE_GUARDS) == 17
    assert {'rollback_aux_gate_a', 'rollback_aux_gate_b',
            'skip_new_input_fetch_on_rollback',
            'prevent_pad_alarm_during_rollback',
            'sound_assign_instance_id', 'sound_no_destroy_voice',
            'sound_no_destroy_voice2', 'sound_prevent_duplicate_sounds'} <= names
    assert len(n.SNAPSHOT_GUARDS) == 1
    assert n.SNAPSHOT_GUARDS[0].name == 'teams_prevent_dead_stranding'

def test_arm_stub_captures_unaligned_odb_children_and_installs_live_branches():
    guard_shims = {g.site: 0x804FA000 + i * 0x80 for i, g in enumerate(n.GUARDS)}
    exi_wrapper = 0x804FB000
    table = n.build_patch_table(guard_shims=guard_shims, exi_wrapper_addr=exi_wrapper)
    table_addr = BASE + 0x500
    blob = n.build_arm_stub(BASE, state_addr=STATE, guard_shims=guard_shims,
                            exi_wrapper_addr=exi_wrapper, patch_table_addr=table_addr)
    mem = {}
    for i, b in enumerate(table): mem[table_addr + i] = b
    seed_odb(mem, local_index=0)
    seed_arena(mem)
    seed_live_slippi_words(mem)
    r = execute(blob, BASE, mem=mem, initial_regs={13: R13})
    assert r['target'] == SENTINEL
    assert r['regs'][3] == 1
    assert get(mem, STATE + n.S_TRACE, 1) == n.TRACE_ARMED
    assert get(mem, STATE + n.S_FAILURE, 1) == 0
    assert get(mem, STATE + n.S_LOCAL_INDEX, 1) == 0
    assert get(mem, STATE + n.S_ORIG_ODB, 4) == ODB
    assert get(mem, STATE + n.S_PHASE, 1) == n.PHASE_TRANSITION
    assert get(mem, STATE + n.S_ARM_ONLINE_INDEX, 1) == 1
    assert get(mem, STATE + n.S_ARM_INPUT_SOURCE_INDEX, 1) == 0
    assert get(mem, (R13 + n.OFST_R13_ARENA_HI) & 0xFFFFFFFF, 4) == n.SESSION_HIGH_BASE
    for spec in n.ACTIVE_GUARDS:
        assert get(mem, spec.site, 4) == 0x60000000
    for spec in n.SNAPSHOT_GUARDS:
        assert get(mem, spec.site, 4) == int.from_bytes(spec.expected, 'big')
    assert get(mem, n.SLIPPI_EXI_VENEER, 4) == int.from_bytes(
        n.encode_branch(n.SLIPPI_EXI_VENEER, exi_wrapper), 'big')


def test_k6_preserves_distinct_slippi_local_remote_and_input_source_indices():
    # K4 collapsed LOCAL and ONLINE to the opponent index. That is the exact
    # ownership bug which made PC P1 input drive Mewtwo/P2. K5 must preserve all
    # three Slippi bytes independently through relocation.
    for local_index, online_index, input_source in ((0, 1, 0), (1, 0, 1)):
        guard_shims = {}
        exi_wrapper = 0x804FB000
        table = n.build_patch_table(guard_shims=guard_shims, exi_wrapper_addr=exi_wrapper)
        table_addr = BASE + 0x500
        blob = n.build_arm_stub(BASE, state_addr=STATE, guard_shims=guard_shims,
                                exi_wrapper_addr=exi_wrapper, patch_table_addr=table_addr)
        mem = {}
        for i,b in enumerate(table): mem[table_addr+i]=b
        seed_odb(mem, local_index=local_index, online_index=online_index,
                 input_source_index=input_source)
        seed_arena(mem); seed_live_slippi_words(mem)
        r=execute(blob,BASE,mem=mem,initial_regs={13:R13})
        assert r['regs'][3] == 1
        assert get(mem,STATE+n.S_LOCAL_INDEX,1) == local_index
        assert get(mem,STATE+n.S_ARM_ONLINE_INDEX,1) == online_index
        assert get(mem,STATE+n.S_ARM_INPUT_SOURCE_INDEX,1) == input_source
        assert get(mem,n.STABLE_ODB+n.ODB_LOCAL_PLAYER_INDEX,1) == local_index
        assert get(mem,n.STABLE_ODB+n.ODB_ONLINE_PLAYER_INDEX,1) == online_index
        assert get(mem,n.STABLE_ODB+n.ODB_INPUT_SOURCE_INDEX,1) == input_source


def test_arm_stub_fails_closed_before_live_modification_on_unknown_slippi_word():
    guard_shims = {g.site: 0x804FA000 + i * 0x80 for i, g in enumerate(n.GUARDS)}
    exi_wrapper = 0x804FB000
    table = n.build_patch_table(guard_shims=guard_shims, exi_wrapper_addr=exi_wrapper)
    table_addr = BASE + 0x500
    blob = n.build_arm_stub(BASE, state_addr=STATE, guard_shims=guard_shims,
                            exi_wrapper_addr=exi_wrapper, patch_table_addr=table_addr)
    mem = {}
    for i, b in enumerate(table): mem[table_addr + i] = b
    seed_odb(mem, local_index=1)
    seed_live_slippi_words(mem)
    bad = n.GUARDS[4]
    put(mem, bad.site, 0xDEADBEEF, 4)
    r = execute(blob, BASE, mem=mem, initial_regs={13: R13})
    assert r['regs'][3] == 0
    assert get(mem, STATE + n.S_FAILURE, 1) == 0x20
    # Earlier guards were validated, not modified: installation starts only
    # after every guard and EXI veneer have passed validation.
    assert get(mem, n.GUARDS[0].site, 4) == int.from_bytes(n.GUARDS[0].expected, 'big')



def test_b0_repairs_zeroed_peer_identity_and_all_odb_child_pointers():
    base=0x804FC000; state=STATE; command=0x81201000
    snap_table=0x804FD000; patch_table=0x804FD100
    blob=n.build_exi_wrapper(base,pending_addr=PENDING,active_addr=ACTIVE,state_addr=state,
                             snapshot_table_addr=snap_table,patch_table_addr=patch_table)

    # Exercise both Direct role assignments. Slippi is free to make either
    # machine matchmaking-local index 0 or 1; that role must never be inferred
    # from the opponent byte or from the fighter's visible P1/P2 slot.
    for local_index, opponent_index, input_source in ((0,1,0),(1,0,0),(1,0,1)):
        mem={}
        put(mem,STATE+n.S_PHASE,n.PHASE_TRANSITION,1)
        put(mem,STATE+n.S_LOCAL_INDEX,local_index,1)
        put(mem,STATE+n.S_ARM_ONLINE_INDEX,opponent_index,1)
        put(mem,STATE+n.S_ARM_INPUT_SOURCE_INDEX,input_source,1)
        for i in range(n.STATE_SIZE): put(mem,state+i,(0xA5+i)&0xFF,1)
        put(mem,state+n.S_PHASE,n.PHASE_TRANSITION,1)
        put(mem,state+n.S_LOCAL_INDEX,local_index,1)
        put(mem,state+n.S_ARM_ONLINE_INDEX,opponent_index,1)
        put(mem,state+n.S_ARM_INPUT_SOURCE_INDEX,input_source,1)
        put(mem,PENDING,1,1); put(mem,ACTIVE,0,1); put(mem,command,n.ONLINE_INPUTS,1)
        # Simulate the scene-handoff corruption seen in the supplied saves.
        # Deliberately collapse all three bytes and zero every child pointer; the
        # wrapper must restore each captured value independently before B0.
        put(mem,n.STABLE_ODB+n.ODB_LOCAL_PLAYER_INDEX,0,1)
        put(mem,n.STABLE_ODB+n.ODB_ONLINE_PLAYER_INDEX,0,1)
        put(mem,n.STABLE_ODB+n.ODB_INPUT_SOURCE_INDEX,0,1)
        put(mem,n.STABLE_ODB+n.ODB_TXB_ADDR,0,4); put(mem,n.STABLE_ODB+n.ODB_RXB_ADDR,0,4)
        put(mem,n.STABLE_ODB+n.ODB_SSRB_ADDR,0,4); put(mem,n.STABLE_ODB+n.ODB_SSCB_ADDR,0,4)
        r=execute(blob,base,mem=mem,initial_regs={3:command,13:R13},stop_targets={n.SLIPPI_EXI_TRANSFER})
        assert r['target'] == n.SLIPPI_EXI_TRANSFER
        assert get(mem,n.STABLE_ODB+n.ODB_LOCAL_PLAYER_INDEX,1) == local_index
        assert get(mem,n.STABLE_ODB+n.ODB_ONLINE_PLAYER_INDEX,1) == opponent_index
        assert get(mem,n.STABLE_ODB+n.ODB_INPUT_SOURCE_INDEX,1) == input_source
        assert get(mem,n.STABLE_ODB+n.ODB_TXB_ADDR,4) == n.STABLE_TXB
        assert get(mem,n.STABLE_ODB+n.ODB_RXB_ADDR,4) == n.STABLE_RXB
        assert get(mem,n.STABLE_ODB+n.ODB_SSRB_ADDR,4) == n.STABLE_SSRB
        assert get(mem,n.STABLE_ODB+n.ODB_SSCB_ADDR,4) == n.STABLE_SSCB

def test_compact_bridge_deferred_gateway_and_arena_fit_original_16k_layout():
    from sdk.slippi_memory_layout import install_arena_reservation, SDK_RUNTIME_LIMIT
    dol = DOLImage((ROOT / 'Build' / 'start.dol').read_bytes())
    # Validate against the current reclaimed low-runtime topology. Historical
    # 0x3400 pre-bridge padding was retired by the later cleanup passes.
    bridge = n.install(dol, 8, gateway_pending_addr=PENDING, gateway_active_addr=ACTIVE)
    assert bridge['marker'] == 'SLNP'
    assert bridge['section']['size'] <= 0xA00
    row = d.install(
        dol, 8, gateway_pending_addr=PENDING,
        p1_ckind_addr=0x804F2001, p1_color_addr=0x804F2002,
        p1_subcolor_addr=0x804F2003, p1_nametag_addr=0x804F2004,
        p2_identity_valid_addr=0x804F2005,
        p2_ckind_addr=0x804F2006, p2_color_addr=0x804F2007,
        p2_subcolor_addr=0x804F2008, p2_nametag_addr=0x804F2009,
        netplay_arm_addr=bridge['arm_stub'])
    # start.dol already carries the prior build's ArenaLo wrapper. A clean ISO
    # presents retail calls here, so restore those two callsites before testing
    # the new reservation installer.
    from sdk.slippi_memory_layout import OS_INIT_ARENA_LO_CALLS, OS_SET_ARENA_LO
    for site in OS_INIT_ARENA_LO_CALLS:
        current = dol.read_at_address(site, 4)
        retail = n.encode_branch(site, OS_SET_ARENA_LO, link=True)
        dol.patch_at_address(site, retail, expected=current)
    reservation = install_arena_reservation(dol, 8)
    final_sec = next(x for x in dol.sections if x.kind == 'data' and x.index == 8)
    assert final_sec.address + final_sec.size <= SDK_RUNTIME_LIMIT
    assert reservation['arena_floor'] == 0x804F4C00
    assert row['netplay_arm_addr'] == bridge['arm_stub']
    assert row['scene_loop_hook'] == d.SCENE_LOOP_HOOK

def test_direct_preload_queues_deferred_bootstrap_instead_of_arming_too_early():
    arm = 0x804F6000
    state = 0x804F5F00
    pending = 0x804F5E00
    gmm = 0x81200000
    match = gmm + d.DIRECT_MATCH_DATA_OFFSET
    tramp = 0x804F6100
    wrapper_base = 0x804F6200
    blob = d.build_wrapper(
        wrapper_base, tramp, state_addr=state, gateway_pending_addr=pending,
        p1_ckind_addr=pending+1, p1_color_addr=pending+2,
        p1_subcolor_addr=pending+3, p1_nametag_addr=pending+4,
        p2_identity_valid_addr=pending+5,
        p2_ckind_addr=pending+6, p2_color_addr=pending+7,
        p2_subcolor_addr=pending+8, p2_nametag_addr=pending+9,
        netplay_arm_addr=arm)
    mem = {}
    put(mem, d.GM_CURRENT_MODE_ADDR, d.GM_ONLINE, 1)
    put(mem, (R13 + d.OFST_R13_ONLINE_MODE) & 0xFFFFFFFF, d.ONLINE_MODE_DIRECT, 1)
    put(mem, (R13 + d.OFST_R13_GM_MAINLIB) & 0xFFFFFFFF, gmm, 4)
    put(mem, match + d.DIRECT_STAGE_LOW_BYTE, d.CARRIER_STAGE, 1)
    put(mem, d.SLIPPI_ALT_MODE_STATIC, d.ADVENTURE_ALT_MARKER, 1)
    put(mem, match + d.P1 + d.PLAYER_TYPE, 0, 1)
    put(mem, match + d.P2 + d.PLAYER_TYPE, 0, 1)
    changes = []
    arm_calls = []
    def retail(regs, _mem): regs[3] = 0x12345678
    def arm_should_not_run(regs, _mem): arm_calls.append(1)
    def change(regs, _mem): changes.append(regs[3])
    r = execute(blob, wrapper_base, mem=mem, initial_regs={13:R13},
                callees={tramp:retail, arm:arm_should_not_run,
                         d.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE:change})
    assert arm_calls == []
    assert changes == []
    assert get(mem, state + d.S_BOOTSTRAP_PENDING, 1) == 1
    assert get(mem, state + d.S_TRACE, 1) == d.TRACE_BOOTSTRAP_QUEUED
    assert r['regs'][3] == 0x12345678

def test_02019_probe_wires_netplay_bridge_before_deferred_direct_gateway():
    probe = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.19'" in probe
    assert 'install_slippi_adventure_netplay_bridge' in probe
    assert "netplay_arm_addr=(slippi_adventure_netplay_bridge['arm_stub']" in probe
    assert probe.index('install_slippi_adventure_netplay_bridge') < probe.index('install_slippi_direct_gateway')

def test_deferred_ingame_bootstrap_arms_and_leaves_scene_exit_for_live_b0():
    arm = 0x804F5100
    state = 0x804F5200
    pending = 0x804F5300
    p2_valid = pending + 1
    tramp = 0x804F5400
    wrapper_base = 0x804F5500
    blob = d.build_ingame_bootstrap_wrapper(
        wrapper_base, tramp, state_addr=state, gateway_pending_addr=pending,
        p2_identity_valid_addr=p2_valid, netplay_arm_addr=arm)
    mem = {}
    put(mem, state + d.S_BOOTSTRAP_PENDING, 1, 1)
    put(mem, d.GM_CURRENT_MODE_ADDR, d.GM_ONLINE, 1)
    put(mem, d.GM_SCENE_BYTE3_ADDR, d.ONLINE_INGAME_BYTE3, 1)
    put(mem, d.NETPLAY_READY_SITE, d.NETPLAY_READY_WORD, 4)
    put(mem, d.SLIPPI_ALT_MODE_STATIC, d.ADVENTURE_ALT_MARKER, 1)
    changes = []
    exits = []
    def arm_ok(regs, _mem): regs[3] = 1
    def change(regs, _mem): changes.append(regs[3])
    def scene_exit(regs, _mem): exits.append(True)
    r = execute(
        blob, wrapper_base, mem=mem,
        callees={arm: arm_ok,
                 d.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE: change,
                 d.SCENE_EXIT_REQUEST: scene_exit},
        stop_targets={tramp})
    assert r['target'] == tramp
    assert changes == [d.GM_ADVENTURE]
    assert exits == []
    assert get(mem, pending, 1) == 1
    assert get(mem, p2_valid, 1) == 1
    assert get(mem, state + d.S_BOOTSTRAP_PENDING, 1) == 0
    assert get(mem, state + d.S_NETPLAY_ARM_RESULT, 1) == 1
    assert get(mem, state + d.S_REQUEST_COUNT, 1) == 1
    assert get(mem, state + d.S_TRACE, 1) == d.TRACE_ADVENTURE_REQUESTED


def test_deferred_ingame_bootstrap_waits_for_live_slippi_signature():
    arm = 0x804F5100
    state = 0x804F5200
    pending = 0x804F5300
    tramp = 0x804F5400
    wrapper_base = 0x804F5500
    blob = d.build_ingame_bootstrap_wrapper(
        wrapper_base, tramp, state_addr=state, gateway_pending_addr=pending,
        p2_identity_valid_addr=pending+1, netplay_arm_addr=arm)
    mem = {}
    put(mem, state + d.S_BOOTSTRAP_PENDING, 1, 1)
    put(mem, d.GM_CURRENT_MODE_ADDR, d.GM_ONLINE, 1)
    put(mem, d.GM_SCENE_BYTE3_ADDR, d.ONLINE_INGAME_BYTE3, 1)
    put(mem, d.NETPLAY_READY_SITE, 0x60000000, 4)
    arm_calls = []
    def arm_should_not_run(regs, _mem): arm_calls.append(True)
    r = execute(blob, wrapper_base, mem=mem, callees={arm: arm_should_not_run},
                stop_targets={tramp})
    assert r['target'] == tramp
    assert arm_calls == []
    assert get(mem, state + d.S_BOOTSTRAP_PENDING, 1) == 1
    assert get(mem, state + d.S_BOOTSTRAP_WAIT, 1) == 1
