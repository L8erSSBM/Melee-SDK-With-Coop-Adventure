from sdk.ui_metadata import decimal_text, slider_spec


def test_decimal_text_formats_without_name_dependency():
    # Regression for Phase 5 startup crash: decimal_text must depend only on value/type.
    assert decimal_text(0.20000000298023224, "float") == "0.2"
    assert decimal_text(75.0, "float") == "75"
    assert decimal_text(3, "int") == "3"
    assert decimal_text(-0.0, "float") == "0"


def test_airdodge_slider_specs_live_in_slider_spec():
    assert slider_spec("escapeair_timer", 3, "int") == (0, 30, 1)
    assert slider_spec("escapeair_deadzone_x", 0.25, "float") == (0, 1.0, 0.01)
    assert slider_spec("escapeair_deadzone_y", 0.25, "float") == (0, 1.0, 0.01)
    assert slider_spec("escapeair_force", 3.1, "float") == (0, 10.0, 0.05)
    assert slider_spec("escapeair_decay", 0.9, "float") == (0, 1.0, 0.01)


def test_editor_mode_is_conservative():
    from sdk.ui_metadata import editor_mode
    # Clear continuous/bounded gameplay values get sliders.
    assert editor_mode('gravity', 'float') == 'slider'
    assert editor_mode('escapeair_force', 'float') == 'slider'
    assert editor_mode('start_shield_health', 'float') == 'slider'
    # Numeric mechanics without a validated useful slider range stay direct-entry.
    assert editor_mode('metal_armor', 'float') == 'number'
    assert editor_mode('kb_min', 'float') == 'number'
    assert editor_mode('hit_weight_mul', 'float') == 'number'
    # True states are represented as toggles, not sliders.
    assert editor_mode('example_state_flag', 'bool') == 'toggle'


def test_global_state_families_group_related_mechanics():
    from sdk.ui_metadata import GLOBAL_STATE_FAMILIES
    assert GLOBAL_STATE_FAMILIES['Metal']['fields'] == ['metal_armor']
    metal_sources = {fact[1] for fact in GLOBAL_STATE_FAMILIES['Metal']['state_facts']}
    assert 'Fighter.is_metal' in metal_sources
    assert 'Fighter.is_always_metal' in metal_sources
    assert 'Fighter.metal_timer' in metal_sources
    assert set(GLOBAL_STATE_FAMILIES['Frozen / Ice']['fields']) == {'kb_ice_mul', 'damageice_gravity_mult'}
    assert GLOBAL_STATE_FAMILIES['Smash Charge']['fields'] == ['kb_smashcharge_mul']


def test_runtime_state_toggle_metadata_present():
    from sdk.ui_metadata import GLOBAL_STATE_FAMILIES
    metal = GLOBAL_STATE_FAMILIES['Metal']['runtime_toggles']
    frozen = GLOBAL_STATE_FAMILIES['Frozen / Ice']['runtime_toggles']
    assert metal[0][0] == 'force_metal'
    assert frozen[0][0] == 'start_frozen'
