"""Captured native file-loader regression; no live Dolphin claims."""
import json
from pathlib import Path
import pytest
from sdk import slippi_engine_repair as er, slippi_adventure_netplay_bridge as nb
from tests.hf29d_ppc import execute, put, get, SENTINEL

FIX=json.loads((Path(__file__).parent/'fixtures/slippi_k17_native_files.json').read_text())
R13=0x804DB6A0

def exercise(name,patched,buffer=0x81000000,scene=4):
    item=FIX[name];base=item['address'];blob=bytearray.fromhex(item['hex'])
    patches=er.patches(0x804F3800,0x804F7000,0x804F7100,0x804F7200,nb)
    if patched:
        for site,word in patches.items():
            if base<=site<base+len(blob):blob[site-base:site-base+4]=word
    mem={};put(mem,0x80479D30,scene,1);sp=0x804EE000;filename=0x803D8CB0;dest=0x80E0D800;size=0x804EE040
    for i,b in enumerate(b'SdClr.usd\0'):mem[filename+i]=b
    put(mem,R13-0x503C,buffer)
    calls=[]
    def strcpy(regs,mem):
        for i in range(10):mem[regs[3]+i]=mem.get(regs[4]+i,0)
    def strlen(regs,mem):regs[3]=9
    def exi(regs,mem):
        calls.append((regs[5],regs[3],regs[4]))
        if regs[5]==0:
            if regs[4]==4:put(mem,regs[3],202)
            else:
                # A displaced/empty shared response recreates the supplied
                # save's zero archive without blaming rollback restoration.
                for i in range(regs[4]):mem[regs[3]+i]=0
    regs={1:sp,3:filename,13:R13,27:dest,28:size,29:0x123,30:0x456,31:0x789}
    result=execute(bytes(blob),base,mem=mem,initial_regs=regs,
        callees={0x80325A50:strcpy,0x80325B04:strlen,0x800055F0:exi},
        stop_targets={0x80016400,0x80016488,0x800166BC,0x8001674C},
        extra_code=[(0x804F7300,er.file_scope(0x804F7300))])
    return result,calls,regs,size,dest

@pytest.mark.parametrize('name,target',[('size',0x80016400),('load',0x800166BC)])
@pytest.mark.parametrize('buffer',[0,0x81000000])
def test_campaign_uses_disc_fallback_without_exi_and_preserves_abi(name,target,buffer):
    r,calls,regs,_,_=exercise(name,True,buffer)
    assert r['target']==target and calls==[]
    assert r['regs'][1]==regs[1] and r['lr']==SENTINEL
    assert r['regs'][3]==regs[3] and r['regs'][30]==regs[3]
    for n in [27,28,29,31]:assert r['regs'][n]==regs[n]

def test_unprotected_native_file_response_can_reproduce_zero_archive():
    r,calls,_,size,dest=exercise('load',False)
    assert len(calls)==4 and r['target']==0x8001674C
    assert get(r['mem'],size)==202 and get(r['mem'],dest)==0
    # HSD_ArchiveParse compares these exact two values and asserts on mismatch.
    assert get(r['mem'],dest)!=get(r['mem'],size)

@pytest.mark.parametrize('name,target',[('size',0x80016488),('load',0x8001674C)])
def test_original_loader_retains_replacement_path_outside_campaign(name,target):
    r,calls,*_=exercise(name,False)
    assert r['target']==target and calls

def test_new_guard_signatures_match_supplied_crash_and_have_cleanup_originals():
    for guard in nb.GUARDS:
        if not guard.name.startswith('k18_'):continue
        item=FIX['size' if 'size' in guard.name else 'load']
        data=bytes.fromhex(item['hex']);off=guard.site-item['address']
        assert guard.expected==data[off:off+4]

@pytest.mark.parametrize('scene',[2,8])
@pytest.mark.parametrize('name,target',[('size',0x80016488),('load',0x8001674C)])
def test_k18_host_assets_survive_return_to_menu_with_bridge_still_armed(scene,name,target):
    r,calls,*_=exercise(name,True,scene=scene)
    assert r['target']==target and calls

@pytest.mark.parametrize('name,target',[('size',0x80016400),('load',0x800166BC)])
def test_k18_menu_without_host_buffer_keeps_retail_fallback(name,target):
    r,calls,*_=exercise(name,True,buffer=0,scene=8)
    assert r['target']==target and not calls
