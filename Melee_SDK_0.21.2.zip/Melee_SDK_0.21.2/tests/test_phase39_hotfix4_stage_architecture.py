import json
from pathlib import Path

from sdk.stage_architecture import ARCHITECTURE_TYPE_LABELS, ASSET_LIBRARY_TYPE_LABELS, MOTION_PATH_PRESETS, TOURNAMENT_REFERENCE_FILES

ROOT=Path(__file__).resolve().parents[1]

def _catalog():
    return json.loads((ROOT/'data'/'stage_builder_catalog'/'stage_builder_asset_catalog.json').read_text(encoding='utf-8'))

def test_architecture_library_is_type_first_and_complete():
    p=ROOT/'data'/'stage_builder_catalog'/'stage_architecture_asset_library.json'
    data=json.loads(p.read_text(encoding='utf-8'))
    assert data['organization']=='asset_type_then_stage'
    assert set(ASSET_LIBRARY_TYPE_LABELS) <= set(data['types'])
    assert any(x['filename']=='GrNBa.dat' for x in data['types']['ledge'])
    assert any(x['filename']=='GrNBa.dat' for x in data['types']['soft_platform'])

def test_tournament_reference_stage_architecture_matches_expected_high_value_primitives():
    cat=_catalog()
    by={s['filename']:s for s in cat['stages']}
    assert set(TOURNAMENT_REFERENCE_FILES) <= set(by)
    bf=by['GrNBa.dat']['architecture_assets']['architecture']
    fd=by['GrNLa.dat']['architecture_assets']['architecture']
    assert bf['type_counts']['soft_platform']==3
    assert bf['type_counts']['ledge']>=2
    assert fd['type_counts'].get('soft_platform',0)==0
    assert fd['type_counts']['ledge']>=2
    assert any(c['role']=='base_floor_structure' for c in bf['components'])
    assert any(c['role']=='base_floor_structure' for c in fd['components'])

def test_moving_platform_path_vocabulary_covers_smashville_and_randall_targets():
    keys={x['key'] for x in MOTION_PATH_PRESETS}
    assert {'horizontal_ping_pong','rectangle_loop','waypoint_loop','orbit'} <= keys
    assert all(x['runtime_status'] in {'READY','PLANNED'} for x in MOTION_PATH_PRESETS)

def test_training_grid_and_preview_example_are_packaged():
    from PIL import Image
    base=ROOT/'data'/'stage_builder_assets'
    grid=Image.open(base/'training_grid_background.png')
    preview=Image.open(base/'battlefield_draft_preview_example.png')
    assert grid.size==(1024,1024)
    assert preview.size==(1280,720)
