import struct
from sdk.dol_patch import DOLImage, SymbolMap
from sdk.stage_slot import StageSlotAuthor, AKANEIA_GRKIND, AKANEIA_STKIND
from sdk.character_slot import CharacterSlotAuthor, FT_KIND_BOY, FT_KIND_GIRL


def make_dol():
    raw=bytearray(0x5000)
    # text0
    struct.pack_into('>I',raw,0x00,0x100)
    struct.pack_into('>I',raw,0x48,0x80001000)
    struct.pack_into('>I',raw,0x90,0x200)
    # data0 large enough for all synthetic tables/caves
    struct.pack_into('>I',raw,0x1C,0x400)
    struct.pack_into('>I',raw,0x64,0x80300000)
    struct.pack_into('>I',raw,0xAC,0x4000)

    def off(addr): return 0x400+(addr-0x80300000)
    # stage_datas 0x1BC, set template grkind 0x24 pointer and dormant 0x1A null
    stage_datas=0x80300000
    template=0x80300500
    struct.pack_into('>I',raw,off(stage_datas)+0x24*4,template)
    # stage_id_map; Akaneia index -> 0x1A
    stage_map=0x80300200
    struct.pack_into('>I',raw,off(stage_map)+AKANEIA_STKIND*0x0C,AKANEIA_GRKIND)
    # synthetic Battlefield StageData at template
    vals=[0x24,0x80001000,0x80300600,0x80001004,0x80001008,0x8000100C,0x80001010,0x80001014,0,0,1,0,0]
    struct.pack_into('>13I',raw,off(template),*vals)
    raw[off(0x80300600):off(0x80300600)+11]=b'/GrNBa.dat\0'
    # fighter state table 33 entries, boy/girl are zero; donor Mario points to text
    ftstates=0x80300800
    struct.pack_into('>I',raw,off(ftstates)+0*4,0x80001020)
    # more FtKind callback tables
    for base in (0x80300900,0x80300A00):
        struct.pack_into('>I',raw,off(base)+0*4,0x80001040)
    # wireframe filename symbols
    raw[off(0x80300B00):off(0x80300B00)+9]=b'PlBo.dat\0'
    raw[off(0x80300B20):off(0x80300B20)+11]=b'PlBoAJ.dat\0'
    raw[off(0x80300B40):off(0x80300B40)+9]=b'PlGl.dat\0'
    raw[off(0x80300B60):off(0x80300B60)+11]=b'PlGlAJ.dat\0'
    return DOLImage(raw)


def symbols():
    return SymbolMap.from_text('''
stage_datas = .data:0x80300000; // type:object size:0x1BC scope:local
stage_id_map = .data:0x80300200; // type:object size:0xD68 scope:global
grNBa_StageData = .data:0x80300500; // type:object size:0x34 scope:global
ftData_CharacterStateTables = .data:0x80300800; // type:object size:0x84 scope:global
ftData_OnLoad = .data:0x80300900; // type:object size:0x84 scope:global
ftData_OnDeath = .data:0x80300A00; // type:object size:0x84 scope:global
ftBo_Init_DatFilename = .data:0x80300B00; // type:object size:0x9 scope:global
ftBo_Init_AnimDatFilename = .data:0x80300B20; // type:object size:0xB scope:global
ftGl_Init_DatFilename = .data:0x80300B40; // type:object size:0x9 scope:global
ftGl_Init_AnimDatFilename = .data:0x80300B60; // type:object size:0xB scope:global
''')


def test_hidden_stage_slot_detected_and_injected():
    d=make_dol(); a=StageSlotAuthor(d,symbols())
    st=a.hidden_slot_status()
    assert st.stkind==0x15 and st.grkind==0x1A and st.stage_data_is_null
    cave=0x80301000
    out=a.inject_hidden_stage_slot('grNBa_StageData','GrMy.dat',cave)
    assert out.filename=='/GrMy.dat'
    assert a.stage_data_pointer(0x1A)==cave
    assert struct.unpack('>I',d.read_at_address(cave,4))[0]==0x1A
    assert struct.unpack('>I',d.read_at_address(cave+8,4))[0]==cave+0x34
    assert d.read_at_address(cave+0x34,10)==b'/GrMy.dat\0'


def test_character_wireframe_slots_and_callback_clone():
    d=make_dol(); a=CharacterSlotAuthor(d,symbols())
    r=a.report()
    assert r['prototype_slots'][0]['dat_filename']=='PlBo.dat'
    assert r['prototype_slots'][1]['anim_filename']=='PlGlAJ.dat'
    assert a.slot_status(FT_KIND_BOY).motion_state_pointer==0
    patches=a.clone_ftkind_callback_tables(0,FT_KIND_BOY)
    assert any(p['table']=='ftData_CharacterStateTables' for p in patches)
    assert struct.unpack('>I',d.read_at_address(0x80300800+FT_KIND_BOY*4,4))[0]==0x80001020


def test_hidden_stage_slot_can_use_new_dol_section_instead_of_data_cave():
    d=make_dol(); a=StageSlotAuthor(d,symbols())
    old_size=len(d.raw)
    out=a.inject_hidden_stage_slot_expanded('grNBa_StageData','GrMy.dat')
    assert len(d.raw)>old_size
    assert a.stage_data_pointer(AKANEIA_GRKIND)==out.stage_data_address
    assert d.read_at_address(out.filename_address,10)==b'/GrMy.dat\0'
