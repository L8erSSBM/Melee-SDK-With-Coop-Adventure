import hashlib
import json
from pathlib import Path

from sdk.project_migration import (
    compatibility_report,
    create_test_clone,
    detect_generation,
    normalize_manifest,
    upgrade_project_metadata,
)


def _sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _old_project(tmp_path: Path):
    root=tmp_path/'old'
    (root/'Original').mkdir(parents=True)
    (root/'Working').mkdir()
    (root/'Build').mkdir()
    data=b'phase18-resource-bytes'
    (root/'Original'/'PlFx.dat').write_bytes(data)
    (root/'Working'/'PlFx.dat').write_bytes(data+b'-edited')
    manifest={
        'format_version':1,
        'sdk_scope':'fighter_and_stage_modding',
        'source_root':'C:/MeleeRoot',
        'resources':[{'filename':'PlFx.dat','source_relative':'PlFx.dat','sha256':_sha(data),'size':len(data)}],
        'fighters':[{'fighter_name':'Fox','base_filename':'PlFx.dat','aj_filename':None,'related_files':['PlFx.dat']}],
        'stages':[],
        'runtime_overrides':{'fighter_states':{}},
    }
    (root/'melee_project.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return root, manifest, data


def test_phase18_style_manifest_is_compatible(tmp_path):
    root, manifest, _ = _old_project(tmp_path)
    r=compatibility_report(root, manifest)
    assert r.compatible
    assert r.detected_generation == 18
    assert r.needs_metadata_upgrade
    assert not r.original_missing
    assert not r.original_hash_mismatches


def test_metadata_upgrade_does_not_touch_resource_bytes(tmp_path):
    root, manifest, original = _old_project(tmp_path)
    before_o=(root/'Original'/'PlFx.dat').read_bytes()
    before_w=(root/'Working'/'PlFx.dat').read_bytes()
    upgraded, backup=upgrade_project_metadata(root, manifest)
    assert backup.exists()
    assert upgraded['sdk_generation'] == 27
    assert (root/'Original'/'PlFx.dat').read_bytes() == before_o == original
    assert (root/'Working'/'PlFx.dat').read_bytes() == before_w
    assert upgraded['project_history'][-1]['action']=='metadata_upgrade'


def test_test_clone_preserves_original_and_working_and_resets_build(tmp_path):
    root, manifest, _ = _old_project(tmp_path)
    (root/'Build'/'stale.dat').write_bytes(b'stale')
    dst=tmp_path/'testclone'
    create_test_clone(root,dst)
    assert (dst/'Original'/'PlFx.dat').read_bytes()==(root/'Original'/'PlFx.dat').read_bytes()
    assert (dst/'Working'/'PlFx.dat').read_bytes()==(root/'Working'/'PlFx.dat').read_bytes()
    assert not (dst/'Build'/'stale.dat').exists()
    m=json.loads((dst/'melee_project.json').read_text())
    assert m['sdk_generation']==27
    assert m['project_history'][-1]['action']=='test_clone_created'


def test_normalize_keeps_unknown_old_fields():
    m={'format_version':1,'custom_legacy_field':{'keep':True}}
    n=normalize_manifest(m)
    assert n['custom_legacy_field']=={'keep':True}
    assert 'runtime_authoring' in n
    assert 'build_targets' in n
