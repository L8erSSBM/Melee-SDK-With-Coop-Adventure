from sdk.adventure_legacy import LEGACY_WRITES, legacy_analysis, legacy_gecko_code


def test_nick_reynolds_code_is_fully_inventoried():
    assert len(LEGACY_WRITES) == 18
    assert sum(w.gecko_type == '04' for w in LEGACY_WRITES) == 17
    assert sum(w.gecko_type == '00' for w in LEGACY_WRITES) == 1


def test_branch_targets_and_player_slot_decode_are_recorded():
    a=legacy_analysis()
    assert a['branch_targets']['0x8016E2F8']=='0x8016E454'
    assert a['branch_targets']['0x80032720']=='0x80832720'
    assert a['player_slots_base']=='0x80453080'
    assert a['historical_extra_record']=='player_slots[4]'


def test_character_placeholder_is_replaced_in_all_four_sites():
    text=legacy_gecko_code(0x12)
    assert '04456AC4 00000012' in text
    assert '04456AC8 00000012' in text
    assert '04432094 00000012' in text
    assert '04832728 2C190012' in text
    assert 'XX' not in text


def test_historical_slot_type_write_is_explicitly_flagged_unsafe():
    row=next(w for w in LEGACY_WRITES if w.address==0x80456AC8)
    assert row.target.endswith('.slot_type')
    assert row.confidence=='low'
    assert 'unsafe' in row.warning.lower()


def test_legacy_generator_rejects_out_of_range_character_id():
    try:
        legacy_gecko_code(0x100)
    except ValueError:
        pass
    else:
        raise AssertionError('expected ValueError')
