import struct
import pytest

from sdk import slippi_coop_stage_page as sp
from sdk.sss_archive_isolation import isolate_menu_load_names, MENU_ALIASES
from tests.hf29d_ppc import execute, put, get

BASE=0x804F0000
STATE=0x804F1000
MODELS=0x80C18410
TABLE_OFFSET=0xA0000


def run_renderer(mem, page, calls):
    def copy(regs, memory):
        dest,source,size=regs[3:6]
        assert size==16, 'Corrupt table must never reach memcpy'
        calls.append(('copy',dest,source,size))
        payload=bytes(memory.get(source+i,0) for i in range(size))
        for i,v in enumerate(payload):memory[dest+i]=v
        # Exercise the PPC ABI instead of assuming volatile registers survive.
        for r in range(4,13):regs[r]=0xDEADBEEF
    def flush(regs, memory):
        calls.append(('flush',regs[3],regs[4]))
        for r in range(3,13):regs[r]=0xBADCAFE
    def invalidate(regs, memory):calls.append(('invalidate',))
    initial={1:0x817FE000,3:page,28:28,29:29,30:30,31:31}
    result=execute(sp.build_render_page(BASE,state_addr=STATE,
        visual_models_offset=16,visual_table_offset=TABLE_OFFSET,visual_record_count=1),
        BASE,mem=mem,initial_regs=initial,callees={sp.MEMCPY_ADDR:copy,
        sp.DC_FLUSH_RANGE_ADDR:flush,sp.GX_INVALIDATE_TEX_ALL_ADDR:invalidate})
    for r in (1,28,29,30,31):assert result['regs'][r]==initial[r]
    assert get(mem,sp.CURSOR_INDEX_ADDR,1)==27


def memory_with_table(magic=b'SSVQ',count=1):
    mem={}
    put(mem,sp.MNSLMAP_MODELS_PTR_ADDR,MODELS)
    table=MODELS+TABLE_OFFSET-16
    put(mem,table,int.from_bytes(magic,'big'));put(mem,table+4,count)
    for i,v in enumerate((0x100,0x200,0x300,16)):put(mem,table+8+4*i,v)
    for i in range(16):mem[MODELS+0x200+i]=i;mem[MODELS+0x300+i]=255-i
    for row in range(sp.STAGE_ROW_COUNT):
        put(mem,sp.STAGE_TABLE+row*sp.STAGE_ROW_SIZE+sp.ROW_X8,2,1)
        put(mem,sp.STAGE_TABLE+row*sp.STAGE_ROW_SIZE+sp.ROW_STKIND,row,1)
    return mem


def test_repeated_page_changes_copy_and_restore_and_preserve_abi():
    mem=memory_with_table();calls=[]
    for _ in range(3):
        for page in (1,0):
            run_renderer(mem,page,calls)
            expected=bytes(255-i if page else i for i in range(16))
            assert bytes(mem[MODELS+0x100+i] for i in range(16))==expected
            assert get(mem,STATE+sp.S_PAGE,1)==page
            for row in range(sp.STAGE_ROW_COUNT):
                a=sp.STAGE_TABLE+row*sp.STAGE_ROW_SIZE
                assert get(mem,a+sp.ROW_STKIND,1)==row
                assert get(mem,a+sp.ROW_X8,1)==(2 if not page or row==27 else 0)
    assert [x[0] for x in calls]==['copy','flush','invalidate']*6


@pytest.mark.parametrize('magic,count',[(b'\xbf\xa9\xb1\xb8',1),(b'SSVQ',0),(b'SSVQ',99)])
def test_missing_or_mismatched_table_never_calls_copy_or_cache_functions(magic,count):
    mem=memory_with_table(magic,count);calls=[]
    run_renderer(mem,1,calls)
    assert calls==[]


def test_menu_aliases_change_only_exact_null_terminated_filenames():
    raw=b'head'+b'\0'.join(s.encode() for s in MENU_ALIASES)+b'\0tail'
    result,changes=isolate_menu_load_names(raw)
    assert len(result)==len(raw)
    assert result==b'headMnCoMap.usd\0MnCoMap.dat\0tail'
    assert len(changes)==2
    with pytest.raises(ValueError):isolate_menu_load_names(result)
