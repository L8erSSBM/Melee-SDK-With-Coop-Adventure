import struct
from pathlib import Path

from sdk.stage import StageDAT, CATALOG_BY_FILENAME


def make_stage_archive():
    data = bytearray(0x200)
    # coll_data @ 0x00 -> verts @ 0x40, 3 vertices; lines @ 0x60, 2 lines.
    struct.pack_into('>I', data, 0x00, 0x40)
    struct.pack_into('>i', data, 0x04, 3)
    struct.pack_into('>I', data, 0x08, 0x60)
    struct.pack_into('>i', data, 0x0C, 2)
    struct.pack_into('>10h', data, 0x10, 0,2, 2,0, 2,0, 2,0, 0,0)
    struct.pack_into('>I', data, 0x24, 0x80)
    struct.pack_into('>i', data, 0x28, 1)
    struct.pack_into('>i', data, 0x2C, 0)
    for i,(x,y) in enumerate([(-10.0,0.0),(0.0,8.0),(10.0,0.0)]):
        struct.pack_into('>ff', data, 0x40+i*8, x,y)
    # MapLine is 0x10 bytes.
    struct.pack_into('>HHhhhhHH', data, 0x60, 0,1,-1,1,-1,-1,0,0)
    struct.pack_into('>HHhhhhHH', data, 0x70, 1,2,0,-1,-1,-1,0,0)
    # one MapJoint, 0x28 bytes
    struct.pack_into('>10h4f2h', data, 0x80, 0,2,2,0,2,0,2,0,0,0, -10,-1,10,8, 0,3)
    # GroundParam public root @ 0x100
    struct.pack_into('>f', data, 0x100, 1.0)
    struct.pack_into('>I', data, 0x14C, 0)  # fixed camera false
    struct.pack_into('>I', data, 0x1B0, 0)  # StageParam pointer
    struct.pack_into('>i', data, 0x1B4, 0)  # count

    relocs = [0x00,0x08,0x24]
    symbols = b'coll_data\0grGroundParam\0map_head\0'
    p0=0
    p1=len(b'coll_data\0')
    # Public offsets are data-relative.
    publics = [(0x00,p0),(0x100,p1)]
    meta = b''.join(struct.pack('>I', r) for r in relocs)
    meta += b''.join(struct.pack('>II', *x) for x in publics)
    body = bytes(data)+meta+symbols
    header = bytearray(0x20)
    struct.pack_into('>5I', header, 0, 0x20+len(body), len(data), len(relocs), len(publics), 0)
    header[0x14:0x18]=b'0011'
    return bytes(header)+body


def test_stage_catalog_contains_core_competitive_stages():
    assert CATALOG_BY_FILENAME['grnba.dat'].name == 'Battlefield'
    assert CATALOG_BY_FILENAME['grnla.dat'].name == 'Final Destination'
    assert CATALOG_BY_FILENAME['grst.dat'].name == "Yoshi's Story"


def test_stage_collision_parse_and_vertex_edit_roundtrip():
    st = StageDAT(make_stage_archive())
    result = st.validate()
    assert result['status'] == 'PASS'
    assert result['collision']['vertex_count'] == 3
    assert result['collision']['line_count'] == 2
    assert st.vertices()[1] == (0.0, 8.0)
    before_len = len(st.bytes())
    st.set_vertex(1, 2.5, 9.25)
    assert st.vertices()[1] == (2.5, 9.25)
    assert len(st.bytes()) == before_len
    assert st.validate()['status'] == 'PASS'


def test_stage_ground_param_source_validated_fields():
    st = StageDAT(make_stage_archive())
    assert st.ground_param()['stage_scale'] == 1.0
    assert st.ground_param()['fixed_camera'] is False
    st.set_stage_scale(1.5)
    st.set_fixed_camera(True)
    gp=st.ground_param()
    assert abs(gp['stage_scale']-1.5) < 1e-6
    assert gp['fixed_camera'] is True


def test_stage_rejects_invalid_line_vertex_reference():
    raw=bytearray(make_stage_archive())
    # data starts at file +0x20; first line v1 at data 0x62.
    struct.pack_into('>H', raw, 0x20+0x62, 99)
    st=StageDAT(raw)
    try:
        st.validate()
    except ValueError as e:
        assert 'outside the vertex array' in str(e)
    else:
        raise AssertionError('invalid collision reference should fail validation')
