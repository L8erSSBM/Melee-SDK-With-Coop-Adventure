from pathlib import Path
from unittest.mock import patch
import pytest
from sdk.gui_iso_build import build_project_iso, validate_options

DEFAULT=dict(coop_direct=True, adventure_difficulty='normal', adventure_stocks=3,
             friendly_fire=True,scene_revive=False,test_shortcuts=False,unlock_all=True)
@pytest.mark.parametrize('difficulty,stocks,ff,revive', [('very_easy',1,False,True),('normal',3,True,False),('very_hard',9,False,False)])
@pytest.mark.parametrize('fresh',[False,True])
def test_gui_build_routes_every_setting_and_resources(tmp_path,difficulty,stocks,ff,revive,fresh):
    opts={**DEFAULT,'adventure_difficulty':difficulty,'adventure_stocks':stocks,'friendly_fire':ff,'scene_revive':revive}
    with patch('sdk.gui_iso_build.build_test_iso',return_value={'rebuild':{},'manifest_path':'manifest'}) as build:
        r=build_project_iso('clean','out',tmp_path,opts,fresh=fresh)
    args=build.call_args.kwargs
    for key in DEFAULT.keys()-{'coop_direct'}:assert args[key]==opts[key]
    assert args['content_dir']==tmp_path and args['adventure_sss_gateway'] and args['vs_p2_identity_bridge']
    assert args['symbols_path'].is_file() and r['mode']=='coop_direct_rebuild'

def test_disabling_coop_rebuilds_clean_instead_of_leaving_old_runtime(tmp_path):
    with patch('sdk.gui_iso_build.fresh_rebuild',return_value={}) as build:
        build_project_iso('clean','out',tmp_path,{**DEFAULT,'coop_direct':False})
    build.assert_called_once_with('clean','out',tmp_path,verify_hash=True)

def test_independent_dol_edits_are_not_silently_lost(tmp_path):
    (tmp_path/'start.dol').write_bytes(b'user runtime')
    with pytest.raises(ValueError,match='separate runtime patches'):
        build_project_iso('clean','out',tmp_path,DEFAULT)

@pytest.mark.parametrize('key,value',[('adventure_stocks',0),('adventure_stocks',10),('adventure_difficulty','unknown')])
def test_invalid_settings_rejected(key,value):
    with pytest.raises(ValueError):validate_options({**DEFAULT,key:value})
