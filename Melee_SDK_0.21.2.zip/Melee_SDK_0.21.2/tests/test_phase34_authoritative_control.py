from pathlib import Path

from sdk.adventure_probe import (
    _control_player_entity_wrapper,
    GROUND_GET_P1_FIGHTER_HOOK, GROUND_GET_P1_FIGHTER_EXPECTED,
    CAMERA_P1_ENTITY_CALL_HOOK, CAMERA_P1_ENTITY_CALL_EXPECTED,
    PLAYER_GET_ENTITY, install_phase30_coop_spawn_probe,
)
from sdk.ppc import decode_branch, li


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def test_phase34_source_grounded_control_selection_sites():
    assert GROUND_GET_P1_FIGHTER_HOOK == 0x801C57A4
    assert GROUND_GET_P1_FIGHTER_EXPECTED.hex() == '7c0802a6'
    assert CAMERA_P1_ENTITY_CALL_HOOK == 0x8002B23C
    assert CAMERA_P1_ENTITY_CALL_EXPECTED.hex() == '48008ed5'
    d = decode_branch(CAMERA_P1_ENTITY_CALL_HOOK, CAMERA_P1_ENTITY_CALL_EXPECTED)
    assert d['link'] is True
    assert d['target'] == PLAYER_GET_ENTITY


def test_phase34_owner_entity_wrapper_has_retail_p1_fallback():
    base=0x804DFA00
    raw=_control_player_entity_wrapper(base, 0x804DF020)
    words=_words(raw)
    assert li(3,0) in words
    # Both paths tail-call Player_GetEntity; they must not link and disturb LR.
    branches=[]
    for i,w in enumerate(words):
        if (int.from_bytes(w,'big') >> 26) == 18:
            d=decode_branch(base+i*4,w)
            if d['target'] == PLAYER_GET_ENTITY:
                branches.append(d)
    assert len(branches) == 2
    assert all(not x['link'] for x in branches)


def test_phase34_install_redirects_route_and_camera_owner(tmp_path):
    clean=Path('/mnt/data/main.dol')
    if not clean.exists():
        return
    out=tmp_path/'phase34.dol'
    m=install_phase30_coop_spawn_probe(clean, Path('data/runtime_symbols_GALE01.txt'), out)
    hooks={x['name']:x for x in m['hooks']}
    assert hooks['control_ground_p1_accessor']['stub_address'] == hooks['control_camera_p1_lookup']['stub_address']
    cc=m['probe_contract']['camera_control']
    assert cc['ground_p1_accessor_redirected'] is True
    assert cc['standard_1p_camera_p1_lookup_redirected'] is True
