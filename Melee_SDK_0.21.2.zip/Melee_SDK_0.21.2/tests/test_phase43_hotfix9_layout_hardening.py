from pathlib import Path

from sdk.adventure_probe import _control_player_entity_wrapper


def test_hf9_layout_invariant_survives_hf10_camera_revert():
    dummy = _control_player_entity_wrapper(0x80400900, 0x80400020)
    final = _control_player_entity_wrapper(0x80412000, 0x80410020)
    assert len(dummy) == len(final) == 72


def test_current_builder_keeps_runtime_layout_invariants():
    text=Path('sdk/adventure_probe.py').read_text(encoding='utf-8')
    assert 'if len(dummy6) != len(owner_entity):' in text
    assert 'dummy_finalwave_tramp' in text
    assert 'len(dummy_finalwave) != len(finalwave_wrapper)' in text
    assert 'Adventure payload sizing mismatch' in text
    assert 'Adventure payload blob overlap' in text
    assert "payload[0x34:0x38]=b'KTDG'" in text
