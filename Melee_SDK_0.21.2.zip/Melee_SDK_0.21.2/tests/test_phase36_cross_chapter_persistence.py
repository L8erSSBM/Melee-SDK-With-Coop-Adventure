from pathlib import Path

from sdk.adventure_probe import (
    _adventure_progress_stock_wrapper,
    _spawn_setup_stub,
    ADVENTURE_PROGRESS_STOCK_HOOK,
    ADVENTURE_PROGRESS_STOCK_EXPECTED,
    PLAYER_GET_STOCKS,
    P1_INIT_OFFSET,
    P2_INIT_OFFSET,
    install_phase30_coop_spawn_probe,
)
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, stb


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def test_phase36_progress_site_and_wrapper_capture_both_players():
    assert ADVENTURE_PROGRESS_STOCK_HOOK == 0x8017D90C
    assert ADVENTURE_PROGRESS_STOCK_EXPECTED.hex() == '881d006c'
    base = 0x804E1000
    raw = _adventure_progress_stock_wrapper(
        base,
        persistence_valid_addr=0x804E0021,
        p1_stocks_addr=0x804E0022,
        p2_stocks_addr=0x804E0023,
    )
    calls=[]
    for i,w in enumerate(_words(raw)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            d=decode_branch(base+i*4,w)
            if d['link']:
                calls.append(d['target'])
    assert calls == [PLAYER_GET_STOCKS, PLAYER_GET_STOCKS]
    assert decode_branch(base+len(raw)-4, raw[-4:])['target'] == ADVENTURE_PROGRESS_STOCK_HOOK+4


def test_phase36_spawn_restore_writes_both_playerinit_stock_bytes():
    base=0x804E2000
    raw=_spawn_setup_stub(
        base,
        camera_owner_addr=0x804E0020,
        persistence_valid_addr=0x804E0021,
        p1_stocks_addr=0x804E0022,
        p2_stocks_addr=0x804E0023,
    )
    words=_words(raw)
    assert stb(11, P1_INIT_OFFSET+2, 30) in words
    assert stb(11, P2_INIT_OFFSET+2, 30) in words


def test_phase36_install_manifest_when_canonical_dol_available(tmp_path):
    clean=Path('/mnt/data/main.dol')
    clean=clean if clean.exists() else None
    if clean is None:
        return
    symbols=Path('data/runtime_symbols_GALE01.txt')
    out=tmp_path/'phase36.dol'
    m=install_phase30_coop_spawn_probe(clean, symbols, out)
    state=m['probe_contract']['cross_chapter_stock_state']
    assert state['retail_team_representative_written'] is True
    assert state['exact_playerinit_restore'] is True
    assert state['control_persists_across_encounters'] is True
    assert state['new_campaign_reset_via_adventure_css'] is True
    hooks={h['name']:h for h in m['hooks']}
    assert hooks['cross_chapter_stock_capture']['site_address'] == ADVENTURE_PROGRESS_STOCK_HOOK
    assert hooks['campaign_state_reset']['via_framework_hook'] == 'gm_801B42E8'
    dol=DOLImage(out.read_bytes())
    assert dol.read_at_address(ADVENTURE_PROGRESS_STOCK_HOOK,4) != ADVENTURE_PROGRESS_STOCK_EXPECTED
