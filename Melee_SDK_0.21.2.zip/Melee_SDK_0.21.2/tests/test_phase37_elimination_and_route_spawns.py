from pathlib import Path

from sdk.adventure_probe import (
    _spawn_setup_stub,
    _event_allocator_start_wrapper,
    _dynamic_enemy_spawn_wrapper,
    EVENT_ALLOCATOR_START_HOOK,
    EVENT_ALLOCATOR_START_EXPECTED,
    DYNAMIC_ENEMY_SPAWN_HOOK,
    DYNAMIC_ENEMY_SPAWN_EXPECTED,
    GROUND_GET_SPAWN_POS,
    P1_INIT_OFFSET,
    P2_INIT_OFFSET,
    install_phase30_coop_spawn_probe,
)
from sdk.additional_content import FEATURE_BY_KEY
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, li, stb, addi


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def test_phase37_default_zero_stock_policy_can_mark_both_humans_na():
    raw = _spawn_setup_stub(
        0x804E2000,
        camera_owner_addr=0x804E0020,
        persistence_valid_addr=0x804E0021,
        p1_stocks_addr=0x804E0022,
        p2_stocks_addr=0x804E0023,
        initial_stocks_addr=0x804E0024,
        scene_revive=False,
    )
    words = _words(raw)
    # The persisted-zero path writes slot_type=Gm_PKind_NA (3), for either P1
    # or P2 instead of leaving a Human with zero stocks (the Phase 36 phantom).
    assert li(11, 3) in words
    assert stb(11, P1_INIT_OFFSET + 1, 30) in words
    assert stb(11, P2_INIT_OFFSET + 1, 30) in words


def test_phase37_revive_policy_uses_initial_stock_state_and_human_slot_type():
    raw = _spawn_setup_stub(
        0x804E3000,
        camera_owner_addr=0x804E0020,
        persistence_valid_addr=0x804E0021,
        p1_stocks_addr=0x804E0022,
        p2_stocks_addr=0x804E0023,
        initial_stocks_addr=0x804E0024,
        scene_revive=True,
    )
    words = _words(raw)
    # Revive mode has human slot writes and stock writes for both players. The
    # initial stock byte is loaded from SDK campaign storage at runtime.
    assert li(11, 0) in words
    assert stb(11, P1_INIT_OFFSET + 1, 30) in words
    assert stb(11, P2_INIT_OFFSET + 1, 30) in words
    assert stb(11, P1_INIT_OFFSET + 2, 30) in words
    assert stb(11, P2_INIT_OFFSET + 2, 30) in words


def test_phase37_event_allocator_and_spawn_marker_wrappers():
    assert EVENT_ALLOCATOR_START_HOOK == 0x8016A0D8
    assert EVENT_ALLOCATOR_START_EXPECTED.hex() == '3bc00000'
    assert DYNAMIC_ENEMY_SPAWN_HOOK == 0x8016A5A4
    assert DYNAMIC_ENEMY_SPAWN_EXPECTED.hex() == '48058781'

    alloc = _event_allocator_start_wrapper(0x804E4000)
    assert li(30, 2) in _words(alloc)  # Adventure starts dynamic enemy search at slot 2.

    base = 0x804E5000
    spawn = _dynamic_enemy_spawn_wrapper(base)
    assert addi(3, 3, -1) in _words(spawn)  # compensate retail spawn_slot + marker - 1
    calls=[]
    for i,w in enumerate(_words(spawn)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            d=decode_branch(base+i*4,w)
            if d['link']:
                calls.append(d['target'])
    assert GROUND_GET_SPAWN_POS in calls


def test_phase37_additional_content_revive_flag_defaults_opt_in():
    f=FEATURE_BY_KEY['coop_scene_revive']
    assert f.dependencies == ('coop_adventure',)
    assert 'revive' in f.label.lower()


def test_phase37_install_both_policies_and_dynamic_hooks(tmp_path):
    clean=Path('/mnt/data/main.dol')
    if not clean.exists():
        return
    symbols=Path('data/runtime_symbols_GALE01.txt')
    for revive in (False, True):
        out=tmp_path/f'phase37_{int(revive)}.dol'
        m=install_phase30_coop_spawn_probe(clean, symbols, out, scene_revive=revive)
        state=m['probe_contract']['cross_chapter_stock_state']
        assert m['probe_contract']['scene_revive'] is revive
        assert state['zero_stock_slot_policy'] == ('revive_to_initial' if revive else 'Gm_PKind_NA')
        assert state['initial_stocks_address']
        dynamic=m['probe_contract']['dynamic_event_enemy_slots']
        assert dynamic['human_slots_reserved'] == [0,1]
        assert dynamic['first_enemy_slot'] == 2
        assert dynamic['spawn_marker_compensation'] == -1
        hooks={h['name']:h for h in m['hooks']}
        assert hooks['event_allocator_human_reservation']['site_address'] == EVENT_ALLOCATOR_START_HOOK
        assert hooks['dynamic_enemy_spawn_marker']['site_address'] == DYNAMIC_ENEMY_SPAWN_HOOK
        dol=DOLImage(out.read_bytes())
        assert dol.read_at_address(EVENT_ALLOCATOR_START_HOOK,4) != EVENT_ALLOCATOR_START_EXPECTED
        assert dol.read_at_address(DYNAMIC_ENEMY_SPAWN_HOOK,4) != DYNAMIC_ENEMY_SPAWN_EXPECTED
