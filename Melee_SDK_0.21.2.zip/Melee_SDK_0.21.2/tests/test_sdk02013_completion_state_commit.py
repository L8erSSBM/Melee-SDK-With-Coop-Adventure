from pathlib import Path
import inspect

from sdk import adventure_gateway_scope as scope
from sdk import adventure_probe
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]


def test_02013_branding():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    build = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    gui = (ROOT / 'melee_sdk.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.18'" in src
    assert "'format':'melee-character-sdk-0.20.18-slippi-adventure-netplay-bridge'" in src
    assert 'MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in build
    assert '_MeleeSDK_0.20.18.iso' in build
    assert '0.20.18 — Slippi Adventure Netplay Bridge' in gui


def test_active_gover_reentry_preserves_scope_without_writing_state_early():
    base = 0x804F2000
    pending = 0x804F0C00
    active = 0x804F0C10
    origin = active + 1
    downstream = 0x80123454
    blob = scope._onload_capture_wrapper(
        base, pending_addr=pending, active_addr=active,
        old_target=downstream, origin_addr=origin)
    mem = {}
    put(mem, pending, 0, 1)
    put(mem, active, 1, 1)
    put(mem, origin, 2, 1)
    put(mem, scope.PREVIOUS_MODE, scope.GM_ADVENTURE_GOVER, 1)
    put(mem, scope.STATE_MACHINE + 3, 0, 1)
    put(mem, scope.STATE_MACHINE + 4, 0, 1)
    result = execute(blob, base, mem=mem, stop_targets=(downstream,))
    assert result['target'] == downstream
    assert get(mem, active, 1) == 1
    assert get(mem, origin, 1) == 2
    # 0.20.12 wrote 0x68 here, but retail later overwrote it with 0x70.
    # 0.20.13 deliberately waits for the final state commit site.
    assert get(mem, scope.STATE_MACHINE + 3, 1) == 0
    assert get(mem, scope.STATE_MACHINE + 4, 1) == 0


def test_final_retail_70_commit_becomes_68_only_for_active_gover_bridge():
    base = 0x804F2400
    active = 0x804F0C10
    blob = scope._adventure_final_state_wrapper(base, active_addr=active)
    mem = {}
    put(mem, active, 1, 1)
    put(mem, scope.PREVIOUS_MODE, scope.GM_ADVENTURE_GOVER, 1)
    result = execute(
        blob, base, mem=mem, initial_regs={3: 0x70},
        stop_targets=(scope.GM_SET_GAME_MODE_STATE_ID,))
    assert result['target'] == scope.GM_SET_GAME_MODE_STATE_ID
    assert result['regs'][3] == 0x68


def test_final_state_commit_is_exact_retail_for_inactive_campaign():
    base = 0x804F2600
    active = 0x804F0C10
    blob = scope._adventure_final_state_wrapper(base, active_addr=active)
    mem = {}
    put(mem, active, 0, 1)
    put(mem, scope.PREVIOUS_MODE, scope.GM_ADVENTURE_GOVER, 1)
    result = execute(
        blob, base, mem=mem, initial_regs={3: 0x70},
        stop_targets=(scope.GM_SET_GAME_MODE_STATE_ID,))
    assert result['regs'][3] == 0x70


def test_final_state_commit_does_not_touch_challenger_or_other_reentry():
    base = 0x804F2800
    active = 0x804F0C10
    blob = scope._adventure_final_state_wrapper(base, active_addr=active)
    mem = {}
    put(mem, active, 1, 1)
    put(mem, scope.PREVIOUS_MODE, 0x14, 1)
    result = execute(
        blob, base, mem=mem, initial_regs={3: 0x70},
        stop_targets=(scope.GM_SET_GAME_MODE_STATE_ID,))
    assert result['regs'][3] == 0x70


def test_final_state_commit_only_rewrites_exact_retail_70_argument():
    base = 0x804F2A00
    active = 0x804F0C10
    blob = scope._adventure_final_state_wrapper(base, active_addr=active)
    mem = {}
    put(mem, active, 1, 1)
    put(mem, scope.PREVIOUS_MODE, scope.GM_ADVENTURE_GOVER, 1)
    result = execute(
        blob, base, mem=mem, initial_regs={3: 0x44},
        stop_targets=(scope.GM_SET_GAME_MODE_STATE_ID,))
    assert result['regs'][3] == 0x44


def test_gover_completion_bridge_requests_adventure_and_preserves_scope():
    base = 0x804F2C00
    active = 0x804F0C10
    origin = active + 1
    blob = scope._staffroll_completion_wrapper(
        base, active_addr=active, origin_addr=origin)
    mem = {}
    put(mem, active, 1, 1)
    put(mem, origin, 2, 1)
    put(mem, scope.CURRENT_MODE, scope.GM_ADVENTURE_GOVER, 1)
    result = execute(
        blob, base, mem=mem, initial_regs={3: 1},
        stop_targets=(scope.GM_SET_PENDING_GAME_MODE,))
    assert result['target'] == scope.GM_SET_PENDING_GAME_MODE
    assert result['regs'][3] == scope.GM_ADVENTURE
    assert get(mem, active, 1) == 1
    assert get(mem, origin, 1) == 2


def test_inactive_gover_completion_remains_retail_argument():
    base = 0x804F2E00
    active = 0x804F0C10
    origin = active + 1
    blob = scope._staffroll_completion_wrapper(
        base, active_addr=active, origin_addr=origin)
    mem = {}
    put(mem, active, 0, 1)
    put(mem, origin, 0, 1)
    put(mem, scope.CURRENT_MODE, scope.GM_ADVENTURE_GOVER, 1)
    result = execute(
        blob, base, mem=mem, initial_regs={3: 1},
        stop_targets=(scope.GM_SET_PENDING_GAME_MODE,))
    assert result['regs'][3] == 1



def test_installer_patches_real_hf29f_integration_point():
    # HF29F is the packaged pre-HF29G DOL, so it exercises the real integration
    # point without requiring a clean ISO fixture. Its Phase-30 probe section
    # begins at 0x804DEC60 and gateway_pending is +0x2E.
    dol = DOLImage((ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    result = scope.install(
        dol, 8, gateway_pending_addr=0x804DEC8E,
        enable_sdk0205_extras=True, capture_origin=True)

    row = result['completion_final_state_commit']
    assert row['site_address'] == scope.ADVENTURE_ONLOAD_FINAL_STATE_CALL
    installed = dol.read_at_address(scope.ADVENTURE_ONLOAD_FINAL_STATE_CALL, 4)
    decoded = decode_branch(scope.ADVENTURE_ONLOAD_FINAL_STATE_CALL, installed)
    assert decoded['link'] is True
    assert decoded['target'] == row['scope_stub']

    size = len(scope._adventure_final_state_wrapper(
        row['scope_stub'], active_addr=result['gateway_coop_active_address']))
    blob = dol.read_at_address(row['scope_stub'], size)
    mem = {}
    put(mem, result['gateway_coop_active_address'], 1, 1)
    put(mem, scope.PREVIOUS_MODE, scope.GM_ADVENTURE_GOVER, 1)
    execution = execute(
        blob, row['scope_stub'], mem=mem, initial_regs={3: 0x70},
        stop_targets=(scope.GM_SET_GAME_MODE_STATE_ID,))
    assert execution['target'] == scope.GM_SET_GAME_MODE_STATE_ID
    assert execution['regs'][3] == 0x68


def test_installer_keeps_all_three_completion_bridge_stages():
    installer = inspect.getsource(adventure_probe.install_phase30_coop_spawn_probe)
    assert 'requires guarded GOver completion bridge' in installer
    assert 'requires final Adventure state-commit wrapper' in installer
    assert 'successful_completion_bridge' in installer
