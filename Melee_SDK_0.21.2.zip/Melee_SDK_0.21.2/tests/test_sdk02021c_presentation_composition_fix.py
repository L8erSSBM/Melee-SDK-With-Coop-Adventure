from pathlib import Path
import struct

from sdk import slippi_adventure_entry_leaf as leaf
from sdk import adventure_probe
from sdk.ppc import decode_branch

ROOT = Path(__file__).resolve().parents[1]


def test_integrated_campaign_leaf_fits_existing_slot_without_new_hook():
    blob = leaf.build_campaign_leaf_wrapper(
        0x804F1CC0, 0x804F1000, origin_addr=0x804F1101)
    assert len(blob) <= leaf.WRAPPER_CAPACITY
    assert len(blob) % 4 == 0
    # It remains a self-contained accessor leaf: no branch-link/callouts.
    for off in range(0, len(blob), 4):
        word = struct.unpack('>I', blob[off:off+4])[0]
        assert not ((word >> 26) == 18 and (word & 1))
        assert not ((word >> 26) == 16 and (word & 1))


def test_historical_0202_leaf_generator_is_unchanged_for_archival_tests():
    legacy = leaf.build_leaf_wrapper(0x804DFB60, 0x804DEC98)
    assert len(legacy) == leaf.WRAPPER_CAPACITY == 0x140


def test_user_logged_outer_hook_value_no_longer_participates_in_install_logic():
    # The real 0.20.21B clean-ISO build reached this already-composed branch at
    # gm_GetButtonsTriggered.  0.20.21C must not assert against or repatch it.
    site = 0x801A36A0
    logged = bytes.fromhex('48350660')
    dec = decode_branch(site, logged)
    assert dec['target'] == 0x804F3D00
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    barrier_src = (ROOT / 'sdk' / 'slippi_adventure_entry_leaf.py').read_text(encoding='utf-8')
    assert 'install_slippi_presentation_barrier' not in src
    assert 'build_campaign_leaf_wrapper' in barrier_src


def test_02021c_does_not_grow_runtime_for_presentation_sync():
    legacy = leaf.build_leaf_wrapper(0x804F1CC0, 0x804F1000)
    campaign = leaf.build_campaign_leaf_wrapper(
        0x804F1CC0, 0x804F1000, origin_addr=0x804F1101)
    assert len(campaign) <= len(legacy)

from hf29d_ppc import execute, put


def _seed_accessor(mem, *, origin_addr, origin, p2_start=False):
    # Current Adventure mode/state in a known presentation state.
    put(mem, leaf.GM_CURRENT_MODE_ADDR, leaf.GM_ADVENTURE, 1)
    put(mem, leaf.GM_CURRENT_MODE_ADDR + 3, leaf.ADVENTURE_PRESENTATION_STATES[0], 1)
    put(mem, origin_addr, origin, 1)
    # Retail gm_GetButtonsTriggered table for pad 0: r3/r4 results at +8/+0xC.
    table = 0x80479C30
    put(mem, table + 0x08, 0x11112222, 4)
    put(mem, table + 0x0C, 0x00000020, 4)
    put(mem, leaf.HSD_PAD_COPY_STATUS + leaf.PAD_STATUS_STRIDE + 0x0C,
        leaf.PAD_BUTTON_START if p2_start else 0, 4)


def test_integrated_leaf_direct_origin_forces_start_without_raw_p2():
    base=0x804F1CC0; origin_addr=0x804F1101; mem={}
    _seed_accessor(mem, origin_addr=origin_addr, origin=8, p2_start=False)
    blob=leaf.build_campaign_leaf_wrapper(base,0x804F1000,origin_addr=origin_addr)
    r=execute(blob,base,mem=mem,initial_regs={3:0})
    assert r['regs'][3] == 0x11112222
    assert r['regs'][4] == (0x20 | leaf.PAD_BUTTON_START)


def test_integrated_leaf_local_origin_keeps_p2_start_mirror():
    base=0x804F1CC0; origin_addr=0x804F1101; mem={}
    _seed_accessor(mem, origin_addr=origin_addr, origin=2, p2_start=True)
    blob=leaf.build_campaign_leaf_wrapper(base,0x804F1000,origin_addr=origin_addr)
    r=execute(blob,base,mem=mem,initial_regs={3:0})
    assert r['regs'][4] == (0x20 | leaf.PAD_BUTTON_START)
