from pathlib import Path
import inspect

from sdk import adventure_gateway_scope as scope
from sdk import adventure_probe
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch

ROOT = Path(__file__).resolve().parents[1]


def test_02010_branding_and_manifest_format():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    build = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    gui = (ROOT / 'melee_sdk.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.18'" in src
    assert "'format':'melee-character-sdk-0.20.18-slippi-adventure-netplay-bridge'" in src
    assert 'MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in build
    assert '_MeleeSDK_0.20.18.iso' in build
    assert '0.20.18 — Slippi Adventure Netplay Bridge' in gui


def test_builder_restores_only_staffroll_call_and_requires_final_origin_guard():
    src = inspect.getsource(adventure_probe.install_phase30_coop_spawn_probe)
    assert 'requires guarded GOver completion bridge' in src
    assert 'requires captured-origin completion wrapper' in src
    # The 0.20.8 policy restored both sites. 0.20.11 must not restore the final
    # Adventure/Coming-Soon GM_MENU call.
    assert 'CAMPAIGN_COMPLETE_SET_PENDING_CALL, CAMPAIGN_COMPLETE_RETAIL,' not in src


def test_scope_installer_emits_final_origin_guard_and_02010_restores_only_staffroll():
    import json
    manifest = json.loads((ROOT / 'Build' / 'HF29F_runtime_manifest.json').read_text())
    pending = manifest['probe_section']['address'] + 0x2E
    d = DOLImage(ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')
    result = scope.install(
        d, manifest['probe_section']['index'], gateway_pending_addr=pending,
        enable_sdk0205_extras=True, capture_origin=True)
    rows = {x['name']: x for x in result['origin_return_guards']}
    campaign = rows['campaign_complete_origin_return']
    raw = d.read_at_address(scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL, 4)
    dec = decode_branch(scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL, raw)
    assert dec['target'] == campaign['guard_stub']
    assert raw != scope.CAMPAIGN_COMPLETE_RETAIL
    # Mimic 0.20.11's only completion rollback: Staff Roll/GOver back to retail.
    installed = d.read_at_address(scope.POST_STAFFROLL_RETURN_CALL, 4)
    assert installed != scope.POST_STAFFROLL_RETURN_RETAIL
    d.patch_at_address(scope.POST_STAFFROLL_RETURN_CALL, scope.POST_STAFFROLL_RETURN_RETAIL, expected=installed)
    assert d.read_at_address(scope.POST_STAFFROLL_RETURN_CALL, 4) == scope.POST_STAFFROLL_RETURN_RETAIL
    assert d.read_at_address(scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL, 4) == raw


def test_spawn_repair_is_frozen_in_current_installer():
    # 0.20.9 static fallback remains retail and its Adventure/Slippi gate remains installed.
    installer = inspect.getsource(adventure_probe.install_phase30_coop_spawn_probe)
    assert 'dol.patch_at_address(STATIC_FIGHTER_SPAWN_SLOT_HOOK' not in installer
    assert 'dol.patch_at_address(MULTISLOT_POST_COORD_HOOK' in installer
    assert 'adventure_slippi_spawn_normalizer_bypass' in installer


def test_staffroll_legacy_shared_cursor_wrapper_is_retained_but_superseded():
    src = inspect.getsource(adventure_probe._staffroll_dual_pad_wrapper)
    assert "Retail only owns one cursor" in src
    assert 'buttons and' in src and 'triggers are ORed' in src
    readme = (ROOT / 'README.md').read_text(encoding='utf-8')
    assert 'The previous axis-merging behavior is no longer used by the active installer' in readme
    assert hasattr(adventure_probe, '_staffroll_dual_lens_proc')
