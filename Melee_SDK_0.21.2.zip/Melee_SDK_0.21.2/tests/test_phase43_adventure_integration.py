from pathlib import Path
import inspect

from sdk import adventure_probe as a
from sdk.iso_builder import ADVENTURE_DIFFICULTIES, build_test_iso
from sdk.ppc import cmpw

ROOT=Path(__file__).resolve().parents[1]


def test_phase43_source_addresses_and_defaults():
    assert a.ADVENTURE_TEAMKIRBY_EXIT_HOOK == 0x801B4C5C
    assert a.ADVENTURE_FALCO_FIGHT_SETUP_HOOK == 0x801B4DAC
    assert a.GM_SET_NEXT_GAME_MODE_STATE_ID == 0x801A42A0
    assert a.ADVENTURE_CORNERIA_INTRO_AFTER_GIANT_KIRBY == 0x28
    assert a.CKIND_FOX == 0x02
    assert a.CKIND_FALCO == 0x14
    sig=inspect.signature(build_test_iso)
    assert sig.parameters['adventure_difficulty'].default == 'normal'
    assert sig.parameters['adventure_stocks'].default == 3
    assert sig.parameters['friendly_fire'].default is None
    assert ADVENTURE_DIFFICULTIES['normal'] == 2


def test_falco_wrapper_is_cpu_domain_only():
    blob=a._falco_cpu_substitution_wrapper(0x80430000)
    assert len(blob) % 4 == 0
    assert 80 <= len(blob) <= 256
    # The generated routine only searches the two CPU-domain PlayerInitData
    # records. Human P1/P2 offsets must not appear as lbz ckind operands.
    assert bytes.fromhex('896a00a8') in blob  # lbz r11, P3 ckind(r10)
    assert bytes.fromhex('896a00cc') in blob  # lbz r11, P4 ckind(r10)
    assert bytes.fromhex('896a0060') not in blob
    assert bytes.fromhex('896a0084') not in blob
    # Regression: Corneria uses CharacterKind, not FighterKind.  The old
    # Phase-43 wrapper accidentally compared Fox/Falco as FtKind 0x01/0x16,
    # so the Falco-selected branch could never match Adventure x7C.
    assert bytes.fromhex('2f8b0014') in blob  # cmpwi cr7,r11,CKind_Falco
    assert blob.count(bytes.fromhex('2f8b0002')) == 2  # CKind_Fox slots 2/3
    assert bytes.fromhex('39600014') in blob  # li r11,CKind_Falco
    assert bytes.fromhex('2f8b0016') not in blob
    assert bytes.fromhex('2f8b0001') not in blob


def test_team_kirby_wrapper_prearms_retail_skip_target():
    blob=a._team_kirby_exit_wrapper(0x80431000,0x80432000)
    assert len(blob) % 4 == 0
    assert 60 <= len(blob) <= 192
    # li r3,0x28 and an outbound call to the source-grounded next-state setter.
    assert bytes.fromhex('38600028') in blob
    # cmpwi cr7,r11,1859 + GT: retail integer frame_count/60 > 30 begins at frame 1860.
    assert bytes.fromhex('2f8b0743') in blob


def test_gateway_config_accepts_normal_and_custom_stocks():
    blob=a._adventure_gateway_onload_wrapper(
        0x80433000,0x80434000,
        gateway_pending_addr=0x8043502E,camera_owner_addr=0x80435020,
        persistence_valid_addr=0x80435021,p1_stocks_addr=0x80435022,
        p2_stocks_addr=0x80435023,initial_stocks_addr=0x80435024,
        p1_ckind_addr=0x8043502A,p1_color_addr=0x8043502B,
        p1_nametag_addr=0x8043502D,adventure_cpu_level=2,adventure_stocks=4)
    assert bytes.fromhex('39600002') in blob  # li r11,2 Normal
    assert bytes.fromhex('39600004') in blob  # li r11,4 stocks


def test_cmpw_encoder_and_subshade_policy_are_present():
    assert len(cmpw(10,11,crf=7)) == 4
    src=inspect.getsource(a._adventure_sss_gateway_exit_wrapper)
    assert 'clone subshading' in src
    assert 'p2_subcolor_addr' in src
    assert 'cmpw(10,11,crf=7)' in src


def test_phase43_cli_exposes_runtime_rule_options():
    text=(ROOT/'iso_build_tools.py').read_text(encoding='utf-8')
    for flag in ('--friendly-fire','--no-friendly-fire','--adventure-difficulty','--adventure-stocks'):
        assert flag in text


def test_phase43_consolidated_launcher_exposes_four_user_rules():
    text=(ROOT/'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    assert 'set "DIFFICULTY=normal"' in text
    assert 'set "STOCKS=3"' in text
    assert 'set "SCENE_REVIVE=off"' in text
    assert 'set "FRIENDLY_FIRE=on"' in text
    for flag in ('--adventure-difficulty','--adventure-stocks','--scene-revive','--friendly-fire','--no-friendly-fire'):
        assert flag in text
