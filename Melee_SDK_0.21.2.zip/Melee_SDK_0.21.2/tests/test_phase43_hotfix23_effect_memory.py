"""HF23 optional particle/generator pool-refill memory guard tests."""
import struct

import pytest

from sdk import effect_memory as em
from sdk.ppc import decode_branch, encode_branch

BASE = 0x804E5000
COUNTER = 0x804E4F10
STOP = 0x80001000
HEAP_DESC = 0x8065CC00
CELL_BASE = 0x81000000


def put(memory, address, value, size=4):
    for i, b in enumerate(int(value & ((1 << (size*8))-1)).to_bytes(size, 'big')):
        memory[address+i] = b


def get(memory, address, size=4):
    return int.from_bytes(bytes(memory.get(address+i, 0) for i in range(size)), 'big')


def heap(sizes=(), *, pool=0x804D0F90, pool_free=0, current_heap=0, num_heaps=1):
    memory = {}
    put(memory, em.ADVENTURE_MODE, 4, 1)
    put(memory, em.CURRENT_HEAP, current_heap)
    put(memory, em.NUM_HEAPS, num_heaps)
    put(memory, em.HEAP_ARRAY, HEAP_DESC)
    # One heap descriptor at HEAP_DESC: size-ish/allocated/free fields; only +4 matters.
    head = CELL_BASE if sizes else 0
    put(memory, HEAP_DESC + 4, head)
    for i, size in enumerate(sizes):
        addr = CELL_BASE + i * 0x20
        nxt = CELL_BASE + (i+1)*0x20 if i+1 < len(sizes) else 0
        put(memory, addr + 0, 0)
        put(memory, addr + 4, nxt)
        put(memory, addr + 8, size)
    put(memory, pool + 0x0C, pool_free)
    return memory


def execute(blob, args, *, memory_init=None, mode=4, counter=0):
    regs = [0] * 32
    regs[1] = 0x81700000
    for i, value in enumerate(args, 3):
        regs[i] = value & 0xFFFFFFFF
    memory = dict(memory_init or heap(pool=args[0] if args else 0x804D0F90))
    put(memory, em.ADVENTURE_MODE, mode, 1)
    put(memory, COUNTER, counter)
    pc, lr = BASE, STOP
    relation = 0
    calls = []

    def signed16(v):
        return v - 0x10000 if v & 0x8000 else v

    def s32(v):
        return v - 0x100000000 if v & 0x80000000 else v

    def cr_bit_true(bi):
        if bi == 28: return relation < 0
        if bi == 29: return relation > 0
        if bi == 30: return relation == 0
        if bi == 31: return False
        raise AssertionError(f'unhandled CR bit {bi}')

    for _ in range(5000):
        if pc == STOP:
            return calls, regs, memory
        if not BASE <= pc < BASE + len(blob):
            calls.append((pc, tuple(regs[3:13])))
            # emulate HSD_ObjAlloc return and volatile clobber
            for r in [0, *range(3, 13)]:
                regs[r] = 0xD00D0000 + r
            regs[3] = 0x81234560
            pc = lr
            continue

        word = struct.unpack_from('>I', blob, pc - BASE)[0]
        op = word >> 26
        rt = (word >> 21) & 31
        ra = (word >> 16) & 31
        rb = (word >> 11) & 31
        immu = word & 0xFFFF
        imm = signed16(immu)
        nxt = pc + 4

        if word == 0x4E800020:
            nxt = lr
        elif op == 14:  # addi
            regs[rt] = ((regs[ra] if ra else 0) + imm) & 0xFFFFFFFF
        elif op == 15:  # lis/addis
            regs[rt] = ((regs[ra] if ra else 0) + (imm << 16)) & 0xFFFFFFFF
        elif op == 34:  # lbz
            regs[rt] = get(memory, (regs[ra] + imm) & 0xFFFFFFFF, 1)
        elif op == 32:  # lwz
            regs[rt] = get(memory, (regs[ra] + imm) & 0xFFFFFFFF, 4)
        elif op == 36:  # stw
            put(memory, (regs[ra] + imm) & 0xFFFFFFFF, regs[rt])
        elif op == 11:  # cmpwi
            av, bv = s32(regs[ra]), imm
            relation = -1 if av < bv else 1 if av > bv else 0
        elif op == 7:  # mulli
            regs[rt] = (s32(regs[ra]) * imm) & 0xFFFFFFFF
        elif op == 16:  # bc
            bd = word & 0xFFFC
            if bd & 0x8000: bd -= 0x10000
            bo, bi = (word >> 21) & 31, (word >> 16) & 31
            take = bo == 20 or (bo == 12 and cr_bit_true(bi)) or (bo == 4 and not cr_bit_true(bi))
            if take: nxt = (pc + bd) & 0xFFFFFFFF
        elif op == 18:  # b/bl
            d = decode_branch(pc, word.to_bytes(4, 'big'))
            if d['link']: lr = pc + 4
            nxt = d['target']
        elif op == 31:
            xo = (word >> 1) & 1023
            if xo == 32:  # cmplw cr7
                av, bv = regs[ra] & 0xFFFFFFFF, regs[rb] & 0xFFFFFFFF
                relation = -1 if av < bv else 1 if av > bv else 0
            elif xo == 266:  # add
                regs[rt] = (regs[ra] + regs[rb]) & 0xFFFFFFFF
            else:
                raise AssertionError(f'unsupported op31 xo={xo} word={word:08x}')
        else:
            raise AssertionError(f'unsupported instruction {word:08x}')
        pc = nxt
    raise AssertionError('wrapper did not return')


def run(sizes=(), *, pool=0x804D0F90, pool_free=0, mode=4, counter=0,
        current_heap=0, num_heaps=1, memory=None):
    if memory is None:
        memory = heap(sizes, pool=pool, pool_free=pool_free,
                      current_heap=current_heap, num_heaps=num_heaps)
    return execute(em.wrapper(BASE, pool, COUNTER), [pool], memory_init=memory,
                   mode=mode, counter=counter)


def test_empty_captured_heap_returns_null_without_calling_fatal_allocator():
    calls, regs, memory = run()
    assert calls == [] and regs[3] == 0 and regs[1] == 0x81700000
    assert get(memory, COUNTER) == 1


@pytest.mark.parametrize('size', [32, 192, em.MIN_FREE_BLOCK - 1])
def test_low_headroom_drops_before_allocation(size):
    calls, regs, memory = run([size])
    assert not calls and regs[3] == 0 and get(memory, COUNTER) == 1


@pytest.mark.parametrize('pool', [0x804D0F90, 0x804D0F60])
@pytest.mark.parametrize('size', [em.MIN_FREE_BLOCK, em.MIN_FREE_BLOCK + 0x10000])
def test_healthy_heap_calls_retail_exactly_once_with_original_pool(pool, size):
    calls, regs, memory = run([size], pool=pool)
    assert len(calls) == 1 and calls[0][0] == em.OBJ_ALLOC and calls[0][1][0] == pool
    assert regs[3] == 0x81234560 and get(memory, COUNTER) == 0


def test_existing_free_pool_object_bypasses_heap_guard_even_when_os_heap_empty():
    calls, regs, memory = run([], pool_free=1)
    assert len(calls) == 1 and calls[0][0] == em.OBJ_ALLOC
    assert regs[3] == 0x81234560 and get(memory, COUNTER) == 0


def test_search_reaches_later_free_block():
    calls, _, _ = run([64] * 159 + [em.MIN_FREE_BLOCK])
    assert len(calls) == 1


def test_fragmented_heap_with_no_reserved_contiguous_block_is_declined():
    calls, regs, _ = run([0x40000] * 8)
    assert not calls and regs[3] == 0


def test_scan_is_bounded_even_if_freelist_cycles():
    memory = heap([64])
    put(memory, CELL_BASE + 4, CELL_BASE)
    calls, regs, _ = run(memory=memory)
    assert not calls and regs[3] == 0


@pytest.mark.parametrize('pointer', [0x100, 0x81800000])
def test_out_of_ram_free_links_decline_effect(pointer):
    memory = heap([])
    put(memory, HEAP_DESC + 4, pointer)
    calls, regs, _ = run(memory=memory)
    assert not calls and regs[3] == 0


@pytest.mark.parametrize('mode', [0, 2, 3, 5])
def test_non_adventure_mode_uses_unmodified_retail_allocation(mode):
    calls, _, memory = run(mode=mode)
    assert len(calls) == 1 and calls[0][0] == em.OBJ_ALLOC
    assert get(memory, COUNTER) == 0


def test_pool_identity_mismatch_keeps_retail():
    # Build wrapper for generator pool but pass another pool in r3.
    memory = heap([], pool=0x804590AC)
    calls, _, memory = execute(em.wrapper(BASE, 0x804D0F90, COUNTER), [0x804590AC], memory_init=memory)
    assert len(calls) == 1 and calls[0][0] == em.OBJ_ALLOC
    assert get(memory, COUNTER) == 0


def test_effects_resume_when_headroom_returns_without_resetting_counter():
    _, _, low = run(counter=12)
    calls, _, high = run([em.MIN_FREE_BLOCK], counter=get(low, COUNTER))
    assert len(calls) == 1 and get(high, COUNTER) == 13


def test_drop_diagnostic_saturates():
    calls, regs, memory = run(counter=0xFFFFFFFF)
    assert not calls and regs[3] == 0 and get(memory, COUNTER) == 0xFFFFFFFF


@pytest.mark.parametrize('heap_index', [1, 0xFFFFFFFF])
def test_invalid_heap_index_is_rejected(heap_index):
    calls, regs, _ = run(current_heap=heap_index, num_heaps=1)
    assert not calls and regs[3] == 0


def test_null_heap_array_is_rejected():
    memory = heap([em.MIN_FREE_BLOCK])
    put(memory, em.HEAP_ARRAY, 0)
    calls, regs, _ = run(memory=memory)
    assert not calls and regs[3] == 0


def test_call_sites_are_the_two_nullable_retail_effect_constructors():
    assert em.SITES == (
        (0x8039D9E0, 'generator', 0x804D0F90),
        (0x80398C90, 'particle', 0x804D0F60),
    )
    assert em.OBJ_ALLOC == 0x8037ABC8


def test_reserve_is_sufficient_for_hf22_clear_screen_plus_observed_tail():
    # HF22's smallest captured total was 323,680 bytes. Round above it to a
    # clean 320-KiB emergency reserve and account for one pool refill.
    assert em.RESERVE_BYTES == 0x50000
    assert em.RESERVE_BYTES >= 153632 + 170048
    assert em.MIN_FREE_BLOCK == em.RESERVE_BYTES + em.REFILL_ALLOWANCE


def test_wrong_call_instruction_refuses_install_before_mutation():
    class WrongDOL:
        def read_at_address(self, addr, size):
            return bytes(4)
    with pytest.raises(ValueError, match='call mismatch'):
        em.install(WrongDOL(), 8)
