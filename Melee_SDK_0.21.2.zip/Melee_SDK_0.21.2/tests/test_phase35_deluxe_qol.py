from pathlib import Path

from sdk.adventure_probe import (
    _adventure_pauser_mode_wrapper,
    install_phase30_coop_spawn_probe,
    ONE_PLAYER_CSTICK_HOOK, ONE_PLAYER_CSTICK_EXPECTED,
    DEFAULT_PAUSER_MODE_CALL_HOOK, DEFAULT_PAUSER_MODE_CALL_EXPECTED,
    GM_GET_CURRENT_GAME_MODE, GM_ADVENTURE, GM_VS,
)
from sdk.ppc import decode_branch, li, nop


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def _direct_calls(base, raw):
    out=[]
    for i,w in enumerate(_words(raw)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            d=decode_branch(base+i*4,w)
            if d['link']:
                out.append(d['target'])
    return out


def test_phase35_published_1p_cstick_patch_site_matches_canonical_dol():
    assert ONE_PLAYER_CSTICK_HOOK == 0x8016B480
    assert ONE_PLAYER_CSTICK_EXPECTED.hex() == '48000008'
    assert nop().hex() == '60000000'


def test_phase35_either_player_pause_intercepts_only_first_mode_query():
    assert DEFAULT_PAUSER_MODE_CALL_HOOK == 0x8016BC8C
    assert DEFAULT_PAUSER_MODE_CALL_EXPECTED.hex() == '48038685'
    d=decode_branch(DEFAULT_PAUSER_MODE_CALL_HOOK, DEFAULT_PAUSER_MODE_CALL_EXPECTED)
    assert d['link'] is True
    assert d['target'] == GM_GET_CURRENT_GAME_MODE

    base=0x804DFC00
    raw=_adventure_pauser_mode_wrapper(base)
    calls=_direct_calls(base,raw)
    assert calls == [GM_GET_CURRENT_GAME_MODE]
    assert li(3,GM_VS) in _words(raw)
    assert GM_ADVENTURE == 4


def test_phase35_install_enables_qol_by_default(tmp_path):
    clean=Path('/mnt/data/main.dol')
    if not clean.exists():
        return
    out=tmp_path/'phase35.dol'
    m=install_phase30_coop_spawn_probe(clean, Path('data/runtime_symbols_GALE01.txt'), out)
    hooks={x['name']:x for x in m['hooks']}
    assert 'one_player_cstick' in hooks
    assert 'either_player_pause_mode_classification' in hooks
    assert m['probe_contract']['one_player_cstick'] is True
    assert m['probe_contract']['either_player_pause'] is True

    # Verify the actual installed c-stick instruction is the historical NOP.
    from sdk.dol_patch import DOLImage
    dol=DOLImage(out.read_bytes())
    assert dol.read_at_address(ONE_PLAYER_CSTICK_HOOK,4) == nop()
    pause=dol.read_at_address(DEFAULT_PAUSER_MODE_CALL_HOOK,4)
    assert decode_branch(DEFAULT_PAUSER_MODE_CALL_HOOK,pause)['target'] == hooks['either_player_pause_mode_classification']['stub_address']
