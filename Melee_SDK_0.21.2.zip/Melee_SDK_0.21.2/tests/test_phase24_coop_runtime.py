from pathlib import Path
import struct
import json

from sdk.adventure_runtime import RUNTIME_TOUCHPOINTS, runtime_touchpoint_report, preflight_runtime_dol


def _fake_dol(symbol_addrs):
    # text0: file 0x100, RAM 0x80001000, 0x1000 bytes
    raw=bytearray(0x1100)
    struct.pack_into('>I',raw,0x00,0x100)
    struct.pack_into('>I',raw,0x48,0x80001000)
    struct.pack_into('>I',raw,0x90,0x1000)
    for i,addr in enumerate(symbol_addrs):
        off=0x100+(addr-0x80001000)
        raw[off:off+0x40]=bytes([(i+1)&0xFF])*0x40
    return bytes(raw)


def test_touchpoint_contract_is_source_grounded_and_unique():
    report=runtime_touchpoint_report()
    assert report['format']=='melee-sdk-coop-runtime-touchpoints-v1'
    names=[x.symbol for x in RUNTIME_TOUCHPOINTS]
    assert len(names)==len(set(names))
    assert {'gm_8017CE34','gm_8017D7AC','gm_8017E7A0','gm_801B4064'} <= set(names)


def test_dol_preflight_captures_all_required_hooks(tmp_path):
    base=0x80001000
    addrs={tp.symbol:base+i*0x80 for i,tp in enumerate(RUNTIME_TOUCHPOINTS)}
    dol=tmp_path/'start.dol'; dol.write_bytes(_fake_dol(list(addrs.values())))
    syms=tmp_path/'symbols.txt'
    syms.write_text('\n'.join(f'{name} = .text:0x{addr:08X}; // size:0x40 type:function scope:global' for name,addr in addrs.items()))
    r=preflight_runtime_dol(dol,syms)
    assert r['status']=='PASS'
    assert len(r['hooks'])==len(RUNTIME_TOUCHPOINTS)
    assert all(h['capture_size']==0x40 for h in r['hooks'])
    assert all(len(h['bytes'])==0x80 for h in r['hooks'])
