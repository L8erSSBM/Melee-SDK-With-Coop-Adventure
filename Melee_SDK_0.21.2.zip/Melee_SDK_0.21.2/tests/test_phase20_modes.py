import json, struct
from pathlib import Path

from sdk.dol_patch import DOLImage, SymbolMap
from sdk.game_modes import OnePlayerModeEditor, CustomModeRecipe, ModePlayer


def make_dol():
    base=0x803D0000; size=0xA500
    raw=bytearray(0x100+size)
    struct.pack_into('>I',raw,0x1C,0x100)
    struct.pack_into('>I',raw,0x64,base)
    struct.pack_into('>I',raw,0xAC,size)
    # classic first entry at 0x803D9910
    off=0x100+(0x803D9910-base)
    raw[off:off+16]=bytes([4,0])+struct.pack('>HH',50,170)+bytes([1,2,3,4,5,6,7,8,9,10])
    # adventure first entry at 0x803D7AC0
    off2=0x100+(0x803D7AC0-base)
    raw[off2:off2+26]=bytes([4,0])+struct.pack('>HH',40,450)+bytes(range(20))
    syms=SymbolMap.from_text('''
gmTraining_ClassicStages = .data:0x803D9910; // type:object size:0x410 scope:local
lbl_803D7AC0 = .data:0x803D7AC0; // type:object size:0xB2C
''')
    return DOLImage(raw),syms


def test_classic_parse_and_patch():
    dol,syms=make_dol(); ed=OnePlayerModeEditor(dol,syms)
    e=ed.classic_entries()[0]
    assert (e.stage_kind,e.scale0_pct,e.scale1_pct)==(4,50,170)
    assert e.opponent_triplets==[(1,2,3),(4,5,6),(7,8,9)]
    ed.patch_classic(0,stage_kind=0x15,scale0_pct=125)
    e2=ed.classic_entries()[0]
    assert (e2.stage_kind,e2.scale0_pct,e2.scale1_pct)==(0x15,125,170)
    assert e2.payload==e.payload


def test_adventure_parse_and_patch_preserves_payload():
    dol,syms=make_dol(); ed=OnePlayerModeEditor(dol,syms)
    e=ed.adventure_entries()[0]
    assert e.payload==bytes(range(20))
    ed.patch_adventure(0,scale1_pct=999)
    e2=ed.adventure_entries()[0]
    assert e2.scale1_pct==999 and e2.payload==bytes(range(20))


def test_duo_recipe_roundtrip(tmp_path):
    p=tmp_path/'duo.json'
    r=CustomModeRecipe('Friends Run',players=[ModePlayer(0,'human',0),ModePlayer(1,'human',0),ModePlayer(2,'cpu',1,cpu_level=8)],stage_kinds=[2,3,0x15],stock_count=5)
    r.save(p); q=CustomModeRecipe.load(p)
    assert q.name=='Friends Run' and len(q.players)==3 and q.stage_kinds[-1]==0x15
    assert sum(x.role=='human' for x in q.players)==2
