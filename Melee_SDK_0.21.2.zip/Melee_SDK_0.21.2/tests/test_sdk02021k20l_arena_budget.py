from sdk import slippi_coop_stage_page as sp


def test_k20l_sss_code_reclaims_k20k_arena_overflow():
    base=0x804F0000
    render=sp.build_render_page(base,state_addr=base,canonical_valid_addr=base+0x1000,
        visual_models_offset=0x1234,visual_table_offset=0x5678,visual_record_count=4)
    frame=sp.build_frame_wrapper(base,0x80000000,state_addr=base,render_addr=base+0x200)
    assert len(render) == 0x1F4
    assert len(frame) == 0xC0
    # K20K was 0x254 + 0xD0.  The 0x70 raw reduction becomes 0x80 after
    # the page payload's 0x20-byte alignment, clearing the observed 0x60 overflow.
    assert (0x254 + 0xD0) - (len(render) + len(frame)) == 0x70


def test_k20l_state_snapshot_never_overlaps_code():
    assert sp.STATE_SIZE >= sp.STATE_SNAPSHOT_END
