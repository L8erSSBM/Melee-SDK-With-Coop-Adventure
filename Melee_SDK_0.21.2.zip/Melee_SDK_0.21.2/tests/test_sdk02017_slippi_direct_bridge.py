from pathlib import Path

from sdk import slippi_direct_gateway as d
from sdk import adventure_gateway_scope as scope
from sdk.dol_patch import DOLImage
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804F9000
TRAMP = 0x804F8F00
STATE = 0x804F8E00
PENDING = 0x804F8D00
P1_CK = 0x804F8D01
P1_COLOR = 0x804F8D02
P1_SUB = 0x804F8D03
P1_TAG = 0x804F8D04
P2_VALID = 0x804F8D05
P2_CK = 0x804F8D06
P2_COLOR = 0x804F8D07
P2_SUB = 0x804F8D08
P2_TAG = 0x804F8D09
R13 = 0x80400000
GMM = 0x81200000
MATCH = GMM + d.DIRECT_MATCH_DATA_OFFSET


def wrapper():
    return d.build_wrapper(
        BASE, TRAMP, state_addr=STATE, gateway_pending_addr=PENDING,
        p1_ckind_addr=P1_CK, p1_color_addr=P1_COLOR,
        p1_subcolor_addr=P1_SUB, p1_nametag_addr=P1_TAG,
        p2_identity_valid_addr=P2_VALID,
        p2_ckind_addr=P2_CK, p2_color_addr=P2_COLOR,
        p2_subcolor_addr=P2_SUB, p2_nametag_addr=P2_TAG)


def base_mem(*, current=d.GM_ONLINE, online=d.ONLINE_MODE_DIRECT,
             stage=d.SENTINEL_STAGE, p1_type=0, p2_type=0,
             p1=(0x02, 1, 2, 3), p2=(0x14, 2, 3, 4)):
    mem = {}
    put(mem, d.GM_CURRENT_MODE_ADDR, current, 1)
    put(mem, (R13 + d.OFST_R13_ONLINE_MODE) & 0xFFFFFFFF, online, 1)
    put(mem, (R13 + d.OFST_R13_GM_MAINLIB) & 0xFFFFFFFF, GMM, 4)
    put(mem, MATCH + d.DIRECT_STAGE_LOW_BYTE, stage, 1)
    put(mem, MATCH + d.P1 + d.PLAYER_TYPE, p1_type, 1)
    put(mem, MATCH + d.P2 + d.PLAYER_TYPE, p2_type, 1)
    for off, val in zip((d.CKIND, d.COLOR, d.SUBCOLOR, d.NAMETAG), p1):
        put(mem, MATCH + d.P1 + off, val, 1)
    for off, val in zip((d.CKIND, d.COLOR, d.SUBCOLOR, d.NAMETAG), p2):
        put(mem, MATCH + d.P2 + off, val, 1)
    return mem


def run(mem):
    changes = []
    def retail(regs, _mem):
        regs[3] = 0x12345678
    def change(regs, _mem):
        changes.append(regs[3])
    result = execute(wrapper(), BASE, mem=mem, initial_regs={13:R13},
                     callees={TRAMP:retail, d.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE:change})
    return result, changes


def test_direct_test_sentinel_is_selectable_yoshis_story_and_local_sentinel_stays_separate():
    assert d.SENTINEL_STAGE == 0x08
    from sdk import adventure_probe as a
    assert a.ADVENTURE_GATEWAY_STKIND == 0x1D


def test_direct_two_human_sentinel_arms_gateway_and_requests_adventure():
    mem = base_mem()
    result, changes = run(mem)
    assert changes == [d.GM_ADVENTURE]
    assert get(mem, PENDING, 1) == 1
    assert get(mem, P2_VALID, 1) == 1
    assert get(mem, P1_CK, 1) == 0x02
    assert get(mem, P1_COLOR, 1) == 1
    assert get(mem, P1_SUB, 1) == 2
    assert get(mem, P1_TAG, 1) == 3
    assert get(mem, P2_CK, 1) == 0x14
    assert get(mem, P2_COLOR, 1) == 2
    # Different characters normalize P2 subshade exactly like local VS.
    assert get(mem, P2_SUB, 1) == 0
    assert get(mem, P2_TAG, 1) == 4
    assert get(mem, STATE + 4, 1) == d.TRACE_ADVENTURE_REQUESTED
    assert get(mem, STATE + 0x0A, 1) == 1
    # Wrapper remains transparent to the caller's retail return value.
    assert result['regs'][3] == 0x12345678


def test_same_character_same_costume_preserves_direct_subshade():
    mem = base_mem(p1=(0x02, 1, 2, 3), p2=(0x02, 1, 7, 4))
    _result, changes = run(mem)
    assert changes == [d.GM_ADVENTURE]
    assert get(mem, P2_SUB, 1) == 7


def test_non_direct_wrong_stage_or_cpu_fails_closed_without_arming_gateway():
    cases = [
        dict(current=0x02),
        dict(online=1),
        dict(stage=0x1F),
        dict(p1_type=1),
        dict(p2_type=1),
    ]
    for kwargs in cases:
        mem = base_mem(**kwargs)
        _result, changes = run(mem)
        assert changes == []
        assert get(mem, PENDING, 1) == 0
        assert get(mem, P2_VALID, 1) == 0


def test_installer_patches_only_retail_preload_entry_and_emits_diagnostics():
    dol = DOLImage((ROOT/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    assert dol.read_at_address(d.HOOK, 4) == d.EXPECTED
    row = d.install(
        dol, 8, gateway_pending_addr=PENDING,
        p1_ckind_addr=P1_CK, p1_color_addr=P1_COLOR,
        p1_subcolor_addr=P1_SUB, p1_nametag_addr=P1_TAG,
        p2_identity_valid_addr=P2_VALID,
        p2_ckind_addr=P2_CK, p2_color_addr=P2_COLOR,
        p2_subcolor_addr=P2_SUB, p2_nametag_addr=P2_TAG)
    assert row['marker'] == 'DRCT'
    assert row['required_major_mode'] == 0x08
    assert row['required_online_mode'] == 2
    assert row['sentinel_stage'] == 0x08
    assert row['return_origin_contract'].endswith('captured origin')
    assert dol.read_at_address(d.HOOK, 4) != d.EXPECTED


def test_existing_captured_origin_contract_accepts_slippi_online_mode_not_only_vs():
    # Origin validation rejects only zero/Adventure; Slippi online 0x08 is a
    # legal captured launcher value for Quit/LRA/GameOver/Completion returns.
    src = (ROOT/'sdk'/'adventure_gateway_scope.py').read_text(encoding='utf-8')
    assert 'cmpwi(11, 0, crf=7)' in src
    assert 'cmpwi(11, GM_ADVENTURE, crf=7)' in src
    assert 'GM_ONLINE' not in src  # no hard-coded VS/online destination split
    assert scope.GM_ADVENTURE == 4


def test_02017_branding_and_team_damage_test_default():
    probe=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    iso=(ROOT/'sdk'/'iso_builder.py').read_text(encoding='utf-8')
    build=(ROOT/'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    gui=(ROOT/'melee_sdk.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.18'" in probe
    assert "'sdk_version':'0.20.18'" in iso
    assert 'MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in build
    assert '_MeleeSDK_0.20.18.iso' in build
    assert 'set "FRIENDLY_FIRE=on"' in build
    assert "0.20.18 — Slippi Adventure Netplay Bridge" in gui
