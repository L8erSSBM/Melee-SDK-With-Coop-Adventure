from pathlib import Path
import inspect

from sdk import slippi_coop_stage_page as sp
from sdk import sss_visual_qol as q

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'sss_qol'


def _bbox_for_rgb(im, rgb):
    pts=[]
    for y in range(im.height):
        for x in range(im.width):
            p=im.pixels[y*im.width+x]
            if all(abs(p[c]-rgb[c])<=8 for c in range(3)) and p[3] > 240:
                pts.append((x,y))
    assert pts
    return min(x for x,_ in pts), min(y for _,y in pts), max(x for x,_ in pts), max(y for _,y in pts)


def test_page2_visuals_use_live_buffer_copy_not_retail_frame_replacement():
    src=inspect.getsource(q.patch_mnslmap_bytes)
    assert "entries'][5]" in src                 # retail slot-27 special-icon frame
    assert "entries'][0x1B]" in src              # retail slot-27 caption frame
    assert "entries'][1]" not in src              # K20P's destructive frame-1 path is gone
    assert "b'SSVQ'" in src
    assert "add_row(r['image'],original,enc,'icon_pixels')" in src
    assert "add_row(r['image'],original,enc,'stage_title')" in src
    # The only resident texture write is the requested Page-1 footer.  Icon/title
    # payloads are appended, then copied into live buffers only on Page 2.
    assert src.count("arc.raw[ns:ns+nav_target['size']]=down_enc") == 1


def test_runtime_applies_all_visual_rows_and_invalidates_texture_cache():
    helper=inspect.getsource(sp._emit_visual_table_swaps)
    render=inspect.getsource(sp.build_render_page)
    assert 'MEMCPY_ADDR' in helper
    assert 'DC_FLUSH_RANGE_ADDR' in helper
    assert 'GX_INVALIDATE_TEX_ALL_ADDR' in helper
    assert '_emit_visual_table_swaps' in render
    assert not hasattr(sp, '_emit_refresh_slot27_icon')


def test_footer_direction_and_shading_are_page_specific():
    down=q._load_png_rgba(ASSETS/'sss_nav_default_down.png')
    up=q._load_png_rgba(ASSETS/'sss_nav_page2_up.png')
    assert down.size == up.size == (232,16)
    # Blue/gray directional fill is on the DOWN arm for Page 1 and UP arm for Page 2.
    db=_bbox_for_rgb(down,(115,135,220))
    ub=_bbox_for_rgb(up,(115,135,220))
    assert db[1] >= 10 and db[3] >= 14
    assert ub[1] <= 1 and ub[3] <= 5
    # Page 1 legend is right-anchored; Page 2 legend is left-anchored.
    def alpha_bbox(im):
        pts=[(i%im.width,i//im.width) for i,p in enumerate(im.pixels) if p[3] > 16]
        return min(x for x,_ in pts),min(y for _,y in pts),max(x for x,_ in pts),max(y for _,y in pts)
    assert alpha_bbox(down)[0] >= 120
    assert alpha_bbox(up)[0] < 8


def test_title_has_clean_black_transparency_and_antialiased_native_intensity():
    title=q._load_png_rgba(ASSETS/'coop_adventure_title_only.png')
    assert title.size == (224,56)
    transparent=[p for p in title.pixels if p[3] == 0]
    assert transparent and all(p[:3] == (0,0,0) for p in transparent)
    # K20R follows retail filled glyphs. Bake alpha into the I4 luminance rather
    # than turning even nearly transparent antialiasing pixels solid white.
    native=q._intensity_art(title)
    assert any(20 <= p[0] <= 100 for p in native.pixels)
    assert all(native.pixels[i][:3]==(0,0,0) for i,p in enumerate(title.pixels) if p[3]==0)


def test_obsolete_barcode_payloads_are_not_shipped():
    assert not (ASSETS/'coop_adventure_icon_c8_48.bin').exists()
    assert not (ASSETS/'coop_adventure_icon_tlut16_rgb565.bin').exists()
