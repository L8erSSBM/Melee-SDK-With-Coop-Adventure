from sdk.ui_metadata import move_group, move_friendly_name


def test_core_attack_grouping():
    assert move_group('AttackDash') == ('Grounded Attacks', 'Dash Attack')
    assert move_group('Attack11') == ('Grounded Attacks', 'Jab / Rapid Jab')
    assert move_group('AttackS3S') == ('Grounded Attacks', 'Tilts')
    assert move_group('AttackHi4') == ('Grounded Attacks', 'Smash Attacks')
    assert move_group('AttackAirF') == ('Aerial Attacks', 'Forward Air')
    assert move_group('AttackAirLw') == ('Aerial Attacks', 'Down Air')


def test_dash_movement_separation():
    assert move_group('Dash') == ('Movement', 'Dash / Turn')
    assert move_group('Run') == ('Movement', 'Walk / Run')
    assert move_group('AttackDash')[0] != 'Movement'


def test_friendly_names():
    assert move_friendly_name('AttackDash') == 'Dash Attack'
    assert move_friendly_name('AttackAirN') == 'Neutral Air'
    assert move_friendly_name('AttackHi3') == 'Up Tilt'


def test_item_and_status_grouping():
    assert move_group('ItemScopeFire')[0] == 'Items / Item Actions'
    assert move_group('ItemScrewDamage') == ('Items / Item Actions', 'Screw Attack')
    assert move_group('SwingDash') == ('Items / Item Actions', 'Item Swings')
    assert move_group('LightThrowF')[0] == 'Items / Item Actions'
    assert move_group('HeavyThrowHi')[0] == 'Items / Item Actions'
    assert move_group('FuraSleepStart') == ('Status / Reactions', 'Dizzy / Sleep')
    assert move_group('MissFoot') == ('Status / Reactions', 'Slip / Misstep')
    assert move_group('EscapeAir')[0] == 'Defense / Evasion'
