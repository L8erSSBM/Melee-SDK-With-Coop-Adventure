from pathlib import Path
import os, math
from sdk.character_schemas import CHARACTER_ATTR_SCHEMAS
from sdk.melee_dat import FighterDAT

ALIASES = {'Drmario':'Mario','Falco':'Fox','Ganon':'Captain','Clink':'Link','Pichu':'Pikachu','Emblem':'Mars'}

def test_clone_schema_aliases_match_parent_layouts():
    for child,parent in ALIASES.items():
        assert CHARACTER_ATTR_SCHEMAS[child] == CHARACTER_ATTR_SCHEMAS[parent]

def test_phase9_semantic_coverage_count():
    mapped = {'Mario','Drmario','Luigi','Donkey','Kirby','Link','Clink','Ness','Peach','Pikachu','Pichu','Yoshi','Purin','Mewtwo','Gamewatch','Mars','Emblem','Fox','Falco','Captain','Ganon'}
    assert mapped <= set(CHARACTER_ATTR_SCHEMAS)
    assert all(CHARACTER_ATTR_SCHEMAS[k] for k in mapped)

def test_all_mapped_real_dat_fields_are_finite_and_set_same_roundtrips():
    root = Path(os.environ['MELEE_FIGHTER_DIR']) if os.environ.get('MELEE_FIGHTER_DIR') else None
    if not root: return
    prefixes={'Mario':'Mr','Drmario':'Dr','Luigi':'Lg','Donkey':'Dk','Kirby':'Kb','Link':'Lk','Clink':'Cl','Ness':'Ns','Peach':'Pe','Pikachu':'Pk','Pichu':'Pc','Yoshi':'Ys','Purin':'Pr','Mewtwo':'Mt','Gamewatch':'Gw','Mars':'Ms','Emblem':'Fe','Fox':'Fx','Falco':'Fc','Captain':'Ca','Ganon':'Gn'}
    for name,prefix in prefixes.items():
        f=FighterDAT(root/f'Pl{prefix}.dat')
        attrs=f.character_attributes(); original=bytes(f.archive.raw)
        assert attrs
        for key,v in attrs.items():
            if isinstance(v['value'],float): assert math.isfinite(v['value']), (name,key,v['value'])
            f.set_character_attribute(key,v['value'])
        assert bytes(f.archive.raw)==original, name
