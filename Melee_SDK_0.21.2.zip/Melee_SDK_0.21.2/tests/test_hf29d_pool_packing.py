import json
from pathlib import Path
import pytest
from sdk import team_kirby_pool_packing as p
from sdk.dol_patch import DOLImage
from hf29d_ppc import execute,put,get,SENTINEL

ROOT=Path(__file__).resolve().parents[1]
BASE=0x804E3000

def initial_memory(mode=4,state=0x23,flags=0,size=8,align=3,arena=0):
    mem={}
    for address,value,n in [(p.MODE,mode,1),(p.STATE,state,1),(p.OBJ_HEAP,arena,4),
                            (p.SLIST_POOL,flags,4),(p.SLIST_POOL+32,size,4),(p.SLIST_POOL+36,align,4)]:
        put(mem,address,value,n)
    return mem

@pytest.mark.parametrize('kw,pool,count,expected',[
    ({},p.SLIST_POOL,1,4),({'mode':2},p.SLIST_POOL,1,1),
    ({'state':0x22},p.SLIST_POOL,1,1),({'state':0x24},p.SLIST_POOL,1,1),
    ({'flags':1},p.SLIST_POOL,1,1),({'flags':0x80000000},p.SLIST_POOL,1,1),
    ({'size':12},p.SLIST_POOL,1,1),({'align':7},p.SLIST_POOL,1,1),
    ({'arena':0x81000000},p.SLIST_POOL,1,1),({},p.SLIST_POOL+44,1,1),
    ({},p.SLIST_POOL,2,2),({},0,1,1)])
def test_hook_gates_and_preserves_abi(kw,pool,count,expected):
    mem=initial_memory(**kw); before=dict(mem)
    regs={i:0xAB000000+i for i in range(32)}; regs.update({3:pool,4:count})
    result=execute(p.wrapper(BASE),BASE,mem=mem,initial_regs=regs,stop_targets=(p.REFILL,))
    assert result['regs'][4]==expected and result['lr']==SENTINEL and mem==before
    for r in set(range(32))-{4,11,12}: assert result['regs'][r]==regs[r]

def test_exact_binary_delta_and_idempotency_guard():
    before=(ROOT/'Build/historical/HF29C.dol').read_bytes()
    after=(ROOT/'Build/historical/HF29D_POOL_PACKING.dol').read_bytes()
    d=DOLImage(before); result=p.install(d,8)
    assert bytes(d.raw)==after
    off=d.file_offset_for_address(p.SITE,4)
    changed={i for i,(a,b) in enumerate(zip(before,after)) if a!=b}
    assert changed<=set(range(off,off+4))|set(range(0xCC,0xD0))
    assert len(after)-len(before)==160
    assert result['section']['address']+result['section']['size']<0x804EE000
    with pytest.raises(ValueError,match='expected-byte'): p.install(d,8)

def test_retail_allocator_and_freelist_execute_with_packed_nodes():
    d=DOLImage(ROOT/'Build/historical/HF29D_POOL_PACKING.dol')
    m=json.loads((ROOT/'Build/HF29D_runtime_manifest.json').read_text())['team_kirby_pool_packing']
    routines=[(0x8037A968,d.read_at_address(0x8037A968,0x3E0)),
              (m['stub_address'],d.read_at_address(m['stub_address'],m['size']))]
    mem=initial_memory(); allocated=[]; cursor=0x81000000
    def alloc(regs,memory):
        nonlocal cursor
        size=regs[3]; assert size in (8,32)
        cell=(size+32+31)&~31
        allocated.append((size,cell)); result=cursor+32; cursor+=cell
        for i in [0,*range(3,13)]: regs[i]=0xDEAD0000+i
        regs[3]=result
    def call(pc,**regs):
        init={i:0xCAFE0000+i for i in range(14,32)}
        init.update({3:p.SLIST_POOL,**{int(k[1:]):v for k,v in regs.items()}})
        r=execute(b'',pc,mem=mem,initial_regs=init,extra_code=routines,callees={0x8037F1E4:alloc})
        assert r['regs'][1]==0x817FF000
        for i in range(14,32): assert r['regs'][i]==init[i]
        return r['regs'][3]
    nodes=[call(0x8037ABC8) for _ in range(101)]
    assert len(set(nodes))==101 and all(n%4==0 for n in nodes)
    assert allocated==[(32,64)]*26
    assert (get(mem,p.SLIST_POOL+8),get(mem,p.SLIST_POOL+12),get(mem,p.SLIST_POOL+16))==(101,3,101)
    # Retail free/reuse, including after the scene-state gate no longer matches.
    for node in nodes[::2]: call(0x8037AD20,r4=node)
    put(mem,p.STATE,0x24,1)
    reused=[call(0x8037ABC8) for _ in nodes[::2]]
    assert reused==list(reversed(nodes[::2])) and len(allocated)==26
    for _ in range(4): call(0x8037ABC8)
    assert allocated[-1]==(8,64) and len(allocated)==27
    assert get(mem,p.SLIST_POOL+8)==105 and get(mem,p.SLIST_POOL+12)==0

def test_equal_heap_cell_threshold_and_accounting_evidence():
    # OSAllocFromHeap rounds (payload + 32) up to 32, and consumes a whole
    # chosen free cell if its remainder is below 64. Both requests select
    # the same first eligible free cell for ANY given heap free-list state.
    for free_cell in range(0,513,32):
        def consumed(payload):
            need=(payload+63)&~31
            if free_cell<need: return None
            return free_cell if free_cell-need<64 else need
        assert consumed(8)==consumed(32)
    e=json.loads((ROOT/'DOUBLE_SHEIK_EVIDENCE.json').read_text())
    assert e['free_bytes']==0 and e['allocated_cells']==15581
    assert e['theoretical_packing']['saved_bytes']==322816
