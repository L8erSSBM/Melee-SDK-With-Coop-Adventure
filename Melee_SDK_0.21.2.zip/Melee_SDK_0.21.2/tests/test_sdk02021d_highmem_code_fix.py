from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk import slippi_memory_layout as ml
from sdk import slippi_adventure_netplay_bridge as nb
from sdk import slippi_coop_stage_page as sp
from sdk import slippi_direct_gateway as dg

ROOT = Path(__file__).resolve().parents[1]


def _install_current_high_components(dol: DOLImage):
    anchor = ml.install_high_code_anchor(dol)
    idx = anchor['section_index']
    bridge = nb.install(
        dol, idx,
        gateway_pending_addr=0x804F1000,
        gateway_active_addr=0x804F1001,
    )
    page = sp.install(dol, idx)
    direct = dg.install(
        dol, idx,
        gateway_pending_addr=0x804F1000,
        p1_ckind_addr=0x804F1001,
        p1_color_addr=0x804F1002,
        p1_subcolor_addr=0x804F1003,
        p1_nametag_addr=0x804F1004,
        p2_identity_valid_addr=0x804F1005,
        p2_ckind_addr=0x804F1006,
        p2_color_addr=0x804F1007,
        p2_subcolor_addr=0x804F1008,
        p2_nametag_addr=0x804F1009,
        netplay_arm_addr=bridge['arm_stub'],
    )
    return anchor, bridge, page, direct, ml.validate_high_code_section(dol, idx)


def test_current_only_direct_components_fit_protected_high_4k_with_guard_space():
    # HF29F is before all three current-only Direct components and still has the
    # exact retail hook bytes each installer requires. It also preserves the
    # real GALE01 DOL section topology/free header slots.
    dol = DOLImage(ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')
    anchor, bridge, page, direct, final = _install_current_high_components(dol)

    assert anchor['code_base'] == 0x817FF000
    assert anchor['code_limit'] == 0x81800000
    assert bridge['section']['address'] == 0x817FF020
    assert page['section']['address'] == 0x817FF740
    assert direct['state_address'] == 0x817FFA80
    assert final['end_address'] == 0x817FFE80
    assert final['free_bytes'] == 0x180


def test_high_code_is_above_relocated_session_and_inside_arena_hi_reservation():
    assert nb.STABLE_SSCB + nb.SSCB_SIZE <= ml.SDK_HIGH_CODE_BASE
    assert ml.SDK_SESSION_HIGH_BASE == 0x817FE000
    assert ml.SDK_HIGH_CODE_BASE == 0x817FF000
    assert ml.SDK_HIGH_CODE_LIMIT == ml.SDK_SESSION_HIGH_LIMIT == 0x81800000


def test_adventure_probe_freezes_low_runtime_before_adding_high_code():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    arena = src.index('slippi_memory_layout = install_arena_reservation')
    anchor = src.index('slippi_high_code = install_high_code_anchor')
    bridge = src.index('install_slippi_adventure_netplay_bridge')
    page = src.index('install_slippi_coop_stage_page')
    direct = src.index('install_slippi_direct_gateway')
    validate = src.index('validate_high_code_section')
    assert arena < anchor < bridge < page < direct
    assert anchor < validate or 'slippi_high_code.update(validate_high_code_section' in src


def test_package_revision_is_02021d_and_low_runtime_limit_never_moves():
    probe = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    iso = (ROOT / 'sdk' / 'iso_builder.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.21D'" in probe
    assert "'package_revision':'0.20.21D'" in iso
    assert ml.SDK_RUNTIME_BASE == 0x804F0C00
    assert ml.SDK_RUNTIME_LIMIT == 0x804F4C00
    assert ml.SDK_RUNTIME_LIMIT - ml.SDK_RUNTIME_BASE == 0x4000
