"""Small PPC interpreter for executing the emitted hook and retail pool routines.

This is instruction-level validation, not a Dolphin/gameplay substitute.
Unsupported instructions fail; memory allocation is supplied by each test.
"""
import struct

SENTINEL = 0x80001000

def put(mem, addr, value, size=4):
    for i,b in enumerate((value & ((1 << (size*8))-1)).to_bytes(size,'big')):
        mem[addr+i]=b

def get(mem, addr, size=4):
    return int.from_bytes(bytes(mem.get(addr+i,0) for i in range(size)),'big')

def signed(n,bits=32):
    return n-(1<<bits) if n & (1<<(bits-1)) else n

def execute(blob, base, *, mem=None, lr=SENTINEL, initial_regs=None,
            callees=None, stop_targets=(), extra_code=(), max_steps=10000):
    mem={} if mem is None else mem
    regs=[0]*32; regs[1]=0x817FF000
    for r,v in (initial_regs or {}).items(): regs[r]=v
    code={}
    for addr,data in [(base,blob),*extra_code]:
        code.update({addr+i:struct.unpack_from('>I',data,i)[0] for i in range(0,len(data),4)})
    pc=base; ctr=0; cr={}; stops={SENTINEL,*stop_targets}
    def compare(a,b,field):
        cr[field*4],cr[field*4+1],cr[field*4+2]=a<b,a>b,a==b
    for _ in range(max_steps):
        if pc in stops: return dict(target=pc,regs=regs,mem=mem,lr=lr)
        if pc in (callees or {}):
            callees[pc](regs,mem); pc=lr; continue
        w=code[pc]; op=w>>26; nxt=pc+4
        rt=(w>>21)&31; ra=(w>>16)&31; rb=(w>>11)&31
        imm=signed(w&0xFFFF,16); xo=(w>>1)&1023
        if op in (14,15): regs[rt]=((regs[ra] if ra else 0)+(imm<<(16 if op==15 else 0)))&0xFFFFFFFF
        elif op==7: regs[rt]=(signed(regs[ra])*imm)&0xFFFFFFFF  # mulli
        elif op==24: regs[ra]=regs[rt]|(w&0xFFFF)  # ori
        elif op in (32,34,40): regs[rt]=get(mem,((regs[ra] if ra else 0)+imm)&0xFFFFFFFF,{32:4,34:1,40:2}[op])
        elif op in (36,37,38,44):
            ea=((regs[ra] if ra else 0)+imm)&0xFFFFFFFF
            put(mem,ea,regs[rt],{38:1,44:2}.get(op,4))
            if op==37: regs[ra]=ea
        elif op in (46,47): # lmw/stmw
            ea=((regs[ra] if ra else 0)+imm)&0xFFFFFFFF
            for reg in range(rt,32):
                if op==46: regs[reg]=get(mem,ea+(reg-rt)*4)
                else: put(mem,ea+(reg-rt)*4,regs[reg])
        elif op in (10,11):
            compare(signed(regs[ra]) if op==11 else regs[ra],imm if op==11 else w&0xFFFF,(w>>23)&7)
        elif op==21:  # rlwinm[.]
            sh=rb; mb=(w>>6)&31; me=(w>>1)&31
            mask=sum(1<<(31-i) for i in range(32) if (mb<=i<=me if mb<=me else i>=mb or i<=me))
            regs[ra]=((regs[rt]<<sh)|(regs[rt]>>(32-sh)))&mask
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==28:
            regs[ra]=regs[rt]&(w&0xFFFF); compare(signed(regs[ra]),0,0)
        elif op==16:
            bo=(w>>21)&31; bi=(w>>16)&31
            if not bo&4: ctr=(ctr-1)&0xFFFFFFFF
            ctr_ok=bool(bo&4) or (bool(ctr)!=bool(bo&2))
            cond_ok=bool(bo&16) or (cr.get(bi,False)==bool(bo&8))
            if ctr_ok and cond_ok:
                nxt=(0 if w&2 else pc)+signed(w&0xFFFC,16)
            if w&1: lr=pc+4
        elif op==18:
            nxt=((0 if w&2 else pc)+signed(w&0x03FFFFFC,26))&0xFFFFFFFF
            if w&1: lr=pc+4
        elif op==31 and xo in (0,32):
            compare(signed(regs[ra]) if xo==0 else regs[ra],signed(regs[rb]) if xo==0 else regs[rb],(w>>23)&7)
        elif op==31 and xo==339:  # mfspr LR
            spr=((w>>16)&31)|((w>>6)&0x3E0)
            assert spr==8; regs[rt]=lr
        elif op==31 and xo==467:
            spr=((w>>16)&31)|((w>>6)&0x3E0)
            if spr==8: lr=regs[rt]
            elif spr==9: ctr=regs[rt]
            else: raise AssertionError(spr)
        elif op==31 and xo==444:
            regs[ra]=regs[rt]|regs[rb]
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo==24:  # slw
            sh=regs[rb]&0x3f
            regs[ra]=0 if sh>=32 else (regs[rt]<<sh)&0xFFFFFFFF
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo==28:  # and[.]
            regs[ra]=regs[rt]&regs[rb]
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo in (235,266,40):
            regs[rt]=({235:lambda:regs[ra]*regs[rb],266:lambda:regs[ra]+regs[rb],40:lambda:regs[rb]-regs[ra]}[xo]())&0xFFFFFFFF
            if w&1: compare(signed(regs[rt]),0,0)
        elif op==31 and xo in (23,87): # lwzx/lbzx
            regs[rt]=get(mem,((regs[ra] if ra else 0)+regs[rb])&0xFFFFFFFF,4 if xo==23 else 1)
        elif op==31 and xo==215: # stbx
            put(mem,((regs[ra] if ra else 0)+regs[rb])&0xFFFFFFFF,regs[rt],1)
        elif op==31 and xo==954: # extsb
            regs[ra]=signed(regs[rt]&255,8)&0xFFFFFFFF
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo==316: # xor
            regs[ra]=regs[rt]^regs[rb]
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo==151:
            put(mem,((regs[ra] if ra else 0)+regs[rb])&0xFFFFFFFF,regs[rt])
        elif op==31 and xo in (54,598,982):
            # dcbst / sync / icbi are cache-ordering operations. They have no
            # semantic effect in this tiny dictionary-backed interpreter.
            pass
        elif op==19 and xo==150:  # isync
            pass
        elif w in (0x4E800420,0x4E800421):
            nxt=ctr&~3
            if w&1: lr=pc+4
        elif w in (0x4E800020,0x4E800021):
            nxt=lr&~3
            if w&1: lr=pc+4
        else: raise AssertionError(f'Unsupported {w:08x} at {pc:08x}')
        pc=nxt
    raise AssertionError('PPC execution did not return')
