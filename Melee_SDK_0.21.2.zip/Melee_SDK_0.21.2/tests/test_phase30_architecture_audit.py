from sdk.additional_content import FEATURES, AdditionalContentProfile
from sdk.dol_patch import DOLImage


def test_all_additional_content_subsets_close_and_validate():
    keys=[x.key for x in FEATURES]
    for mask in range(1 << len(keys)):
        raw=[keys[i] for i in range(len(keys)) if mask & (1 << i)]
        AdditionalContentProfile('test',raw).with_dependencies().validate()


def test_append_to_data_section_reuses_header_slot(tmp_path):
    # Minimal valid DOL with one data section at physical EOF and BSS elsewhere.
    raw=bytearray(0x140)
    import struct
    struct.pack_into('>I',raw,0x1C,0x100)
    struct.pack_into('>I',raw,0x64,0x80400000)
    struct.pack_into('>I',raw,0xAC,0x40)
    struct.pack_into('>I',raw,0xD8,0x80500000)
    struct.pack_into('>I',raw,0xDC,0x1000)
    d=DOLImage(raw)
    before=[i for i in range(11) if struct.unpack_from('>I',d.raw,0xAC+i*4)[0]==0]
    row=d.append_to_data_section(0,b'PAYLOAD',alignment=0x20)
    after=[i for i in range(11) if struct.unpack_from('>I',d.raw,0xAC+i*4)[0]==0]
    assert before==after
    assert row['shared_section'] is True
    assert d.read_at_address(row['address'],7)==b'PAYLOAD'
