from __future__ import annotations

import json
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, lbz, lis, stb, li
from sdk import adventure_gateway_scope as scope
from sdk import slippi_boot_hardening as harden
from sdk.adventure_probe import (
    _rebirth_owner_preflight_wrapper,
    _staffroll_dual_pad_wrapper,
    PLAYER_GET_STOCKS,
    PLAYER_GET_ENTITY,
    REBIRTH_OWNER_PREFLIGHT_HOOK,
    REBIRTH_OWNER_PREFLIGHT_EXPECTED,
    GAME_CAMERA_OWNER_SLOT,
)

ROOT = Path(__file__).resolve().parents[1]
HF29F_DOL = ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol'
HF29G_DOL = ROOT / 'Build' / 'historical' / 'HF29G_GATEWAY_SCOPED_COOP_GAMEOVER_RETURN.dol'
HF29F_MANIFEST = ROOT / 'Build' / 'HF29F_runtime_manifest.json'
HF29G_MANIFEST = ROOT / 'Build' / 'HF29G_runtime_manifest.json'


def _branch_calls(base: int, blob: bytes) -> list[int]:
    out: list[int] = []
    for off in range(0, len(blob), 4):
        word = blob[off:off + 4]
        if len(word) != 4 or (int.from_bytes(word, 'big') >> 26) != 18:
            continue
        try:
            d = decode_branch(base + off, word)
        except ValueError:
            continue
        if d['link']:
            out.append(int(d['target']))
    return out


def test_sdk0205_rebirth_preflight_validates_partner_before_retail_route_camera():
    base = 0x804F1800
    owner = 0x804F0C20
    blob = _rebirth_owner_preflight_wrapper(base, owner)
    calls = _branch_calls(base, blob)
    assert calls.count(PLAYER_GET_STOCKS) == 1
    assert calls.count(PLAYER_GET_ENTITY) == 1
    assert li(11, 0) in [blob[i:i+4] for i in range(0, len(blob), 4)]
    assert li(11, 1) in [blob[i:i+4] for i in range(0, len(blob), 4)]
    assert REBIRTH_OWNER_PREFLIGHT_EXPECTED in blob  # displaced mflr r0
    assert GAME_CAMERA_OWNER_SLOT == 0x80452F2C
    tail = decode_branch(base + len(blob) - 4, blob[-4:])
    assert tail['target'] == REBIRTH_OWNER_PREFLIGHT_HOOK + 4
    assert tail['link'] is False


def test_sdk0205_scope_captures_launcher_origin_at_adventure_onload():
    manifest = json.loads(HF29F_MANIFEST.read_text())
    d = DOLImage(HF29F_DOL)
    pending = manifest['probe_section']['address'] + 0x2E
    result = scope.install(
        d, manifest['probe_section']['index'],
        gateway_pending_addr=pending, capture_origin=True)
    active = result['gateway_coop_active_address']
    origin = result['gateway_origin_address']
    assert origin == active + 1
    assert result['captured_origin_enabled'] is True

    stub = result['onload_hook']['scope_stub']
    blob = d.read_at_address(stub, 0x90)
    hi, lo = scope._addr_parts(scope.PREVIOUS_MODE)
    assert lis(12, hi) + lbz(11, lo, 12) in blob
    ohi, olo = scope._addr_parts(origin)
    assert lis(12, ohi) + stb(11, olo, 12) in blob


def test_sdk0205_all_three_campaign_exits_use_captured_origin_contract():
    manifest = json.loads(HF29F_MANIFEST.read_text())
    d = DOLImage(HF29F_DOL)
    pending = manifest['probe_section']['address'] + 0x2E
    result = scope.install(
        d, manifest['probe_section']['index'],
        gateway_pending_addr=pending, capture_origin=True)

    rows = {x['site_address']: x for x in result['origin_return_guards']}
    assert set(rows) == {
        scope.ABORT_RETURN_CALL,
        scope.CSS_CANCEL_RETURN_CALL,
        scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL,
    }
    assert rows[scope.ABORT_RETURN_CALL]['retail_target'] == scope.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE
    assert rows[scope.CSS_CANCEL_RETURN_CALL]['retail_target'] == scope.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE
    assert rows[scope.CAMPAIGN_COMPLETE_SET_PENDING_CALL]['retail_target'] == scope.GM_SET_PENDING_GAME_MODE
    assert 'captured launcher origin' in result['game_over']['active_behavior']


def test_sdk0205_credits_is_intentional_cross_mode_campaign_guard():
    manifest = json.loads(HF29G_MANIFEST.read_text())
    d = DOLImage(HF29G_DOL)
    result = harden.install(
        d, manifest['probe_section']['index'],
        gateway_scope=manifest['adventure_gateway_scope'],
        legacy_trace_hooks=manifest['icies_teardown_trace_hooks'],
        allow_campaign_credits_cross_mode=True)

    cross = result['cross_mode_campaign_guards']
    assert len(cross) == 1
    row = cross[0]
    assert row['name'] == 'dual_player_credits_input'
    assert 'staff-roll' in row['policy']
    assert all(x['name'] != 'dual_player_credits_input'
               for x in result['mode_first_guards'])

    # The live site remains the HF29G active-campaign dispatch, not a mode-first
    # retail escape. That is what lets Staff Roll use P2 input cross-mode.
    dec = decode_branch(row['site_address'], d.read_at_address(row['site_address'], 4))
    assert dec['target'] == row['hf29g_guard_stub']


def test_sdk0205_credits_merge_is_not_stock_gated():
    blob = _staffroll_dual_pad_wrapper(0x804F1C00, 0x804F0C21)
    calls = _branch_calls(0x804F1C00, blob)
    assert PLAYER_GET_STOCKS not in calls
    assert PLAYER_GET_ENTITY not in calls
    # Both P1 and P2 pad-copy-status blocks are referenced by the existing merge.
    assert len(blob) > 64


def test_sdk0205_extra_scope_guards_cover_static_spawn_and_early_rebirth():
    names = {x.name for x in scope.SDK0205_EXTRA_GUARDS}
    assert names == {'static_fighter_spawn_slot_remap', 'rebirth_owner_preflight'}
    assert len(scope.ACTIVE_GUARDS) == len(scope.CORE_GUARDS) + 2


def test_sdk0205_release_branding_and_single_canonical_builder():
    bats = sorted(p.name for p in ROOT.glob('*.bat'))
    assert bats == ['BUILD_MELEE_SDK.bat', 'Launch_Melee_SDK.bat']
    build = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    assert 'SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in build
    assert '_MeleeSDK_0.20.18.iso' in build
    assert '_MeleeSDK_0.20.4.iso' not in build
    gui = (ROOT / 'melee_sdk.py').read_text(encoding='utf-8')
    assert "0.20.18 — Slippi Adventure Netplay Bridge" in gui


def test_sdk0205_builder_manifest_version_is_current():
    src = (ROOT / 'sdk' / 'iso_builder.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.18'" in src
    assert "prefix='melee_sdk_0205_'" in src
