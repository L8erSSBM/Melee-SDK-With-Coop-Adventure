from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
BUILD = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
README = (ROOT / 'README.md').read_text(encoding='utf-8')


def test_static_spawn_hook_is_retired_from_current_installer():
    assert 'dol.patch_at_address(STATIC_FIGHTER_SPAWN_SLOT_HOOK' not in SRC
    assert 'MULTISLOT_POST_COORD_HOOK = 0x8016E50C' in SRC


def test_current_manifest_does_not_advertise_static_spawn_hook():
    hook_expr = "ProbeHook('static_fighter_spawn_slot_remap'"
    assert hook_expr not in SRC
    assert "'static_cpu_spawn_remap':{'policy':'0.20.9 preserves exact retail 0x8016E48C" in SRC


def test_historical_wrapper_is_kept_only_for_layout_reproducibility():
    assert 'def _static_fighter_spawn_slot_wrapper' in SRC
    assert 'def _static_fighter_spawn_slot_wrapper' in SRC
    assert 'static_spawn=_adventure_slippi_spawn_guard_wrapper' in SRC


def test_slippi_relocation_is_still_installed():
    assert 'slippi_memory_layout = install_arena_reservation(dol, runtime_sec.index)' in SRC
    assert '0.20.3 runtime relocation' in BUILD
    assert 'Slippi-safe runtime relocation' in README


def test_builder_branding_is_0209():
    assert 'MELEE CHARACTER SDK 0.20.18 - SLIPPI ADVENTURE NETPLAY BRIDGE' in BUILD
    assert '_MeleeSDK_0.20.18.iso' in BUILD
    assert "'sdk_version':'0.20.18'" in SRC


def test_gateway_scope_leaves_retail_static_spawn_site_unwrapped():
    import json
    from sdk.dol_patch import DOLImage
    from sdk import adventure_gateway_scope as scope
    root = ROOT
    manifest = json.loads((root / 'Build' / 'HF29F_runtime_manifest.json').read_text())
    pending = manifest['probe_section']['address'] + 0x2E
    dol = DOLImage(root / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')
    assert dol.read_at_address(scope.SDK0205_EXTRA_GUARDS[0].site, 4) == scope.SDK0205_EXTRA_GUARDS[0].retail
    result = scope.install(dol, manifest['probe_section']['index'], gateway_pending_addr=pending,
                           enable_sdk0205_extras=True, capture_origin=True)
    assert dol.read_at_address(scope.SDK0205_EXTRA_GUARDS[0].site, 4) == scope.SDK0205_EXTRA_GUARDS[0].retail
    skipped = {row['name'] for row in result['skipped_retail_hooks']}
    assert 'static_fighter_spawn_slot_remap' in skipped
