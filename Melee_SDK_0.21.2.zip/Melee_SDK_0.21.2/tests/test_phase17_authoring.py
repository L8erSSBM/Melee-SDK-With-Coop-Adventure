import struct
from pathlib import Path

from sdk.melee_dat import HSDArchive
from sdk.menu_archives import MenuArchiveInspector
from sdk.dol_patch import DOLImage


def archive_from_data(data: bytes, public_name: str) -> bytes:
    data = bytes(data)
    name = public_name.encode('ascii') + b'\0'
    # no relocations, one public pair whose symbol name starts at offset 0
    meta = struct.pack('>II', 0, 0) + name
    total = 0x20 + len(data) + len(meta)
    header = bytearray(0x20)
    struct.pack_into('>5I', header, 0, total, len(data), 0, 1, 0)
    header[0x14:0x18] = b'0011'
    return bytes(header) + data + meta


def synthetic_dol():
    raw = bytearray(0x400)
    # one data section in slot 0 at file 0x200, RAM 0x80300000, size 0x40
    struct.pack_into('>I', raw, 0x1C, 0x200)
    struct.pack_into('>I', raw, 0x64, 0x80300000)
    struct.pack_into('>I', raw, 0xAC, 0x40)
    # BSS after ordinary section, forcing appended loader data above it
    struct.pack_into('>I', raw, 0xD8, 0x80310000)
    struct.pack_into('>I', raw, 0xDC, 0x1000)
    return raw


def test_menu_inspector_requires_source_known_root():
    raw = archive_from_data(bytes(0x40), 'MnSelectStageDataTable')
    i = MenuArchiveInspector(raw)
    i.filename = 'MnSlMap.usd'
    r = i.report('MnSelectStageDataTable')
    assert r.public_found
    assert r.public_offset == 0
    assert i.require_public('MnSelectStageDataTable') == 0


def test_menu_inspector_rejects_wrong_root():
    raw = archive_from_data(bytes(0x40), 'SomethingElse')
    i = MenuArchiveInspector(raw)
    try:
        i.require_public('MnSelectStageDataTable')
    except ValueError as e:
        assert 'MnSelectStageDataTable' in str(e)
    else:
        raise AssertionError('missing root should be rejected')


def test_dol_added_data_section_uses_loader_section_and_avoids_bss(tmp_path):
    p = tmp_path/'main.dol'; p.write_bytes(synthetic_dol())
    d = DOLImage(p)
    result = d.add_data_section(b'new runtime table')
    assert result['address'] >= 0x80311000
    assert result['file_offset'] >= 0x400
    assert d.raw[result['file_offset']:result['file_offset']+17] == b'new runtime table'
