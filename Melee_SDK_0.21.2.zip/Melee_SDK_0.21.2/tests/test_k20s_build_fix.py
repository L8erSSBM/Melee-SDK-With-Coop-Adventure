from pathlib import Path
import json

ROOT = Path(__file__).resolve().parents[1]


def test_primary_bat_matches_validated_standalone_headroom_policy():
    text = (ROOT / 'BUILD_MELEE_SDK.bat').read_text(errors='replace')
    build_line = next(line for line in text.splitlines() if 'iso_build_tools.py' in line and '--variant coop_showcase' in line)
    assert '--adventure-sss-gateway' in build_line
    assert '--unlock-all' in build_line
    assert '--test-shortcuts' not in build_line


def test_packaged_validation_configuration_has_fixed_arena_headroom():
    data = json.loads((ROOT / 'Build' / 'K20S_build_manifest.json').read_text())
    assert data['test_shortcuts'] is False
    end = data['runtime']['slippi_memory_layout']['runtime_end']
    assert end == 0x804F4A60
    assert 0x804F4C00 - end == 0x1A0
