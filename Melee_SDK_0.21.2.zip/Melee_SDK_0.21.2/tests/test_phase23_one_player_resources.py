import json, zipfile
from pathlib import Path

from sdk.one_player_resources import (
    inspect_one_player_resources, adventure_resource_audit,
    ADVENTURE_STAGE_RESOURCES, ADVENTURE_AUXILIARY_STAGE_FILES,
)
from sdk.adventure_coop import CoopAdventureCampaign


def test_one_player_zip_inventory_without_movies(tmp_path):
    z=tmp_path/'onep.zip'
    with zipfile.ZipFile(z,'w') as f:
        f.writestr('root/IrNml.dat',b'abc')
        f.writestr('root/TyMario.dat',b'defg')
        f.writestr('root/TyMnInfo.usd',b'xx')
    r=inspect_one_player_resources(z)
    assert r.file_count==3 and r.movie_count==0
    assert r.categories['1p_visual_interface']==1
    assert r.categories['trophy_resource']==1
    assert r.categories['trophy_menu']==1


def test_adventure_stage_audit_all_source_mapped_files():
    files={row[3] for row in ADVENTURE_STAGE_RESOURCES}
    files.update(ADVENTURE_AUXILIARY_STAGE_FILES)
    a=adventure_resource_audit(extra_filenames=files)
    assert a['ready_for_retail_adventure_stage_assets']
    assert a['required_stage_file_count']==17
    assert not a['missing_stage_files']
    assert not a['missing_auxiliary_stage_files']


def test_campaign_segments_resolve_retail_files():
    c=CoopAdventureCampaign.vanilla_sequence()
    seg=c.linear_segments()
    assert len(seg)==23
    assert seg[0].filename=='GrNKr.dat'
    assert any(s.filename=='GrNSr.dat' for s in seg)
    assert any(s.filename=='GrNZr.dat' for s in seg)
    assert any(s.filename=='GrNBr.dat' for s in seg)
    assert c.runtime_plan()['retail_resource_model'].startswith('uses Melee retail Adventure')
