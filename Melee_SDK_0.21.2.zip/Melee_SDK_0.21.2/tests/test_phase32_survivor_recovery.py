from sdk.adventure_probe import (
    _respawn_platform_wrapper,
    PLAYER_LOAD_COORDS,
    PLAYER_SET_SPAWN_PLATFORM_POS,
)
from sdk.ppc import decode_branch, li


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def _branches(base, raw):
    out=[]
    for i,w in enumerate(_words(raw)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            out.append(decode_branch(base+i*4,w))
    return out


def test_phase32_respawn_wrapper_can_select_either_partner():
    base=0x804DF400
    raw=_respawn_platform_wrapper(base)
    words=_words(raw)
    # Hotfix 2 stores candidate/fallback slot IDs in r11; both directions remain.
    assert li(11,1) in words
    assert li(11,0) in words
    calls=[x for x in _branches(base,raw) if x['link']]
    targets=[x['target'] for x in calls]
    assert PLAYER_LOAD_COORDS in targets
    assert PLAYER_SET_SPAWN_PLATFORM_POS in targets


def test_phase32_wrapper_keeps_single_retail_spawn_platform_call():
    base=0x804DF400
    raw=_respawn_platform_wrapper(base)
    calls=[x for x in _branches(base,raw) if x['link']]
    assert sum(x['target']==PLAYER_SET_SPAWN_PLATFORM_POS for x in calls)==1
