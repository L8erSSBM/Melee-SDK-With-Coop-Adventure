"""HF24 low-memory clear-screen captured-background fail-safe tests."""
import struct

import pytest

from sdk import clear_screen_failsafe as cf
from sdk.ppc import decode_branch, encode_branch

BASE = 0x804E6000
HF22 = 0x804E0500
COUNTER = 0x804E5F10
HEAP_DESC = 0x8065CC00
CELL_BASE = 0x81000000


def put(memory, address, value, size=4):
    for i, b in enumerate(int(value & ((1 << (size*8))-1)).to_bytes(size, 'big')):
        memory[address+i] = b


def get(memory, address, size=4):
    return int.from_bytes(bytes(memory.get(address+i, 0) for i in range(size)), 'big')


def heap(sizes=(), *, mode=4, state=0x23, guard=1, guard_addr=0x804E000F,
         current_heap=0, num_heaps=1):
    memory = {}
    put(memory, cf.ADVENTURE_MODE, mode, 1)
    put(memory, cf.ADVENTURE_STATE, state, 1)
    put(memory, guard_addr, guard, 1)
    put(memory, cf.CURRENT_HEAP, current_heap)
    put(memory, cf.NUM_HEAPS, num_heaps)
    put(memory, cf.HEAP_ARRAY, HEAP_DESC)
    put(memory, HEAP_DESC + 4, CELL_BASE if sizes else 0)
    for i, size in enumerate(sizes):
        addr = CELL_BASE + i * 0x20
        put(memory, addr + 0, 0)
        put(memory, addr + 4, CELL_BASE + (i+1)*0x20 if i+1 < len(sizes) else 0)
        put(memory, addr + 8, size)
    return memory


def execute(blob, memory, guard_addr, *, args=(0x80472D58,640,480,5,0), counter=0):
    regs = [0]*32
    regs[1] = 0x81700000
    for i, value in enumerate(args, 3): regs[i] = value & 0xFFFFFFFF
    put(memory, COUNTER, counter)
    pc = BASE
    relation = 0

    def signed16(v): return v - 0x10000 if v & 0x8000 else v
    def s32(v): return v - 0x100000000 if v & 0x80000000 else v
    def cr_bit_true(bi):
        if bi == 28: return relation < 0
        if bi == 29: return relation > 0
        if bi == 30: return relation == 0
        if bi == 31: return False
        raise AssertionError(f'unhandled CR bit {bi}')

    for _ in range(5000):
        if pc in (HF22, cf.BACKGROUND_CONTINUE):
            return pc, regs, memory
        if not BASE <= pc < BASE + len(blob):
            raise AssertionError(f'unexpected external branch {pc:#x}')
        word = struct.unpack_from('>I', blob, pc-BASE)[0]
        op = word >> 26
        rt=(word>>21)&31; ra=(word>>16)&31; rb=(word>>11)&31
        immu=word&0xFFFF; imm=signed16(immu); nxt=pc+4
        if op == 14:
            regs[rt]=((regs[ra] if ra else 0)+imm)&0xFFFFFFFF
        elif op == 15:
            regs[rt]=((regs[ra] if ra else 0)+(imm<<16))&0xFFFFFFFF
        elif op == 34:
            regs[rt]=get(memory,(regs[ra]+imm)&0xFFFFFFFF,1)
        elif op == 32:
            regs[rt]=get(memory,(regs[ra]+imm)&0xFFFFFFFF,4)
        elif op == 36:
            put(memory,(regs[ra]+imm)&0xFFFFFFFF,regs[rt])
        elif op == 37:  # stwu
            ea=(regs[ra]+imm)&0xFFFFFFFF
            put(memory,ea,regs[rt]); regs[ra]=ea
        elif op == 11:
            av,bv=s32(regs[ra]),imm; relation=-1 if av<bv else 1 if av>bv else 0
        elif op == 7:
            regs[rt]=(s32(regs[ra])*imm)&0xFFFFFFFF
        elif op == 16:
            bd=word&0xFFFC
            if bd&0x8000: bd-=0x10000
            bo,bi=(word>>21)&31,(word>>16)&31
            take=bo==20 or (bo==12 and cr_bit_true(bi)) or (bo==4 and not cr_bit_true(bi))
            if take: nxt=(pc+bd)&0xFFFFFFFF
        elif op == 18:
            nxt=decode_branch(pc,word.to_bytes(4,'big'))['target']
        elif op == 31:
            xo=(word>>1)&1023
            if xo==32:
                av,bv=regs[ra]&0xFFFFFFFF,regs[rb]&0xFFFFFFFF
                relation=-1 if av<bv else 1 if av>bv else 0
            elif xo==266:
                regs[rt]=(regs[ra]+regs[rb])&0xFFFFFFFF
            else: raise AssertionError(f'unsupported op31 xo={xo}')
        else:
            raise AssertionError(f'unsupported instruction {word:08x}')
        pc=nxt
    raise AssertionError('wrapper did not terminate')


def run(sizes=(), **kw):
    guard_addr=kw.pop('guard_addr',0x804E000F)
    mem=kw.pop('memory',None) or heap(sizes,guard_addr=guard_addr,
                                      mode=kw.pop('mode',4),state=kw.pop('state',0x23),
                                      guard=kw.pop('guard',1),
                                      current_heap=kw.pop('current_heap',0),
                                      num_heaps=kw.pop('num_heaps',1))
    blob=cf.wrapper(BASE,HF22,guard_addr,COUNTER)
    return execute(blob,mem,guard_addr,**kw)


def test_sufficient_contiguous_block_enters_hf22_with_original_args_and_stack():
    target,regs,memory=run([cf.MIN_CLEAR_BLOCK])
    assert target==HF22
    assert regs[1]==0x81700000
    assert tuple(regs[3:8])==(0x80472D58,640,480,5,0)
    assert get(memory,COUNTER)==0


def test_later_large_block_is_accepted():
    target,_,_=run([0x1000,0x2000,cf.MIN_CLEAR_BLOCK+0x1000])
    assert target==HF22


@pytest.mark.parametrize('sizes',[[],[32],[cf.MIN_CLEAR_BLOCK-1],[0x10000,0x20000]])
def test_insufficient_headroom_skips_only_background_setup(sizes):
    target,regs,memory=run(sizes)
    assert target==cf.BACKGROUND_CONTINUE
    assert regs[1]==0x81700000
    assert get(memory,COUNTER)==1


def test_skip_counter_saturates():
    target,_,memory=run([],counter=0xFFFFFFFF)
    assert target==cf.BACKGROUND_CONTINUE
    assert get(memory,COUNTER)==0xFFFFFFFF


@pytest.mark.parametrize('mode,state,guard,args',[ 
    (3,0x23,1,(0x80472D58,640,480,5,0)),
    (4,0x22,1,(0x80472D58,640,480,5,0)),
    (4,0x23,0,(0x80472D58,640,480,5,0)),
    (4,0x23,1,(0x80472D58,320,240,5,0)),
])
def test_unscoped_paths_preserve_hf22(mode,state,guard,args):
    target,regs,memory=run([],mode=mode,state=state,guard=guard,args=args)
    assert target==HF22
    assert tuple(regs[3:8])==args
    assert get(memory,COUNTER)==0


@pytest.mark.parametrize('heap_index',[1,0xFFFFFFFF])
def test_invalid_heap_index_fails_safe_to_background_skip(heap_index):
    target,_,_=run([cf.MIN_CLEAR_BLOCK],current_heap=heap_index,num_heaps=1)
    assert target==cf.BACKGROUND_CONTINUE


def test_invalid_freelist_pointer_fails_safe():
    mem=heap([],guard_addr=0x804E000F)
    put(mem,HEAP_DESC+4,0x81800000)
    target,_,_=run(memory=mem)
    assert target==cf.BACKGROUND_CONTINUE


def test_threshold_matches_hf22_allocation_plus_observed_overhead():
    assert cf.HF22_BUFFER_BYTES==153600
    assert cf.MIN_CLEAR_BLOCK==153632


def test_install_requires_the_existing_hf22_hook():
    class WrongDOL:
        def read_at_address(self,addr,size): return bytes(4)
    with pytest.raises(ValueError,match='expected HF22 allocation hook mismatch'):
        cf.install(WrongDOL(),8,0x804E000F,HF22)
