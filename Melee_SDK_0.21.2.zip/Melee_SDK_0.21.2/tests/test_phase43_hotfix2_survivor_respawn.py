from pathlib import Path

from sdk.adventure_probe import (
    _respawn_platform_wrapper,
    PLAYER_GET_STOCKS,
    PLAYER_GET_ENTITY,
    PLAYER_LOAD_COORDS,
    PLAYER_SET_SPAWN_PLATFORM_POS,
    GAME_CAMERA_OWNER_SLOT,
)
from sdk.ppc import decode_branch, li

ROOT=Path(__file__).resolve().parents[1]


def _words(raw):
    return [raw[i:i+4] for i in range(0, len(raw), 4)]


def _calls(base, raw):
    out=[]
    for i,w in enumerate(_words(raw)):
        if (int.from_bytes(w,'big') >> 26) == 18:
            d=decode_branch(base+i*4,w)
            if d['link']:
                out.append(d['target'])
    return out


def test_hf2_respawn_validates_partner_before_following():
    base=0x804DF400
    raw=_respawn_platform_wrapper(base, 0x804DF020)
    calls=_calls(base,raw)
    assert calls.count(PLAYER_GET_STOCKS) == 1
    assert calls.count(PLAYER_GET_ENTITY) == 1
    assert calls.count(PLAYER_LOAD_COORDS) == 1
    assert calls.count(PLAYER_SET_SPAWN_PLATFORM_POS) == 1


def test_hf2_wrapper_can_assign_control_to_partner_or_respawning_survivor():
    base=0x804DF400
    raw=_respawn_platform_wrapper(base, 0x804DF020)
    words=_words(raw)
    # Both slot constants must exist for candidate-partner selection and fallback
    # survivor ownership in either direction.
    assert li(11,0) in words
    assert li(11,1) in words
    assert GAME_CAMERA_OWNER_SLOT == 0x80452F2C


def test_hf2_root_exposes_only_current_build_and_gui_bats():
    root_bats=sorted(p.name for p in ROOT.glob('*.bat'))
    assert root_bats == ['BUILD_MELEE_SDK.bat', 'Launch_Melee_SDK.bat']
    reg=ROOT/'Regression Builds'
    assert (reg/'BUILD_COOP_TEST.bat').is_file()
    assert (reg/'BUILD_COOP_ADVENTURE_GATE_TEST.bat').is_file()
