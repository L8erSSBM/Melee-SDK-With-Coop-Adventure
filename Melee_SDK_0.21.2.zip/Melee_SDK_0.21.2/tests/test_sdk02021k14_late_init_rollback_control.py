from pathlib import Path

from sdk import slippi_adventure_netplay_bridge as nb


def test_k14_native_rollback_control_invariants():
    assert nb.ODB_DELAY_FRAMES == 0x021
    assert nb.SSCB_SSDB_COUNT == 0x01
    assert nb.MIN_DELAY_FRAMES == 1
    assert nb.ROLLBACK_MAX_FRAME_COUNT == 7
    assert nb.STATE_VERSION == 11


def test_k14_repairs_missing_init_values_on_pending_carrier_b0():
    src = Path(nb.__file__).read_text(encoding='utf-8')
    pending = src.index('# Pending carrier:')
    end = src.index("a.label('b0_active_check')", pending)
    block = src[pending:end]
    assert 'ODB_DELAY_FRAMES' in block
    assert 'SSCB_SSDB_COUNT' in block
    assert 'MIN_DELAY_FRAMES' in block
    assert 'ROLLBACK_MAX_FRAME_COUNT' in block
    assert 'stb(10, ODB_DELAY_FRAMES, 9)' in block
    assert 'stb(10, SSCB_SSDB_COUNT, 9)' in block
    # The repair precedes the actual carrier -> Adventure exit request.
    assert block.index('ODB_DELAY_FRAMES') < block.index('GM_SCENE_EXIT_FLAG_ADDR')


def test_k14_does_not_overwrite_valid_negotiated_values_unconditionally():
    src = Path(nb.__file__).read_text(encoding='utf-8')
    pending = src.index('# Pending carrier:')
    end = src.index("a.label('b0_active_check')", pending)
    block = src[pending:end]
    # Both repairs are explicitly zero-gated, preserving real negotiated values.
    assert block.count('cmpwi(10, 0, crf=7)') >= 2
    assert "a.label('delay_ready')" in block
    assert "a.label('sscb_ready')" in block


def test_package_revision_is_k14():
    root = Path(__file__).resolve().parents[1]
    assert "'sdk_version':'0.20.21K14'" in (root/'sdk/adventure_probe.py').read_text()
    assert "'package_revision':'0.20.21K14'" in (root/'sdk/iso_builder.py').read_text()
    assert '_MeleeSDK_0.20.21K14.iso' in (root/'BUILD_MELEE_SDK.bat').read_text()

from tests.hf29d_ppc import execute, get, put


def test_k14_emitted_first_carrier_b0_repairs_zero_delay_and_sscb_count():
    base = 0x804F9000
    state = 0x804F3A00
    pending = 0x804F3900
    active = 0x804F3901
    command = 0x804F3800
    mem = {}
    put(mem, state + nb.S_PHASE, nb.PHASE_TRANSITION, 1)
    put(mem, pending, 1, 1)
    put(mem, active, 0, 1)
    put(mem, command, nb.ONLINE_INPUTS, 1)
    put(mem, command + 1, 123, 4)
    put(mem, nb.STABLE_ODB + nb.ODB_DELAY_FRAMES, 0, 1)
    put(mem, nb.STABLE_SSCB + nb.SSCB_SSDB_COUNT, 0, 1)
    blob = nb.build_exi_wrapper(
        base, pending_addr=pending, active_addr=active, state_addr=state,
        patch_table_addr=0x804F8000)
    result = execute(
        blob, base, mem=mem, initial_regs={3: command, 13: 0x80400000},
        stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert result['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem, nb.STABLE_ODB + nb.ODB_DELAY_FRAMES, 1) == 1
    assert get(mem, nb.STABLE_SSCB + nb.SSCB_SSDB_COUNT, 1) == 7
    assert get(mem, nb.GM_SCENE_EXIT_FLAG_ADDR, 4) == 1


def test_k14_emitted_first_carrier_b0_preserves_nonzero_native_values():
    base = 0x804F9000
    state = 0x804F3A00
    pending = 0x804F3900
    active = 0x804F3901
    command = 0x804F3800
    mem = {}
    put(mem, state + nb.S_PHASE, nb.PHASE_TRANSITION, 1)
    put(mem, pending, 1, 1)
    put(mem, active, 0, 1)
    put(mem, command, nb.ONLINE_INPUTS, 1)
    put(mem, command + 1, 123, 4)
    put(mem, nb.STABLE_ODB + nb.ODB_DELAY_FRAMES, 2, 1)
    put(mem, nb.STABLE_SSCB + nb.SSCB_SSDB_COUNT, 7, 1)
    blob = nb.build_exi_wrapper(
        base, pending_addr=pending, active_addr=active, state_addr=state,
        patch_table_addr=0x804F8000)
    execute(blob, base, mem=mem, initial_regs={3: command, 13: 0x80400000},
            stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert get(mem, nb.STABLE_ODB + nb.ODB_DELAY_FRAMES, 1) == 2
    assert get(mem, nb.STABLE_SSCB + nb.SSCB_SSDB_COUNT, 1) == 7
