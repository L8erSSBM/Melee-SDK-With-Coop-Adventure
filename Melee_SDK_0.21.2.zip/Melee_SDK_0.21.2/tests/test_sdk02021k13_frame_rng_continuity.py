from pathlib import Path
from sdk import slippi_adventure_netplay_bridge as nb


def test_k13_frame_and_rng_contract_constants():
    assert nb.ODB_FRAME == 0x003
    assert nb.ODB_RNG_OFFSET == 0x007
    assert nb.GLOBAL_FRAME_ADDR == 0x80479D60
    assert nb.RNG_SEED_ADDR == 0x804D5F90
    # Structure layout did not change; retain compatibility version.
    assert nb.STATE_VERSION == 11


def test_k13_bridge_contains_one_time_frame_rebase_and_native_rng_formula():
    src = Path(nb.__file__).read_text()
    assert 'K13 paired-save repair' in src
    assert 'Recreate Slippi\'s native FN_SyncRNG formula' in src
    assert '_load_be_u32_unaligned(a, 10, 9, ODB_FRAME' in src
    assert '_load_be_u32_unaligned(a, 11, 9, ODB_RNG_OFFSET' in src
    assert '_rlwinm(10, 10, 16, 0, 31)' in src
    assert '_short_base_and_disp(GLOBAL_FRAME_ADDR)' in src
    assert '_short_base_and_disp(RNG_SEED_ADDR)' in src


def test_package_revision_is_k13():
    root = Path(__file__).resolve().parents[1]
    probe = (root/'sdk/adventure_probe.py').read_text()
    iso = (root/'sdk/iso_builder.py').read_text()
    bat = (root/'BUILD_MELEE_SDK.bat').read_text()
    assert "'sdk_version':'0.20.21K14'" in probe
    assert "'package_revision':'0.20.21K14'" in iso
    assert '_MeleeSDK_0.20.21K14.iso' in bat
