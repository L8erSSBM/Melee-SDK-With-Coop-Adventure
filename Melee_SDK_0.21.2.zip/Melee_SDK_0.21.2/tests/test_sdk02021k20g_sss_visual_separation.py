from pathlib import Path

import sdk.sss_visual_qol as q

ROOT = Path(__file__).resolve().parents[1]
ASSETS = ROOT / 'assets' / 'sss_qol'


def test_k20g_title_and_navigation_are_separate_assets():
    title = q._load_png_rgba(ASSETS / 'coop_adventure_title_only.png')
    footer = q._load_png_rgba(ASSETS / 'sss_nav_footer.png')
    assert title.width >= 224 and title.height >= 56
    assert footer.width > footer.height * 8
    # Both are visibly populated and independent PNGs.
    assert sum(px[3] > 32 for px in title.pixels) > 1000
    assert sum(px[3] > 32 for px in footer.pixels) > 500


def test_k20g_c8_icon_replaces_indices_and_full_palette():
    icon = q._load_png_rgba(ASSETS / 'coop_adventure_icon_128.png')
    indices, palette = q._encode_c8_rgb332(icon, 48, 48)
    assert len(indices) == 48 * 48
    assert len(palette) == 256 * 2
    assert len(set(indices)) > 32
    assert len(set(palette[i:i+2] for i in range(0, len(palette), 2))) > 200
