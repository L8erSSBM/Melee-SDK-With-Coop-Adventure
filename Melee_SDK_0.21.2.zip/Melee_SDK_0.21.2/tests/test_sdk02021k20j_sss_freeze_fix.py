from pathlib import Path

from sdk import slippi_coop_stage_page as sp
from sdk import sss_visual_qol as q

ROOT=Path(__file__).resolve().parents[1]
ASSETS=ROOT/'assets'/'sss_qol'


def _bounds(im):
    pts=[(i%im.width,i//im.width) for i,p in enumerate(im.pixels) if p[3]>64]
    return min(x for x,_ in pts),min(y for _,y in pts),max(x for x,_ in pts),max(y for _,y in pts)


def test_k20j_snapshot_storage_cannot_overlap_injected_code():
    # x8 snapshot: 0x10..0x2D; StKind snapshot: 0x30..0x4D.
    assert sp.S_X8_SNAPSHOT + sp.STAGE_ROW_COUNT <= sp.S_STKIND_SNAPSHOT
    assert sp.STATE_SNAPSHOT_END == 0x4E
    assert sp.STATE_SIZE >= 0x4E
    assert sp.STATE_SIZE == 0x50


def test_k20j_footer_art_has_one_pixel_top_margin():
    down=q._load_png_rgba(ASSETS/'sss_nav_default_down.png')
    up=q._load_png_rgba(ASSETS/'sss_nav_page2_up.png')
    assert down.size==(232,16) and up.size==(232,16)
    assert _bounds(down)[1] >= 1
    assert _bounds(up)[1] >= 1
    assert _bounds(down)[3] <= 15
    assert _bounds(up)[3] <= 15
