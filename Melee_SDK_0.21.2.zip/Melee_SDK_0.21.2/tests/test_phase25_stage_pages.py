from __future__ import annotations

import json
from pathlib import Path
from types import SimpleNamespace

from sdk.stage_select_pages import (
    StagePageEntry, StagePage, StagePageSet, build_project_page_set,
    runtime_plan, inspect_sss_menu, MAX_VISIBLE_SLOTS, PAD_DPAD_UP, PAD_DPAD_DOWN,
)


def test_page_roundtrip():
    s=StagePageSet([
        StagePage('retail','Retail',builtin_retail=True),
        StagePage('custom','Custom',[StagePageEntry('s:a','A','stage',stage_filename='GrXa.dat'), StagePageEntry('m:c','Co-op','mode',mode_id='coop_adventure')])
    ])
    raw=s.to_dict(); assert raw['page_up_mask']==PAD_DPAD_UP and raw['page_down_mask']==PAD_DPAD_DOWN
    r=StagePageSet.from_dict(raw); assert r.pages[1].entries[1].mode_id=='coop_adventure'


def test_max_29_slots():
    p=StagePage('x','X',[StagePageEntry(f's:{i}',str(i),'stage',stage_filename=f'Gr{i}.dat') for i in range(MAX_VISIBLE_SLOTS)])
    p.validate()


def test_project_builder_custom_and_modes(tmp_path):
    manifest={'resources':[
        {'filename':'GrNBa.dat','source_relative':'GrNBa.dat'},
        {'filename':'GrXz.dat','source_relative':'<authored from GrNBa.dat>','authored_new':True},
        {'filename':'GrAb.dat','source_relative':'<imported stage package mod.zip>','authored_new':True},
    ],'runtime_authoring':{'stage_slot':{'filename':'GrXz.dat'}}}
    project=SimpleNamespace(manifest=manifest, stages=[
        SimpleNamespace(filename='GrNBa.dat',display_name='Battlefield'),
        SimpleNamespace(filename='GrXz.dat',display_name='X Zone'),
        SimpleNamespace(filename='GrAb.dat',display_name='AB'),
    ])
    pages=build_project_page_set(project)
    assert pages.pages[0].builtin_retail
    c=pages.pages[1].entries
    assert any(e.stage_filename=='GrXz.dat' and e.stkind==0x15 for e in c)
    assert any(e.stage_filename=='GrAb.dat' and e.stkind is None for e in c)
    assert any(e.mode_id=='coop_adventure' for e in c)


def test_runtime_plan_virtual_and_modes():
    s=StagePageSet([StagePage('retail','Retail',builtin_retail=True),StagePage('custom','Custom',[
        StagePageEntry('s:a','A','stage',stage_filename='GrXa.dat'),
        StagePageEntry('m:c','Co-op','mode',mode_id='coop_adventure')])])
    p=runtime_plan(s)
    assert p['source_facts']['stage_table_rows']==30
    assert p['source_facts']['visible_stage_rows']==29
    assert p['virtual_stage_bridge']['entries'][0]['filename']=='GrXa.dat'
    assert p['mode_launchers'][0]['mode_id']=='coop_adventure'


def test_real_mnslmap_if_available():
    candidates=[Path('/mnt/data/p25menu/Melee_Game_And_Menu/MnSlMap.dat'),Path('/mnt/data/p25menu/Melee_Game_And_Menu/MnSlMap.usd')]
    path=next((p for p in candidates if p.exists()),None)
    if path is None:return
    r=inspect_sss_menu(path)
    assert r['model_count']==12
    assert r['visible_stage_slots']==29

def test_project_builder_spills_to_more_pages():
    resources=[]; stages=[]
    for i in range(60):
        fn=f'GrX{i:02d}.dat'; resources.append({'filename':fn,'source_relative':'<authored>','authored_new':True}); stages.append(SimpleNamespace(filename=fn,display_name=f'Custom {i}'))
    project=SimpleNamespace(manifest={'resources':resources},stages=stages)
    pages=build_project_page_set(project)
    assert len(pages.pages) >= 4
    assert sum(1 for p in pages.pages for e in p.entries if e.kind=='stage') == 60
    assert all(len(p.entries) <= 29 for p in pages.pages)
