from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import encode_branch
from sdk import slippi_memory_layout as ml
from sdk import slippi_adventure_netplay_bridge as nb
from sdk import slippi_coop_stage_page as sp
from sdk import slippi_direct_gateway as dg
from sdk.adventure_probe import (
    SCENE_EXIT_REQUEST_HOOK, SCENE_EXIT_REQUEST_ALT_HOOK, SCENE_LOOP_HOOK,
    VS_SCENE_EXIT_HOOK, SCENE_INIT_HOOK, RESULTS_SCENE_ENTER_HOOK,
)
from tests.hf29d_ppc import execute, get, put, SENTINEL

ROOT = Path(__file__).resolve().parents[1]
R13 = 0x80400000


def _install_current_low_components(dol: DOLImage):
    idx = 8
    pending=0x804F1000; active=0x804F1001
    p2=0x804F1007; p1=0x804F100B
    canonical=0x804F1010
    bridge = nb.install(
        dol, idx, gateway_pending_addr=pending, gateway_active_addr=active,
        canonical_valid_addr=canonical, canonical_local_addr=canonical+1,
        canonical_remote_addr=canonical+2)
    page = sp.install(
        dol, idx,
        canonical_valid_addr=canonical, canonical_local_addr=canonical+1,
        canonical_remote_addr=canonical+2, canonical_trace_addr=canonical+3,
        p1_ckind_addr=p1, p1_color_addr=p1+1,
        p1_subcolor_addr=p1+2, p1_nametag_addr=p1+3,
        p2_ckind_addr=p2, p2_color_addr=p2+1,
        p2_subcolor_addr=p2+2, p2_nametag_addr=p2+3)
    direct = dg.install(
        dol, idx, gateway_pending_addr=pending,
        p1_ckind_addr=p1, p1_color_addr=p1+1,
        p1_subcolor_addr=p1+2, p1_nametag_addr=p1+3,
        p2_identity_valid_addr=0x804F1006,
        p2_ckind_addr=p2, p2_color_addr=p2+1,
        p2_subcolor_addr=p2+2, p2_nametag_addr=p2+3,
        netplay_arm_addr=bridge['arm_stub'], canonical_valid_addr=canonical,
        canonical_players_addr=page['canonical_players_address'])
    return bridge, page, direct


def test_02021e_current_components_fit_original_16k_low_runtime():
    dol = DOLImage(ROOT / 'Build' / 'start.dol')
    bridge, page, direct = _install_current_low_components(dol)

    # start.dol carries an older SDK ArenaLo wrapper. A clean ISO has the retail
    # calls here, so restore those callsites before validating the current
    # reservation installer.
    for site in ml.OS_INIT_ARENA_LO_CALLS:
        cur = dol.read_at_address(site, 4)
        retail = encode_branch(site, ml.OS_SET_ARENA_LO, link=True)
        dol.patch_at_address(site, retail, expected=cur)

    hi_before = dol.read_at_address(ml.OS_INIT_ARENA_HI_CALL, 4)
    layout = ml.install_arena_reservation(dol, 8)
    sec = next(s for s in dol.sections if s.kind == 'data' and s.index == 8)

    assert bridge['section']['address'] >= ml.SDK_RUNTIME_BASE
    assert page['section']['address'] >= bridge['section']['address']
    assert direct['state_address'] >= page['section']['address']
    assert sec.end_address <= ml.SDK_RUNTIME_LIMIT
    assert layout['runtime_end'] <= ml.SDK_RUNTIME_LIMIT
    assert ml.SDK_RUNTIME_LIMIT - layout['runtime_end'] >= 0x1A0

    # The packaged start.dol fixture is 0x160 bytes leaner than the real clean-ISO
    # path observed in BUILD_MELEE_SDK(6).log. Keep >=0x1C0 fixture headroom so
    # a clean ISO still retains at least 0x60 bytes before the 16 KiB ceiling.

    # 0.20.21D's boot-loaded high DOL section and ArenaHi clamp are gone.
    assert all(s.address < ml.SDK_SESSION_HIGH_BASE for s in dol.sections)
    assert dol.read_at_address(ml.OS_INIT_ARENA_HI_CALL, 4) == hi_before
    assert hi_before == encode_branch(ml.OS_INIT_ARENA_HI_CALL, ml.OS_SET_ARENA_HI, link=True)


def test_retired_hf21_scene_trace_sites_remain_retail_in_proven_start_fixture():
    dol = DOLImage(ROOT / 'Build' / 'start.dol')
    expected = {
        SCENE_EXIT_REQUEST_HOOK: bytes.fromhex('3c608048'),
        SCENE_EXIT_REQUEST_ALT_HOOK: bytes.fromhex('3c608048'),
        SCENE_LOOP_HOOK: bytes.fromhex('7c0802a6'),
        VS_SCENE_EXIT_HOOK: bytes.fromhex('7c0802a6'),
        SCENE_INIT_HOOK: bytes.fromhex('7c0802a6'),
        RESULTS_SCENE_ENTER_HOOK: bytes.fromhex('7c0802a6'),
    }
    for site, word in expected.items():
        assert dol.read_at_address(site, 4) == word


def test_probe_reclaims_only_retired_hf21_payload_and_uses_no_high_code_anchor():
    src = (ROOT / 'sdk' / 'adventure_probe.py').read_text(encoding='utf-8')
    assert "hook != SCENE_EXIT_REQUEST_HOOK" in src
    assert 'install_high_code_anchor' not in src
    assert 'validate_high_code_section' not in src
    arena = src.index('slippi_memory_layout = install_arena_reservation')
    bridge = src.index('slippi_adventure_netplay_bridge = install_slippi_adventure_netplay_bridge')
    page = src.index('slippi_coop_stage_page = install_slippi_coop_stage_page')
    direct = src.index('slippi_direct_gateway = install_slippi_direct_gateway')
    assert bridge < page < direct < arena


def test_memfree_high_range_is_retail_until_direct_session_scope_arms():
    base = 0x804F7000
    state = 0x804F6800
    blob = nb.build_free_wrapper(base, pending_addr=0x804F6700,
                                 active_addr=0x804F6701, state_addr=state)
    mem = {}
    put(mem, state + nb.S_SESSION_SCOPE, 0, 1)
    put(mem, state + nb.S_ODB, nb.STABLE_ODB, 4)
    r = execute(blob, base, mem=mem, initial_regs={3: nb.STABLE_ODB},
                stop_targets={nb.HSD_MEM_FREE + 4})
    assert r['target'] == nb.HSD_MEM_FREE + 4
    assert get(mem, state + nb.S_FREE_SKIP_COUNT, 4) == 0


def test_k6_arm_reserves_arena_hi_and_cleanup_restores_guards():
    base = 0x804F7000; state = 0x804F6800; table_addr = 0x804F7A00
    txrx_blob_addr = 0x804F7B00; ss_blob_addr = 0x804F7B08; meta_blob_addr = 0x804F7B10
    snap_table_addr = 0x804F7C00; pending = 0x804F6700; active = 0x804F6701
    odb, txb, rxb, ssrb, sscb = 0x80BF3960, 0x80BF4680, 0x80BF46C0, 0x80BF4820, 0x80BF4880
    exi = 0x804FB000
    table = nb.build_patch_table(exi_wrapper_addr=exi)
    blob = nb.build_arm_stub(base, state_addr=state, guard_shims={}, exi_wrapper_addr=exi,
                             patch_table_addr=table_addr, txrx_blob_addr=txrx_blob_addr,
                             ss_blob_addr=ss_blob_addr, ssrb_meta_blob_addr=meta_blob_addr)
    mem={}
    for i,b in enumerate(table): mem[table_addr+i]=b
    snap=nb.build_snapshot_table()
    for i,b in enumerate(snap): mem[snap_table_addr+i]=b
    for i,b in enumerate(nb.STABLE_TXB.to_bytes(4,'big')+nb.STABLE_RXB.to_bytes(4,'big')): mem[txrx_blob_addr+i]=b
    for i,b in enumerate(nb.STABLE_SSRB.to_bytes(4,'big')+nb.STABLE_SSCB.to_bytes(4,'big')): mem[ss_blob_addr+i]=b
    meta=(nb.STABLE_ODB.to_bytes(4,'big')+nb.ODB_SIZE.to_bytes(4,'big')+
          nb.STABLE_RXB.to_bytes(4,'big')+nb.RXB_SIZE.to_bytes(4,'big')+
          nb.STABLE_SSCB.to_bytes(4,'big')+nb.SSCB_SIZE.to_bytes(4,'big'))
    for i,b in enumerate(meta): mem[meta_blob_addr+i]=b
    put(mem,(R13+nb.OFST_R13_ODB_ADDR)&0xffffffff,odb,4)
    for ptr,size,seed in ((odb,nb.ODB_SIZE,0x11),(txb,nb.TXB_SIZE,0x22),(rxb,nb.RXB_SIZE,0x33),(ssrb,nb.SSRB_SIZE,0x44),(sscb,nb.SSCB_SIZE,0x55)):
        for i in range(size): mem[ptr+i]=(seed+i*7)&0xff
    put(mem,odb+nb.ODB_LOCAL_PLAYER_INDEX,0,1); put(mem,odb+nb.ODB_ONLINE_PLAYER_INDEX,0,1); put(mem,odb+nb.ODB_INPUT_SOURCE_INDEX,0,1)
    put(mem,odb+nb.ODB_TXB_ADDR,txb,4); put(mem,odb+nb.ODB_RXB_ADDR,rxb,4); put(mem,odb+nb.ODB_SSRB_ADDR,ssrb,4); put(mem,odb+nb.ODB_SSCB_ADDR,sscb,4)
    for spec in nb.GUARDS: put(mem,spec.site,int.from_bytes(spec.expected,'big'),4)
    put(mem,nb.SLIPPI_EXI_VENEER,int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED,'big'),4)
    original_hi=0x81829800
    put(mem,(R13+nb.OFST_R13_ARENA_HI)&0xffffffff,original_hi,4)

    r=execute(blob,base,mem=mem,initial_regs={13:R13})
    assert r['regs'][3] == 1
    assert get(mem,state+nb.S_ORIG_ARENA_HI,4) == original_hi
    assert get(mem,(R13+nb.OFST_R13_ARENA_HI)&0xffffffff,4) == nb.SESSION_HIGH_BASE
    assert get(mem,state+nb.S_PHASE,1) == nb.PHASE_TRANSITION

    exi_blob=nb.build_exi_wrapper(0x804FC000,pending_addr=pending,active_addr=active,state_addr=state,
                                  snapshot_table_addr=snap_table_addr,patch_table_addr=table_addr)
    cmd=0x81201000; put(mem,pending,0,1); put(mem,active,0,1); put(mem,cmd,nb.CLEANUP_CONNECTIONS,1)
    rr=execute(exi_blob,0x804FC000,mem=mem,initial_regs={3:cmd,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert rr['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem,state+nb.S_PHASE,1) == nb.PHASE_OFF
    assert get(mem,state+nb.S_ORIG_ARENA_HI,4) == original_hi
    assert get(mem,(R13+nb.OFST_R13_ARENA_HI)&0xffffffff,4) == original_hi
    assert all(get(mem,g.site,4) == int.from_bytes(g.expected,'big') for g in nb.GUARDS)

def _seed_k4_exi_state(mem, state, *, local=0):
    put(mem,state+nb.S_PHASE,nb.PHASE_TRANSITION,1)
    put(mem,state+nb.S_ODB,nb.STABLE_ODB,4)
    put(mem,state+nb.S_LOCAL_INDEX,local,1)
    put(mem,state+nb.S_ARM_ONLINE_INDEX,1-local,1)
    put(mem,state+nb.S_ARM_INPUT_SOURCE_INDEX,0,1)
    put(mem,state+nb.S_TXB,nb.STABLE_TXB,4); put(mem,state+nb.S_RXB,nb.STABLE_RXB,4)
    put(mem,state+nb.S_SSRB,nb.STABLE_SSRB,4); put(mem,state+nb.S_SSCB,nb.STABLE_SSCB,4)


def test_k8_b0_does_not_mutate_guest_heap_boundary_in_carrier():
    base=0x804FC000; state=0x804F6800; pending=0x804F6700; active=0x804F6701
    blob=nb.build_exi_wrapper(base,pending_addr=pending,active_addr=active,state_addr=state,
                              patch_table_addr=0x804FD100)
    mem={}; _seed_k4_exi_state(mem,state)
    cmd=0x81201000; put(mem,cmd,nb.ONLINE_INPUTS,1); put(mem,cmd+1,1,4)
    put(mem,pending,1,1); put(mem,active,0,1)
    carrier_end=0x811DE400; put(mem,nb.MAIN_HEAP_END_ADDR,carrier_end,4)
    r=execute(blob,base,mem=mem,initial_regs={3:cmd,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert r['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem,nb.MAIN_HEAP_END_ADDR,4) == carrier_end


def test_k10_first_adventure_b0_preserves_native_rollback_state_and_adventure_scene():
    base=0x804FC000; state=0x804F6800; pending=0x804F6700; active=0x804F6701
    blob=nb.build_exi_wrapper(base,pending_addr=pending,active_addr=active,state_addr=state,
                              patch_table_addr=0x804FD100)
    mem={}; _seed_k4_exi_state(mem,state,local=1)
    for i in range(0xDF,0x3A0): put(mem,nb.STABLE_ODB+i,(0xA5+i)&0xff,1)
    for i in range(nb.SSCB_SIZE): put(mem,nb.STABLE_SSCB+i,(0x5A+i)&0xff,1)
    odb_before=bytes(get(mem,nb.STABLE_ODB+i,1) for i in range(0xDF,0x3A0))
    sscb_before=bytes(get(mem,nb.STABLE_SSCB+i,1) for i in range(nb.SSCB_SIZE))
    original_scene=0x04000002; put(mem,nb.GM_SCENE_WORD_ADDR,original_scene,4)
    cmd=0x81201000; put(mem,cmd,nb.ONLINE_INPUTS,1); put(mem,cmd+1,90,4)
    put(mem,pending,0,1); put(mem,active,1,1)
    real_adventure_end=0x817F7000; put(mem,nb.MAIN_HEAP_END_ADDR,real_adventure_end,4)
    r=execute(blob,base,mem=mem,initial_regs={3:cmd,13:R13},stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert r['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem,nb.MAIN_HEAP_END_ADDR,4) == real_adventure_end
    assert get(mem,state+nb.S_PHASE,1) == nb.PHASE_FULL
    assert get(mem,state+nb.S_TRANSITION_RESET_COUNT,4) == 1
    assert bytes(get(mem,nb.STABLE_ODB+i,1) for i in range(0xDF,0x3A0)) == odb_before
    assert bytes(get(mem,nb.STABLE_SSCB+i,1) for i in range(nb.SSCB_SIZE)) == sscb_before
    assert get(mem,nb.GM_SCENE_WORD_ADDR,4) == original_scene
    assert get(mem,state+nb.S_SCENE_SHADOW_ACTIVE,1) == 0

def test_package_revision_retains_02021e_layout_in_02021f():
    probe = (ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    iso = (ROOT/'sdk'/'iso_builder.py').read_text(encoding='utf-8')
    bat = (ROOT/'BUILD_MELEE_SDK.bat').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.21K13'" in probe
    assert "'package_revision':'0.20.21K13'" in iso
    assert '_MeleeSDK_0.20.21K13.iso' in bat


def test_sdk_low_bridge_state_is_outside_slippi_rollback_memory_regions():
    # Current SlippiSavestate.cpp fixed regions end Melee data/BSS at 0x804DEC00
    # and resume at 0x8065C000; its dynamic main-heap region is high MEM1.
    # Keeping SDK phase/telemetry in this gap is intentional: a B2 gameplay
    # rewind must not roll PHASE_FULL back to WARMUP or undo EXI diagnostics.
    assert ml.SDK_RUNTIME_BASE >= 0x804DEC00
    assert ml.SDK_RUNTIME_LIMIT <= 0x8065C000
