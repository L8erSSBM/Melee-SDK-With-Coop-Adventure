"""Execute K15 PPC helpers. These tests do not substitute for peer testing."""
from sdk import slippi_engine_repair as er
from sdk import slippi_adventure_netplay_bridge as nb
from tests.hf29d_ppc import execute, put, get, SENTINEL
import pytest
BASE=0x804F7000
STATE=0x804F3800
R13=0x804DB6A0

def run(fn, mem, regs=None, **kw):
    return execute(fn(BASE,STATE,nb),BASE,mem=mem,initial_regs={1:0x804E0000,**(regs or {})},**kw)

@pytest.mark.parametrize('depth,batch_count',[(1,1),(3,3),(3,2),(5,4)])
def test_input_batch_clock_uses_locked_queue_not_scene_timer(depth,batch_count):
    mem={};put(mem,nb.STABLE_ODB+3,4083);put(mem,0x804C1F7B,depth,1)
    put(mem,nb.GLOBAL_FRAME_ADDR,4122)
    run(er.batch,mem,{4:4080,5:nb.STABLE_ODB,27:batch_count},stop_targets={er.BATCH_SITE+4})
    assert get(mem,STATE+nb.S_BATCH_FRAME)==4083-depth
    for index in range(batch_count):
        result=run(er.start,mem,{26:index,30:nb.STABLE_ODB},stop_targets={0x806667CC})
        assert result['regs'][31]==4083-depth+index
        assert get(mem,nb.STABLE_ODB+er.ODB_SIM_MIRROR)==4083-depth+index
    assert get(mem,nb.GLOBAL_FRAME_ADDR)==4122

def test_rollback_replay_preserves_restored_clock_then_advances_once():
    mem={};put(mem,STATE+nb.S_SIM_FRAME,4080);put(mem,STATE+nb.S_BATCH_FRAME,9999)
    put(mem,nb.STABLE_ODB+0xABF,1,1)
    for frame in range(4080,4083):
        r=run(er.start,mem,{26:0,30:nb.STABLE_ODB},stop_targets={0x806667CC})
        assert r['regs'][31]==frame
        r=run(er.end,mem,{31:nb.STABLE_ODB},stop_targets={0x80666194})
        assert r['regs'][24]-1==frame
        assert get(mem,STATE+nb.S_SIM_FRAME)==frame+1

@pytest.mark.parametrize('phase',[0,1,3])
def test_rng_repeats_for_same_simulation_frame_without_b0(phase):
    mem={};put(mem,STATE+nb.S_PHASE,phase,1);put(mem,STATE+nb.S_SIM_FRAME,4080)
    put(mem,nb.STABLE_ODB+7,0x12345678);put(mem,nb.RNG_SEED_ADDR,0x55)
    run(er.rng,mem,stop_targets={0x80390D00})
    expected=((4080<<16)+0x12345678)&0xFFFFFFFF if phase else 0x55
    assert get(mem,nb.RNG_SEED_ADDR)==expected
    if phase:
        put(mem,nb.RNG_SEED_ADDR,0xDEADBEEF)
        run(er.rng,mem,stop_targets={0x80390D00})
        assert get(mem,nb.RNG_SEED_ADDR)==expected

@pytest.mark.parametrize('upper',[0x81700000,0x81829800])
def test_allocator_receives_reserved_upper_bound(upper):
    mem={};put(mem,R13-0x3FE8,0x8071B000);put(mem,R13-0x3FE4,upper)
    execute(er.heap(BASE,nb),BASE,mem=mem,initial_regs={13:R13,3:0x100,4:0x104})
    assert get(mem,0x100)==0x8071B000
    assert get(mem,0x104)==min(upper,nb.FULL_ROLLBACK_HEAP_END)

@pytest.mark.parametrize('frame,command',[(1,0xB0),(2,0xB0),(1,0xB1)])
def test_host_map_prime_restores_actual_heap_bounds(frame,command):
    mem={};put(mem,0x100,command,1);put(mem,0x101,frame)
    put(mem,nb.MAIN_HEAP_END_ADDR-4,0x80B00000);put(mem,nb.MAIN_HEAP_END_ADDR,0x80D00000)
    observed=[]
    def native(regs,mem):
        observed.append((get(mem,nb.MAIN_HEAP_END_ADDR-4),get(mem,nb.MAIN_HEAP_END_ADDR)))
    execute(er.prime(BASE,nb),BASE,mem=mem,initial_regs={1:0x804E0000,3:0x100,4:0x1A,5:1},callees={nb.SLIPPI_EXI_TRANSFER:native})
    assert observed==[(nb.FULL_ROLLBACK_HEAP_START,nb.FULL_ROLLBACK_HEAP_END) if command==0xB0 and frame==1 else (0x80B00000,0x80D00000)]
    assert get(mem,nb.MAIN_HEAP_END_ADDR-4)==0x80B00000
    assert get(mem,nb.MAIN_HEAP_END_ADDR)==0x80D00000

@pytest.mark.parametrize('slot',range(7))
def test_sdk_snapshot_restores_simulation_but_keeps_transport_live(slot):
    mem={}; frame=4080+slot; ptr=nb.STABLE_SSRB
    for i in range(7):put(mem,nb.STABLE_SSCB+2+i*4,4080+i)
    put(mem,nb.STABLE_SSCB,(slot+1)%7,1)
    put(mem,ptr,0xB1,1);put(mem,ptr+1,frame)
    put(mem,STATE+nb.S_SIM_FRAME,frame);put(mem,STATE+nb.S_BATCH_FRAME,9000)
    put(mem,STATE+nb.S_B0_COUNT,11);put(mem,nb.SDK_RUNTIME_BASE+0x90,0x12345678)
    calls=[]
    def native(regs,mem):
        calls.append(get(mem,regs[3],1))
        if calls[-1]==0xB2:
            # Model host restore happening BEFORE the missing low SDK state is restored.
            put(mem,nb.SDK_RUNTIME_BASE+0x90,0xEEEEEEEE)
    opts=dict(callees={nb.SLIPPI_EXI_TRANSFER:native},max_steps=100000)
    run(er.snapshot,mem,{3:ptr,4:0x21,5:1},**opts)
    put(mem,nb.SDK_RUNTIME_BASE+0x90,0xBAD);put(mem,STATE+nb.S_SIM_FRAME,9999)
    put(mem,STATE+nb.S_BATCH_FRAME,9001);put(mem,STATE+nb.S_B0_COUNT,12)
    put(mem,ptr,0xB2,1)
    run(er.snapshot,mem,{3:ptr,4:0x21,5:1},**opts)
    assert calls==[0xB1,0xB2]
    assert get(mem,nb.SDK_RUNTIME_BASE+0x90)==0x12345678
    assert get(mem,STATE+nb.S_SIM_FRAME)==frame
    assert get(mem,nb.STABLE_ODB+er.ODB_SIM_MIRROR)==frame
    assert get(mem,STATE+nb.S_BATCH_FRAME)==9001
    assert get(mem,STATE+nb.S_B0_COUNT)==12
    assert nb.SDK_SNAPSHOT_BASE+7*nb.SDK_RUNTIME_SIZE<=nb.SESSION_HIGH_BASE


def test_duplicate_frame_tags_restore_the_newest_native_slot():
    mem={};ptr=nb.STABLE_SSRB;frame=4080
    put(mem,nb.STABLE_SSCB,5,1)
    put(mem,nb.STABLE_SSCB+2,frame)
    put(mem,nb.STABLE_SSCB+2+4*4,frame)
    put(mem,ptr,0xB1,1);put(mem,ptr+1,frame)
    put(mem,nb.SDK_RUNTIME_BASE+0x90,0x12345678)
    def native(regs,mem): pass
    opts=dict(callees={nb.SLIPPI_EXI_TRANSFER:native},max_steps=100000)
    run(er.snapshot,mem,{3:ptr,4:0x21,5:1},**opts)
    assert get(mem,nb.SDK_SNAPSHOT_BASE+4*nb.SDK_RUNTIME_SIZE+0x90)==0x12345678
    assert get(mem,nb.SDK_SNAPSHOT_BASE+0x90)==0
    put(mem,ptr,0xB2,1);put(mem,nb.SDK_RUNTIME_BASE+0x90,0xBAD)
    run(er.snapshot,mem,{3:ptr,4:0x21,5:1},**opts)
    assert get(mem,nb.SDK_RUNTIME_BASE+0x90)==0x12345678

def test_real_installer_layout_arms_and_relocates_without_fixture_overlap():
    from pathlib import Path
    from sdk.dol_patch import DOLImage
    from tests.test_sdk02021k10_canonical_direct_mapping import _seed_arm, R13 as ARM_R13
    root=Path(__file__).resolve().parents[1]
    dol=DOLImage(root/'Build'/'start.dol')
    bridge=nb.install(dol,8,gateway_pending_addr=0x804F1000,gateway_active_addr=0x804F1001)
    sec=next(s for s in dol.sections if s.kind=='data' and s.index==8)
    mem={sec.address+i:b for i,b in enumerate(dol.read_at_address(sec.address,sec.size))}
    table=dol.read_at_address(bridge['patch_table'],bridge['patch_table_size'])
    _seed_arm(mem,state=bridge['state_address'],table_addr=bridge['patch_table'],table=table)
    blob=dol.read_at_address(bridge['arm_stub'],sec.end_address-bridge['arm_stub'])
    r=execute(blob,bridge['arm_stub'],mem=mem,initial_regs={13:ARM_R13})
    assert r['regs'][3]==1
    assert get(mem,(ARM_R13+nb.OFST_R13_ODB_ADDR)&0xFFFFFFFF)==nb.STABLE_ODB
    assert get(mem,nb.STABLE_ODB+nb.ODB_TXB_ADDR)==nb.STABLE_TXB
    assert get(mem,nb.STABLE_ODB+nb.ODB_SSCB_ADDR)==nb.STABLE_SSCB
    for row in range(0,len(table),12):
        site=int.from_bytes(table[row:row+4],'big')
        installed=int.from_bytes(table[row+8:row+12],'big')
        assert get(mem,site)==installed
