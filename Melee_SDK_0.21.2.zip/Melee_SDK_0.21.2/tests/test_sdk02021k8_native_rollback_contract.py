from sdk import slippi_adventure_netplay_bridge as nb
from tests.hf29d_ppc import execute, get, put

R13 = 0x80400000
BASE = 0x804FC000
STATE = 0x804F6800
PENDING = 0x804F6700
ACTIVE = 0x804F6701
PATCH_TABLE = 0x804FD100


def _seed_scope(mem):
    put(mem, STATE + nb.S_PHASE, nb.PHASE_FULL, 1)
    put(mem, STATE + nb.S_LOCAL_INDEX, 0, 1)
    put(mem, STATE + nb.S_ARM_ONLINE_INDEX, 1, 1)
    put(mem, STATE + nb.S_ARM_INPUT_SOURCE_INDEX, 0, 1)
    put(mem, PENDING, 0, 1)
    put(mem, ACTIVE, 1, 1)


def test_k8_heap_ceiling_is_inside_mem1_and_excludes_session_island():
    assert nb.FULL_ROLLBACK_HEAP_END == nb.SESSION_HIGH_BASE == 0x817FE000
    assert nb.FULL_ROLLBACK_HEAP_END < nb.SESSION_HIGH_LIMIT == 0x81800000


def test_k8_auxiliary_sites_are_sound_team_not_savestate_gates():
    assert [g.name for g in nb.AUX_SCENE_GUARDS] == [
        'sound_assign_instance_id',
        'sound_no_destroy_voice',
        'sound_no_destroy_voice2',
        'sound_prevent_duplicate_sounds',
        'teams_prevent_dead_stranding',
    ]
    assert not any(g in nb.ACTIVE_GUARDS for g in nb.AUX_SCENE_GUARDS)


def test_k8_b1_b2_are_native_but_telemetered():
    blob = nb.build_exi_wrapper(BASE, pending_addr=PENDING, active_addr=ACTIVE,
                                state_addr=STATE, patch_table_addr=PATCH_TABLE)
    mem = {}; _seed_scope(mem)
    req = 0x81201000
    put(mem, req, nb.CAPTURE_SAVESTATE, 1); put(mem, req + 1, 123, 4)
    r = execute(blob, BASE, mem=mem, initial_regs={3:req,13:R13},
                stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert r['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem, STATE + nb.S_B1_COUNT, 4) == 1
    assert get(mem, STATE + nb.S_LAST_B1_FRAME, 4) == 123

    put(mem, req, nb.LOAD_SAVESTATE, 1); put(mem, req + 1, 119, 4)
    r = execute(blob, BASE, mem=mem, initial_regs={3:req,13:R13},
                stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert r['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem, STATE + nb.S_B2_COUNT, 4) == 1
    assert get(mem, STATE + nb.S_LAST_B2_FRAME, 4) == 119


def test_k8_physical_input_source_stays_independent_of_player_slots():
    blob = nb.build_exi_wrapper(BASE, pending_addr=PENDING, active_addr=ACTIVE,
                                state_addr=STATE, patch_table_addr=PATCH_TABLE)
    mem = {}; _seed_scope(mem)
    # Model the ROG case: physical Port 1 (index 0), but local fighter/network
    # slot is P2 (index 1), and the remote PC fighter is P1 (index 0).
    put(mem, STATE + nb.S_LOCAL_INDEX, 1, 1)
    put(mem, STATE + nb.S_ARM_ONLINE_INDEX, 0, 1)
    put(mem, STATE + nb.S_ARM_INPUT_SOURCE_INDEX, 0, 1)
    req = 0x81201000; put(mem, req, nb.ONLINE_INPUTS, 1)
    r = execute(blob, BASE, mem=mem, initial_regs={3:req,13:R13},
                stop_targets={nb.SLIPPI_EXI_TRANSFER})
    assert r['target'] == nb.SLIPPI_EXI_TRANSFER
    assert get(mem, nb.STABLE_ODB + nb.ODB_LOCAL_PLAYER_INDEX, 1) == 1
    assert get(mem, nb.STABLE_ODB + nb.ODB_ONLINE_PLAYER_INDEX, 1) == 0
    assert get(mem, nb.STABLE_ODB + nb.ODB_INPUT_SOURCE_INDEX, 1) == 0
