from sdk.adventure_probe import _spawn_setup_stub, _ground_event_either_human_wrapper


def test_hf5_spawn_never_forces_p2_subcolor_one():
    blob = _spawn_setup_stub(0x80410000)
    # li r11,1 ; stb r11,0x8b(r30) was the shading bug (+0x84 + 7).
    assert bytes.fromhex('39600001997e008b') not in blob


def test_hf5_form_tracker_remains_in_ground_event_wrapper():
    blob=_ground_event_either_human_wrapper(
        0x80412000,0x80411000,0x80410020,
        p1_form_addr=0x80410030,p2_form_addr=0x80410031)
    # Zelda/Sheik active-form observation remains live; Icies teardown moved to
    # the HF7 match-end callback instead of this scanner.
    assert len(blob) > 250


def test_hf5_form_restore_accepts_zelda_and_sheik_saved_state():
    blob=_spawn_setup_stub(0x80414000,p1_form_addr=0x80410030,p2_form_addr=0x80410031)
    assert bytes.fromhex('2f8a0012') in blob
    assert bytes.fromhex('2f8a0013') in blob
