from pathlib import Path
import inspect

from sdk import adventure_probe
from sdk.iso_builder import build_test_iso

ROOT=Path(__file__).resolve().parents[1]


def test_vs_p2_identity_source_layout_is_source_grounded():
    # doldecomp: gmm_x0::modes.vs_melee @ +0x590, VsModeData.start @ +0x08,
    # StartMeleeData.players @ +0x60, PlayerInitData[1] @ +0x24.
    assert adventure_probe.GM_MAINLIB_PTR_ADDR == 0x804D3EE0
    assert adventure_probe.VS_MELEE_P2_INIT_OFFSET == 0x590 + 0x08 + 0x60 + 0x24 == 0x61C
    assert adventure_probe.PLAYER_INIT_SIZE == 0x24


def test_bridge_is_explicit_opt_in_and_builder_exposes_it():
    sig=inspect.signature(adventure_probe.install_phase30_coop_spawn_probe)
    assert sig.parameters['enable_vs_p2_identity_bridge'].default is False
    sig2=inspect.signature(build_test_iso)
    assert sig2.parameters['vs_p2_identity_bridge'].default is False


def test_phase41_different_character_bat_is_controlled_full_unlock_build():
    text=(ROOT/'Regression Builds'/'BUILD_COOP_DIFFERENT_CHAR_TEST.bat').read_text(errors='replace')
    assert '--variant coop_showcase' in text
    assert '--unlock-all' in text
    assert '--test-shortcuts' in text
    assert '--vs-p2-profile' in text
    assert '--scene-revive' not in text


def test_bridge_stubs_build_both_enabled_and_disabled():
    common=dict(camera_owner_addr=0x80400020,persistence_valid_addr=0x80400021,
                p1_stocks_addr=0x80400022,p2_stocks_addr=0x80400023,
                initial_stocks_addr=0x80400024)
    legacy=adventure_probe._spawn_setup_stub(0x80410000, **common)
    bridged=adventure_probe._spawn_setup_stub(
        0x80410000, **common,
        vs_p2_identity_valid_addr=0x80400025,
        vs_p2_ckind_addr=0x80400026,
        vs_p2_color_addr=0x80400027,
        vs_p2_subcolor_addr=0x80400028,
        vs_p2_nametag_addr=0x80400029)
    assert len(bridged) > len(legacy)
    reset=adventure_probe._campaign_state_reset_stub(
        0x80420000, **common, return_address=0x801B42EC,
        vs_p2_identity_valid_addr=0x80400025,
        vs_p2_ckind_addr=0x80400026,
        vs_p2_color_addr=0x80400027,
        vs_p2_subcolor_addr=0x80400028,
        vs_p2_nametag_addr=0x80400029)
    assert len(reset) > 0
