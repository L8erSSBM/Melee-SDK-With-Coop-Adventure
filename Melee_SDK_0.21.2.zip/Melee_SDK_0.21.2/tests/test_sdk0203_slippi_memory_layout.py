"""Execute arena guards and reproduce the captured m-ex write collision."""
import hashlib
import json
import struct
from pathlib import Path

import pytest

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from sdk import slippi_memory_layout as layout
from sdk.slippi_adventure_entry_leaf import build_leaf_wrapper
from hf29d_ppc import execute, SENTINEL

ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / 'Build/SDK023_runtime_manifest.json'


@pytest.mark.parametrize('requested', [0, 0x804EEC00, 0x804F0C00,
                                     0x804F4BE0, 0x804F4C00, 0x80500000])
def test_boot_arena_floor_executes_and_preserves_call_contract(requested):
    result = execute(layout.build_arena_floor(0x804F4000), 0x804F4000,
                     initial_regs={3: requested, 2: 0x804DF9E0,
                                   13: 0x804DB6A0, 4: 0x12345678},
                     stop_targets=(layout.OS_SET_ARENA_LO,))
    assert result['target'] == layout.OS_SET_ARENA_LO
    assert result['regs'][3] == max(requested, layout.SDK_RUNTIME_LIMIT)
    assert result['lr'] == SENTINEL
    assert result['regs'][1] == 0x817FF000
    assert result['regs'][2] == 0x804DF9E0
    assert result['regs'][13] == 0x804DB6A0
    assert result['regs'][4] == 0x12345678


def test_both_os_init_paths_call_the_reserved_wrapper():
    m = json.loads(MANIFEST.read_text())['slippi_memory_layout']
    dol = DOLImage(ROOT / 'Build/start.dol')
    for site in layout.OS_INIT_ARENA_LO_CALLS:
        branch = decode_branch(site, dol.read_at_address(site, 4))
        assert branch['link'] and branch['target'] == m['arena_wrapper']
    assert dol.read_at_address(m['arena_wrapper'], m['arena_wrapper_size']) == \
        layout.build_arena_floor(m['arena_wrapper'])


def test_runtime_outside_both_stacks_and_fully_below_heap_floor():
    dol = DOLImage(ROOT / 'Build/start.dol')
    section = next(s for s in dol.sections if s.address == layout.SDK_RUNTIME_BASE)
    assert section.address >= layout.RETAIL_DEBUG_STACK[1]
    assert section.end_address <= layout.SDK_RUNTIME_LIMIT
    assert all(not(section.address <= a < section.end_address)
               for a in layout.OBSERVED_MEX_GLOBALS)
    assert dol.read_at_address(section.address, 8) == b'MSDKRT29'


def test_captured_mex_pointer_write_reproduces_old_fault_but_cannot_hit_new_leaf():
    # Exact 2.15.1 live-memory evidence: r2+0x184 received this file-table pointer.
    target, pointer = 0x804DFB64, 0x80668CEC
    old = DOLImage(ROOT / 'Build/historical/SDK022_SLIPPI_ADVENTURE_TRACE.dol')
    assert old.read_at_address(target, 4) == bytes.fromhex('3d00804e')
    old.patch_at_address(target, struct.pack('>I', pointer))
    word = struct.unpack('>I', old.read_at_address(target, 4))[0]
    assert word >> 26 == 32  # lwz r3,-0x7314(r6); r6 holds requested pad 0
    assert (word >> 16) & 31 == 6
    assert ((word & 0xFFFF) - 0x10000) & 0xFFFFFFFF == 0xFFFF8CEC
    new = DOLImage(ROOT / 'Build/start.dol')
    m = json.loads(MANIFEST.read_text())['slippi_adventure_entry_leaf']
    assert not (m['presentation_wrapper'] <= target <
                m['presentation_wrapper'] + m['wrapper_size'])
    assert new.read_at_address(m['presentation_wrapper'], m['wrapper_size']) == \
        build_leaf_wrapper(m['presentation_wrapper'], m['trace_stage_address'])


def test_runtime_manifest_matches_delivered_binary():
    m = json.loads(MANIFEST.read_text())
    assert m['sdk_version'] == '0.20.3'
    assert hashlib.sha256((ROOT / 'Build/start.dol').read_bytes()).hexdigest() == m['output_sha256']


def test_arena_reservation_rejects_wrong_placement():
    old = DOLImage(ROOT / 'Build/historical/SDK022_SLIPPI_ADVENTURE_TRACE.dol')
    with pytest.raises(ValueError, match='regenerated runtime'):
        layout.install_arena_reservation(old, 8)
