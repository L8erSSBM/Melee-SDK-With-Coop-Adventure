import struct
from sdk.dol_patch import DOLImage, SymbolMap
from sdk.action_state import MotionStateTableEditor


def make_dol():
    raw=bytearray(0x500)
    # text0 file 0x100 -> 0x80001000 size 0x100
    struct.pack_into('>I',raw,0x00,0x100); struct.pack_into('>I',raw,0x48,0x80001000); struct.pack_into('>I',raw,0x90,0x100)
    # data0 file 0x200 -> 0x80300000 size 0x200
    struct.pack_into('>I',raw,0x1C,0x200); struct.pack_into('>I',raw,0x64,0x80300000); struct.pack_into('>I',raw,0xAC,0x200)
    # two motion states at data address 0x80300000
    for i in range(2):
        vals=(100+i,0x11+i,0x22000000,0x80001000,0x80001004,0x80001008,0x8000100C,0x80001010)
        struct.pack_into('>8I',raw,0x200+i*0x20,*vals)
    return DOLImage(raw)


def test_motion_state_table_read_validate_clone_and_callback_patch():
    syms=SymbolMap.from_text('tbl = .data:0x80300000; // size:0x40\ncb = .text:0x80001020; // size:0x4\n')
    ed=MotionStateTableEditor(make_dol(),syms)
    assert ed.table_capacity('tbl')==2
    assert ed.validate_table('tbl')['status']=='PASS'
    assert ed.read_table('tbl')[1].anim_id==101
    ed.clone_entry('tbl',0,1)
    assert ed.read_table('tbl')[1].anim_id==100
    ed.set_callback('tbl',1,'anim','cb')
    assert ed.read_table('tbl')[1].anim_cb==0x80001020
