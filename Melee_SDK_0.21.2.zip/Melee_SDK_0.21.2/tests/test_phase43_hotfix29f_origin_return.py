from __future__ import annotations

import json
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from sdk import adventure_origin_return as origin

ROOT = Path(__file__).resolve().parents[1]


def _manifest():
    return json.loads((ROOT / 'Build' / 'HF29F_runtime_manifest.json').read_text())


def test_origin_return_manifest_has_three_narrow_adventure_exit_hooks():
    m = _manifest()['adventure_origin_return']
    assert m['marker'] == 'HF29FORG'
    assert m['mutable_state'].startswith('none')
    assert m['current_mode_address'] == origin.CURRENT_MODE
    assert m['previous_mode_address'] == origin.PREVIOUS_MODE
    hooks = m['hooks']
    assert [h['site_address'] for h in hooks] == [
        origin.ABORT_RETURN_CALL,
        origin.CSS_CANCEL_RETURN_CALL,
        origin.CAMPAIGN_COMPLETE_SET_PENDING_CALL,
    ]


def test_origin_return_site_branches_resolve_to_expected_wrappers():
    d = DOLImage(ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')
    m = _manifest()['adventure_origin_return']
    expected_targets = [m['change_mode_stub'], m['change_mode_stub'], m['set_pending_stub']]
    for h, target in zip(m['hooks'], expected_targets):
        raw = d.read_at_address(h['site_address'], 4)
        dec = decode_branch(h['site_address'], raw)
        assert dec['target'] == target
        assert dec['link'] is True


def test_wrappers_match_generated_source_and_use_retail_prev_mode():
    d = DOLImage(ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')
    m = _manifest()['adventure_origin_return']
    change = origin._wrapper(m['change_mode_stub'], origin.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE)
    pending = origin._wrapper(m['set_pending_stub'], origin.GM_SET_PENDING_GAME_MODE)
    assert d.read_at_address(m['change_mode_stub'], len(change)) == change
    assert d.read_at_address(m['set_pending_stub'], len(pending)) == pending
    # Asm.absolute uses r12 as the address base and returns the byte in r11.
    # For 0x80479D32 this is: lis r12,0x8048; addi r12,r12,-0x62CE; lbz r11,0(r12).
    pattern = bytes.fromhex('3D808048398C9D32896C0000')
    assert pattern in change
    assert pattern in pending


def test_hf29f_binary_containment_relative_to_hf29e():
    old = (ROOT / 'Build' / 'historical' / 'HF29E.dol').read_bytes()
    new = (ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes()
    assert len(new) == len(old) + 160

    common = min(len(old), len(new))
    diff = [i for i in range(common) if old[i] != new[i]]

    # Existing bytes may change only at the DOL data-section size field and the
    # three linked-call sites redirected to the new origin-aware wrappers.
    d = DOLImage(ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')

    def file_offset(addr):
        for sec in d.sections:
            if sec.address <= addr < sec.address + sec.size:
                return sec.file_offset + (addr - sec.address)
        raise ValueError(f'address not mapped: {addr:#x}')

    hook_offsets = {file_offset(x) for x in (
        origin.ABORT_RETURN_CALL,
        origin.CSS_CANCEL_RETURN_CALL,
        origin.CAMPAIGN_COMPLETE_SET_PENDING_CALL,
    )}
    allowed = set(range(0xCE, 0xD0))
    for off in hook_offsets:
        allowed.update(range(off, off + 4))
    assert set(diff) <= allowed

    assert new[-160:-152] == b'HF29FORG'


def test_hf29e_memory_fixes_remain_present_and_unchanged_at_hook_sites():
    old = DOLImage(ROOT / 'Build' / 'historical' / 'HF29E.dol')
    new = DOLImage(ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol')
    old_m = json.loads((ROOT / 'Build' / 'HF29E_runtime_manifest.json').read_text())

    for key in ('clear_screen_background_omit', 'team_kirby_pool_packing'):
        info = old_m[key]
        site = info['site_address']
        assert new.read_at_address(site, 4) == old.read_at_address(site, 4)

    raw = (ROOT / 'Build' / 'historical' / 'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes()
    for marker in (b'HF29CBGO', b'HF29DSLP', b'HF29TKRW'):
        assert marker in raw
