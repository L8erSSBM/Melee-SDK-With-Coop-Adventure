"""HF26 Team-Kirby developer force-clear tests."""
from __future__ import annotations

import shutil
import struct
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch
from sdk import team_kirby_force_clear as hf

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804E1000
OLD = 0x804DF980
REQ = 0x804E0C10
REQCNT = 0x804E0C14
TERMCNT = 0x804E0C18
KOCNT = 0x804E0C1C
VEC = 0x804DFAC0
SENTINEL = 0x81234560


def put(mem, addr, value, size=4):
    raw = int(value & ((1 << (size*8))-1)).to_bytes(size, 'big')
    for i,b in enumerate(raw): mem[addr+i]=b


def get(mem, addr, size=4):
    return int.from_bytes(bytes(mem.get(addr+i,0) for i in range(size)), 'big')


def run(*, state=0x23, req=0, p0_button=0, p0_trigger=0,
        p1_button=0, p1_trigger=0, complete=0, active=1, stocks=None, entities=None):
    blob = hf.wrapper(BASE, old_shortcut_addr=OLD, request_state_addr=REQ,
                      request_counter_addr=REQCNT, terminal_counter_addr=TERMCNT,
                      ko_counter_addr=KOCNT, offscreen_vec_addr=VEC)
    mem={}
    put(mem,hf.ADVENTURE_MODE_ADDR,4,1); put(mem,hf.ADVENTURE_STATE_ADDR,state,1); put(mem,REQ,req,1)
    for idx,(button,trigger) in enumerate(((p0_button,p0_trigger),(p1_button,p1_trigger))):
        pad=hf.HSD_PAD_COPY_STATUS+hf.PAD_STATUS_STRIDE*idx
        put(mem,pad+hf.PAD_BUTTON_OFF,button); put(mem,pad+hf.PAD_TRIGGER_OFF,trigger)
    regs=[0]*32; regs[1]=0x817FF000
    lr=SENTINEL; cr={2:False,30:False}; pc=BASE; positions=[]
    stocks = dict(stocks or {})
    entities = dict(entities or {})

    def s16(x): return x-0x10000 if x&0x8000 else x
    def signed32(x): return x-0x100000000 if x&0x80000000 else x

    for _ in range(5000):
        if pc in (OLD+4,SENTINEL):
            return {'target':pc,'mem':mem,'positions':positions,'regs':regs}
        if pc in (hf.EVENT_ENEMY_IS_COMPLETE,hf.EVENT_ENEMY_IS_ACTIVE,hf.PLAYER_GET_STOCKS,
                  hf.PLAYER_GET_ENTITY,hf.PLAYER_SET_POSITION):
            if pc==hf.EVENT_ENEMY_IS_COMPLETE: regs[3]=complete
            elif pc==hf.EVENT_ENEMY_IS_ACTIVE: regs[3]=active
            elif pc==hf.PLAYER_GET_STOCKS: regs[3]=stocks.get(regs[3],0)
            elif pc==hf.PLAYER_GET_ENTITY: regs[3]=entities.get(regs[3],0)
            elif pc==hf.PLAYER_SET_POSITION: positions.append((regs[3],regs[4]))
            pc=lr; continue
        if not BASE <= pc < BASE+len(blob): raise AssertionError(hex(pc))
        w=struct.unpack_from('>I',blob,pc-BASE)[0]; op=w>>26; nxt=pc+4
        rt=(w>>21)&31; ra=(w>>16)&31; imm=s16(w&0xffff)
        if op==14: regs[rt]=((regs[ra] if ra else 0)+imm)&0xffffffff
        elif op==15: regs[rt]=((regs[ra] if ra else 0)+(imm<<16))&0xffffffff
        elif op==32: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,4)
        elif op==34: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,1)
        elif op==36: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt],4)
        elif op==37:
            regs[ra]=(regs[ra]+imm)&0xffffffff; put(mem,regs[ra],regs[rt],4)
        elif op==38: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt],1)
        elif op==28: # andi.
            regs[ra]=regs[rt] & (w&0xffff); cr[2]=(regs[ra]==0)
        elif op==11:
            av,bv=signed32(regs[ra]),imm; cr[30]=(av==bv)
        elif op==16:
            bd=w&0xfffc
            if bd&0x8000: bd-=0x10000
            bo,bi=(w>>21)&31,(w>>16)&31
            bit=cr.get(bi,False)
            take=bo==20 or (bo==12 and bit) or (bo==4 and not bit)
            if take:nxt=(pc+bd)&0xffffffff
        elif op==18:
            info=decode_branch(pc,w.to_bytes(4,'big'))
            if info['link']: lr=(pc+4)&0xffffffff
            nxt=info['target']
        elif op==31:
            # Exact SDK mflr/mtlr forms used here.
            if (w & 0xFC1FFFFF)==0x7C0802A6: regs[rt]=lr
            elif (w & 0xFC1FFFFF)==0x7C0803A6: lr=regs[rt]
            else: raise AssertionError(f'op31 {w:08x}')
        elif w==0x4E800020: nxt=lr
        else: raise AssertionError(f'unsupported {w:08x} @ {pc:08x}')
        pc=nxt
    raise AssertionError('wrapper did not terminate')


def chord(): return hf.PAD_BUTTON_L, hf.PAD_BUTTON_DDOWN


def test_idle_non_team_kirby_delegates_original_shortcut():
    b,t=chord(); r=run(state=0x22,p0_button=b,p0_trigger=t)
    assert r['target']==OLD+4
    assert get(r['mem'],REQ,1)==0


def test_idle_team_kirby_without_down_delegates_original_shortcut():
    r=run(state=0x23,p0_button=hf.PAD_BUTTON_L,p0_trigger=0)
    assert r['target']==OLD+4


def test_team_kirby_chord_latches_and_drives_only_live_event_slots():
    b,t=chord(); r=run(p0_button=b,p0_trigger=t,complete=0,active=1,
        stocks={2:1,3:0,4:1,5:1},entities={2:0x90001000,4:0,5:0x90005000})
    assert r['target']==SENTINEL
    assert get(r['mem'],REQ,1)==1
    assert get(r['mem'],REQCNT)==1
    assert [s for s,_ in r['positions']]==[2,5]
    assert get(r['mem'],KOCNT)==2
    assert get(r['mem'],hf.VS_TERMINATE_MATCH_ADDR,1)==0


def test_terminal_edge_gets_one_full_helper_frame_before_termination():
    r=run(req=1,complete=1,active=0)
    assert r['target']==SENTINEL
    assert get(r['mem'],REQ,1)==2
    assert get(r['mem'],TERMCNT)==1
    assert get(r['mem'],hf.VS_TERMINATE_MATCH_ADDR,1)==0

    r=run(req=2,complete=1,active=0)
    assert r['target']==SENTINEL
    assert get(r['mem'],REQ,1)==0
    assert get(r['mem'],hf.VS_MATCH_RESULT_ADDR,1)==hf.MATCH_OUTCOME_1P_STAGE_END
    assert get(r['mem'],hf.VS_TERMINATE_MATCH_ADDR,1)==1


def test_wrapper_calls_only_retail_event_queries_and_normal_fighter_apis():
    blob=hf.wrapper(BASE,old_shortcut_addr=OLD,request_state_addr=REQ,
                    request_counter_addr=REQCNT,terminal_counter_addr=TERMCNT,
                    ko_counter_addr=KOCNT,offscreen_vec_addr=VEC)
    targets=[]
    for off in range(0,len(blob),4):
        raw=blob[off:off+4]
        if int.from_bytes(raw,'big')>>26==18:
            targets.append(decode_branch(BASE+off,raw)['target'])
    for target in (hf.EVENT_ENEMY_IS_COMPLETE,hf.EVENT_ENEMY_IS_ACTIVE,hf.PLAYER_GET_STOCKS,
                   hf.PLAYER_GET_ENTITY,hf.PLAYER_SET_POSITION,OLD+4):
        assert target in targets
    # Explicitly no direct fighter destroy / event cleanup calls.
    assert 0x80031EBC not in targets
    assert 0x8016A164 not in targets


def test_hf25_dol_upgrade_is_contained_to_entry_branch_plus_appended_payload(tmp_path):
    # The packaged Build/start.dol is already HF26. Reconstruct the exact HF25
    # prefix by removing the final HF26 append, restoring data8's previous size,
    # and replaying the expected original shortcut prologue. This keeps the test
    # self-contained without shipping a redundant 4.3 MiB historical DOL.
    src=ROOT/'Build'/'start.dol'; raw=bytearray(src.read_bytes())
    marker_off=raw.find(b'HF26TKFC'); assert marker_off>0
    current=DOLImage(raw)
    sec=next(s for s in current.sections if s.kind=='data' and s.index==8)
    old_size=marker_off-sec.file_offset
    struct.pack_into('>I',raw,0xAC+8*4,old_size)
    entry_off=sec.file_offset+(OLD-sec.address)
    raw[entry_off:entry_off+4]=hf.SHORTCUT_ENTRY_EXPECTED
    del raw[marker_off:]
    dst=tmp_path/'hf25.dol'; dst.write_bytes(raw)

    before=dst.read_bytes(); d=DOLImage(dst)
    old_section=next(s for s in d.sections if s.kind=='data' and s.index==8)
    result=hf.install(d,8,old_shortcut_addr=OLD,offscreen_vec_addr=VEC)
    d.save_as(dst); after=dst.read_bytes()
    d2=DOLImage(dst)
    assert decode_branch(OLD,d2.read_at_address(OLD,4))['target']==result['stub_address']
    assert d2.read_at_address(result['section']['address'],8)==b'HF26TKFC'
    assert result['section']['address']==old_section.address+old_section.size
    # Within the entire original file, only the 4-byte shortcut entry changes
    # (plus the DOL section-size header field needed to expose appended bytes).
    diffs=[i for i,(a,b) in enumerate(zip(before,after[:len(before)])) if a!=b]
    allowed=set(range(entry_off,entry_off+4)) | set(range(0xAC+8*4,0xAC+8*4+4))
    assert set(diffs) <= allowed
