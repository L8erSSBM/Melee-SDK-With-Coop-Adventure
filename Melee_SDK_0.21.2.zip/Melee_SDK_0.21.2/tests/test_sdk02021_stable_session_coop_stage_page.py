from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk import slippi_coop_stage_page as sp
from sdk import slippi_direct_gateway as dg
from sdk import slippi_adventure_netplay_bridge as nb
from sdk import slippi_memory_layout as ml
from sdk import slippi_adventure_entry_leaf as leaf
from sdk import slippi_presentation_barrier as barrier
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]
R13 = 0x80400000
GMM = 0x81200000
MATCH = GMM + dg.DIRECT_MATCH_DATA_OFFSET
ALT_BLOCK = 0x80667000
ALT_BYTE = dg.SLIPPI_ALT_MODE_STATIC


def test_direct_page_installer_is_direct_only_and_uses_virtual_intent_token():
    dol = DOLImage((ROOT/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    row = sp.install(dol, 8)
    assert row['marker'] == 'STPG'
    assert row['coop_intent_stkind'] is None
    assert row['legacy_dormant_stkind'] == 0x15
    assert row['coop_tile_slot'] == 27
    assert 'Slippi Direct' in row['scope']
    assert dol.read_at_address(sp.ONENTER_HOOK, 4) != sp.PROLOGUE_EXPECTED
    assert dol.read_at_address(sp.ONFRAME_HOOK, 4) != sp.PROLOGUE_EXPECTED


def _build_direct_wrapper(netplay_arm=None):
    base=0x804F7000; tramp=0x804F6E00; state=0x804F6C00; pending=0x804F6B00
    blob=dg.build_wrapper(base,tramp,state_addr=state,gateway_pending_addr=pending,
        p1_ckind_addr=pending+1,p1_color_addr=pending+2,p1_subcolor_addr=pending+3,p1_nametag_addr=pending+4,
        p2_identity_valid_addr=pending+5,p2_ckind_addr=pending+6,p2_color_addr=pending+7,
        p2_subcolor_addr=pending+8,p2_nametag_addr=pending+9,netplay_arm_addr=netplay_arm)
    return base,tramp,state,pending,blob


def _seed_direct(stage, alt_mode=0):
    mem={}
    put(mem, dg.SLIPPI_ALT_MODE_HOOK,
        int.from_bytes(dg.encode_branch(dg.SLIPPI_ALT_MODE_HOOK, ALT_BLOCK), 'big'), 4)
    put(mem, ALT_BYTE, alt_mode, 1)
    put(mem,dg.GM_CURRENT_MODE_ADDR,dg.GM_ONLINE,1)
    put(mem,(R13+dg.OFST_R13_ONLINE_MODE)&0xffffffff,dg.ONLINE_MODE_DIRECT,1)
    put(mem,(R13+dg.OFST_R13_GM_MAINLIB)&0xffffffff,GMM,4)
    put(mem,MATCH+dg.DIRECT_STAGE_LOW_BYTE,stage,1)
    put(mem,MATCH+dg.P1+dg.PLAYER_TYPE,0,1); put(mem,MATCH+dg.P2+dg.PLAYER_TYPE,0,1)
    put(mem,MATCH+dg.P1+dg.CKIND,2,1); put(mem,MATCH+dg.P2+dg.CKIND,0x14,1)
    return mem


def test_carrier_preload_is_only_a_candidate_and_does_not_read_alt_marker_yet():
    base,tramp,state,pending,blob=_build_direct_wrapper(netplay_arm=0x804F6900)
    mem=_seed_direct(dg.CARRIER_STAGE)
    seen=[]
    def retail(regs,m): seen.append(get(m,MATCH+dg.DIRECT_STAGE_LOW_BYTE,1)); regs[3]=0x1234
    r=execute(blob,base,mem=mem,initial_regs={13:R13},callees={tramp:retail})
    assert seen == [0x08]
    assert get(mem,state+dg.S_BOOTSTRAP_PENDING,1) == 1
    assert get(mem,state+dg.S_TRACE,1) == dg.TRACE_BOOTSTRAP_QUEUED
    assert get(mem,MATCH+dg.DIRECT_STAGE_LOW_BYTE,1) == 0x08
    assert r['regs'][3] == 0x1234


def test_hud_init_rejects_ordinary_yoshi_candidate_without_synced_marker():
    arm=0x804F6900; state=0x804F6C00; pending=0x804F6B00; tramp=0x804F6A00; base=0x804F7000
    blob=dg.build_ingame_bootstrap_wrapper(base,tramp,state_addr=state,
        gateway_pending_addr=pending,p2_identity_valid_addr=pending+5,netplay_arm_addr=arm)
    mem=_seed_direct(dg.CARRIER_STAGE, 0)
    put(mem,state+dg.S_BOOTSTRAP_PENDING,1,1)
    put(mem,dg.GM_SCENE_BYTE3_ADDR,dg.ONLINE_INGAME_BYTE3,1)
    put(mem,dg.NETPLAY_READY_SITE,dg.NETPLAY_READY_WORD,4)
    arm_calls=[]
    def arm_fn(regs,m): arm_calls.append(1); regs[3]=1
    r=execute(blob,base,mem=mem,initial_regs={13:R13},callees={arm:arm_fn},stop_targets={tramp})
    assert r['target'] == tramp
    assert arm_calls == []
    assert get(mem,state+dg.S_BOOTSTRAP_PENDING,1) == 0
    assert get(mem,state+dg.S_ALT_MODE,1) == 0
    assert get(mem,state+dg.S_TRACE,1) == dg.TRACE_CARRIER_ORDINARY


def test_hud_init_accepts_synced_marker_on_both_peers_and_consumes_it():
    arm=0x804F6900; state=0x804F6C00; pending=0x804F6B00; tramp=0x804F6A00; base=0x804F7000
    blob=dg.build_ingame_bootstrap_wrapper(base,tramp,state_addr=state,
        gateway_pending_addr=pending,p2_identity_valid_addr=pending+5,netplay_arm_addr=arm)
    mem=_seed_direct(dg.CARRIER_STAGE, dg.ADVENTURE_ALT_MARKER)
    put(mem,state+dg.S_BOOTSTRAP_PENDING,1,1)
    put(mem,dg.GM_SCENE_BYTE3_ADDR,dg.ONLINE_INGAME_BYTE3,1)
    put(mem,dg.NETPLAY_READY_SITE,dg.NETPLAY_READY_WORD,4)
    changes=[]; exits=[]
    def arm_fn(regs,m): regs[3]=1
    def change(regs,m): changes.append(regs[3])
    def exit_fn(regs,m): exits.append(1)
    r=execute(blob,base,mem=mem,initial_regs={13:R13},callees={
        arm:arm_fn,dg.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE:change,dg.SCENE_EXIT_REQUEST:exit_fn},
        stop_targets={tramp})
    assert r['target'] == tramp
    assert get(mem,ALT_BYTE,1) == 0
    assert get(mem,state+dg.S_ALT_MODE,1) == dg.ADVENTURE_ALT_MARKER
    assert get(mem,state+dg.S_BOOTSTRAP_PENDING,1) == 0
    assert get(mem,pending,1) == 1
    assert changes == [dg.GM_ADVENTURE]
    assert exits == []
    assert get(mem,state+dg.S_TRACE,1) == dg.TRACE_ADVENTURE_REQUESTED


def test_stable_session_layout_fits_reserved_high_mem1_island():
    assert ml.SDK_RUNTIME_LIMIT == 0x804F4C00
    assert ml.SDK_SESSION_HIGH_BASE == nb.SESSION_HIGH_BASE == 0x817FE000
    assert ml.SDK_SESSION_HIGH_LIMIT == nb.SESSION_HIGH_LIMIT == 0x81800000
    assert nb.STABLE_ODB + nb.ODB_SIZE <= nb.STABLE_TXB
    assert nb.STABLE_SSCB + nb.SSCB_SIZE <= nb.SESSION_HIGH_LIMIT


def test_direct_presentation_barrier_wraps_existing_leaf_without_growing_legacy_slot():
    legacy=leaf.build_leaf_wrapper(0x80401900,0x804F1000)
    assert len(legacy) <= leaf.WRAPPER_CAPACITY
    blob=barrier.build_wrapper(0x804F2000,0x80401900,active_addr=0x804F1100,origin_addr=0x804F1101)
    assert len(blob) < 0x200


def test_probe_wires_page_session_bridge_and_version_02021():
    src=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    assert "'sdk_version':'0.20.21'" in src
    assert 'install_slippi_coop_stage_page' in src
    assert 'install_slippi_adventure_netplay_bridge' in src
    assert 'install_slippi_direct_gateway' in src
    assert src.index('install_slippi_adventure_netplay_bridge') < src.index('install_slippi_coop_stage_page') < src.index('install_slippi_direct_gateway')


def _seed_live_session(mem, *, odb, txb, rxb, ssrb, sscb, local_index=0):
    put(mem, (R13 + nb.OFST_R13_ODB_ADDR) & 0xffffffff, odb, 4)
    # Distinct deterministic payloads prove the actual bytes relocate, not just pointers.
    for base, size, seed in ((odb, nb.ODB_SIZE, 0x11), (txb, nb.TXB_SIZE, 0x22),
                             (rxb, nb.RXB_SIZE, 0x33), (ssrb, nb.SSRB_SIZE, 0x44),
                             (sscb, nb.SSCB_SIZE, 0x55)):
        for i in range(size):
            mem[base+i] = (seed + i * 7) & 0xff
    put(mem, odb + nb.ODB_LOCAL_PLAYER_INDEX, local_index, 1)
    put(mem, odb + nb.ODB_ONLINE_PLAYER_INDEX, local_index, 1)
    put(mem, odb + nb.ODB_INPUT_SOURCE_INDEX, 0, 1)
    put(mem, odb + nb.ODB_TXB_ADDR, txb, 4)
    put(mem, odb + nb.ODB_RXB_ADDR, rxb, 4)
    put(mem, odb + nb.ODB_SSRB_ADDR, ssrb, 4)
    put(mem, odb + nb.ODB_SSCB_ADDR, sscb, 4)
    for spec in nb.GUARDS:
        put(mem, spec.site, int.from_bytes(spec.expected, 'big'), 4)
    put(mem, nb.SLIPPI_EXI_VENEER, int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'), 4)
    put(mem, (R13 + nb.OFST_R13_ARENA_HI) & 0xffffffff, 0x81829800, 4)



def test_netplay_arm_relocates_live_session_and_rebases_authoritative_pointers():
    base=0x804F7000; state=0x804F6800; table_addr=0x804F7A00
    txrx_blob_addr=0x804F7B00; ss_blob_addr=0x804F7B08; meta_blob_addr=0x804F7B10
    odb=0x80BF3960; txb=0x80BF4680; rxb=0x80BF46C0; ssrb=0x80BF4820; sscb=0x80BF4880
    shims={g.site:0x804FA000+i*0x40 for i,g in enumerate(nb.ACTIVE_GUARDS)}
    exi=0x804FB000
    table=nb.build_patch_table(guard_shims=shims,exi_wrapper_addr=exi)
    blob=nb.build_arm_stub(base,state_addr=state,guard_shims=shims,exi_wrapper_addr=exi,
                           patch_table_addr=table_addr,txrx_blob_addr=txrx_blob_addr,
                           ss_blob_addr=ss_blob_addr,ssrb_meta_blob_addr=meta_blob_addr)
    mem={}
    for i,b in enumerate(table): mem[table_addr+i]=b
    for i,b in enumerate((nb.STABLE_TXB.to_bytes(4,'big')+nb.STABLE_RXB.to_bytes(4,'big'))): mem[txrx_blob_addr+i]=b
    for i,b in enumerate((nb.STABLE_SSRB.to_bytes(4,'big')+nb.STABLE_SSCB.to_bytes(4,'big'))): mem[ss_blob_addr+i]=b
    meta=(nb.STABLE_ODB.to_bytes(4,'big')+nb.ODB_SIZE.to_bytes(4,'big')+
          nb.STABLE_RXB.to_bytes(4,'big')+nb.RXB_SIZE.to_bytes(4,'big')+
          nb.STABLE_SSCB.to_bytes(4,'big')+nb.SSCB_SIZE.to_bytes(4,'big'))
    for i,b in enumerate(meta): mem[meta_blob_addr+i]=b
    _seed_live_session(mem,odb=odb,txb=txb,rxb=rxb,ssrb=ssrb,sscb=sscb,local_index=0)
    original_odb_prefix=bytes(mem[odb+i] for i in range(0x20))
    original_txb=bytes(mem[txb+i] for i in range(nb.TXB_SIZE))
    original_rxb=bytes(mem[rxb+i] for i in range(nb.RXB_SIZE))
    original_sscb=bytes(mem[sscb+i] for i in range(nb.SSCB_SIZE))
    r=execute(blob,base,mem=mem,initial_regs={13:R13})
    assert r['regs'][3] == 1
    assert get(mem,state+nb.S_FAILURE,1) == 0
    assert get(mem,state+nb.S_TRACE,1) == nb.TRACE_ARMED
    assert get(mem,(R13+nb.OFST_R13_ODB_ADDR)&0xffffffff,4) == nb.STABLE_ODB
    assert get(mem,state+nb.S_ORIG_ODB,4) == odb
    assert get(mem,state+nb.S_ORIG_TXB,4) == txb
    assert get(mem,state+nb.S_ORIG_RXB,4) == rxb
    assert get(mem,state+nb.S_ORIG_SSRB,4) == ssrb
    assert get(mem,state+nb.S_ORIG_SSCB,4) == sscb
    assert bytes(mem[nb.STABLE_ODB+i] for i in range(0x20)) == original_odb_prefix
    assert bytes(mem[nb.STABLE_TXB+i] for i in range(nb.TXB_SIZE)) == original_txb
    assert bytes(mem[nb.STABLE_RXB+i] for i in range(nb.RXB_SIZE)) == original_rxb
    assert bytes(mem[nb.STABLE_SSCB+i] for i in range(nb.SSCB_SIZE)) == original_sscb
    assert get(mem,nb.STABLE_ODB+nb.ODB_TXB_ADDR,4) == nb.STABLE_TXB
    assert get(mem,nb.STABLE_ODB+nb.ODB_RXB_ADDR,4) == nb.STABLE_RXB
    assert get(mem,nb.STABLE_ODB+nb.ODB_SSRB_ADDR,4) == nb.STABLE_SSRB
    assert get(mem,nb.STABLE_ODB+nb.ODB_SSCB_ADDR,4) == nb.STABLE_SSCB
    assert bytes(mem[nb.STABLE_SSRB+5+i] for i in range(24)) == meta
    for g in nb.ACTIVE_GUARDS:
        assert get(mem,g.site,4) == 0x60000000
    for g in nb.SNAPSHOT_GUARDS:
        assert get(mem,g.site,4) == int.from_bytes(g.expected,'big')
    assert get(mem,state+nb.S_PHASE,1) == nb.PHASE_TRANSITION
    assert get(mem,state+nb.S_ORIG_ARENA_HI,4) == 0x81829800
    assert get(mem,(R13+nb.OFST_R13_ARENA_HI)&0xffffffff,4) == nb.SESSION_HIGH_BASE
    assert get(mem,state+nb.S_PHASE,1) == nb.PHASE_TRANSITION


def test_coop_page_descriptor_swap_and_restore_are_lossless_without_jobjs():
    state=0x804F6000; base=0x804F7000
    mem={}
    original=[]
    for i in range(sp.STAGE_ROW_COUNT):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        # null JObj keeps the simulation inside descriptor logic only.
        put(mem,row,0,4)
        x8=(i%3)+1; st=(0x20+i)&0xff
        put(mem,row+sp.ROW_X8,x8,1); put(mem,row+sp.ROW_STKIND,st,1)
        original.append((x8,st))
    apply_blob=sp.build_apply_custom(base,state_addr=state)
    r=execute(apply_blob,base,mem=mem)
    assert get(mem,state+sp.S_PAGE,1) == 1
    for i in range(sp.STAGE_ROW_COUNT):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        if i == sp.COOP_TILE_SLOT:
            assert get(mem,row+sp.ROW_X8,1) == 2
            assert get(mem,row+sp.ROW_STKIND,1) == original[i][1]
        else:
            assert get(mem,row+sp.ROW_X8,1) == 0
    restore_base=base+0x800
    restore_blob=sp.build_restore_retail(restore_base,state_addr=state)
    r=execute(restore_blob,restore_base,mem=mem)
    assert get(mem,state+sp.S_PAGE,1) == 0
    assert get(mem,state+sp.S_SAVED,1) == 0
    for i,(x8,st) in enumerate(original):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        assert get(mem,row+sp.ROW_X8,1) == x8
        assert get(mem,row+sp.ROW_STKIND,1) == st



def test_custom_page_commit_restores_retail_table_before_emitting_carrier():
    state=0x804F6000; apply_base=0x804F7000; commit_base=0x804F7800; tramp=0x804F7900
    mem={}; original=[]
    for i in range(sp.STAGE_ROW_COUNT):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        put(mem,row,0,4)
        x8=(i%3)+1; st=(0x30+i)&0xff
        put(mem,row+sp.ROW_X8,x8,1); put(mem,row+sp.ROW_STKIND,st,1)
        original.append((x8,st))
    execute(sp.build_apply_custom(apply_base,state_addr=state),apply_base,mem=mem)
    blob=sp.build_stage_commit_wrapper(commit_base,tramp,state_addr=state)
    def retail_mapper(regs,_mem): regs[3]=0x12345678
    r=execute(blob,commit_base,mem=mem,callees={tramp:retail_mapper})
    assert r['regs'][3] == sp.DIRECT_CARRIER_STKIND
    assert get(mem,state+sp.S_PAGE,1) == 0
    assert get(mem,state+sp.S_SAVED,1) == 0
    assert get(mem,sp.SLIPPI_ALT_MODE_STATIC,1) == sp.ADVENTURE_ALT_MARKER
    for i,(x8,st) in enumerate(original):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        assert get(mem,row+sp.ROW_X8,1) == x8
        assert get(mem,row+sp.ROW_STKIND,1) == st


def test_next_sss_enter_repairs_stale_custom_page_snapshot():
    state=0x804F6000; apply_base=0x804F7000; enter_base=0x804F7800; tramp=0x804F7900
    mem={}; original=[]
    for i in range(sp.STAGE_ROW_COUNT):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        put(mem,row,0,4)
        x8=(i%3)+1; st=(0x40+i)&0xff
        put(mem,row+sp.ROW_X8,x8,1); put(mem,row+sp.ROW_STKIND,st,1)
        original.append((x8,st))
    execute(sp.build_apply_custom(apply_base,state_addr=state),apply_base,mem=mem)
    execute(sp.build_enter_wrapper(enter_base,tramp,state_addr=state),enter_base,mem=mem,stop_targets={tramp})
    assert get(mem,state+sp.S_PAGE,1) == 0
    assert get(mem,state+sp.S_SAVED,1) == 0
    for i,(x8,st) in enumerate(original):
        row=sp.STAGE_TABLE+i*sp.STAGE_ROW_SIZE
        assert get(mem,row+sp.ROW_X8,1) == x8
        assert get(mem,row+sp.ROW_STKIND,1) == st

def test_arena_hi_ceiling_reserves_final_8k_without_raising_arena_lo():
    base=0x804F2000
    blob=ml.build_arena_ceiling(base)
    low=0x81700000
    r=execute(blob,base,initial_regs={3:low},stop_targets={ml.OS_SET_ARENA_HI})
    assert r['target'] == ml.OS_SET_ARENA_HI and r['regs'][3] == low
    r=execute(blob,base,initial_regs={3:0x81800000},stop_targets={ml.OS_SET_ARENA_HI})
    assert r['target'] == ml.OS_SET_ARENA_HI and r['regs'][3] == ml.SDK_SESSION_HIGH_BASE
