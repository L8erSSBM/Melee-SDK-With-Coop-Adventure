import json
from sdk.adventure_coop import CoopAdventureCampaign, write_campaign_bundle

def test_vanilla_sequence_is_one_12_chapter_campaign():
    c=CoopAdventureCampaign.vanilla_sequence()
    assert len(c.chapters)==12
    assert [s.stkind for s in c.linear_segments()] == list(range(59,82))

def test_campaign_roundtrip(tmp_path):
    c=CoopAdventureCampaign.vanilla_sequence('Friends Adventure')
    c.rules.p2_character_kind=1
    p=c.save(tmp_path/'a.json')
    d=CoopAdventureCampaign.load(p)
    assert d.name=='Friends Adventure' and d.rules.p2_character_kind==1
    assert len(d.linear_segments())==23

def test_runtime_plan_names_real_source_hooks():
    p=CoopAdventureCampaign.vanilla_sequence().runtime_plan()
    names={x['symbol'] for x in p['source_hooks']}
    assert {'gm_801B4064','gm_8017CE34','gm_8017D7AC','gm_8017E7A0'} <= names
    assert 'four PlayerInitData' in p['hard_limit']

def test_bundle(tmp_path):
    root=write_campaign_bundle(tmp_path/'bundle')
    for n in ('coop_adventure.json','runtime_plan.json','compatibility.json'):
        assert (root/n).exists()
    risks={x['risk'] for x in json.loads((root/'compatibility.json').read_text())}
    assert {'special-route','wave-battle','boss/final'} <= risks
