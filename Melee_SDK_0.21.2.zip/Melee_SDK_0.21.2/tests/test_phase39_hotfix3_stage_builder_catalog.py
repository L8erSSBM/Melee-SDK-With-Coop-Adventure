import csv, json
from pathlib import Path

from sdk.additional_content import FEATURES
from sdk.stage_builder_catalog import ASSET_CLASSES, STATUS_EDITABLE

ROOT=Path(__file__).resolve().parents[1]

def test_stage_builder_capability_taxonomy_is_unique_and_has_safe_editors():
    keys=[x.key for x in ASSET_CLASSES]
    assert len(keys)==len(set(keys))
    editable={x.key for x in ASSET_CLASSES if x.status==STATUS_EDITABLE}
    assert {'collision','spawns','camera'} <= editable
    assert any(x.key=='stage_code' and x.status=='EXTERNAL' for x in ASSET_CLASSES)
    assert any(x.key=='yakumono' and x.status=='UNDECODED' for x in ASSET_CLASSES)

def test_retail_corpus_catalogue_is_packaged_and_complete():
    base=ROOT/'data'/'stage_builder_catalog'
    data=json.loads((base/'stage_builder_asset_catalog.json').read_text(encoding='utf-8'))
    assert data['stage_count']==71
    assert data['failure_count']==0
    assert len(data['stages'])==71
    assert any(s['filename']=='GrNBa.dat' for s in data['stages'])
    assert any(s['filename']=='GrNKr.dat' for s in data['stages'])
    with (base/'stage_builder_stage_index.csv').open(encoding='utf-8-sig',newline='') as f:
        rows=list(csv.reader(f))
    assert len(rows)==72

def test_additional_content_now_has_fifteen_capabilities():
    assert len(FEATURES)==15
    keys={x.key for x in FEATURES}
    assert {'coop_either_human_events','coop_scene_revive','coop_dual_credits'} <= keys
