from pathlib import Path

from sdk import adventure_probe as a
from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, lwz, stw
from tests.hf29d_ppc import execute, get, put

ROOT = Path(__file__).resolve().parents[1]


def _branch_calls(base: int, blob: bytes) -> list[int]:
    out=[]
    for off in range(0,len(blob),4):
        raw=blob[off:off+4]
        if len(raw)!=4 or (int.from_bytes(raw,'big')>>26)!=18:
            continue
        d=decode_branch(base+off,raw)
        if d['link']:
            out.append(d['target'])
    return out


def test_retail_staffroll_hook_bytes_match_packaged_historical_dol():
    # These three new sites were never modified by the older shared-cursor
    # implementation, so a historical packaged DOL is a useful retail-byte
    # fixture even though gm_801BF010 itself is already hooked there.
    dol=DOLImage((ROOT/'Build'/'historical'/'HF29F_ORIGIN_AWARE_RETURN.dol').read_bytes())
    assert dol.read_at_address(a.STAFFROLL_CURSOR_LOOKUP_CALL,4)==a.STAFFROLL_CURSOR_LOOKUP_EXPECTED
    assert dol.read_at_address(a.STAFFROLL_LOCAL_PASS_END_HOOK,4)==a.STAFFROLL_LOCAL_PASS_END_EXPECTED
    assert dol.read_at_address(a.STAFFROLL_SETUP_PROC_CALL,4)==a.STAFFROLL_SETUP_PROC_EXPECTED


def test_independent_pad_selector_uses_p1_then_p2_and_retail_when_inactive():
    base=0x804F5000; active=0x804F4000; pass_addr=active+1
    blob=a._staffroll_independent_pad_wrapper(base,active,pass_addr)

    mem={}; put(mem,active,1,1); put(mem,pass_addr,0,1)
    assert execute(blob,base,mem=mem)['regs'][3]==0

    mem={}; put(mem,active,1,1); put(mem,pass_addr,1,1)
    assert execute(blob,base,mem=mem)['regs'][3]==1

    # Retail fallback reads selected pad from 0x8049C181 (base 0x804A + -0x3E88 + 9).
    mem={}; put(mem,active,0,1); put(mem,0x8049C181,3,1)
    assert execute(blob,base,mem=mem)['regs'][3]==3


def test_cursor_lookup_substitutes_only_p2_clone():
    base=0x804F5200; pass_addr=0x804F4100; ptr_addr=pass_addr+4
    out_ptr=0x817FEF00; retail_cursor=0x81230000; p2_cursor=0x81240000
    blob=a._staffroll_cursor_lookup_wrapper(base,pass_addr,ptr_addr)

    def retail_lookup(regs,mem):
        put(mem,regs[4],retail_cursor,4)

    mem={}; put(mem,pass_addr,1,1); put(mem,ptr_addr,p2_cursor,4)
    result=execute(blob,base,mem=mem,initial_regs={4:out_ptr},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert result['target'] != 0
    assert get(mem,out_ptr,4)==p2_cursor

    mem={}; put(mem,pass_addr,0,1); put(mem,ptr_addr,p2_cursor,4)
    execute(blob,base,mem=mem,initial_regs={4:out_ptr},callees={a.LB_JOBJ_LOOKUP:retail_lookup})
    assert get(mem,out_ptr,4)==retail_cursor


def test_p2_local_pass_exits_before_shared_timeline_and_p1_keeps_displaced_instruction():
    base=0x804F5400; pass_addr=0x804F4100
    blob=a._staffroll_local_pass_end_wrapper(base,pass_addr)
    mem={}; put(mem,pass_addr,1,1)
    result=execute(blob,base,mem=mem,stop_targets=(a.STAFFROLL_RETAIL_EPILOGUE,))
    assert result['target']==a.STAFFROLL_RETAIL_EPILOGUE
    assert a.STAFFROLL_LOCAL_PASS_END_EXPECTED in blob
    tail=decode_branch(base+len(blob)-4,blob[-4:])
    assert tail['target']==a.STAFFROLL_LOCAL_PASS_END_HOOK+4
    assert not tail['link']


def test_dual_proc_runs_p2_local_pass_before_one_full_p1_pass():
    base=0x804F5600; active=0x804F4100; pass_addr=active+1
    assembly_addr=active+4; cursor_addr=active+8
    blob=a._staffroll_dual_lens_proc(base,active,pass_addr,assembly_addr,cursor_addr)
    calls=[]
    def retail_proc(regs,mem):
        calls.append(get(mem,pass_addr,1))
    mem={}; put(mem,active,1,1); put(mem,assembly_addr,0x81230000,4); put(mem,cursor_addr,0x81240000,4)
    put(mem,a.STAFFROLL_TIMELINE_COUNTER_ADDR,100,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000},callees={a.STAFFROLL_RETAIL_PROC:retail_proc})
    assert calls==[1,0]
    assert get(mem,pass_addr,1)==0

    calls.clear(); mem={}; put(mem,active,1,1); put(mem,cursor_addr,0,4)
    execute(blob,base,mem=mem,initial_regs={3:0x81200000},callees={a.STAFFROLL_RETAIL_PROC:retail_proc})
    assert calls==[0]


def test_setup_clones_complete_shooter_subtree_and_restores_original_id_mapping():
    base=0x804F5800
    blob=a._staffroll_setup_proc_wrapper(base,0x804F4100,0x804F4101,0x804F4104,0x804F4108,0x804F5700)
    calls=_branch_calls(base,blob)
    assert a.LB_JOBJ_LOOKUP in calls
    assert a.HSD_JOBJ_LOAD_JOINT in calls
    assert a.HSD_ID_INSERT_TO_TABLE in calls
    assert a.HSD_JOBJ_REPARENT in calls
    assert a.HSD_GOBJ_SETUP_PROC in calls
    # Source HSD_Joint->next is saved, cleared for the clone, then restored.
    words=[blob[i:i+4] for i in range(0,len(blob),4)]
    assert lwz(10,0x0C,3) in words
    assert stw(0,0x0C,3) in words
    assert stw(10,0x0C,11) in words


def test_installer_contains_all_independent_lens_hooks_and_runtime_state():
    src=(ROOT/'sdk'/'adventure_probe.py').read_text(encoding='utf-8')
    assert "payload[credits_state_off:credits_state_off+4]=b'P2LN'" in src
    assert 'STAFFROLL_CURSOR_LOOKUP_CALL,credits_lookup_branch' in src
    assert 'STAFFROLL_LOCAL_PASS_END_HOOK,credits_cut_branch' in src
    assert 'STAFFROLL_SETUP_PROC_CALL,credits_setup_branch' in src
    assert '_staffroll_independent_pad_wrapper' in src
    assert '_staffroll_dual_lens_proc' in src
