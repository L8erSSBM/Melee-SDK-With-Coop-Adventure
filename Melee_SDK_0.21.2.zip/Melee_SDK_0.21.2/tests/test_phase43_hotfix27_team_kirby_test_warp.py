"""HF27 developer Team-Kirby test-warp tests."""
from __future__ import annotations

import json
import struct
from pathlib import Path

from sdk.dol_patch import DOLImage
from sdk.ppc import decode_branch, encode_branch
from sdk import team_kirby_test_warp as hf

ROOT = Path(__file__).resolve().parents[1]
BASE = 0x804E2000
HF26 = 0x804E0C20
OLD = 0x804DF980
FLAG = 0x804E1C10
REQCNT = 0x804E1C14
APPLYCNT = 0x804E1C18
SENTINEL = 0x81234560


def put(mem, addr, value, size=4):
    raw=int(value & ((1 << (size*8))-1)).to_bytes(size,'big')
    for i,b in enumerate(raw): mem[addr+i]=b


def get(mem, addr, size=4):
    return int.from_bytes(bytes(mem.get(addr+i,0) for i in range(size)),'big')


def execute(blob, base, *, mem=None, lr=SENTINEL, r31=0, stop_targets=()):
    mem={} if mem is None else mem
    regs=[0]*32; regs[1]=0x817FF000; regs[31]=r31
    cr={2:False,30:False}; pc=base
    stop=set(stop_targets)|{SENTINEL}
    def s16(x): return x-0x10000 if x&0x8000 else x
    def signed32(x): return x-0x100000000 if x&0x80000000 else x
    for _ in range(3000):
        if pc in stop: return {'target':pc,'mem':mem,'regs':regs}
        if not base <= pc < base+len(blob): raise AssertionError(hex(pc))
        w=struct.unpack_from('>I',blob,pc-base)[0]; op=w>>26; nxt=pc+4
        rt=(w>>21)&31; ra=(w>>16)&31; imm=s16(w&0xffff)
        if op==14: regs[rt]=((regs[ra] if ra else 0)+imm)&0xffffffff
        elif op==15: regs[rt]=((regs[ra] if ra else 0)+(imm<<16))&0xffffffff
        elif op==32: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,4)
        elif op==34: regs[rt]=get(mem,(regs[ra]+imm)&0xffffffff,1)
        elif op==36: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt],4)
        elif op==38: put(mem,(regs[ra]+imm)&0xffffffff,regs[rt],1)
        elif op==28:
            regs[ra]=regs[rt] & (w&0xffff); cr[2]=(regs[ra]==0)
        elif op==11:
            cr[30]=(signed32(regs[ra])==imm)
        elif op==16:
            bd=w&0xfffc
            if bd&0x8000: bd-=0x10000
            bo,bi=(w>>21)&31,(w>>16)&31; bit=cr.get(bi,False)
            take=bo==20 or (bo==12 and bit) or (bo==4 and not bit)
            if take:nxt=(pc+bd)&0xffffffff
        elif op==18:
            info=decode_branch(pc,w.to_bytes(4,'big'))
            if info['link']: lr=(pc+4)&0xffffffff
            nxt=info['target']
        elif w==0x4E800020: nxt=lr
        else: raise AssertionError(f'unsupported {w:08x} @ {pc:08x}')
        pc=nxt
    raise AssertionError('wrapper did not terminate')


def shortcut_run(*, state=1, trigger=0, button=0, pad=0):
    blob=hf.shortcut_wrapper(BASE,hf26_stub=HF26,warp_flag_addr=FLAG,request_counter_addr=REQCNT)
    mem={}; put(mem,hf.ADVENTURE_MODE_ADDR,hf.GM_ADVENTURE,1); put(mem,hf.ADVENTURE_STATE_ADDR,state,1)
    p=hf.HSD_PAD_COPY_STATUS+hf.PAD_STATUS_STRIDE*pad
    put(mem,p+hf.PAD_BUTTON_OFF,button); put(mem,p+hf.PAD_TRIGGER_OFF,trigger)
    return execute(blob,BASE,mem=mem,stop_targets=(HF26,))


def test_left_is_now_warp_not_p1_ko():
    r=shortcut_run(state=1,button=hf.PAD_BUTTON_L,trigger=hf.PAD_BUTTON_DLEFT)
    assert r['target']==SENTINEL
    assert get(r['mem'],FLAG,1)==1
    assert get(r['mem'],REQCNT)==1
    assert get(r['mem'],hf.VS_MATCH_RESULT_ADDR,1)==hf.MATCH_OUTCOME_1P_STAGE_END
    assert get(r['mem'],hf.VS_TERMINATE_MATCH_ADDR,1)==1


def test_left_is_noop_when_already_team_kirby():
    r=shortcut_run(state=hf.TEAM_KIRBY_FIGHT_STATE,button=hf.PAD_BUTTON_L,trigger=hf.PAD_BUTTON_DLEFT)
    assert r['target']==SENTINEL
    assert get(r['mem'],FLAG,1)==0
    assert get(r['mem'],hf.VS_TERMINATE_MATCH_ADDR,1)==0


def test_other_shortcuts_delegate_to_hf26_unchanged():
    # L+Right is intentionally not consumed by HF27.
    r=shortcut_run(state=1,button=hf.PAD_BUTTON_L,trigger=0x0002)
    assert r['target']==HF26
    assert get(r['mem'],FLAG,1)==0


def test_routing_hook_overrides_after_retail_on_exit():
    base=BASE+0x400
    blob=hf.routing_wrapper(base,warp_flag_addr=FLAG,applied_counter_addr=APPLYCNT)
    mem={}; put(mem,FLAG,1,1); put(mem,hf.ADVENTURE_NEXT_STATE_ADDR,0x03,1)
    # r31 is state_machine base at the real hook; current state is arbitrary.
    put(mem,0x80479D33,0x01,1)
    r=execute(blob,base,mem=mem,r31=0x80479D30,stop_targets=(hf.ROUTING_RETURN,))
    assert r['target']==hf.ROUTING_RETURN
    assert get(mem,FLAG,1)==0
    assert get(mem,hf.ADVENTURE_NEXT_STATE_ADDR,1)==0x24
    assert get(mem,APPLYCNT)==1
    assert r['regs'][0]==0x01  # displaced lbz r0,3(r31) replayed


def test_install_on_packaged_hf26_is_contained(tmp_path):
    # The packaged Build/start.dol is already HF27. Reconstruct the exact HF26
    # prefix by removing the final HF27 append and restoring the two displaced
    # hook instructions. This keeps the test self-contained.
    src=ROOT/'Build'/'start.dol'; raw=bytearray(src.read_bytes())
    marker_off=raw.find(b'HF27TKWP'); assert marker_off>0
    current=DOLImage(raw)
    sec27=next(s for s in current.sections if s.kind=='data' and s.index==8)
    old_size=marker_off-sec27.file_offset
    struct.pack_into('>I',raw,0xAC+8*4,old_size)
    manifest=json.loads((ROOT/'Build'/'HF26_runtime_manifest.json').read_text())
    old=manifest['team_kirby_force_clear']['shortcut_entry']
    hf26_stub=manifest['team_kirby_force_clear']['stub_address']
    entry_off=sec27.file_offset+(old-sec27.address)
    raw[entry_off:entry_off+4]=encode_branch(old,hf26_stub)
    route_sec=current.section_for_address(hf.ROUTING_HOOK,4)
    route_off=route_sec.file_offset+(hf.ROUTING_HOOK-route_sec.address)
    raw[route_off:route_off+4]=hf.ROUTING_EXPECTED
    del raw[marker_off:]
    before=bytes(raw); d=DOLImage(before)
    sec=next(s for s in d.sections if s.kind=='data' and s.index==8)

    result=hf.install(d,8,old_shortcut_addr=old,hf26_stub=hf26_stub)
    dst=tmp_path/'hf27.dol'; d.save_as(dst); after=dst.read_bytes(); d2=DOLImage(dst)
    assert d2.read_at_address(result['section']['address'],8)==b'HF27TKWP'
    assert decode_branch(old,d2.read_at_address(old,4))['target']==result['shortcut_stub']
    assert decode_branch(hf.ROUTING_HOOK,d2.read_at_address(hf.ROUTING_HOOK,4))['target']==result['routing_stub']

    diffs=[i for i,(a,b) in enumerate(zip(before,after[:len(before)])) if a!=b]
    allowed=(set(range(entry_off,entry_off+4)) | set(range(route_off,route_off+4)) |
             set(range(0xAC+8*4,0xAC+8*4+4)))
    assert set(diffs) <= allowed
