"""Validate all 26 playable Melee characters against the SDK's structural decoder.

Usage:
    python validate_roster.py "C:\\path\\to\\folder containing Pl*.dat"

Ice Climbers are reported as one playable character while Popo and Nana are
validated as separate internal fighter entities.
"""
from __future__ import annotations
import json, math, sys
from pathlib import Path
from sdk.melee_dat import FighterDAT, encode_hitbox

ROSTER = [
    ('Mario',['PlMr.dat']),('Fox',['PlFx.dat']),('Captain Falcon',['PlCa.dat']),('Donkey Kong',['PlDk.dat']),
    ('Kirby',['PlKb.dat']),('Bowser',['PlKp.dat']),('Link',['PlLk.dat']),('Sheik',['PlSk.dat']),('Ness',['PlNs.dat']),
    ('Peach',['PlPe.dat']),('Ice Climbers',['PlPp.dat','PlNn.dat']),('Pikachu',['PlPk.dat']),('Samus',['PlSs.dat']),
    ('Yoshi',['PlYs.dat']),('Jigglypuff',['PlPr.dat']),('Mewtwo',['PlMt.dat']),('Luigi',['PlLg.dat']),('Marth',['PlMs.dat']),
    ('Zelda',['PlZd.dat']),('Young Link',['PlCl.dat']),('Dr. Mario',['PlDr.dat']),('Falco',['PlFc.dat']),('Pichu',['PlPc.dat']),
    ('Mr. Game & Watch',['PlGw.dat']),('Ganondorf',['PlGn.dat']),('Roy',['PlFe.dat'])]

def main(folder: Path):
    files={p.name:p for p in folder.rglob('*') if p.is_file()}
    results=[]
    for char,names in ROSTER:
        ents=[]
        for name in names:
            p=files.get(name)
            if not p:
                ents.append({'file':name,'ok':False,'error':'missing'}); continue
            try:
                f=FighterDAT(p); scripts=terminated=invalid=hitboxes=rtfail=control_scripts=pointer_events=control_errors=0
                for a in f.animations:
                    if not a.symbol or not a.script_offset: continue
                    scripts += 1; evs=f.parse_script(a,2000)
                    if evs and evs[-1]['opcode'] in (0,6,7): terminated += 1
                    if evs and evs[-1]['name']=='Invalid/Unknown': invalid += 1
                    has_control = any(ev.get('opcode') in (3,4,5,6,7) for ev in evs)
                    if has_control:
                        control_scripts += 1
                        try: f.analyze_script_control_flow(a, 2000)
                        except Exception: control_errors += 1
                    for ev in evs:
                        if ev.get('opcode') in (5,7):
                            pointer_events += 1
                            if not (ev.get('pointer_relocated') or (ev.get('opcode') == 7 and ev.get('pointer_target') == 0)):
                                control_errors += 1
                    for ev in evs:
                        if ev.get('opcode')==11 and 'hitbox' in ev:
                            hitboxes += 1
                            if encode_hitbox(ev['hitbox'],ev['words']) != ev['words']: rtfail += 1
                aj=files.get(p.stem+'AJ.dat'); ajv=f.validate_animation_archive(aj) if aj else None
                common=f.common_attributes(); nonfinite=[k for k,v in common.items() if isinstance(v['value'],float) and not math.isfinite(v['value'])]
                ents.append({'file':name,'ok':not(nonfinite or invalid or rtfail or control_errors or terminated != scripts or (ajv and ajv['errors'])),
                             'internal':f.fighter_name,'animations':f.anim_count,'scripts':scripts,'terminated':terminated,
                             'control_scripts':control_scripts,'pointer_events':pointer_events,'control_flow_errors':control_errors,
                             'invalid_streams':invalid,'hitboxes':hitboxes,'hitbox_roundtrip_failures':rtfail,
                             'aj':ajv,'nonfinite_common_attrs':nonfinite,'semantic_fields':len(f.character_attributes())})
            except Exception as e:
                ents.append({'file':name,'ok':False,'error':f'{type(e).__name__}: {e}'})
        results.append({'character':char,'ok':all(e['ok'] for e in ents),'entities':ents})
    out={'characters':len(results),'passed':sum(r['ok'] for r in results),'roster':results}
    Path('roster_validation_latest.json').write_text(json.dumps(out,indent=2))
    for r in results: print(f"{r['character']:<22} {'PASS' if r['ok'] else 'FAIL'}")
    print(f"\n{out['passed']}/{out['characters']} playable characters passed core validation.")
    return 0 if out['passed']==out['characters'] else 1

if __name__=='__main__':
    if len(sys.argv)!=2:
        print(__doc__); raise SystemExit(2)
    raise SystemExit(main(Path(sys.argv[1])))
