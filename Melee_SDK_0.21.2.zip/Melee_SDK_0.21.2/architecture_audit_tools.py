from __future__ import annotations
import argparse, json
from sdk.architecture_audit import audit_architecture

def main():
    ap=argparse.ArgumentParser(description='Audit cross-feature DOL/runtime architecture composition.')
    ap.add_argument('--dol', required=True)
    ap.add_argument('--symbols', default='data/runtime_symbols_GALE01.txt')
    ap.add_argument('--output')
    args=ap.parse_args()
    result=audit_architecture(args.dol,args.symbols)
    text=json.dumps(result,indent=2)
    if args.output:
        open(args.output,'w',encoding='utf-8').write(text+'\n')
    print(text)
if __name__=='__main__': main()
