from pathlib import Path
import json
p=Path('tests/fixtures/slippi_k16_native_lifecycle.json');j=json.loads(p.read_text());r=Path('../PCsaveNow.ram').read_bytes();a,b=0x80666C48,0x806673AC
j['regions']['trigger_inputs']={'address':a,'hex':r[a-0x80000000:b-0x80000000].hex()};p.write_text(json.dumps(j,indent=2))
p=Path('tests/hf29d_ppc.py');s=p.read_text();s=s.replace('elif op in (32,34): regs[rt]=get(mem,((regs[ra] if ra else 0)+imm)&0xFFFFFFFF,1 if op==34 else 4)','elif op in (32,34,40): regs[rt]=get(mem,((regs[ra] if ra else 0)+imm)&0xFFFFFFFF,{32:4,34:1,40:2}[op])')
s=s.replace('elif op in (36,37,38):','elif op in (36,37,38,44):').replace('put(mem,ea,regs[rt],1 if op==38 else 4)','put(mem,ea,regs[rt],{38:1,44:2}.get(op,4))')
s=s.replace('        elif op==31 and xo==151:', '''        elif op==31 and xo in (23,87): # lwzx/lbzx
            regs[rt]=get(mem,((regs[ra] if ra else 0)+regs[rb])&0xFFFFFFFF,4 if xo==23 else 1)
        elif op==31 and xo==215: # stbx
            put(mem,((regs[ra] if ra else 0)+regs[rb])&0xFFFFFFFF,regs[rt],1)
        elif op==31 and xo==954: # extsb
            regs[ra]=signed(regs[rt]&255,8)&0xFFFFFFFF
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo==316: # xor
            regs[ra]=regs[rt]^regs[rb]
            if w&1: compare(signed(regs[ra]),0,0)
        elif op==31 and xo==151:''')
s=s.replace('        elif w==0x4E800020: nxt=lr', '''        elif w in (0x4E800420,0x4E800421):
            nxt=ctr&~3
            if w&1: lr=pc+4
        elif w==0x4E800020: nxt=lr''');p.write_text(s)
