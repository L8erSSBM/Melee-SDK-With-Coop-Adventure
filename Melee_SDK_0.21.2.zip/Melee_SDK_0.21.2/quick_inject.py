from __future__ import annotations
import argparse, tempfile
from pathlib import Path
from sdk.gamecube_iso import GameCubeISO, verify_melee_102
from sdk.package_import import _iter_package_files
from sdk.stage import StageDAT
from sdk.melee_dat import HSDArchive


def _write_temp(payloads):
    td=tempfile.TemporaryDirectory(); root=Path(td.name); out={}
    for name,data in payloads:
        p=root/Path(name).name; p.write_bytes(data); out[p.name]=p
    return td,out


def inject_stage(clean_iso, package, output_iso, target='GrNBa.dat'):
    candidates=[]
    for n,d in _iter_package_files(package):
        if n.lower().startswith('gr') and n.lower().endswith('.dat'):
            try: StageDAT(d).validate()
            except Exception: continue
            candidates.append((n,d))
    if len(candidates)!=1: raise ValueError(f'Expected exactly one valid Gr*.dat in package; found {len(candidates)}')
    verify_melee_102(clean_iso,full_hash=False); iso=GameCubeISO(clean_iso); iso.find_file(target)
    td,files=_write_temp(candidates)
    try: return iso.repack_files(output_iso,{target:next(iter(files.values()))})
    finally: td.cleanup()


def inject_fighter(clean_iso, package, output_iso):
    payload=[]
    for n,d in _iter_package_files(package):
        if n.lower().startswith('pl') and n.lower().endswith('.dat'):
            try:HSDArchive(d)
            except Exception:continue
            payload.append((n,d))
    if not payload: raise ValueError('No valid Pl*.dat resources found')
    verify_melee_102(clean_iso,full_hash=False); iso=GameCubeISO(clean_iso)
    td,files=_write_temp(payload)
    try:
        replacements={}
        for n,p in files.items():
            try:iso.find_file(n)
            except KeyError:continue
            replacements[n]=p
        if not replacements: raise ValueError('None of the package fighter filenames exist in the ISO')
        return iso.repack_files(output_iso,replacements)
    finally: td.cleanup()


def main():
    ap=argparse.ArgumentParser(description='Fast one-shot Melee stage/fighter injection for testing')
    sub=ap.add_subparsers(dest='mode',required=True)
    st=sub.add_parser('stage'); st.add_argument('clean_iso'); st.add_argument('package'); st.add_argument('output_iso'); st.add_argument('--target',default='GrNBa.dat')
    ft=sub.add_parser('fighter'); ft.add_argument('clean_iso'); ft.add_argument('package'); ft.add_argument('output_iso')
    a=ap.parse_args()
    r=inject_stage(a.clean_iso,a.package,a.output_iso,a.target) if a.mode=='stage' else inject_fighter(a.clean_iso,a.package,a.output_iso)
    print(f"Built {r['output_iso']}")
    print(f"FST entries: {r['fst_entries_old']} -> {r['fst_entries_new']}")
if __name__=='__main__':main()
