# Slippi compatibility — SDK 0.20.19

## Deferred Direct -> Adventure synchronized-runtime bridge

The supplied paired Direct/Adventure savestates established the architectural boundary: 0.20.17 could request Adventure, but leaving Online In-Game destroyed Slippi's Online Data Buffer/session allocations and stopped the normal synchronized-input/rollback guards.

`YoshiStory.sav` then exposed two 0.20.18 regressions. The Direct producer reached **D4**, but the bridge failed at **SLNP E2 / 0x21** because the Online-In-Game injection was not installed yet during Splash. The 0.20.18B 24 KiB ArenaLo workaround also moved Slippi's ODB and dynamic gameplay code by exactly `+0x2000`.

0.20.19 restores the original 16 KiB SDK arena and defers arming until the normal Online-In-Game scene exists. Splash only records **D7**. The scene-loop then waits for the working-save signature at `0x80665540`, captures the normal ODB/session allocation graph, validates/redirects the live Slippi guard surface, and requests Adventure only after the bridge is armed.

The live guard shims preserve the original CR0 result when the SDK session scope is inactive. While scoped, they admit the Direct-launched Adventure campaign without changing logical player ownership. `CleanupConnections (0xBA)` is blocked only while the gateway is pending/active; after campaign scope clears, a real cleanup clears the bridge session scope and delegates to Slippi.

The bridge remains version-scoped and fail-closed. If the expected dynamic runtime does not appear or a live word differs, the Yoshi's Story match remains ordinary Direct play.

The peer milestone is unchanged: **PC-local Mewtwo controls Mewtwo, ROG-local Link controls Link, and Start/cutscene input advances both peers together.**

---

## 0.20.17 compatibility baseline

# Slippi compatibility — SDK 0.20.17

## Existing memory-layout repair

The SDK runtime was previously relocated away from Slippi m-ex globals and protected by an arena reservation. That protection remains unchanged in 0.20.17. Cold-boot rebuilt ISOs; executable-memory savestates from older SDK builds must not be reused as runtime validation.

## Local VS status

The local VS -> Co-op Adventure gateway and captured VS return path are runtime-confirmed. Local VS continues to use Yoshi's Island (N64) as its temporary Adventure sentinel.

## Slippi Direct candidate

0.20.17 adds the first Direct-specific gateway producer. It recognizes the Slippi online major plus Direct mode at the synchronized match-preload boundary, reads the committed P1/P2 identity, and feeds the same Adventure gateway state already proven locally.

For the test build, **Yoshi's Story** is the Direct-only sentinel. Both players must select it and must use the exact same 0.20.17 rebuilt ISO.

Adventure then captures online major `0x08` as its launcher origin. The existing origin-aware LRA+Start, loss, quit, and completion paths are intended to return to Slippi online rather than local VS.

## Important validation boundary

The offline SDK tests verify the DOL hook, Direct-mode/sentinel guards, identity capture, Adventure request, and generic captured-origin return contract. They do **not** prove that Slippi's peer-to-peer rollback/session machinery will accept a long-running Adventure campaign. Real Direct testing is still required.

If entry fails, save immediately after the attempted Yoshi's Story launch. The `DRCT` diagnostic state records breadcrumbs `D1` through `D5` so the failure can be located without guessing.

