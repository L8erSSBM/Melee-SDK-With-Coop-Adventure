# Melee SDK — Stage Builder Asset Catalogue

Retail corpus scanned: **71 Gr*.dat files**; failures: **0**.

This document is organized by what a stage creator needs to change, not by reverse-engineering file order. The JSON beside it contains the full per-stage inventory.

## Status legend

- **EDITABLE** — the current SDK has a source-grounded writer for the asset.
- **PARTIAL** — useful fields are editable, but the whole structure is not decoded.
- **INVENTORIED** — the SDK can find/report it but does not yet offer a semantic writer.
- **EXTERNAL** — the feature lives primarily outside the stage DAT (DOL/menu/audio/runtime).
- **UNDECODED** — preserved and catalogued, but the semantics are not safe to guess.

## Builder coverage

| Area | Asset | Status | Storage | What you can do now |
| --- | --- | --- | --- | --- |
| Project / Runtime | Stage identity & runtime routing | PARTIAL | DOL StageData + FST Gr*.dat identity | Visible SSS presentation and runtime identity are separate systems. |
| Layout | Gameplay collision geometry | EDITABLE | coll_data / MapCollData | View/edit vertices; add/split/join/delete segments; topology is reindexed safely. |
| Layout | Collision materials & behavior flags | PARTIAL | MapCollLine flags | Editable by exact source-confirmed bit fields. |
| Gameplay Markers | Player starts & respawn platform markers | EDITABLE | map_head HSD_Joint marker IDs 0x00..0x07 | World-space marker inventory and position editing. |
| Gameplay Markers | Camera frame & blast zones | EDITABLE | map_head marker IDs 0x94..0x98 | World-space bounds editor backed by marker JObjs. |
| Gameplay Markers | Stage-specific marker IDs | INVENTORIED | map_head marker pairs | Every marker is inventoried and movable by ID. |
| Layout | Collision joints / moving-platform base geometry | PARTIAL | MapJoint[] | Joint ranges/bounds are parsed; base collision can be translated. |
| Visuals | Visual scene hierarchy | PARTIAL | HSD_Joint / DObj trees reachable from map_head | JObj inventory; position/rotation/scale writer available. |
| Visuals | Textures | PARTIAL | HSD_ImageDesc + *_image publics | Dimensions/GX formats inventoried. Same-size PNG replacement supports I4/I8/IA4/IA8/RGB565/RGB5A3/RGBA8/CMPR. |
| Animation | Model / material animation tracks | INVENTORIED | HSD AnimJoint/FObj graph inside stage archive | Underlying archive structures are preserved and JObj base transforms are editable. |
| Gameplay | Global stage parameters | PARTIAL | grGroundParam | Stage scale and fixed-camera flag are source-confirmed and editable. |
| Gameplay | Stage-specific object / hazard parameters | UNDECODED | yakumono_param | Presence and raw public symbol are catalogued. |
| Gameplay | Stage item data | UNDECODED | itemdata | Presence is catalogued. |
| Effects | Particles / stage effects | INVENTORIED | map_ptcl / archive effect descriptors when present | Presence and related public symbols/textures are catalogued. |
| Visuals | Lighting | INVENTORIED | map_plit and HSD scene descriptors when present | Presence is catalogued. |
| Visuals | Texture animation/group data | INVENTORIED | map_texg when present | Presence is catalogued. |
| Effects | Stage quake/camera-shake model set | INVENTORIED | quake_model_set when present | Presence is catalogued. |
| Frontend | Stage Select icon / thumbnail / labels | PARTIAL | MnSlMap.dat/.usd + paged SSS runtime data | Paged stage model and reusable retail tile mapping exist; custom thumbnail capability is registered. |
| Audio | Music / audio routing | EXTERNAL | Runtime stage/audio tables and audio resources, not generic Gr*.dat geometry | Not part of the current Gr*.dat asset editor. |
| Runtime | Stage logic / hazards / callbacks | EXTERNAL | DOL gr*.c StageData callbacks + stage-specific state | A custom stage can reuse donor callbacks through the runtime slot author. |

## Known gameplay markers

| ID | Meaning |
| --- | --- |
| 0x00 | Player Spawn 1 |
| 0x01 | Player Spawn 2 |
| 0x02 | Player Spawn 3 |
| 0x03 | Player Spawn 4 |
| 0x04 | Respawn Platform 1 |
| 0x05 | Respawn Platform 2 |
| 0x06 | Respawn Platform 3 |
| 0x07 | Respawn Platform 4 |
| 0x94 | Camera Center |
| 0x95 | Camera Range A |
| 0x96 | Camera Range B |
| 0x97 | Blast Zone A |
| 0x98 | Blast Zone B |

All other marker IDs are retained in the per-stage inventory as **unknown/undecoded**, even though their world positions can be inspected. Do not assign a meaning to an unknown ID merely because it appears at an interesting location.

## Texture coverage across the retail corpus

| GX format | Descriptors found |
| --- | --- |
| C4 | 491 |
| C8 | 1506 |
| CMPR | 7028 |
| I4 | 220 |
| I8 | 226 |
| IA4 | 89 |
| IA8 | 333 |
| RGB565 | 409 |
| RGB5A3 | 197 |
| RGBA8 | 709 |

Same-size PNG replacement is currently enabled for non-mipmapped I4, I8, IA4, IA8, RGB565, RGB5A3, RGBA8 and CMPR. Paletted C4/C8/C14X2 require TLUT rewriting first.

## Stage architecture asset types

| Type | Meaning | Retail line records |
| --- | --- | --- |
| Ground / Base Floor | base floor | 2731 |
| Ceiling | ceiling | 1208 |
| Dynamic / Moving Platform Geometry | dynamic platform | 303 |
| Flat Walkable Surface | flat surface | 1800 |
| Grab-Enabled Edge / Ledge | ledge | 209 |
| Slope / Ramp | slope | 1761 |
| Soft / Drop-Through Platform | soft platform | 830 |
| Wall | wall | 2522 |

Collision assets are now indexed both **by type** and **by source stage**. `platform` is retained as the source-known collision flag and is presented as a soft/drop-through platform surface; ceilings remain a distinct collision category so builders can avoid accidentally adding a combo-altering overhead surface.

### Tournament / competitive reference templates

| DAT | Reference stage |
| --- | --- |
| GrIz.dat | Fountain of Dreams |
| GrNBa.dat | Battlefield |
| GrNLa.dat | Final Destination |
| GrOp.dat | Dream Land (N64) |
| GrPs.dat | Pokemon Stadium |
| GrSt.dat | Yoshi's Story |

These are convenience reference groups only; the SDK does not enforce a tournament ruleset.

## Moving-platform authoring roadmap

| Preset | Status | Purpose |
| --- | --- | --- |
| Static | READY | No motion; fixed transform. |
| Horizontal Back-and-Forth | PLANNED | Constant-height linear path that reverses at each endpoint (Smashville-like). |
| Vertical Back-and-Forth | PLANNED | Linear vertical path that reverses at each endpoint. |
| Waypoint Loop | PLANNED | Moves through an ordered closed list of points. |
| Rectangular Loop | PLANNED | Four-corner loop useful for Randall-like perimeter motion. |
| Orbit | PLANNED | Circular/elliptical motion around a center point. |
| Rotate in Place | PLANNED | Rotates a platform/object around its own pivot. |

The path presets are deliberately schema/preview targets until the AnimJoint/FObj track-to-object relationship is safe to write. Horizontal ping-pong is the intended Smashville-like first implementation; rectangle-loop is intended for Randall-like perimeter motion.

## Retail stage index

| DAT | Stage / resource | Family | Verts | Lines | Markers | JObjs | Textures | PNG-editable |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| GrBb.dat | Big Blue | Versus stage | 729 | 663 | 24 | 30 | 598 | 490 |
| GrCn.dat | Corneria | Versus stage | 72 | 65 | 20 | 21 | 435 | 417 |
| GrCs.dat | Princess Peach's Castle | Versus stage | 60 | 51 | 19 | 20 | 299 | 196 |
| GrEF1.dat | GrEF1 | Other retail stage resource | 39 | 39 | 21 | 22 | 35 | 31 |
| GrEF2.dat | GrEF2 | Other retail stage resource | 87 | 87 | 21 | 22 | 70 | 43 |
| GrEF3.dat | GrEF3 | Other retail stage resource | 38 | 38 | 21 | 22 | 44 | 29 |
| GrFs.dat | Fourside | Versus stage | 46 | 41 | 18 | 19 | 184 | 160 |
| GrFz.dat | Flat Zone | Versus stage | 177 | 108 | 14 | 15 | 20 | 19 |
| GrGb.dat | Great Bay | Versus stage | 76 | 74 | 18 | 19 | 221 | 200 |
| GrGd.dat | Jungle Japes | Versus stage | 22 | 21 | 21 | 22 | 101 | 94 |
| GrGr.dat | Green Greens | Versus stage | 160 | 158 | 22 | 23 | 194 | 180 |
| GrHe.dat | GrHe | Other retail stage resource | 11 | 11 | 11 | 12 | 110 | 37 |
| GrHr.dat | GrHr | Other retail stage resource | 13 | 12 | 8 | 9 | 172 | 172 |
| GrI1.dat | Mushroom Kingdom | Versus stage | 96 | 91 | 23 | 24 | 137 | 35 |
| GrI2.dat | Mushroom Kingdom II | Versus stage | 46 | 30 | 20 | 21 | 541 | 494 |
| GrIm.dat | Icicle Mountain | Versus stage | 738 | 556 | 116 | 180 | 963 | 963 |
| GrIz.dat | Fountain of Dreams | Versus stage | 38 | 34 | 18 | 19 | 193 | 136 |
| GrKg.dat | Kongo Jungle | Versus stage | 75 | 70 | 22 | 56 | 208 | 205 |
| GrKr.dat | Brinstar Depths | Versus stage | 102 | 98 | 16 | 17 | 194 | 179 |
| GrMc.dat | Mute City | Versus stage | 68 | 54 | 15 | 16 | 282 | 220 |
| GrNBa.dat | Battlefield | Versus stage | 26 | 23 | 21 | 22 | 49 | 44 |
| GrNBr.dat | Adventure — F-Zero Grand Prix Route | Adventure route | 109 | 98 | 20 | 21 | 347 | 218 |
| GrNFg.dat | GrNFg | Other retail stage resource | 48 | 44 | 7 | 9 | 26 | 17 |
| GrNKr.dat | Adventure — Mushroom Kingdom Route | Adventure route | 342 | 324 | 81 | 83 | 280 | 58 |
| GrNLa.dat | Final Destination | Versus stage | 16 | 16 | 21 | 22 | 68 | 68 |
| GrNPo.dat | GrNPo | Other retail stage resource | 456 | 430 | 44 | 45 | 82 | 62 |
| GrNSr.dat | Adventure — Underground Maze Route | Adventure route | 480 | 412 | 71 | 72 | 247 | 92 |
| GrNZr.dat | Adventure — Brinstar Escape Route | Adventure route | 177 | 152 | 9 | 10 | 153 | 62 |
| GrOk.dat | Kongo Jungle (N64) | Versus stage | 22 | 17 | 24 | 25 | 97 | 18 |
| GrOp.dat | Dream Land (N64) | Versus stage | 14 | 11 | 29 | 30 | 120 | 79 |
| GrOt.dat | Onett | Versus stage | 70 | 63 | 23 | 24 | 263 | 235 |
| GrOy.dat | Yoshi's Island (N64) | Versus stage | 22 | 16 | 21 | 22 | 104 | 25 |
| GrPs.dat | Pokemon Stadium | Versus stage | 155 | 136 | 20 | 24 | 136 | 76 |
| GrPs1.dat | GrPs1 | Pokémon Stadium transformation resource | 155 | 136 | 20 | 24 | 74 | 61 |
| GrPs2.dat | GrPs2 | Pokémon Stadium transformation resource | 155 | 136 | 20 | 24 | 41 | 41 |
| GrPs3.dat | GrPs3 | Pokémon Stadium transformation resource | 155 | 136 | 20 | 24 | 81 | 78 |
| GrPs4.dat | GrPs4 | Pokémon Stadium transformation resource | 155 | 136 | 20 | 24 | 100 | 100 |
| GrPu.dat | Poke Floats | Versus stage | 554 | 539 | 21 | 22 | 157 | 81 |
| GrRc.dat | Rainbow Cruise | Versus stage | 175 | 129 | 27 | 33 | 360 | 221 |
| GrSh.dat | Temple | Versus stage | 98 | 91 | 20 | 21 | 198 | 118 |
| GrSt.dat | Yoshi's Story | Versus stage | 34 | 29 | 22 | 26 | 174 | 158 |
| GrTCa.dat | GrTCa | Target-test family | 138 | 134 | 17 | 24 | 60 | 49 |
| GrTCl.dat | GrTCl | Target-test family | 67 | 65 | 20 | 24 | 28 | 28 |
| GrTDk.dat | GrTDk | Target-test family | 58 | 52 | 17 | 23 | 121 | 121 |
| GrTDr.dat | GrTDr | Target-test family | 40 | 35 | 17 | 25 | 100 | 100 |
| GrTe.dat | GrTe | Other retail stage resource | 107 | 98 | 11 | 12 | 5 | 5 |
| GrTFc.dat | GrTFc | Target-test family | 77 | 74 | 17 | 28 | 32 | 8 |
| GrTFe.dat | GrTFe | Target-test family | 28 | 24 | 21 | 36 | 31 | 31 |
| GrTFx.dat | GrTFx | Target-test family | 73 | 72 | 17 | 29 | 38 | 37 |
| GrTGn.dat | GrTGn | Target-test family | 34 | 27 | 17 | 42 | 36 | 15 |
| GrTGw.dat | GrTGw | Target-test family | 15 | 10 | 17 | 23 | 26 | 25 |
| GrTIc.dat | GrTIc | Target-test family | 257 | 235 | 17 | 81 | 137 | 130 |
| GrTKb.dat | GrTKb | Target-test family | 100 | 97 | 17 | 175 | 222 | 222 |
| GrTKp.dat | GrTKp | Target-test family | 67 | 64 | 17 | 24 | 74 | 74 |
| GrTLg.dat | GrTLg | Target-test family | 94 | 92 | 20 | 23 | 57 | 52 |
| GrTLk.dat | GrTLk | Target-test family | 57 | 56 | 17 | 60 | 66 | 66 |
| GrTMr.dat | GrTMr | Target-test family | 90 | 76 | 16 | 99 | 190 | 189 |
| GrTMs.dat | GrTMs | Target-test family | 119 | 115 | 21 | 51 | 63 | 63 |
| GrTMt.dat | GrTMt | Target-test family | 73 | 71 | 17 | 39 | 29 | 29 |
| GrTNs.dat | GrTNs | Target-test family | 76 | 75 | 17 | 30 | 175 | 175 |
| GrTPc.dat | GrTPc | Target-test family | 88 | 87 | 17 | 29 | 41 | 41 |
| GrTPe.dat | GrTPe | Target-test family | 101 | 98 | 17 | 20 | 101 | 101 |
| GrTPk.dat | GrTPk | Target-test family | 83 | 79 | 17 | 21 | 29 | 28 |
| GrTPr.dat | GrTPr | Target-test family | 101 | 92 | 17 | 77 | 82 | 82 |
| GrTSk.dat | GrTSk | Target-test family | 2 | 1 | 11 | 12 | 6 | 6 |
| GrTSs.dat | GrTSs | Target-test family | 73 | 71 | 16 | 83 | 167 | 161 |
| GrTYs.dat | GrTYs | Target-test family | 125 | 123 | 17 | 21 | 32 | 26 |
| GrTZd.dat | GrTZd | Target-test family | 50 | 47 | 17 | 57 | 72 | 63 |
| GrVe.dat | Venom | Versus stage | 69 | 64 | 19 | 20 | 681 | 615 |
| GrYt.dat | Yoshi's Island | Versus stage | 54 | 54 | 23 | 24 | 175 | 160 |
| GrZe.dat | Brinstar | Versus stage | 37 | 31 | 23 | 115 | 174 | 137 |

## How the Stage Builder should be mentally organized

1. **Identity** — choose a donor/template and decide whether this is a replacement or an independent runtime stage.
2. **Layout** — edit collision, materials, platforms and dynamic collision ownership.
3. **Gameplay Markers** — place player starts, respawns, camera and blast zones; inspect unknown stage-specific markers separately.
4. **Visuals** — position JObjs and replace compatible textures without confusing visual meshes with gameplay collision.
5. **Animation / Hazards** — keep donor behavior until animation tracks and stage-specific `yakumono_param` schemas are source-traced.
6. **Presentation** — Stage Select tile/thumbnail/name and music are separate layers and should not be hidden inside the DAT editor.

## Safety boundary

The catalogue deliberately does **not** turn unknown public symbols, marker IDs, animation tracks, hazard payloads, or material IDs into friendly names without evidence. The builder should make unknowns visible, but never pretend they are understood.
