@echo off
setlocal
cd /d "%~dp0"
set "ERRLOG=%~dp0Melee_SDK_startup_error.txt"
if exist "%ERRLOG%" del /q "%ERRLOG%" >nul 2>nul

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 melee_sdk.py 2>"%ERRLOG%"
    if %errorlevel%==0 exit /b 0
    goto :app_error
)

where python >nul 2>nul
if %errorlevel%==0 (
    python melee_sdk.py 2>"%ERRLOG%"
    if %errorlevel%==0 exit /b 0
    goto :app_error
)

echo.
echo Melee Character SDK could not start because Python was not found on PATH.
echo.
echo Install/use a Python 3 environment, then run:
echo     python melee_sdk.py
echo.
pause
exit /b 1

:app_error
echo.
echo Melee Character SDK returned an error.
echo The traceback was saved to:
echo     %ERRLOG%
echo.
if exist "%ERRLOG%" type "%ERRLOG%"
echo.
pause
exit /b 1
