# K20S validation

Automated checks cover:

- 105 targeted tests covering new stage routing and existing K20R behavior.
- All thirteen slot markers survive volatile register/cursor changes during commit.
- The synchronized gateway accepts A5–B2 and rejects unrelated markers.
- All thirteen emitted launch paths and matching play-scene exit paths.
- Race uses its native Classic bonus flags, subtype, time and stage ID.
- Versus setup retains two human identities, uses separate spawns, disables CPUs,
  removes adventure callbacks and enables stock/timer/VS rules.
- 154 executions of the emitted low dispatcher across active, inactive, campaign,
  wrong-mode, out-of-range and missing-module cases.
- Thirteen executions of the emitted file loader, including cache maintenance.
- Both authored language menus: 172 texture copies per archive across repeated
  Page 2/Default changes, with exact default restoration.
- Seven serialized arena archives reparsed, with spawn/respawn markers and
  correctly oriented upper-left/lower-right camera and blast bounds.
- Original route archives and original stock menu archives match the clean disc.
- Complete rebuilt GameCube disc size/magic and embedded DOL match.
- Final ZIP CRC check and packaged-file comparison.

Detailed generated results are in docs/K20S_verification.json and the build
manifest. docs/K20S_disc_page2_preview.png shows decoded disc textures; it is
not an emulator screenshot.

## In-game checks still required

Cold-boot the same K20S ISO on both Direct peers. Check each selection, both
characters' movement, camera, collision, death and respawn. Complete or quit
each challenge and finish each versus match; confirm return to Direct and
select another stage. Check Arwing scripting, Race timer/goal, each Link layout,
Yoshi arena boundaries, normal Page 1 matches, and full Coop Adventure.

If a selection fails, record its name, whether failure occurred on selection,
loading, gameplay or exit, and capture the relevant savestate from each peer.

## K20S1 build launcher verification

Rebuilt the full ISO through iso_build_tools.py with the corrected batch launcher
settings: coop_showcase, unlock-all, VS P2 profile, Adventure gateway, normal
difficulty, three stocks, friendly fire on, scene revive off, test shortcuts off.
The previous automatic test-shortcuts flag exceeded the runtime memory limit.
