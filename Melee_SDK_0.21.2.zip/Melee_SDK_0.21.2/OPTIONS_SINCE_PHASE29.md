# Options / Additional Content — What changed since Phase 29

If you last opened the SDK around the original Additional Content/DLC work, the registry grew from **7 capabilities in Phase 29** to **15 capabilities in Phase 39**.

## Original Phase 29 options still present

- **Expanded Stage Select** (`stage_hub`)
- **Custom / Imported Stages** (`custom_stages`)
- **2-Player Adventure** (`coop_adventure`)
- **Duo Challenges** (`duo_challenges`, experimental)
- **Stock Run** (`stock_run`, experimental)
- **Custom Stage Thumbnails** (`custom_thumbnails`, experimental)
- **Slippi-Compatible Extensions** (`slippi_extensions`, experimental)

## Added since Phase 29

- **Co-op Adventure Friendly Fire** (`coop_friendly_fire`) — used by the Chaos builds.
- **Co-op Team Survival** (`coop_team_survival`) — independent P1/P2 stocks; Adventure fails only after both humans are eliminated.
- **Co-op Camera Control** (`coop_camera_control`) — death-driven persistent Control/camera handoff.
- **C-stick in 1-Player Modes** (`one_player_cstick`) — narrow 1P C-stick enablement.
- **Either Player Can Pause** (`coop_either_player_pause`) — Co-op Adventure pause ownership.
- **Two-Player Credits Shooting** (`coop_dual_credits`) — registered and patched; **runtime P2 support was still failing in the Phase 39 benchmark, with Hotfix 2 awaiting confirmation**.
- **Either Human Triggers Adventure Events** (`coop_either_human_events`) — **runtime-confirmed working** in Phase 39; trigger authority is independent of Control/camera ownership.
- **Revive Eliminated Players Next Scene** (`coop_scene_revive`) — optional, default concept remains OFF; test BATs provide revive variants.

## Important UI reality

The backend registry and build profiles contain all 15 capabilities, but there still is **not a polished single “Options” page in the main GUI** that exposes every one as a friendly checkbox. Several options are currently selected by the dedicated BAT/profile/test-build paths instead. That is a UI consolidation task, not missing backend state.

## Current Co-op build choices

The packaged BATs give the four useful campaign combinations:

- normal Co-op Adventure
- normal + scene revive
- Chaos/friendly fire
- Chaos + scene revive

The newer campaign behaviors (team survival, Control/camera, either-human events, HUD hardening, etc.) are composed into those builds rather than requiring separate BATs for every dependency.
