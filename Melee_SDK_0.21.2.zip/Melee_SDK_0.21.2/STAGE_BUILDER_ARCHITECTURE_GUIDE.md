# Stage Builder Architecture Guide

## Build from gameplay outward

A practical Melee stage can be thought of in this order:

1. **Base floor** — the main playable solid structure.
2. **Ledges** — outer grab-enabled edges. These are first-class gameplay assets, not decoration.
3. **Soft platforms** — one-way/drop-through surfaces. Tournament-style upper platforms should not accidentally acquire ceilings.
4. **Solid structures** — geometry that can contain floor, wall and ceiling collision. Use intentionally because wall/ceiling contact changes interactions.
5. **Slopes / ramps** — walkable angled floor lines.
6. **Dynamic platforms** — collision owned by moving stage pieces.
7. **Markers** — spawns, respawns, camera and blast zones.
8. **Visuals** — JObjs, textures and eventually meshes/materials.
9. **Motion / hazards** — animation paths and stage callbacks.

## Asset browser organization

The generated retail library is organized **type first, stage second**. That means a builder can start with a gameplay need (“I need a soft platform”) and then compare how retail stages implement it.

The current release indexes collision assets and reference geometry. Copying a complete visual mesh/material/JObj package together with its collision is the next step; the SDK will not pretend collision lines alone are a finished art asset.

## Soft platforms vs ceilings

The SDK keeps Melee's source-known platform flag and collision category separate. A soft platform is shown as a floor surface with the platform flag. Ceiling collision remains its own category. This is important because adding an unintended ceiling/wall changes actual combat behavior.

## Moving platform goal

The path model already reserves common behaviors, including a Smashville-style fixed-height horizontal ping-pong and a Randall-style rectangular loop. These are schema/preview definitions today, not runtime animation writers yet.

## Preview background

The default neutral grid is designed for alignment: minor squares, major squares, and stronger world-center axes. It is intentionally visually plain so gameplay geometry stays readable.
