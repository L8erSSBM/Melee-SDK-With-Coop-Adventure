# K20S standalone-stage build fix

The user build failed before ISO reconstruction with:

- runtime end: `0x804F4CC0`
- fixed limit: `0x804F4C00`
- overflow: `0xC0`

The shipped K20S verification build ended at `0x804F4A60`, leaving `0x1A0` bytes.
The difference came from the main BAT still enabling the legacy developer
`--test-shortcuts` path while the validated K20S configuration had it disabled.
`--unlock-all` is retained; its query overrides patch retail instructions in place
and do not append low-runtime code.

Fix: the normal `BUILD_MELEE_SDK.bat` no longer passes `--test-shortcuts`. No
memory boundary was moved and no K20S standalone-stage/runtime behavior was
otherwise changed.
