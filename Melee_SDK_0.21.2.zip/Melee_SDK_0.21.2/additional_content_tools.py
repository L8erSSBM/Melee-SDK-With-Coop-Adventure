from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.additional_content import AdditionalContentProfile, full_dlc_profile, vanilla_character_only_profile, FEATURES
from sdk.adventure_install import install_phase29_runtime_framework, write_install_manifest


def main(argv=None):
    p=argparse.ArgumentParser(description='Phase 29 Additional Content / DLC profile and runtime-framework tools')
    p.add_argument('--list-features',action='store_true')
    p.add_argument('--profile',help='Load an Additional Content profile JSON')
    p.add_argument('--full-dlc',action='store_true')
    p.add_argument('--character-only',action='store_true')
    p.add_argument('--write-profile')
    p.add_argument('--write-plan')
    p.add_argument('--dol')
    p.add_argument('--symbols',default='data/runtime_symbols_GALE01.txt')
    p.add_argument('--install-framework')
    p.add_argument('--manifest')
    args=p.parse_args(argv)

    if args.list_features:
        print(json.dumps([f.__dict__ for f in FEATURES],indent=2))

    prof=None
    if args.profile: prof=AdditionalContentProfile.load(args.profile)
    elif args.full_dlc: prof=full_dlc_profile()
    elif args.character_only: prof=vanilla_character_only_profile()
    if prof:
        if args.write_profile: prof.save(args.write_profile)
        if args.write_plan: Path(args.write_plan).write_text(json.dumps(prof.build_plan(),indent=2),encoding='utf-8')

    if args.install_framework:
        if not args.dol: p.error('--install-framework requires --dol')
        m=install_phase29_runtime_framework(args.dol,args.symbols,args.install_framework)
        if args.manifest: write_install_manifest(args.manifest,m)
        else: print(json.dumps(m,indent=2))

if __name__=='__main__': main()
