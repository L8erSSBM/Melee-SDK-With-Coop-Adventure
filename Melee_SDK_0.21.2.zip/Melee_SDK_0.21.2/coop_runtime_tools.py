from __future__ import annotations
import argparse, json
from pathlib import Path
from sdk.adventure_runtime import (
    build_route_partner_atlas, preflight_runtime_dol, runtime_touchpoint_report,
    write_runtime_prep_bundle,
)
from sdk.adventure_legacy import legacy_analysis, legacy_gecko_code


def main() -> int:
    ap=argparse.ArgumentParser(description='Phase 28 co-op Adventure runtime + historical 2P research tools')
    ap.add_argument('--stage-folder', help='Folder containing retail Gr*.dat stage resources')
    ap.add_argument('--dol', help='Working/start.dol or clean GALE01 1.02 main.dol')
    ap.add_argument('--symbols', default=str(Path(__file__).parent/'data'/'runtime_symbols_GALE01.txt'))
    ap.add_argument('--bundle', help='Write a complete co-op runtime preparation bundle to this folder')
    ap.add_argument('--route-atlas', help='Write route partner atlas JSON')
    ap.add_argument('--preflight', help='Write DOL hook-site preflight JSON')
    ap.add_argument('--touchpoints', help='Write source-grounded touchpoint report JSON')
    ap.add_argument('--legacy-analysis', help='Write decoded Nick Reynolds 2P Adventure analysis JSON')
    ap.add_argument('--legacy-gecko', help='Write the historical 18-line Gecko code to this file')
    ap.add_argument('--character-id', type=lambda x:int(x,0), help='Character ID used for --legacy-gecko (e.g. 0x12)')
    ns=ap.parse_args()
    did=False
    if ns.route_atlas:
        if not ns.stage_folder: ap.error('--route-atlas requires --stage-folder')
        Path(ns.route_atlas).write_text(json.dumps(build_route_partner_atlas(ns.stage_folder),indent=2),encoding='utf-8'); did=True
    if ns.preflight:
        if not ns.dol: ap.error('--preflight requires --dol')
        Path(ns.preflight).write_text(json.dumps(preflight_runtime_dol(ns.dol,ns.symbols),indent=2),encoding='utf-8'); did=True
    if ns.touchpoints:
        Path(ns.touchpoints).write_text(json.dumps(runtime_touchpoint_report(),indent=2),encoding='utf-8'); did=True
    if ns.legacy_analysis:
        Path(ns.legacy_analysis).write_text(json.dumps(legacy_analysis(),indent=2),encoding='utf-8'); did=True
    if ns.legacy_gecko:
        if ns.character_id is None: ap.error('--legacy-gecko requires --character-id')
        Path(ns.legacy_gecko).write_text(legacy_gecko_code(ns.character_id),encoding='utf-8'); did=True
    if ns.bundle:
        write_runtime_prep_bundle(ns.bundle,stage_folder=ns.stage_folder,dol_path=ns.dol,
                                  symbols_path=ns.symbols if ns.dol else None)
        did=True
    if not did:
        print(json.dumps(runtime_touchpoint_report(),indent=2))
    return 0

if __name__=='__main__':
    raise SystemExit(main())
