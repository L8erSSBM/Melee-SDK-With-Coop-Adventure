from __future__ import annotations

import math


def pretty_name(name: str) -> str:
    replacements = {
        'vel': 'velocity', 'mul': 'multiplier', 'accel': 'acceleration',
        'hi': 'up', 'lw': 'down', 'airn': 'neutral air', 'airf': 'forward air',
        'airb': 'back air', 'airhi': 'up air', 'airlw': 'down air',
        'kb': 'knockback', 'sfx': 'sound', 'unk': 'unknown',
    }
    parts = name.split('_')
    parts = [replacements.get(p, p) for p in parts]
    return ' '.join(parts).replace('  ', ' ').title()


COMMON_ATTR_GROUP_ORDER = [
    'Ground Movement',
    'Jump',
    'Air Physics',
    'Landing',
    'Combat / Shield',
    'Ledge / Wall',
    'Other',
]


def category_for_attr(name: str) -> str:
    """Human-facing grouping for per-character common attributes.

    Ordering is deliberate. Landing-air fields contain the word ``air`` but are
    landing lag, while jump parameters are separated from persistent airborne
    physics so users can copy/tune one subsystem without unintentionally
    changing the other.
    """
    if 'landing' in name:
        return 'Landing'
    if any(k in name for k in ('walk', 'dash', 'run', 'ground_max', 'ground_friction', 'standing_turn')):
        return 'Ground Movement'
    if any(k in name for k in ('jump_', 'jump_startup', 'ground_to_air_jump', 'hop_', 'max_jumps')):
        return 'Jump'
    if any(k in name for k in ('gravity', 'terminal_velocity', 'air_drift', 'aerial_drift', 'aerial_friction', 'fast_fall', 'air_max_horizontal')):
        return 'Air Physics'
    if any(k in name for k in ('shield', 'jab', 'clank', 'hit_spark', 'item_throw', 'heavy_throw', 'specials_ground', 'rapid_jab')):
        return 'Combat / Shield'
    if any(k in name for k in ('wall', 'ledge', 'passive')):
        return 'Ledge / Wall'
    return 'Other'


def decimal_text(value, typ: str) -> str:
    if typ == 'int':
        return str(int(value))
    v = float(value)
    if not math.isfinite(v):
        return str(v)
    # Preserve useful precision without exposing IEEE-754 noise such as
    # 0.20000000298023224. Six decimals is finer than practical UI editing needs.
    s = f'{v:.6f}'.rstrip('0').rstrip('.')
    return '0' if s in ('-0', '') else s


# UI editing policy. A slider is shown only when the field has a reasonably
# understandable numeric continuum/range. Other numeric fields remain editable
# through direct base-10 entry. Boolean/state fields should use checkboxes.
# This is deliberately conservative: a field being numeric in the DAT does not
# automatically make a slider a good or safe UI control.
SLIDER_FIELDS = {
    # Per-character movement / physics
    'walk_accel_mul','walk_accel_base','walk_max_vel','slow_walk_max','mid_walk_point','fast_walk_min',
    'ground_friction','dash_initial_velocity','dash_accel_mul','dash_accel_base','dash_max_velocity',
    'ground_max_horizontal_velocity','jump_startup_time','jump_h_initial_velocity','jump_v_initial_velocity',
    'ground_to_air_jump_momentum_multiplier','jump_h_max_velocity','hop_v_initial_velocity',
    'air_jump_v_multiplier','air_jump_h_multiplier','max_jumps','gravity','terminal_velocity',
    'air_drift_stick_mul','aerial_drift_base','air_drift_max','aerial_friction','fast_fall_velocity',
    'air_max_horizontal_velocity','weight','model_scaling','initial_shield_size','normal_landing_lag',
    'landingairn_lag','landingairf_lag','landingairb_lag','landingairhi_lag','landingairlw_lag',

    # Global input / timing controls with clear bounded semantics
    'horizontal_stick_deadzone','vertical_stick_deadzone','shield_press_threshold','walk_stick_threshold',
    'dash_smash_stick_threshold','dash_smash_window','tap_jump_threshold','tap_jump_window',
    'tap_jump_release_threshold','relaxed_tap_jump_threshold',

    # Air dodge
    'escapeair_deadzone_x','escapeair_deadzone_y','escapeair_timer','escapeair_force','escapeair_decay',

    # Other well-understood numeric mechanics
    'kb_squat_mul','aerial_friction_oob','knockback_frame_decay','start_shield_health',
    'powershield_input_window','shield_knockback_frame_decay','shield_ground_friction_multiplier',
    'teeter_walk_threshold','ledge_cooldown','sdi_min_stick_mag','sdi_stick_window','sdi_pos_scale',
    'kb_ice_mul','damageice_gravity_mult','kb_smashcharge_mul',
}


def editor_mode(name: str, typ: str) -> str:
    """Return 'toggle', 'slider', or 'number' for a field.

    The DAT storage type and the best UI control are separate concepts.
    Only true boolean/state fields become toggles. A numeric threshold such as
    metal_armor remains a number even though it belongs to a status mechanic.
    """
    if typ == 'bool':
        return 'toggle'
    if name in SLIDER_FIELDS:
        return 'slider'
    return 'number'


def slider_spec(name: str, value: float, typ: str) -> tuple[float, float, float]:
    """Friendly editing range. It is a UI aid, not a validation/clamp rule.

    Values can always be typed directly outside this range.
    """
    # Global Air Dodge controls have deliberately narrow, human-friendly ranges.
    # These are slider ranges only; direct text entry is still allowed outside them.
    if name == 'escapeair_timer': return (0, 30, 1)
    if name in ('escapeair_deadzone_x', 'escapeair_deadzone_y'): return (0, 1.0, 0.01)
    if name == 'escapeair_force': return (0, 10.0, 0.05)
    if name == 'escapeair_decay': return (0, 1.0, 0.01)
    if name in ('horizontal_stick_deadzone','vertical_stick_deadzone','shield_press_threshold','walk_stick_threshold','dash_smash_stick_threshold','tap_jump_threshold','tap_jump_release_threshold','relaxed_tap_jump_threshold','sdi_min_stick_mag','teeter_walk_threshold'): return (0, 1.0, 0.01)
    if name in ('dash_smash_window','tap_jump_window','powershield_input_window','ledge_cooldown','sdi_stick_window'): return (0, 120, 1)
    if name in ('kb_squat_mul','shield_ground_friction_multiplier','kb_ice_mul','damageice_gravity_mult','kb_smashcharge_mul','hit_weight_mul','passive_wall_vel_y_base'): return (0, 3.0, 0.01)
    if name in ('knockback_frame_decay','shield_knockback_frame_decay','aerial_friction_oob','grab_timer_decrement'): return (0, max(2.0, value * 3 + 0.1), 0.01)
    if name in ('start_shield_health','metal_armor','max_grounded_kb_on_landing','sdi_pos_scale','kb_min'): return (0, max(120.0, value * 2 + 10), 0.1)

    if typ == 'int':
        if name == 'max_jumps': return (0, 10, 1)
        if 'variant' in name or 'bone' in name: return (0, max(20, value * 2 + 2), 1)
        return (0, max(120, value * 2 + 10), 1)
    if name == 'weight': return (1, 150, 1)
    if name == 'model_scaling': return (0.1, 3.0, 0.01)
    if 'shield_size' in name: return (0, max(100, value * 2), 0.5)
    if any(k in name for k in ('lag', 'frames', 'window', 'time', 'duration', 'delay')):
        return (0, max(120, value * 2 + 10), 1)
    if 'angle' in name: return (-360, 361, 1)
    if any(k in name for k in ('multiplier', '_mul', 'retention', 'friction', 'scaling')):
        return (0, max(3.0, value * 2 + .5), 0.01)
    if any(k in name for k in ('velocity', '_vel', 'speed', 'gravity', 'accel', 'drift')):
        return (-10, max(10, abs(value) * 2 + 1), 0.01)
    span = max(10.0, abs(value) * 2 + 1)
    return (-span if value < 0 else 0, span, 0.01)



# State/effect-family metadata for the Global Mechanics UI.  A family can
# combine editable PlCo.dat tuning values with read-only runtime state facts.
# This keeps related mechanics together without pretending runtime Fighter flags
# are stored in PlCo.dat.
GLOBAL_STATE_FAMILIES = {
    'Metal': {
        'description': 'Metal is a runtime fighter state. PlCo.dat supplies the shared armor amount used while that state is active.',
        'fields': ['metal_armor'],
        'runtime_toggles': [
            ('force_metal', 'Force Metal for selected character', 'Project runtime override. This is saved as project intent; a code-patch backend is still required before Build can make it active in-game.'),
        ],
        'state_facts': [
            ('Current Metal state', 'Fighter.is_metal', 'Runtime boolean; not stored in PlCo.dat.'),
            ('Always-Metal state', 'Fighter.is_always_metal', 'Initialized from the player Metal flag; used by modes such as Classic Metal Mario.'),
            ('Metal duration', 'Fighter.metal_timer', 'Runtime timer used for temporary Metal state.'),
            ('Metal visuals', 'ftmetal / ftmaterial', 'Rendering/material behavior follows the same Metal state.'),
        ],
    },
    'Frozen / Ice': {
        'description': 'Frozen behavior is tied to the DamageIce state. These PlCo.dat values modify knockback and gravity only while that state is active.',
        'fields': ['kb_ice_mul', 'damageice_gravity_mult'],
        'runtime_toggles': [
            ('start_frozen', 'Start selected character Frozen', 'Project runtime override. This is saved as project intent; a code-patch backend is still required before Build can force the DamageIce state in-game.'),
        ],
        'state_facts': [
            ('Frozen state', 'DamageIce action state', 'Runtime action/status; not a persistent PlCo.dat toggle.'),
            ('Normal gravity', 'fighter Common Attributes', 'Per-character gravity remains the base value; the frozen multiplier scales it.'),
        ],
    },
    'Smash Charge': {
        'description': 'Smash charging is an action/script-driven state. PlCo.dat provides the shared knockback multiplier applied to charged smash attacks.',
        'fields': ['kb_smashcharge_mul'],
        'state_facts': [
            ('Charge state', 'Smash-attack action/script state', 'Entered by move logic; not a global on/off flag in PlCo.dat.'),
            ('Charge timing/rate', 'Action command data', 'Charge frames/rate are encoded in move scripts and should be edited with the move system, not this global value.'),
        ],
    },
    'Weight / Hit Calculation': {
        'description': 'Shared calculation constants rather than a status toggle.',
        'fields': ['hit_weight_mul'],
        'state_facts': [
            ('Scope', 'Common damage/knockback calculation', 'Numeric engine constant; applies where the common calculation uses it.'),
        ],
    },
}

def move_group(action_name: str) -> tuple[str, str]:
    """Return a conservative UI group for a Melee action-state name.

    Ordering matters: item throws/swings are classified before fighter throws,
    and AttackDash is classified before locomotion. Unknown states remain
    visible under Unclassified instead of being assigned speculative semantics.
    """
    n = (action_name or '').strip()
    l = n.lower()

    # Grounded attacks first so AttackDash can never fall into movement.
    if l.startswith('attackdash'):
        return ('Grounded Attacks', 'Dash Attack')
    if l.startswith(('attack11','attack12','attack13','attack100')):
        return ('Grounded Attacks', 'Jab / Rapid Jab')
    if l.startswith(('attacks3','attackhi3','attacklw3')):
        return ('Grounded Attacks', 'Tilts')
    if l.startswith(('attacks4','attackhi4','attacklw4')):
        return ('Grounded Attacks', 'Smash Attacks')

    # Aerial normals and their landing states.
    aerial_map = {
        'attackairn': 'Neutral Air', 'attackairf': 'Forward Air',
        'attackairb': 'Back Air', 'attackairhi': 'Up Air', 'attackairlw': 'Down Air',
        'landingairn': 'Aerial Landing', 'landingairf': 'Aerial Landing',
        'landingairb': 'Aerial Landing', 'landingairhi': 'Aerial Landing',
        'landingairlw': 'Aerial Landing',
    }
    for prefix, sub in aerial_map.items():
        if l.startswith(prefix):
            return ('Aerial Attacks', sub)

    # Item interactions. Light/HeavyThrow are item-throw states, not character throws.
    if l.startswith(('item', 'swing', 'lightget', 'heavyget', 'lightthrow', 'heavythrow',
                     'heavywalk', 'lift', 'itemparasol', 'itemhammer')):
        if 'scope' in l or 'shoot' in l:
            sub = 'Projectile Items / Super Scope'
        elif 'screw' in l:
            sub = 'Screw Attack'
        elif l.startswith('swing'):
            sub = 'Item Swings'
        elif 'throw' in l or l.startswith(('lightget','heavyget','heavywalk','lift')):
            sub = 'Item Pickup / Carry / Throw'
        elif 'hammer' in l:
            sub = 'Hammer'
        elif 'parasol' in l:
            sub = 'Parasol'
        else:
            sub = 'Other Item Actions'
        return ('Items / Item Actions', sub)

    # Character grabs and throws.
    if l.startswith(('catch','throw')):
        return ('Grabs / Throws', 'Grab / Character Throw')

    # Character-specific specials generally contain SpecialN/S/Hi/Lw.
    if l.startswith('special') or any(x in l for x in ('specialn','specials','specialhi','speciallw')):
        if 'specialn' in l: sub='Neutral Special'
        elif 'specialhi' in l: sub='Up Special'
        elif 'speciallw' in l: sub='Down Special'
        elif 'specials' in l: sub='Side Special'
        else: sub='Special / Other'
        return ('Special Moves', sub)

    # Movement / locomotion. Keep this after attacks/items.
    if l.startswith(('wait','walk','dash','run','turn','jump','fall','squat','landing','pass','ottotto')):
        if l.startswith('wait'): sub='Idle'
        elif l.startswith(('walk','run')): sub='Walk / Run'
        elif l.startswith(('dash','turn')): sub='Dash / Turn'
        elif l.startswith(('jump','fall')): sub='Jump / Fall'
        elif l.startswith('squat'): sub='Crouch'
        elif l.startswith('landing'): sub='Landing'
        else: sub='Other Movement'
        return ('Movement', sub)

    # Defense/evasion. EscapeAir is intentionally here, but the SDK cross-links it
    # to Global Mechanics because its initial speed/decay live in PlCo.dat.
    if l.startswith(('guard','escape','rebound','down','passive')):
        return ('Defense / Evasion', 'Shield / Dodge / Recovery')

    if l.startswith(('cliff','ledge')):
        return ('Ledge Actions', 'Ledge')

    # Fighter reactions/statuses. FuraSleep and MissFoot are gameplay states rather
    # than effect DATs, so keep them distinct from visual effects/resources.
    if l.startswith(('damage','damagefly','furafura','furasleep','capture','dead','rebirth','missfoot','stopwall','stopceil')):
        if l.startswith(('furafura','furasleep')): sub='Dizzy / Sleep'
        elif l.startswith('missfoot'): sub='Slip / Misstep'
        elif l.startswith(('dead','rebirth')): sub='Death / Respawn'
        elif l.startswith('capture'): sub='Captured / Grabbed'
        else: sub='Damage / Knockback'
        return ('Status / Reactions', sub)

    return ('Unclassified', 'Unclassified')

def move_friendly_name(action_name: str) -> str:
    """Human-readable action labels while preserving exact engine names elsewhere."""
    exact = {
        'Attack11':'Jab 1', 'Attack12':'Jab 2', 'Attack13':'Jab 3',
        'Attack100Start':'Rapid Jab Start', 'Attack100Loop':'Rapid Jab Loop', 'Attack100End':'Rapid Jab End',
        'AttackDash':'Dash Attack',
        'AttackS3S':'Forward Tilt', 'AttackS3Hi':'Forward Tilt (High)', 'AttackS3HiS':'Forward Tilt (High-mid)',
        'AttackS3Lw':'Forward Tilt (Low)', 'AttackS3LwS':'Forward Tilt (Low-mid)',
        'AttackHi3':'Up Tilt', 'AttackLw3':'Down Tilt',
        'AttackS4':'Forward Smash', 'AttackS4S':'Forward Smash', 'AttackS4Hi':'Forward Smash (High)', 'AttackS4HiS':'Forward Smash (High-mid)',
        'AttackS4Lw':'Forward Smash (Low)', 'AttackS4LwS':'Forward Smash (Low-mid)',
        'AttackHi4':'Up Smash', 'AttackLw4':'Down Smash',
        'AttackAirN':'Neutral Air', 'AttackAirF':'Forward Air', 'AttackAirB':'Back Air',
        'AttackAirHi':'Up Air', 'AttackAirLw':'Down Air',
        'LandingAirN':'Neutral Air Landing', 'LandingAirF':'Forward Air Landing',
        'LandingAirB':'Back Air Landing', 'LandingAirHi':'Up Air Landing', 'LandingAirLw':'Down Air Landing',
        'GuardOn':'Shield Startup', 'Guard':'Shield', 'GuardOff':'Shield Release', 'GuardDamage':'Shield Stun',
        'EscapeN':'Spot Dodge', 'EscapeF':'Forward Roll', 'EscapeB':'Back Roll', 'EscapeAir':'Air Dodge',
        'Wait1':'Idle / Wait 1', 'Wait2':'Idle / Wait 2', 'WalkSlow':'Walk (Slow)',
        'WalkMiddle':'Walk (Medium)', 'WalkFast':'Walk (Fast)', 'Turn':'Turn', 'TurnRun':'Run Turn',
        'Dash':'Dash', 'Run':'Run', 'RunBrake':'Run Brake', 'JumpF':'Jump Forward', 'JumpB':'Jump Back',
        'JumpAerialF':'Double Jump Forward', 'JumpAerialB':'Double Jump Back', 'Fall':'Fall',
        'FallF':'Fall Forward', 'FallB':'Fall Back', 'FallAerial':'Aerial Fall', 'FallSpecial':'Special Fall',
        'Squat':'Crouch Start', 'SquatWait':'Crouch', 'SquatRv':'Crouch End',
    }
    return exact.get(action_name, action_name)
