from __future__ import annotations

import importlib
from dataclasses import dataclass, asdict
from pathlib import Path

REQUIRED_MODULES = [
    'sdk.melee_dat','sdk.workspace','sdk.gamecube_iso','sdk.stage','sdk.stage_assets',
    'sdk.package_import','sdk.dol_patch','sdk.action_state','sdk.stage_slot',
    'sdk.character_slot','sdk.runtime_authoring','sdk.menu_archives','sdk.game_modes','sdk.event_match',
    'sdk.adventure_coop', 'sdk.adventure_runtime','sdk.one_player_resources'
]
REQUIRED_FILES = ['melee_sdk.py','Launch_Melee_SDK.bat','quick_inject.py','slot_tools.py','mode_tools.py','event_tools.py','adventure_tools.py','one_player_tools.py','coop_runtime_tools.py']

@dataclass
class HealthCheck:
    name: str
    ok: bool
    detail: str


def audit_sdk(root: str|Path) -> list[HealthCheck]:
    root=Path(root)
    out=[]
    for fn in REQUIRED_FILES:
        p=root/fn; out.append(HealthCheck(f'file:{fn}',p.is_file(),str(p)))
    for mod in REQUIRED_MODULES:
        try:
            importlib.import_module(mod); out.append(HealthCheck(f'import:{mod}',True,'ok'))
        except Exception as exc:
            out.append(HealthCheck(f'import:{mod}',False,f'{type(exc).__name__}: {exc}'))
    caches=list(root.rglob('__pycache__'))+list(root.rglob('*.pyc'))
    out.append(HealthCheck('distribution:no-python-caches',not caches,f'{len(caches)} cache artifact(s) present'))
    return out
