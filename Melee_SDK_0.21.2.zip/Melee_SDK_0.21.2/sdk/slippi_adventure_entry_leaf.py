from __future__ import annotations

import struct

from .ppc import encode_bc, lis, lbz, lwz, cmpwi, andi_dot, ori, blr, nop, addi, li, stb

MARKER = b'MSDK022T'
WRAPPER_CAPACITY = 0x140
GM_CURRENT_MODE_ADDR = 0x80479D30
GM_ADVENTURE = 4
HSD_PAD_COPY_STATUS = 0x804C20BC
PAD_STATUS_STRIDE = 0x44
PAD_BUTTON_START = 0x1000
ADVENTURE_PRESENTATION_STATES = (
    0x00,0x02,0x08,0x10,0x18,0x1A,0x1C,0x20,0x22,0x24,0x28,0x2A,
    0x30,0x38,0x39,0x40,0x48,0x50,0x52,0x58,0x5A,0x5B,0x5D,
)

# Trace stages written into one of the now-retired HF21 diagnostic bytes.  The
# wrapper never calls out to another SDK helper, so if a Slippi failure remains
# a savestate/memory dump can distinguish how far the leaf itself executed.
TRACE_STAGE_ENTRY = 0x21
TRACE_STAGE_RETAIL_RESULT = 0x22
TRACE_STAGE_PRESENTATION = 0x23
TRACE_STAGE_P2_READ = 0x24
TRACE_STAGE_RETURN = 0x25
TRACE_STAGES = {
    TRACE_STAGE_ENTRY: 'entered presentation accessor leaf',
    TRACE_STAGE_RETAIL_RESULT: 'inline retail pad result complete',
    TRACE_STAGE_PRESENTATION: 'Adventure presentation state matched',
    TRACE_STAGE_P2_READ: 'P2 Start word read/tested',
    TRACE_STAGE_RETURN: 'leaf reached final return',
}


def _word(v: int) -> bytes:
    return struct.pack('>I', int(v) & 0xFFFFFFFF)


def _mulli(rt: int, ra: int, imm: int) -> bytes:
    return _word((7 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) | (imm & 0xFFFF))


def _add(rt: int, ra: int, rb: int) -> bytes:
    return _word((31 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) | ((rb & 31) << 11) | (266 << 1))


def _rlwinm(rt: int, rs: int, sh: int, mb: int, me: int) -> bytes:
    return _word((21 << 26) | ((rs & 31) << 21) | ((rt & 31) << 16) |
                 ((sh & 31) << 11) | ((mb & 31) << 6) | ((me & 31) << 1))


def _addr_parts(addr: int) -> tuple[int, int]:
    lo = int(addr) & 0xFFFF
    signed_lo = lo - 0x10000 if lo & 0x8000 else lo
    hi = ((int(addr) - signed_lo) >> 16) & 0xFFFF
    return hi, signed_lo


def build_leaf_wrapper(base: int, trace_stage_addr: int) -> bytes:
    """Call-free gm_GetButtonsTriggered replacement for gateway co-op.

    0.20.0 proved Slippi could clobber the tiny helper at 0x804DFB40.
    0.20.1 moved that helper, but runtime still collapsed into low memory during
    Adventure entry.  0.20.2 removes the helper/call/return dependency entirely:
    the retail pad lookup is executed inline and P2 Start is read directly.

    Five breadcrumb values are written to an otherwise-retired HF21 diagnostic
    byte.  They do not alter branching or call external code.
    """
    out = bytearray()
    trace_hi, trace_lo = _addr_parts(trace_stage_addr)

    # Preserve requested pad index; preload trace-page base once.  r6/r7/r8 are
    # volatile scratch registers and are not part of the retail return contract.
    out += addi(6, 3, 0)
    out += lis(8, trace_hi)
    out += li(7, TRACE_STAGE_ENTRY)
    out += stb(7, trace_lo, 8)

    # Exact retail gm_GetButtonsTriggered body, minus its final blr.
    out += _rlwinm(0, 3, 0, 24, 31)
    out += _mulli(0, 0, 0x30)
    out += lis(3, 0x8048)
    out += addi(3, 3, -0x63D0)  # 0x80479C30
    out += _add(4, 3, 0)
    out += lwz(3, 0x08, 4)
    out += lwz(4, 0x0C, 4)
    out += li(7, TRACE_STAGE_RETAIL_RESULT)
    out += stb(7, trace_lo, 8)

    # Only pad 0 gets the P2 Start mirror.
    out += cmpwi(6, 0, crf=7)
    b_not_p0 = len(out); out += b'\0' * 4

    # Defense-in-depth: normal non-Adventure traffic must remain retail.
    out += lis(5, 0x8048)
    out += lbz(5, -0x62D0, 5)  # 0x80479D30
    out += cmpwi(5, GM_ADVENTURE, crf=7)
    b_not_adv = len(out); out += b'\0' * 4

    # Current state byte is current_mode+3.
    out += lis(5, 0x8048)
    out += lbz(5, -0x62CD, 5)  # 0x80479D33
    eq_branches = []
    for state in ADVENTURE_PRESENTATION_STATES:
        out += cmpwi(5, state, crf=7)
        pos = len(out); out += b'\0' * 4
        eq_branches.append(pos)
    b_no_state = len(out); out += b'\0' * 4

    presentation = base + len(out)
    out += li(7, TRACE_STAGE_PRESENTATION)
    out += stb(7, trace_lo, 8)

    # Read the exact P2 button-trigger word that the old second accessor call
    # returned: HSD_PAD_COPY_STATUS + stride + 0x0C.
    p2_word = HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE + 0x0C
    p2_hi, p2_lo = _addr_parts(p2_word)
    out += lis(5, p2_hi)
    out += lwz(5, p2_lo, 5)
    out += andi_dot(5, 5, PAD_BUTTON_START)
    out += li(7, TRACE_STAGE_P2_READ)
    out += stb(7, trace_lo, 8)
    b_no_start = len(out); out += b'\0' * 4
    out += ori(4, 4, PAD_BUTTON_START)

    done = base + len(out)
    out += li(7, TRACE_STAGE_RETURN)
    out += stb(7, trace_lo, 8)
    out += blr()

    out[b_not_p0:b_not_p0+4] = encode_bc(base+b_not_p0, done, bo=4, bi=30)
    out[b_not_adv:b_not_adv+4] = encode_bc(base+b_not_adv, done, bo=4, bi=30)
    for pos in eq_branches:
        out[pos:pos+4] = encode_bc(base+pos, presentation, bo=12, bi=30)
    out[b_no_state:b_no_state+4] = encode_bc(base+b_no_state, done, bo=20, bi=0)
    out[b_no_start:b_no_start+4] = encode_bc(base+b_no_start, done, bo=12, bi=2)

    if len(out) > WRAPPER_CAPACITY:
        raise ValueError(f'0.20.2 traced leaf is 0x{len(out):X}, exceeds 0x{WRAPPER_CAPACITY:X} slot')
    return bytes(out)


def build_campaign_leaf_wrapper(base: int, trace_stage_addr: int, *, origin_addr: int) -> bytes:
    """0.20.21C presentation leaf with Direct barrier integrated in-place.

    This leaf is already reached through the HF29G + SDK 0.20 mode-first
    active-campaign dispatch chain.  Integrating the Direct barrier here avoids
    adding another hook-site wrapper around a tail-dispatch stub.
    """
    out = bytearray()

    # Preserve requested logical pad index in volatile r6.
    out += addi(6, 3, 0)

    # Exact retail gm_GetButtonsTriggered body, minus final blr.
    out += _rlwinm(0, 3, 0, 24, 31)
    out += _mulli(0, 0, 0x30)
    out += lis(3, 0x8048)
    out += addi(3, 3, -0x63D0)
    out += _add(4, 3, 0)
    out += lwz(3, 0x08, 4)
    out += lwz(4, 0x0C, 4)

    out += cmpwi(6, 0, crf=7)
    b_not_p0 = len(out); out += b'\0' * 4

    mode_hi, mode_lo = _addr_parts(GM_CURRENT_MODE_ADDR)
    out += lis(5, mode_hi)
    out += lbz(5, mode_lo, 5)
    out += cmpwi(5, GM_ADVENTURE, crf=7)
    b_not_adv = len(out); out += b'\0' * 4

    state_hi, state_lo = _addr_parts(GM_CURRENT_MODE_ADDR + 3)
    out += lis(5, state_hi)
    out += lbz(5, state_lo, 5)
    eq_branches = []
    for state in ADVENTURE_PRESENTATION_STATES:
        out += cmpwi(5, state, crf=7)
        pos = len(out); out += b'\0' * 4
        eq_branches.append(pos)
    b_no_state = len(out); out += b'\0' * 4

    presentation = base + len(out)

    # Direct-origin campaign: deterministic presentation authority.
    origin_hi, origin_lo = _addr_parts(origin_addr)
    out += lis(5, origin_hi)
    out += lbz(5, origin_lo, 5)
    out += cmpwi(5, 8, crf=7)
    b_direct = len(out); out += b'\0' * 4

    # Local-VS fallback retains the proven physical-P2 Start mirror.
    p2_word = HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE + 0x0C
    p2_hi, p2_lo = _addr_parts(p2_word)
    out += lis(5, p2_hi)
    out += lwz(5, p2_lo, 5)
    out += andi_dot(5, 5, PAD_BUTTON_START)
    b_no_start = len(out); out += b'\0' * 4

    force = base + len(out)
    out += ori(4, 4, PAD_BUTTON_START)
    done = base + len(out)
    out += blr()

    out[b_not_p0:b_not_p0+4] = encode_bc(base+b_not_p0, done, bo=4, bi=30)
    out[b_not_adv:b_not_adv+4] = encode_bc(base+b_not_adv, done, bo=4, bi=30)
    for pos in eq_branches:
        out[pos:pos+4] = encode_bc(base+pos, presentation, bo=12, bi=30)
    out[b_no_state:b_no_state+4] = encode_bc(base+b_no_state, done, bo=20, bi=0)
    out[b_direct:b_direct+4] = encode_bc(base+b_direct, force, bo=12, bi=30)
    out[b_no_start:b_no_start+4] = encode_bc(base+b_no_start, done, bo=12, bi=2)

    if len(out) > WRAPPER_CAPACITY:
        raise ValueError(
            f'0.20.21C integrated presentation leaf is 0x{len(out):X}, '
            f'exceeds 0x{WRAPPER_CAPACITY:X} slot')
    return bytes(out)


def install(dol, runtime_index: int, *, presentation_wrapper_addr: int,
            trace_stage_addr: int, origin_addr: int | None = None,
            wrapper_capacity: int = WRAPPER_CAPACITY) -> dict:
    if origin_addr is None:
        wrapper = build_leaf_wrapper(presentation_wrapper_addr, trace_stage_addr)
        policy = 'call-free traced leaf: inline exact retail pad accessor, direct P2 Start read, five breadcrumb stages, no SDK helper/trampoline execution'
    else:
        wrapper = build_campaign_leaf_wrapper(
            presentation_wrapper_addr, trace_stage_addr, origin_addr=origin_addr)
        policy = ('0.20.21C integrated presentation barrier: Direct-origin campaigns '
                  'inject logical Start in the existing active leaf; local-VS '
                  'campaigns retain raw-P2 Start mirror; no additional hook-site wrapper')
    if wrapper_capacity % 4 or len(wrapper) > wrapper_capacity:
        raise ValueError('Presentation leaf exceeds its allocated runtime slot')
    padded = wrapper + nop() * ((wrapper_capacity - len(wrapper)) // 4)
    dol.patch_at_address(presentation_wrapper_addr, padded)
    return {
        'marker': MARKER.decode('ascii'),
        'presentation_wrapper': presentation_wrapper_addr,
        'wrapper_size': len(wrapper),
        'wrapper_capacity': wrapper_capacity,
        'helper_calls': 0,
        'p2_start_word': HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE + 0x0C,
        'presentation_states': list(ADVENTURE_PRESENTATION_STATES),
        'trace_stage_address': trace_stage_addr,
        'trace_stages': {f'0x{k:02X}': v for k, v in TRACE_STAGES.items()},
        'policy': policy,
        'origin_address': origin_addr,
        'direct_barrier_integrated': origin_addr is not None,
        'runtime_evidence': '0.20.21B builder logs proved an outer presentation wrapper was composition-order dependent; 0.20.21C integrates Direct presentation authority into the existing active leaf slot',
    }
