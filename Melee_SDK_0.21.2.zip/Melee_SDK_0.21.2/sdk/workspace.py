from __future__ import annotations

import hashlib
import json
import shutil
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .project_migration import normalize_manifest, compatibility_report, upgrade_project_metadata, create_test_clone

from .melee_dat import FighterDAT, CommonFighterDAT, HSDArchive, rename_hsd_public_symbol
from .stage import StageDAT, CATALOG_BY_FILENAME

MANIFEST_NAME = 'melee_project.json'


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class FighterResource:
    fighter_name: str
    base_filename: str
    aj_filename: str | None
    related_files: list[str]


@dataclass
class StageResource:
    filename: str
    display_name: str
    source_relative: str


class MeleeProject:
    """Safe workspace around an extracted Melee filesystem.

    Original/ is an immutable snapshot of Pl*.dat resources at project creation.
    Working/ contains files the editor is allowed to modify.
    Build/ contains only changed files, ready to copy back into an extracted disc.
    The user's source extraction is never written to by this class.
    """

    def __init__(self, root: str | Path):
        self.root = Path(root).resolve()
        self.manifest_path = self.root / MANIFEST_NAME
        if not self.manifest_path.exists():
            raise FileNotFoundError(f'{MANIFEST_NAME} not found in {self.root}')
        self.manifest: dict[str, Any] = normalize_manifest(json.loads(self.manifest_path.read_text(encoding='utf-8')))
        self.original_dir = self.root / 'Original'
        self.working_dir = self.root / 'Working'
        self.build_dir = self.root / 'Build'
        self.fighters = self._load_fighters()
        self.stages = self._load_stages()

    @classmethod
    def create(cls, source_root: str | Path, project_root: str | Path) -> 'MeleeProject':
        source_root = Path(source_root).resolve()
        project_root = Path(project_root).resolve()
        if not source_root.is_dir():
            raise ValueError('The source folder does not exist.')
        project_root.mkdir(parents=True, exist_ok=True)
        original = project_root / 'Original'
        working = project_root / 'Working'
        build = project_root / 'Build'
        for d in (original, working, build):
            d.mkdir(exist_ok=True)

        # Phase 14 snapshots fighter and stage DAT resources. Source remains read-only.
        fighter_found = {p.resolve() for p in source_root.rglob('Pl*.dat') if p.is_file()}
        stage_found = {p.resolve() for p in source_root.rglob('Gr*.dat') if p.is_file()}
        found = sorted(fighter_found | stage_found, key=lambda p: p.name.lower())
        if not fighter_found:
            raise ValueError('No Pl*.dat fighter resources were found under the selected source folder.')

        copied: list[dict[str, Any]] = []
        seen_names: set[str] = set()
        for src in found:
            # Melee root resources normally have unique basenames. Refuse ambiguity
            # rather than silently choosing the wrong duplicate.
            key = src.name.lower()
            if key in seen_names:
                raise ValueError(f'Duplicate fighter resource basename found: {src.name}. Use a source folder with one Melee root filesystem.')
            seen_names.add(key)
            dst_orig = original / src.name
            dst_work = working / src.name
            shutil.copy2(src, dst_orig)
            shutil.copy2(src, dst_work)
            copied.append({
                'filename': src.name,
                'source_relative': str(src.relative_to(source_root)),
                'sha256': sha256_file(dst_orig),
                'size': dst_orig.stat().st_size,
            })

        # Detect standard fighter DATs by actual ftData structure, not filename guesses.
        fighters: list[dict[str, Any]] = []
        for entry in copied:
            name = entry['filename']
            # Base fighter archives are conventionally PlXX.dat. Parsing is the final check.
            stem = Path(name).stem
            if len(stem) != 4 or not stem.startswith('Pl'):
                continue
            try:
                fighter = FighterDAT(original / name)
            except Exception:
                continue
            aj_name = stem + 'AJ.dat'
            related_prefix = stem
            related = sorted(x['filename'] for x in copied if x['filename'].startswith(related_prefix))
            fighters.append({
                'fighter_name': fighter.fighter_name,
                'base_filename': name,
                'aj_filename': aj_name if (original / aj_name).exists() else None,
                'related_files': related,
            })

        if not fighters:
            raise ValueError('Fighter resources were copied, but no standard PlXX.dat ftData archives could be identified.')

        stages: list[dict[str, Any]] = []
        for entry in copied:
            name = entry['filename']
            if not name.lower().startswith('gr') or not name.lower().endswith('.dat'):
                continue
            try:
                StageDAT(original / name)
            except Exception:
                continue
            cat = CATALOG_BY_FILENAME.get(name.lower())
            stages.append({
                'filename': name,
                'display_name': cat.name if cat else Path(name).stem,
                'source_relative': entry['source_relative'],
            })

        manifest = {
            'format_version': 1,
            'sdk_scope': 'fighter_and_stage_modding',
            'created_utc': datetime.now(timezone.utc).isoformat(),
            'source_root': str(source_root),
            'safety': {
                'source_is_read_only': True,
                'original_snapshot_is_read_only_by_policy': True,
                'edits_target': 'Working',
                'build_contains_changed_files_only': True,
            },
            'resources': copied,
            'fighters': fighters,
            'stages': stages,
            'runtime_overrides': {
                'fighter_states': {}
            },
        }
        (project_root / MANIFEST_NAME).write_text(json.dumps(manifest, indent=2), encoding='utf-8')
        return cls(project_root)


    def compatibility_report(self):
        return compatibility_report(self.root, self.manifest)

    def upgrade_metadata(self):
        upgraded, backup = upgrade_project_metadata(self.root, self.manifest)
        self.manifest = normalize_manifest(upgraded)
        self.fighters = self._load_fighters()
        self.stages = self._load_stages()
        return backup

    def create_test_clone(self, destination: str | Path, *, reset_build: bool = True) -> Path:
        return create_test_clone(self.root, destination, reset_build=reset_build)

    def _load_fighters(self) -> list[FighterResource]:
        return [FighterResource(**x) for x in self.manifest.get('fighters', [])]

    def _load_stages(self) -> list[StageResource]:
        return [StageResource(**x) for x in self.manifest.get('stages', [])]

    def stage_by_filename(self, filename: str) -> StageResource:
        for st in self.stages:
            if st.filename.lower() == filename.lower():
                return st
        raise KeyError(filename)

    def working_stage_path(self, filename: str) -> Path:
        return self.working_dir / self.stage_by_filename(filename).filename

    def save_stage(self, stage: StageDAT) -> Path:
        if stage.path is None:
            raise ValueError('Stage has no source filename')
        target = self.working_dir / stage.path.name
        stage.save_as(target)
        return target

    def reset_stage(self, filename: str) -> Path:
        r = self.stage_by_filename(filename)
        src = self.original_dir / r.filename
        dst = self.working_dir / r.filename
        shutil.copy2(src, dst)
        return dst

    def import_stages_from_iso(self, iso_path: str | Path) -> int:
        """Snapshot every Gr*.dat directly from a clean Melee ISO into this project."""
        from .gamecube_iso import GameCubeISO
        iso = GameCubeISO(iso_path)
        existing = {r['filename'].lower(): r for r in self.manifest.get('resources', [])}
        stage_rows = {r['filename'].lower(): r for r in self.manifest.get('stages', [])}
        count = 0
        for entry in iso.files:
            name = Path(entry.path).name
            if not (name.lower().startswith('gr') and name.lower().endswith('.dat')):
                continue
            # Refuse basename ambiguity for the same safety reason as extracted projects.
            data = iso.read_file(entry)
            try:
                StageDAT(data)
            except Exception:
                continue
            orig = self.original_dir / name
            work = self.working_dir / name
            if not orig.exists():
                orig.write_bytes(data)
                work.write_bytes(data)
            meta = {
                'filename': name, 'source_relative': entry.path,
                'sha256': sha256_file(orig), 'size': orig.stat().st_size,
            }
            existing[name.lower()] = meta
            cat = CATALOG_BY_FILENAME.get(name.lower())
            stage_rows[name.lower()] = {
                'filename': name, 'display_name': cat.name if cat else Path(name).stem,
                'source_relative': entry.path,
            }
            count += 1
        self.manifest['resources'] = sorted(existing.values(), key=lambda x: x['filename'].lower())
        self.manifest['stages'] = sorted(stage_rows.values(), key=lambda x: x['display_name'].lower())
        self.save_manifest()
        self.stages = self._load_stages()
        return count


    def save_manifest(self) -> None:
        self.manifest_path.write_text(json.dumps(self.manifest, indent=2), encoding='utf-8')

    def fighter_state_override(self, fighter_name: str, state_key: str) -> bool:
        return bool(
            self.manifest.get('runtime_overrides', {})
            .get('fighter_states', {})
            .get(fighter_name, {})
            .get(state_key, False)
        )

    def set_fighter_state_override(self, fighter_name: str, state_key: str, enabled: bool) -> None:
        overrides = self.manifest.setdefault('runtime_overrides', {})
        fighter_states = overrides.setdefault('fighter_states', {})
        states = fighter_states.setdefault(fighter_name, {})
        if enabled:
            states[state_key] = True
        else:
            states.pop(state_key, None)
            if not states:
                fighter_states.pop(fighter_name, None)
        self.save_manifest()

    def reset_fighter_state_overrides(self, fighter_name: str) -> None:
        overrides = self.manifest.setdefault('runtime_overrides', {})
        fighter_states = overrides.setdefault('fighter_states', {})
        if fighter_name in fighter_states:
            fighter_states.pop(fighter_name, None)
            self.save_manifest()

    def build_target_settings(self) -> dict[str, Any]:
        return dict(self.manifest.get('build_targets', {}))

    def set_build_target_settings(self, **values: Any) -> None:
        settings = self.manifest.setdefault('build_targets', {})
        for key, value in values.items():
            if value is None or value == '':
                settings.pop(key, None)
            else:
                settings[key] = value
        self.save_manifest()

    def active_runtime_overrides(self) -> dict[str, Any]:
        fighter_states = self.manifest.get('runtime_overrides', {}).get('fighter_states', {})
        return {
            fighter: {key: bool(value) for key, value in states.items() if value}
            for fighter, states in fighter_states.items()
            if any(bool(value) for value in states.values())
        }

    def fighter_by_name(self, name: str) -> FighterResource:
        for f in self.fighters:
            if f.fighter_name == name:
                return f
        raise KeyError(name)

    def working_fighter_path(self, name: str) -> Path:
        return self.working_dir / self.fighter_by_name(name).base_filename

    def working_aj_path(self, name: str) -> Path | None:
        r = self.fighter_by_name(name)
        return (self.working_dir / r.aj_filename) if r.aj_filename else None


    def working_common_path(self) -> Path | None:
        p = self.working_dir / 'PlCo.dat'
        return p if p.exists() else None

    def save_common(self, common: CommonFighterDAT) -> Path:
        target = self.working_dir / 'PlCo.dat'
        common.save_as(target)
        return target

    def reset_common(self) -> Path:
        src = self.original_dir / 'PlCo.dat'
        dst = self.working_dir / 'PlCo.dat'
        if not src.exists():
            raise FileNotFoundError('PlCo.dat is not present in the project Original snapshot.')
        shutil.copy2(src, dst)
        return dst

    def save_fighter(self, fighter: FighterDAT) -> Path:
        target = self.working_dir / fighter.path.name
        fighter.save_as(target)
        return target

    def save_aj_bytes(self, fighter_name: str, data: bytes | bytearray) -> Path:
        target = self.working_aj_path(fighter_name)
        if target is None:
            raise FileNotFoundError(f'No AJ resource is registered for {fighter_name}')
        target.write_bytes(bytes(data))
        return target

    def reset_fighter(self, name: str) -> list[Path]:
        resource = self.fighter_by_name(name)
        restored: list[Path] = []
        # Reset all related PlXX* files, not only the gameplay archive.
        for filename in resource.related_files:
            src = self.original_dir / filename
            dst = self.working_dir / filename
            if src.exists():
                shutil.copy2(src, dst)
                restored.append(dst)
        return restored

    def changed_files(self) -> list[dict[str, Any]]:
        baseline = {r['filename']: r for r in self.manifest.get('resources', [])}
        changed: list[dict[str, Any]] = []
        for filename, meta in baseline.items():
            p = self.working_dir / filename
            if not p.exists():
                changed.append({'filename': filename, 'status': 'missing', 'original_sha256': meta['sha256']})
                continue
            digest = sha256_file(p)
            authored_new = bool(meta.get('authored_new') or str(meta.get('source_relative','')).startswith('<authored'))
            if authored_new or digest != meta['sha256']:
                changed.append({
                    'filename': filename,
                    'status': 'new' if authored_new else 'modified',
                    'original_sha256': meta['sha256'],
                    'working_sha256': digest,
                    'size': p.stat().st_size,
                })
        return changed

    def build(self) -> dict[str, Any]:
        # SSS paging controls are an SDK-level ABI. Reassert them on every
        # project build so imported/custom metadata cannot remap D-Pad Up/Down.
        from .stage_select_pages import enforce_project_page_navigation
        enforce_project_page_navigation(self, rebuild=False)
        self.build_dir.mkdir(exist_ok=True)
        # A Build is a clean snapshot of changes; remove stale files from prior builds.
        for p in self.build_dir.iterdir():
            if p.is_file():
                p.unlink()
            elif p.is_dir():
                shutil.rmtree(p)
        changed = self.changed_files()
        copied = []
        for item in changed:
            if item['status'] not in ('modified', 'new'):
                continue
            src = self.working_dir / item['filename']
            dst = self.build_dir / item['filename']
            shutil.copy2(src, dst)
            copied.append(item)
        runtime_overrides = self.active_runtime_overrides()
        build_manifest = {
            'built_utc': datetime.now(timezone.utc).isoformat(),
            'project': str(self.root),
            'modified_files': copied,
            'runtime_overrides': runtime_overrides,
            'runtime_override_status': ('pending_code_patch' if runtime_overrides else 'none'),
        }
        (self.build_dir / 'build_manifest.json').write_text(json.dumps(build_manifest, indent=2), encoding='utf-8')
        return build_manifest

# Phase 15 project helpers are attached here to keep older manifests compatible.
def _clone_stage_variant(self: MeleeProject, source_filename: str, new_filename: str, display_name: str | None = None) -> Path:
    source = self.working_stage_path(source_filename)
    new_filename = Path(new_filename).name
    if not new_filename.lower().startswith('gr') or not new_filename.lower().endswith('.dat'):
        raise ValueError('Stage variant filenames must use the Gr*.dat convention.')
    if any(s.filename.lower() == new_filename.lower() for s in self.stages):
        raise ValueError(f'{new_filename} is already registered in this project.')
    data = source.read_bytes()
    StageDAT(data).validate()
    orig = self.original_dir / new_filename
    work = self.working_dir / new_filename
    orig.write_bytes(data); work.write_bytes(data)
    row = {'filename':new_filename,'source_relative':f'<authored from {source_filename}>','sha256':sha256_file(orig),'size':len(data),'authored_new':True}
    self.manifest.setdefault('resources',[]).append(row)
    self.manifest.setdefault('stages',[]).append({'filename':new_filename,'display_name':display_name or Path(new_filename).stem,'source_relative':row['source_relative']})
    self.manifest['resources']=sorted(self.manifest['resources'],key=lambda x:x['filename'].lower())
    self.manifest['stages']=sorted(self.manifest['stages'],key=lambda x:x['display_name'].lower())
    self.save_manifest(); self.stages=self._load_stages()
    from .stage_select_pages import enforce_project_page_navigation
    enforce_project_page_navigation(self, rebuild=True)
    return work


def _install_stage_into_slot(self: MeleeProject, authored_filename: str, target_filename: str) -> Path:
    src = self.working_stage_path(authored_filename)
    target = self.stage_by_filename(target_filename)
    if authored_filename.lower() == target_filename.lower():
        return src
    data=src.read_bytes(); StageDAT(data).validate()
    dst=self.working_dir/target.filename; dst.write_bytes(data)
    return dst

MeleeProject.clone_stage_variant = _clone_stage_variant
MeleeProject.install_stage_into_slot = _install_stage_into_slot


# --- Phase 17: first-class new FST resources + prototype fighter authoring ---
def _register_or_update_resource(self: MeleeProject, filename: str, source_relative: str,
                                 *, authored_new: bool = False) -> None:
    p = self.original_dir / filename
    if not p.exists():
        raise FileNotFoundError(p)
    rows = self.manifest.setdefault('resources', [])
    row = next((x for x in rows if x['filename'].lower() == filename.lower()), None)
    data = {'filename': filename, 'source_relative': source_relative,
            'sha256': sha256_file(p), 'size': p.stat().st_size}
    if authored_new:
        data['authored_new'] = True
    if row is None:
        rows.append(data)
    else:
        row.update(data)
    self.manifest['resources'] = sorted(rows, key=lambda x: x['filename'].lower())
    self.save_manifest()


def _create_wireframe_prototype(self: MeleeProject, donor_fighter_name: str,
                                target: str = 'Boy') -> dict[str, Any]:
    """Clone donor fighter data/AJ into the reserved Boy/Girl asset identity.

    The base DAT public root is renamed to the symbol expected by the reserved
    loader (ftDataBoy / ftDataGirl). The reserved costume/model file is left in
    place intentionally; this is a runtime-slot bring-up path, not final model
    authoring.
    """
    target_key = target.strip().lower()
    if target_key not in ('boy','girl'):
        raise ValueError('Prototype target must be Boy or Girl')
    donor = self.fighter_by_name(donor_fighter_name)
    donor_base = self.working_dir / donor.base_filename
    donor_aj = self.working_dir / donor.aj_filename if donor.aj_filename else None
    stem = 'PlBo' if target_key == 'boy' else 'PlGl'
    expected_public = 'ftDataBoy' if target_key == 'boy' else 'ftDataGirl'
    target_base = self.working_dir / f'{stem}.dat'
    target_aj = self.working_dir / f'{stem}AJ.dat'
    target_costume = self.working_dir / f'{stem}Nr.dat'

    raw = donor_base.read_bytes()
    arc = HSDArchive(raw)
    idx = next((i for i,p in enumerate(arc.publics) if p.name.startswith('ftData') and 'Copy' not in p.name), None)
    if idx is None:
        raise ValueError(f'{donor.base_filename} has no standard ftData public root')
    raw = rename_hsd_public_symbol(raw, expected_public, idx)
    # HSDArchive construction plus the validated ftData root above proves the renamed archive remains structurally parseable.
    target_base.write_bytes(raw)
    if donor_aj and donor_aj.exists():
        target_aj.write_bytes(donor_aj.read_bytes())

    # Clone the donor's neutral costume/model as well so its skeleton matches the
    # donor AJ animation set.  The reserved Boy/Girl loader only asks for one
    # Share_joint public symbol and no material-animation public, which makes this
    # a clean bring-up identity while custom model authoring remains optional.
    donor_costume_name = next((fn for fn in donor.related_files if fn.lower().endswith('nr.dat')), None)
    if donor_costume_name:
        donor_costume = self.working_dir / donor_costume_name
        if donor_costume.exists():
            costume_raw = donor_costume.read_bytes()
            costume_arc = HSDArchive(costume_raw)
            joint_idx = next((i for i,p in enumerate(costume_arc.publics) if p.name.endswith('_Share_joint')), None)
            if joint_idx is None:
                raise ValueError(f'{donor_costume_name} has no Share_joint public root')
            expected_joint = 'PlyBoy_Share_joint' if target_key == 'boy' else 'PlyGirl_Share_joint'
            costume_raw = rename_hsd_public_symbol(costume_raw, expected_joint, joint_idx)
            verify_costume = HSDArchive(costume_raw)
            if not any(p.name == expected_joint for p in verify_costume.publics):
                raise ValueError('Prototype costume public-root rename failed')
            target_costume.write_bytes(costume_raw)

    # If these assets were not originally part of the project, register them as
    # new FST resources. If they were, preserve their original baseline metadata.
    for fn, work in ((target_base.name,target_base),(target_aj.name,target_aj),(target_costume.name,target_costume)):
        if not work.exists():
            continue
        if not (self.original_dir/fn).exists():
            (self.original_dir/fn).write_bytes(work.read_bytes())
            _register_or_update_resource(self, fn, f'<authored prototype from {donor.base_filename}>', authored_new=True)
    plan = self.manifest.setdefault('runtime_authoring', {}).setdefault('fighter_prototypes', {})
    plan[target_key] = {'donor_fighter': donor_fighter_name, 'target_kind': 0x1D if target_key=='boy' else 0x1E,
                        'base_filename': target_base.name,
                        'aj_filename': target_aj.name if target_aj.exists() else None,
                        'costume_filename': target_costume.name if target_costume.exists() else None,
                        'data_public': expected_public,
                        'status': 'assets_prepared_callbacks_need_dol_patch'}
    self.save_manifest()
    return plan[target_key]


def _register_runtime_dol(self: MeleeProject, dol_path: str | Path, *, description: str) -> Path:
    src = Path(dol_path)
    dst = self.working_dir / 'start.dol'
    shutil.copy2(src, dst)
    orig = self.original_dir / 'start.dol'
    if not orig.exists():
        # The baseline DOL is not an FST resource, but keeping a snapshot lets
        # changed_files/build use the same safe Original/Working model.
        shutil.copy2(src, orig)
        self.manifest.setdefault('resources', []).append({'filename':'start.dol','source_relative':'<extracted main.dol>',
            'sha256':sha256_file(orig),'size':orig.stat().st_size})
    self.manifest.setdefault('runtime_authoring', {})['dol_description'] = description
    self.save_manifest()
    return dst

MeleeProject.register_or_update_resource = _register_or_update_resource
MeleeProject.create_wireframe_prototype = _create_wireframe_prototype
MeleeProject.register_runtime_dol = _register_runtime_dol


def _import_menu_archives_from_iso(self: MeleeProject, iso_path: str | Path) -> dict[str, Any]:
    """Snapshot the retail Stage Select/CSS HSD archives for menu-slot work."""
    from .gamecube_iso import GameCubeISO
    from .menu_archives import MENU_ARCHIVES, MenuArchiveInspector
    iso = GameCubeISO(iso_path)
    imported = []
    reports = []
    rows = self.manifest.setdefault('resources', [])
    by_name = {r['filename'].lower(): r for r in rows}
    for filename, expected_root in MENU_ARCHIVES.items():
        try:
            entry = iso.find_file(filename)
        except KeyError:
            continue
        data = iso.read_file(entry)
        inspector = MenuArchiveInspector(data)
        inspector.filename = filename
        rep = inspector.report(expected_root)
        if not rep.public_found:
            raise ValueError(f'{filename}: expected public root {expected_root} was not found')
        orig = self.original_dir / filename
        work = self.working_dir / filename
        if not orig.exists():
            orig.write_bytes(data)
            work.write_bytes(data)
        meta = {'filename': filename, 'source_relative': entry.path,
                'sha256': sha256_file(orig), 'size': orig.stat().st_size}
        by_name[filename.lower()] = meta
        imported.append(filename)
        reports.append(rep.__dict__.copy())
    self.manifest['resources'] = sorted(by_name.values(), key=lambda x: x['filename'].lower())
    self.manifest.setdefault('runtime_authoring', {})['menu_archives'] = {
        'status': 'snapshotted_for_stage_css_authoring',
        'files': imported,
        'reports': reports,
    }
    self.save_manifest()
    return {'count': len(imported), 'files': imported, 'reports': reports}

MeleeProject.import_menu_archives_from_iso = _import_menu_archives_from_iso


# --- Phase 19: transactional new-stage creation / preflight ------------------
def _preflight_new_stage(self: MeleeProject, source_filename: str, new_filename: str) -> dict[str, str]:
    source_filename=Path(str(source_filename).strip()).name
    new_filename=Path(str(new_filename).strip()).name
    if not new_filename.lower().startswith('gr') or not new_filename.lower().endswith('.dat'):
        raise ValueError('New stage filename must use the Gr*.dat convention (example: GrMy.dat).')
    try:
        donor=self.stage_by_filename(source_filename)
    except KeyError:
        available=', '.join(x.filename for x in sorted(self.stages,key=lambda x:x.filename.lower()))
        raise ValueError(f'Donor stage {source_filename!r} is not registered in this project. Choose an existing donor stage.\n\nAvailable donors: {available}') from None
    src=self.working_dir/donor.filename
    if not src.is_file(): raise FileNotFoundError(f'Donor Working file is missing: {src}')
    if any(x.filename.lower()==new_filename.lower() for x in self.stages) or (self.working_dir/new_filename).exists() or (self.original_dir/new_filename).exists():
        raise ValueError(f'New stage {new_filename!r} already exists. Choose a different Gr*.dat filename.')
    StageDAT(src).validate()
    return {'donor':donor.filename,'new_filename':new_filename}


def _clone_stage_variant_phase19(self: MeleeProject, source_filename: str, new_filename: str, display_name: str|None=None) -> Path:
    check=self.preflight_new_stage(source_filename,new_filename); source_filename=check['donor']; new_filename=check['new_filename']
    source=self.working_dir/source_filename; data=source.read_bytes(); StageDAT(data).validate()
    orig=self.original_dir/new_filename; work=self.working_dir/new_filename
    old_manifest=json.loads(json.dumps(self.manifest))
    try:
        # Write files first, validate the exact bytes on disk, then commit manifest registration.
        orig.write_bytes(data); work.write_bytes(data); StageDAT(work).validate()
        row={'filename':new_filename,'source_relative':f'<authored from {source_filename}>','sha256':sha256_file(orig),'size':len(data),'authored_new':True}
        self.manifest.setdefault('resources',[]).append(row)
        self.manifest.setdefault('stages',[]).append({'filename':new_filename,'display_name':display_name or Path(new_filename).stem,'source_relative':row['source_relative']})
        self.manifest['resources']=sorted(self.manifest['resources'],key=lambda x:x['filename'].lower())
        self.manifest['stages']=sorted(self.manifest['stages'],key=lambda x:x['display_name'].lower())
        self.save_manifest(); self.stages=self._load_stages()
        # New authored stages immediately join the canonical custom-page set;
        # page navigation remains reserved to D-Pad Down / D-Pad Up.
        from .stage_select_pages import enforce_project_page_navigation
        enforce_project_page_navigation(self, rebuild=True)
        # Postcondition: the newly registered stage must resolve before returning to the GUI.
        assert self.working_stage_path(new_filename)==work
        return work
    except Exception:
        self.manifest=old_manifest; self.stages=self._load_stages()
        for q in (orig,work):
            try:q.unlink()
            except FileNotFoundError:pass
        self.save_manifest(); raise

MeleeProject.preflight_new_stage=_preflight_new_stage
MeleeProject.clone_stage_variant=_clone_stage_variant_phase19

# --- Phase 20: canonical runtime executable + custom-mode recipes -----------
def _import_runtime_dol_from_iso(self: MeleeProject, iso_path: str | Path) -> Path:
    from .gamecube_iso import GameCubeISO, verify_melee_102
    verify_melee_102(iso_path, full_hash=True)
    iso=GameCubeISO(iso_path)
    tmp=self.root/'_phase20_main.dol.tmp'
    iso.extract_dol(tmp)
    try:
        dst=self.working_dir/'start.dol'; orig=self.original_dir/'start.dol'
        data=tmp.read_bytes()
        if not orig.exists(): orig.write_bytes(data)
        # Do not silently destroy existing runtime patches. Only populate Working
        # when it is absent; callers may explicitly reset if they want vanilla.
        if not dst.exists(): dst.write_bytes(data)
        rows=self.manifest.setdefault('resources',[])
        row=next((x for x in rows if x['filename'].lower()=='start.dol'),None)
        meta={'filename':'start.dol','source_relative':'<canonical GALE01 1.02 main.dol>',
              'sha256':sha256_file(orig),'size':orig.stat().st_size}
        if row is None: rows.append(meta)
        else: row.update(meta)
        self.manifest['resources']=sorted(rows,key=lambda x:x['filename'].lower())
        self.manifest.setdefault('runtime_authoring',{})['dol_source']='canonical_GALE01_1.02'
        self.save_manifest()
        return dst
    finally:
        try: tmp.unlink()
        except FileNotFoundError: pass


def _mode_recipe_dir(self: MeleeProject) -> Path:
    p=self.root/'ModeRecipes'; p.mkdir(exist_ok=True); return p

MeleeProject.import_runtime_dol_from_iso=_import_runtime_dol_from_iso
MeleeProject.mode_recipe_dir=_mode_recipe_dir

# --- Phase 21: Event Match / duo runtime archive ----------------------------
def _import_event_archive_from_iso(self: MeleeProject, iso_path: str | Path) -> dict[str, Any]:
    """Snapshot and validate retail GmEvent.dat for Event/Duo authoring."""
    from .gamecube_iso import GameCubeISO
    from .event_match import EventMatchArchive
    iso=GameCubeISO(iso_path)
    entry=iso.find_file('GmEvent.dat')
    data=iso.read_file(entry)
    ev=EventMatchArchive(data)
    report=ev.report()
    orig=self.original_dir/'GmEvent.dat'; work=self.working_dir/'GmEvent.dat'
    if not orig.exists():
        orig.write_bytes(data)
    if not work.exists():
        work.write_bytes(data)
    rows=self.manifest.setdefault('resources',[])
    by={r['filename'].lower():r for r in rows}
    by['gmevent.dat']={'filename':'GmEvent.dat','source_relative':entry.path,
        'sha256':sha256_file(orig),'size':orig.stat().st_size}
    self.manifest['resources']=sorted(by.values(),key=lambda x:x['filename'].lower())
    self.manifest.setdefault('runtime_authoring',{})['event_match']={
        'status':'snapshotted_for_event_and_duo_authoring','source':entry.path,
        'event_count':report['event_count'],'ordinary_events':report['ordinary_events'],
        'bonus_events':report['bonus_events'],'multiround_events':report['multiround_events']}
    self.save_manifest()
    return self.manifest['runtime_authoring']['event_match']


def _register_event_archive(self: MeleeProject, source_path: str | Path) -> dict[str, Any]:
    """Register a user-supplied GmEvent.dat while retaining an Original baseline."""
    from .event_match import EventMatchArchive
    src=Path(source_path)
    ev=EventMatchArchive(src); report=ev.report()
    orig=self.original_dir/'GmEvent.dat'; work=self.working_dir/'GmEvent.dat'
    if not orig.exists(): shutil.copy2(src,orig)
    shutil.copy2(src,work)
    rows=self.manifest.setdefault('resources',[]); by={r['filename'].lower():r for r in rows}
    by['gmevent.dat']={'filename':'GmEvent.dat','source_relative':str(src),
        'sha256':sha256_file(orig),'size':orig.stat().st_size}
    self.manifest['resources']=sorted(by.values(),key=lambda x:x['filename'].lower())
    self.manifest.setdefault('runtime_authoring',{})['event_match']={
        'status':'registered_for_event_and_duo_authoring','source':str(src),
        'event_count':report['event_count'],'ordinary_events':report['ordinary_events'],
        'bonus_events':report['bonus_events'],'multiround_events':report['multiround_events']}
    self.save_manifest(); return self.manifest['runtime_authoring']['event_match']

MeleeProject.import_event_archive_from_iso = _import_event_archive_from_iso
MeleeProject.register_event_archive = _register_event_archive
