"""Reserve stable low SDK code and a small high-MEM1 Slippi session island.

The SDK executable/data runtime stays in the original 16 KiB low arena reservation
at 0x804F0C00..0x804F4C00.  Raising ArenaLo was proven unsafe because it shifts
Slippi's dynamic allocations and injected Online-In-Game code.

SDK 0.20.21E no longer touches ArenaHi during OSInit. 0.20.21D's first
loader-backed section at 0x817FF000 black-screened before a savestate-capable
boot. The final 8 KiB remains the runtime relocation target, but 0.20.21J paired
Adventure saves proved that simply copying there is not enough. Paired K2 saves then
proved the active HSD heap actually ends near 0x811DE400, well below the island.
0.20.21K6 leaves cold boot ArenaHi retail, then the scoped Direct bridge lazily
lowers live ArenaHi to 0x817FE000 before Adventure constructs its heap. It also
primes Slippi's host-side savestate heap ceiling at B0 frame 1 to that same
boundary. The top 8 KiB therefore contains only persistent Slippi session/control
state and is physically excluded from Adventure allocations and rollback backup;
cleanup restores the original ArenaHi.
"""
from __future__ import annotations

import struct

from .ppc import addi, encode_bc, encode_branch, lis

SDK_RUNTIME_BASE = 0x804F0C00
SDK_RUNTIME_LIMIT = 0x804F4C00
SDK_SESSION_HIGH_BASE = 0x817FE000
SDK_SESSION_HIGH_LIMIT = 0x81800000
SDK_SESSION_HIGH_SIZE = SDK_SESSION_HIGH_LIMIT - SDK_SESSION_HIGH_BASE
# Historical 0.20.21D high-code constants are retained only for regression
# tooling. 0.20.21E never installs a DOL section here; the entire 8 KiB island
# is runtime-only session data territory after Direct arm.
SDK_HIGH_CODE_BASE = 0x817FF000
SDK_HIGH_CODE_LIMIT = 0x81800000
SDK_HIGH_CODE_ANCHOR_SIZE = 0x20

OS_SET_ARENA_LO = 0x803444E0
OS_SET_ARENA_HI = 0x803444D8
OS_INIT_ARENA_LO_CALLS = (0x803430A0, 0x803430DC)
OS_INIT_ARENA_HI_CALL = 0x803430FC
RETAIL_MAIN_STACK = (0x804DEC00, 0x804EEC00)
RETAIL_DEBUG_STACK = (0x804EEC00, 0x804F0C00)
OBSERVED_MEX_GLOBALS = (
    0x804DFAB4, 0x804DFAB8, 0x804DFAD8,
    0x804DFB44, 0x804DFB48, 0x804DFB64,
)


def _cmplw_cr7(ra: int, rb: int) -> bytes:
    return struct.pack('>I', (31 << 26) | (7 << 23) | ((ra & 31) << 16) |
                       ((rb & 31) << 11) | (32 << 1))


def build_arena_floor(base: int) -> bytes:
    """Tail-call OSSetArenaLo(max(requested, SDK_RUNTIME_LIMIT)); retain LR."""
    out = bytearray(lis(12, SDK_RUNTIME_LIMIT >> 16))
    out += addi(12, 12, SDK_RUNTIME_LIMIT & 0xFFFF)
    out += _cmplw_cr7(3, 12)
    out += encode_bc(base + 12, base + 20, bo=4, bi=28)  # bge cr7
    out += addi(3, 12, 0)
    out += encode_branch(base + 20, OS_SET_ARENA_LO)
    return bytes(out)


def build_arena_ceiling(base: int) -> bytes:
    """Tail-call OSSetArenaHi(min(requested, SDK_SESSION_HIGH_BASE)); retain LR."""
    # addi sign-extends its low half; 0xE000 therefore requires the
    # carry-adjusted high half (0x8180 + -0x2000 = 0x817FE000).
    hi = ((SDK_SESSION_HIGH_BASE + 0x8000) >> 16) & 0xFFFF
    out = bytearray(lis(12, hi))
    out += addi(12, 12, SDK_SESSION_HIGH_BASE & 0xFFFF)
    out += _cmplw_cr7(3, 12)
    # Keep requested when r3 <= ceiling.  CR7[GT] is bit 29, so branch when
    # that bit is false.  Otherwise replace r3 with the ceiling.
    out += encode_bc(base + 12, base + 20, bo=4, bi=29)  # ble cr7
    out += addi(3, 12, 0)
    out += encode_branch(base + 20, OS_SET_ARENA_HI)
    return bytes(out)




def install_high_code_anchor(dol) -> dict:
    """Historical 0.20.21D helper; current 0.20.21E builds must not call it."""
    payload = bytearray(SDK_HIGH_CODE_ANCHOR_SIZE)
    payload[:8] = b'MSDK21H\0'
    added = dol.add_data_section(
        payload, address=SDK_HIGH_CODE_BASE,
        file_alignment=0x20, address_alignment=0x20)
    if added['address'] != SDK_HIGH_CODE_BASE:
        raise ValueError('SDK high-code anchor address mismatch')
    return {
        'marker': 'MSDK21H',
        'section_index': added['index'],
        'section_address': added['address'],
        'section_size': added['size'],
        'code_base': SDK_HIGH_CODE_BASE,
        'code_limit': SDK_HIGH_CODE_LIMIT,
        'capacity': SDK_HIGH_CODE_LIMIT - SDK_HIGH_CODE_BASE,
    }


def validate_high_code_section(dol, index: int) -> dict:
    section = next(s for s in dol.sections if s.kind == 'data' and s.index == int(index))
    if section.address != SDK_HIGH_CODE_BASE:
        raise ValueError('SDK high-code section moved unexpectedly')
    if section.end_address > SDK_HIGH_CODE_LIMIT:
        raise ValueError(
            f'SDK high-MEM1 support code exceeds protected 4 KiB block: '
            f'end=0x{section.end_address:08X}, limit=0x{SDK_HIGH_CODE_LIMIT:08X}')
    return {
        'section_index': section.index,
        'address': section.address,
        'end_address': section.end_address,
        'size': section.size,
        'free_bytes': SDK_HIGH_CODE_LIMIT - section.end_address,
    }

def install_arena_reservation(dol, runtime_index: int) -> dict:
    """Reserve the proven 16 KiB low SDK block; leave ArenaHi retail at boot.

    The Direct bridge reserves the top 8 KiB session island through its
    frame-1/Adventure heap-end ceiling. Cold boot therefore keeps retail ArenaHi unchanged and
    no executable DOL section is loaded into apploader high-memory territory.
    """
    section = next(s for s in dol.sections
                   if s.kind == 'data' and s.index == runtime_index)
    if section.address != SDK_RUNTIME_BASE:
        raise ValueError('SDK memory reservation requires regenerated runtime addresses')

    base = section.address + ((section.size + 31) & ~31)
    floor = build_arena_floor(base)
    payload = bytearray(floor)
    payload.extend(bytes((-len(payload)) % 32))
    if base + len(payload) > SDK_RUNTIME_LIMIT:
        end = base + len(payload)
        raise ValueError(
            f'SDK runtime exceeds its reserved 16 KiB arena block: '
            f'end=0x{end:08X}, limit=0x{SDK_RUNTIME_LIMIT:08X}, '
            f'excess=0x{end-SDK_RUNTIME_LIMIT:X}')

    lo_expected = {a: encode_branch(a, OS_SET_ARENA_LO, link=True)
                   for a in OS_INIT_ARENA_LO_CALLS}
    for a, word in lo_expected.items():
        if dol.read_at_address(a, 4) != word:
            raise ValueError(f'OSInit ArenaLo call changed at {a:#x}')

    # ArenaHi must remain byte-for-byte retail at cold boot. 0.20.21D patched
    # this call and also added a top-of-MEM1 DOL section; either can execute
    # before normal Melee startup. The runtime bridge will reserve its data
    # island later, after Slippi Online-In-Game is live.
    hi_expected = encode_branch(OS_INIT_ARENA_HI_CALL, OS_SET_ARENA_HI, link=True)
    if dol.read_at_address(OS_INIT_ARENA_HI_CALL, 4) != hi_expected:
        raise ValueError(f'OSInit ArenaHi call changed at {OS_INIT_ARENA_HI_CALL:#x}')

    added = dol.append_to_data_section(runtime_index, bytes(payload))
    if added['address'] != base:
        raise ValueError('SDK arena wrapper append address mismatch')
    for a, word in lo_expected.items():
        dol.patch_at_address(a, encode_branch(a, base, link=True), expected=word)

    return {
        'marker': 'MSDK021M',
        'runtime_base': SDK_RUNTIME_BASE,
        'runtime_end': base + len(payload),
        'arena_floor': SDK_RUNTIME_LIMIT,
        'reserved_bytes': SDK_RUNTIME_LIMIT - SDK_RUNTIME_BASE,
        'arena_floor_wrapper': base,
        'arena_floor_wrapper_size': len(floor),
        'arena_ceiling': SDK_SESSION_HIGH_BASE,
        'arena_hi_retail_limit': SDK_SESSION_HIGH_LIMIT,
        'high_session_reserved_bytes': SDK_SESSION_HIGH_SIZE,
        'high_code_base': None,
        'high_code_limit': None,
        'arena_ceiling_wrapper': None,
        'arena_ceiling_wrapper_size': 0,
        'arena_ceiling_policy': 'retail ArenaHi; Direct bridge controls rollback/main-heap reporting ceiling',
        'os_init_lo_call_sites': list(OS_INIT_ARENA_LO_CALLS),
        'os_init_hi_call_site': OS_INIT_ARENA_HI_CALL,
        'os_init_hi_policy': 'exact retail call preserved',
        'retail_main_stack': list(RETAIL_MAIN_STACK),
        'retail_debug_stack': list(RETAIL_DEBUG_STACK),
        'observed_mex_globals': list(OBSERVED_MEX_GLOBALS),
        'policy': (
            'keep original 16 KiB ArenaLo and retail ArenaHi; Direct B0 frame 1 primes '
            'Slippi backup coverage through 0x817FE000 and Adventure reuses that ceiling'),
    }

