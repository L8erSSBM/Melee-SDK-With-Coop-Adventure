"""HF22: quarter-size storage for the Icies Team-Kirby clear-screen background.

Only three gmregclear call sites are changed. The image remains a normal
heap-owned RGB5A3 texture; capture downsamples the full EFB and drawing scales
it back to full screen. Do not shrink allocation without these paired changes.
"""
import struct

from .ppc import (addi, blr, cmpwi, encode_bc, encode_branch, lbz, li, lis,
                  lwz, mflr, mtlr, stw, stwu)

ALLOC_SITE, COPY_SITE, DRAW_SITE = 0x80180A08, 0x8017FE84, 0x80180A2C
ALLOC_RETAIL, COPY_RETAIL, DRAW_RETAIL = 0x800121FC, 0x800122C8, 0x800138EC
COPY_SRC, COPY_DST = 0x8033D4C8, 0x8033D5CC
ZMODE, COPY_TEX = 0x80361BB8, 0x8033DCBC
PIX_SYNC, INVALIDATE = 0x8033CD1C, 0x8033F270
IMAGE_DESC = 0x80472D58
WIDTH, HEIGHT = 320, 240
BUFFER_BYTES = WIDTH * HEIGHT * 2


class Code:
    def __init__(self, base):
        self.base, self.data, self.skips = base, bytearray(), []

    def emit(self, *words):
        for word in words:
            self.data.extend(word)

    def call(self, addr, link=True):
        self.emit(encode_branch(self.base + len(self.data), addr, link=link))

    def require(self, reg, value):
        self.emit(cmpwi(reg, value, crf=7))
        self.skips.append(len(self.data))
        self.emit(bytes(4))

    def load_byte(self, reg, addr):
        self.emit(lis(12, (addr + 0x8000) >> 16), lbz(reg, addr & 0xFFFF, 12))

    def fallback(self, addr):
        dest = self.base + len(self.data)
        for offset in self.skips:
            self.data[offset:offset+4] = encode_bc(self.base+offset, dest, bo=4, bi=30)
        self.call(addr, link=False)
        return bytes(self.data)


def _lhz(reg, offset, base):
    return struct.pack('>I', (40 << 26) | (reg << 21) | (base << 16) | offset)


def _image_gate(c):
    # Scope by descriptor identity AND dimensions. Capture/draw continue to
    # work even if campaign diagnostics change after the image was allocated.
    c.emit(lis(11, IMAGE_DESC >> 16), addi(11, 11, IMAGE_DESC & 0xFFFF))
    c.emit(struct.pack('>I', (31 << 26) | (7 << 23) | (3 << 16) | (11 << 11)))
    c.skips.append(len(c.data)); c.emit(bytes(4))
    c.emit(_lhz(11, 4, 3)); c.require(11, WIDTH)
    c.emit(_lhz(11, 6, 3)); c.require(11, HEIGHT)


def allocation_wrapper(base, terminal_guard):
    c = Code(base)
    c.load_byte(11, 0x80479D30); c.require(11, 4)  # Adventure
    c.load_byte(11, terminal_guard); c.require(11, 1)  # verified Icies terminal
    # The guard survives transitions; also restrict to the Team-Kirby state.
    c.load_byte(11, 0x80479D33); c.require(11, 0x23)
    c.require(4, 640); c.require(5, 480); c.require(6, 5); c.require(7, 0)
    c.emit(li(4, WIDTH), li(5, HEIGHT))
    return c.fallback(ALLOC_RETAIL)


def draw_wrapper(base):
    c = Code(base); _image_gate(c)
    # f1/f2 are position; f3/f4 are scale. fadds doubles only the scale.
    for reg in (3, 4):
        c.emit(struct.pack('>I', (59 << 26) | (reg << 21) | (reg << 16) | (reg << 11) | (21 << 1)))
    return c.fallback(DRAW_RETAIL)


def copy_wrapper(base):
    c = Code(base); _image_gate(c)
    c.emit(stwu(1, -0x20, 1), mflr(0), stw(0, 0x24, 1), stw(3, 8, 1), stw(6, 12, 1))
    # GXSetTexCopyDst(..., true) downsamples 2:1. The ImageDesc mipmap stays
    # zero: this is one texture level, not a mip chain.
    c.emit(li(3, 0), li(4, 0), li(5, 640), li(6, 480)); c.call(COPY_SRC)
    c.emit(li(3, WIDTH), li(4, HEIGHT), li(5, 5), li(6, 1)); c.call(COPY_DST)
    c.emit(lwz(11, 12, 1), cmpwi(11, 0, crf=7))
    no_clear = len(c.data); c.emit(bytes(4))
    c.emit(li(3, 1), li(4, 3), li(5, 1)); c.call(ZMODE)
    c.data[no_clear:no_clear+4] = encode_bc(base+no_clear, base+len(c.data), bo=12, bi=30)
    c.emit(lwz(3, 8, 1), lwz(3, 0, 3), lwz(4, 12, 1)); c.call(COPY_TEX)
    c.call(PIX_SYNC); c.call(INVALIDATE)
    c.emit(lwz(0, 0x24, 1), mtlr(0), addi(1, 1, 0x20), blr())
    return c.fallback(COPY_RETAIL)


def install(dol, runtime_index, terminal_guard):
    specs = [(ALLOC_SITE, ALLOC_RETAIL, 'allocation'),
             (COPY_SITE, COPY_RETAIL, 'capture'), (DRAW_SITE, DRAW_RETAIL, 'display')]
    # Validate every call site before any mutation.
    for site, target, _ in specs:
        expected = encode_branch(site, target, link=True)
        if dol.read_at_address(site, 4) != expected:
            raise ValueError(f'HF22 clear-screen expected-byte guard failed at {site:#x}')
    section = next(s for s in dol.sections if s.kind == 'data' and s.index == runtime_index)
    base = section.address + ((section.size + 31) & ~31)
    payload = bytearray(b'HF22CLEAR' + bytes(23))
    hooks = []
    for (site, target, name), build in zip(specs, (
            lambda a: allocation_wrapper(a, terminal_guard), copy_wrapper, draw_wrapper)):
        addr = base + len(payload)
        blob = build(addr); payload.extend(blob)
        payload.extend(bytes((-len(payload)) % 32))
        hooks.append(dict(name='hf22_clear_screen_'+name, site_address=site,
                          expected=encode_branch(site,target,link=True).hex(),
                          stub_address=addr, size=len(blob),
                          site_branch=encode_branch(site,addr,link=True).hex()))
    added = dol.append_to_data_section(runtime_index, payload)
    assert added['address'] == base
    for row in hooks:
        dol.patch_at_address(row['site_address'], bytes.fromhex(row['site_branch']),
                             expected=bytes.fromhex(row['expected']))
    return dict(marker='HF22CLEAR', section=added, hooks=hooks,
                dimensions=[WIDTH, HEIGHT], buffer_bytes=BUFFER_BYTES,
                original_buffer_bytes=614400, scope='Adventure terminal Icies Team Kirby',
                runtime_validation='pending Dolphin reproduction')
