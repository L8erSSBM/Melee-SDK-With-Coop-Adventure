from __future__ import annotations

import math
import struct
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .melee_dat import HSDArchive

BE_U16 = struct.Struct('>H')
BE_I16 = struct.Struct('>h')
BE_U32 = struct.Struct('>I')
BE_I32 = struct.Struct('>i')
BE_F32 = struct.Struct('>f')


@dataclass(frozen=True)
class StageCatalogEntry:
    stkind: int
    grkind: int
    name: str
    filename: str
    source_module: str
    versus: bool = True


# Source-derived from src/melee/gr/forward.h + StageData filenames in gr*.c.
# This catalog intentionally covers the selectable versus stages first. The
# project scanner still accepts every Gr*.dat (target-test/event/route files).
STAGE_CATALOG = [
    StageCatalogEntry(0x02, 0x0C, 'Fountain of Dreams', 'GrIz.dat', 'grizumi.c'),
    StageCatalogEntry(0x03, 0x10, 'Pokemon Stadium', 'GrPs.dat', 'grpstadium.c'),
    StageCatalogEntry(0x04, 0x02, "Princess Peach's Castle", 'GrCs.dat', 'grcastle.c'),
    StageCatalogEntry(0x05, 0x04, 'Kongo Jungle', 'GrKg.dat', 'grkongo.c'),
    StageCatalogEntry(0x06, 0x08, 'Brinstar', 'GrZe.dat', 'grzebes.c'),
    StageCatalogEntry(0x07, 0x0E, 'Corneria', 'GrCn.dat', 'grcorneria.c'),
    StageCatalogEntry(0x08, 0x0A, "Yoshi's Story", 'GrSt.dat', 'grstory.c'),
    StageCatalogEntry(0x09, 0x14, 'Onett', 'GrOt.dat', 'gronett.c'),
    StageCatalogEntry(0x0A, 0x12, 'Mute City', 'GrMc.dat', 'grmutecity.c'),
    StageCatalogEntry(0x0B, 0x03, 'Rainbow Cruise', 'GrRc.dat', 'grrcruise.c'),
    StageCatalogEntry(0x0C, 0x05, 'Jungle Japes', 'GrGd.dat', 'grgarden.c'),
    StageCatalogEntry(0x0D, 0x06, 'Great Bay', 'GrGb.dat', 'grgreatbay.c'),
    StageCatalogEntry(0x0E, 0x07, 'Temple', 'GrSh.dat', 'grshrine.c'),
    StageCatalogEntry(0x0F, 0x09, 'Brinstar Depths', 'GrKr.dat', 'grkraid.c'),
    StageCatalogEntry(0x10, 0x0B, "Yoshi's Island", 'GrYt.dat', 'gryorster.c'),
    StageCatalogEntry(0x11, 0x0D, 'Green Greens', 'GrGr.dat', 'grgreens.c'),
    StageCatalogEntry(0x12, 0x15, 'Fourside', 'GrFs.dat', 'grfourside.c'),
    StageCatalogEntry(0x13, 0x18, 'Mushroom Kingdom', 'GrI1.dat', 'grinishie1.c'),
    StageCatalogEntry(0x14, 0x19, 'Mushroom Kingdom II', 'GrI2.dat', 'grinishie2.c'),
    StageCatalogEntry(0x16, 0x0F, 'Venom', 'GrVe.dat', 'grcorneria.c'),
    StageCatalogEntry(0x17, 0x11, 'Poke Floats', 'GrPu.dat', 'grpura.c'),
    StageCatalogEntry(0x18, 0x13, 'Big Blue', 'GrBb.dat', 'grbigblue.c'),
    StageCatalogEntry(0x19, 0x16, 'Icicle Mountain', 'GrIm.dat', 'gricemt.c'),
    StageCatalogEntry(0x1B, 0x1B, 'Flat Zone', 'GrFz.dat', 'grflatzone.c'),
    StageCatalogEntry(0x1C, 0x1C, 'Dream Land (N64)', 'GrOp.dat', 'groldpupupu.c'),
    StageCatalogEntry(0x1D, 0x1D, "Yoshi's Island (N64)", 'GrOy.dat', 'groldyoshi.c'),
    StageCatalogEntry(0x1E, 0x1E, 'Kongo Jungle (N64)', 'GrOk.dat', 'groldkongo.c'),
    StageCatalogEntry(0x1F, 0x24, 'Battlefield', 'GrNBa.dat', 'grbattle.c'),
    StageCatalogEntry(0x20, 0x25, 'Final Destination', 'GrNLa.dat', 'grlast.c'),
    # Retail Adventure-only route archives. Their StKind values are the
    # single-player stage_id_map indices used by Adventure, not versus slots.
    StageCatalogEntry(0x3B, 0x1F, 'Adventure — Mushroom Kingdom Route', 'GrNKr.dat', 'grkinokoroute.c', False),
    StageCatalogEntry(0x3F, 0x20, 'Adventure — Underground Maze Route', 'GrNSr.dat', 'grshrineroute.c', False),
    StageCatalogEntry(0x42, 0x21, 'Adventure — Brinstar Escape Route', 'GrNZr.dat', 'grzebesroute.c', False),
    StageCatalogEntry(0x49, 0x22, 'Adventure — F-Zero Grand Prix Route', 'GrNBr.dat', 'grbigblueroute.c', False),
]
CATALOG_BY_FILENAME = {x.filename.lower(): x for x in STAGE_CATALOG}


@dataclass
class CollisionSummary:
    vertex_count: int
    line_count: int
    floor_start: int
    floor_count: int
    ceiling_start: int
    ceiling_count: int
    right_wall_start: int
    right_wall_count: int
    left_wall_start: int
    left_wall_count: int
    dynamic_start: int
    dynamic_count: int
    joint_count: int


class StageDAT:
    """Conservative stage DAT parser/editor for source-validated primitives.

    Phase 14 deliberately starts with stable archive-level structures used by
    grDatFiles_801C6038: map_head, coll_data, and grGroundParam. Geometry edits
    operate on the direct Vec2 vertex array behind MapCollData. Camera/blast-zone
    marker editing is not guessed: those bounds are derived at runtime from JObj
    marker IDs 0x94..0x98 and are left for the next validated layer.
    """

    def __init__(self, path_or_bytes: str | Path | bytes | bytearray):
        if isinstance(path_or_bytes, (str, Path)):
            self.path = Path(path_or_bytes)
            raw = self.path.read_bytes()
        else:
            self.path = None
            raw = bytes(path_or_bytes)
        self.archive = HSDArchive(raw)
        self.filename = self.path.name if self.path else '<memory>'
        self.catalog = CATALOG_BY_FILENAME.get(self.filename.lower())
        self._public = {p.name: p.offset for p in self.archive.publics}

    def public_symbols(self) -> list[dict[str, Any]]:
        return [{'name': p.name, 'offset': p.offset} for p in self.archive.publics]

    def has_public(self, name: str) -> bool:
        return name in self._public

    def public_offset(self, name: str) -> int:
        if name not in self._public:
            raise KeyError(f'{name} is not present in {self.filename}')
        return self._public[name]

    def _bounds(self, off: int, size: int, what: str) -> None:
        if off < 0 or size < 0 or off + size > self.archive.header.data_size:
            raise ValueError(f'{what} lies outside the HSD data section: 0x{off:X}+0x{size:X}')

    def ground_param(self) -> dict[str, Any] | None:
        if not self.has_public('grGroundParam'):
            return None
        off = self.public_offset('grGroundParam')
        self._bounds(off, 0xDC, 'grGroundParam')
        # Only semantically identified fields are named here.
        return {
            'offset': off,
            'stage_scale': self.archive.data_f32(off + 0x00),
            'fixed_camera': bool(self.archive.data_u32(off + 0x4C)),
            'stage_param_pointer': self.archive.data_u32(off + 0xB0),
            'stage_param_count': self.archive.data_i32(off + 0xB4),
        }

    def set_stage_scale(self, value: float) -> None:
        if not math.isfinite(value) or value <= 0:
            raise ValueError('Stage scale must be a finite number greater than zero.')
        off = self.public_offset('grGroundParam')
        self.archive.write_data_f32(off, float(value))

    def set_fixed_camera(self, enabled: bool) -> None:
        off = self.public_offset('grGroundParam')
        self.archive.write_data_u32(off + 0x4C, 1 if enabled else 0)

    def _coll_root(self) -> int:
        off = self.public_offset('coll_data')
        self._bounds(off, 0x30, 'MapCollData')
        return off

    def collision_summary(self) -> CollisionSummary | None:
        if not self.has_public('coll_data'):
            return None
        o = self._coll_root()
        # MapCollData layout from src/melee/mp/types.h.
        vals = struct.unpack_from('>II II 10h II I', self.archive.raw, self.archive.data_start + o)
        # Explicit reads are clearer than depending on tuple layout quirks.
        s16 = lambda rel: BE_I16.unpack_from(self.archive.raw, self.archive.data_start + o + rel)[0]
        return CollisionSummary(
            vertex_count=self.archive.data_i32(o + 0x04),
            line_count=self.archive.data_i32(o + 0x0C),
            floor_start=s16(0x10), floor_count=s16(0x12),
            ceiling_start=s16(0x14), ceiling_count=s16(0x16),
            right_wall_start=s16(0x18), right_wall_count=s16(0x1A),
            left_wall_start=s16(0x1C), left_wall_count=s16(0x1E),
            dynamic_start=s16(0x20), dynamic_count=s16(0x22),
            joint_count=self.archive.data_i32(o + 0x28),
        )

    def vertices(self) -> list[tuple[float, float]]:
        o = self._coll_root()
        ptr = self.archive.data_u32(o + 0x00)
        count = self.archive.data_i32(o + 0x04)
        if count < 0 or count > 100000:
            raise ValueError(f'Unreasonable collision vertex count: {count}')
        self._bounds(ptr, count * 8, 'collision vertex array')
        out = []
        for i in range(count):
            x = self.archive.data_f32(ptr + i * 8)
            y = self.archive.data_f32(ptr + i * 8 + 4)
            if not (math.isfinite(x) and math.isfinite(y)):
                raise ValueError(f'Collision vertex {i} contains non-finite coordinates')
            out.append((x, y))
        return out

    def set_vertex(self, index: int, x: float, y: float) -> None:
        if not (math.isfinite(x) and math.isfinite(y)):
            raise ValueError('Collision coordinates must be finite.')
        o = self._coll_root()
        ptr = self.archive.data_u32(o + 0x00)
        count = self.archive.data_i32(o + 0x04)
        if not 0 <= index < count:
            raise IndexError(index)
        self._bounds(ptr + index * 8, 8, 'collision vertex')
        self.archive.write_data_f32(ptr + index * 8, float(x))
        self.archive.write_data_f32(ptr + index * 8 + 4, float(y))

    def lines(self) -> list[dict[str, int]]:
        o = self._coll_root()
        ptr = self.archive.data_u32(o + 0x08)
        count = self.archive.data_i32(o + 0x0C)
        if count < 0 or count > 100000:
            raise ValueError(f'Unreasonable collision line count: {count}')
        self._bounds(ptr, count * 0x10, 'collision line array')
        out = []
        for i in range(count):
            p = self.archive.data_start + ptr + i * 0x10
            v0, v1 = struct.unpack_from('>HH', self.archive.raw, p)
            prev0, next0, prev1, next1 = struct.unpack_from('>hhhh', self.archive.raw, p + 4)
            hi, lo = struct.unpack_from('>HH', self.archive.raw, p + 0x0C)
            out.append({'index': i, 'v0': v0, 'v1': v1, 'prev0': prev0, 'next0': next0,
                        'prev1': prev1, 'next1': next1, 'hi_flags': hi, 'lo_flags': lo})
        return out

    def validate(self) -> dict[str, Any]:
        result: dict[str, Any] = {
            'filename': self.filename,
            'catalog_name': self.catalog.name if self.catalog else None,
            'public_symbols': [p.name for p in self.archive.publics],
            'archive_size': len(self.archive.raw),
            'data_size': self.archive.header.data_size,
            'relocations': self.archive.header.nb_reloc,
        }
        if self.has_public('coll_data'):
            summary = self.collision_summary()
            verts = self.vertices()
            lines = self.lines()
            if any(x['v0'] >= len(verts) or x['v1'] >= len(verts) for x in lines):
                raise ValueError('Collision line references a vertex outside the vertex array.')
            result['collision'] = asdict(summary)
            result['collision']['validated_vertices'] = len(verts)
            result['collision']['validated_lines'] = len(lines)
        if self.has_public('grGroundParam'):
            gp = self.ground_param()
            if gp['stage_param_count'] < 0 or gp['stage_param_count'] > 10000:
                raise ValueError('Unreasonable StageParam count')
            result['ground_param'] = gp
        result['status'] = 'PASS'
        return result

    def bytes(self) -> bytes:
        return bytes(self.archive.raw)

    def save_as(self, path: str | Path) -> Path:
        path = Path(path)
        path.write_bytes(self.bytes())
        return path


def scan_stage_folder(folder: str | Path) -> list[dict[str, Any]]:
    folder = Path(folder)
    rows = []
    for p in sorted(folder.glob('Gr*.dat'), key=lambda x: x.name.lower()):
        try:
            st = StageDAT(p)
            r = st.validate()
        except Exception as e:
            rows.append({'filename': p.name, 'status': 'FAIL', 'error': str(e)})
        else:
            rows.append(r)
    return rows

# --- Phase 15: marker/joint/material authoring ---------------------------------

JOBJ_INSTANCE = 1 << 12
COLL_KIND_NAMES = {1: 'Floor', 2: 'Ceiling', 4: 'Right Wall', 8: 'Left Wall'}
MARKER_NAMES = {0:'Player Spawn 1',1:'Player Spawn 2',2:'Player Spawn 3',3:'Player Spawn 4',4:'Respawn Platform 1',5:'Respawn Platform 2',6:'Respawn Platform 3',7:'Respawn Platform 4',0x94:'Camera Center',0x95:'Camera Range A',0x96:'Camera Range B',0x97:'Blast Zone A',0x98:'Blast Zone B'}

@dataclass
class StageMarker:
    marker_id:int; name:str; joint_offset:int; map_joint_offset:int; preorder_index:int
    local_x:float; local_y:float; local_z:float; world_x:float; world_y:float; world_z:float

def _mat_mul(a,b):
    return [[sum(a[r][k]*b[k][c] for k in range(4)) for c in range(4)] for r in range(4)]

def _local_srt(scale,rot,pos,parent_scl=None):
    sx,sy,sz=scale; rx,ry,rz=rot; tx,ty,tz=pos
    sinx,cosx=math.sin(rx),math.cos(rx); siny,cosy=math.sin(ry),math.cos(ry); sinz,cosz=math.sin(rz),math.cos(rz)
    sx2=sx1=sxx=sx; sy2=sy1=syy=sy; sz2=sz1=szz=sz
    if parent_scl is not None and all(abs(v)>1e-12 for v in parent_scl):
        psx,psy,psz=parent_scl
        sx2*=psy/psx; sz2*=psz/psx; sx1*=psx/psy; sz1*=psz/psy; sxx*=psx/psz; syy*=psy/psz
    return [[cosz*(sx2*cosy),sy2*((cosz*(sinx*siny))-(cosx*sinz)),sz2*((cosz*(cosx*siny))+(sinx*sinz)),tx],
            [sinz*(sx1*cosy),sy1*((sinz*(sinx*siny))+(cosx*cosz)),sz1*((sinz*(cosx*siny))-(sinx*cosz)),ty],
            [-sxx*siny,cosy*(syy*sinx),cosy*(szz*cosx),tz],[0.0,0.0,0.0,1.0]]

def _transform_point(m,p):
    x,y,z=p
    return (m[0][0]*x+m[0][1]*y+m[0][2]*z+m[0][3],m[1][0]*x+m[1][1]*y+m[1][2]*z+m[1][3],m[2][0]*x+m[2][1]*y+m[2][2]*z+m[2][3])

def _affine_inverse(m):
    a,b,c=m[0][:3]; d,e,f=m[1][:3]; g,h,i=m[2][:3]
    det=a*(e*i-f*h)-b*(d*i-f*g)+c*(d*h-e*g)
    if abs(det)<1e-12: raise ValueError('Marker parent transform is singular; world-space editing is unavailable.')
    inv=[[ (e*i-f*h)/det,(c*h-b*i)/det,(b*f-c*e)/det],[(f*g-d*i)/det,(a*i-c*g)/det,(c*d-a*f)/det],[(d*h-e*g)/det,(b*g-a*h)/det,(a*e-b*d)/det]]
    t=[m[0][3],m[1][3],m[2][3]]; it=[-sum(inv[r][k]*t[k] for k in range(3)) for r in range(3)]
    return [inv[0]+[it[0]],inv[1]+[it[1]],inv[2]+[it[2]],[0.0,0.0,0.0,1.0]]

def _stage_joint_record(self,off):
    self._bounds(off,0x40,'HSD_Joint')
    return {'offset':off,'flags':self.archive.data_u32(off+4),'child':self.archive.data_u32(off+8),'next':self.archive.data_u32(off+0xC),
            'rotation':tuple(self.archive.data_f32(off+0x14+i*4) for i in range(3)),
            'scale':tuple(self.archive.data_f32(off+0x20+i*4) for i in range(3)),
            'position':tuple(self.archive.data_f32(off+0x2C+i*4) for i in range(3))}

def _flatten_joint_tree(self,root_off):
    out=[]; seen=set()
    def walk(off,parent_index,parent_world,parent_scl):
        while off:
            if off in seen: raise ValueError(f'Cycle detected in HSD_Joint descriptor tree at 0x{off:X}')
            seen.add(off); node=_stage_joint_record(self,off)
            local=_local_srt(node['scale'],node['rotation'],node['position'],parent_scl); world=_mat_mul(parent_world,local) if parent_world else local
            idx=len(out); node['parent_index']=parent_index; node['world_matrix']=world; node['world_position']=_transform_point(world,(0,0,0)); out.append(node)
            scl=tuple(node['scale'][k]*(parent_scl[k] if parent_scl else 1.0) for k in range(3))
            if node['child'] and not (node['flags'] & JOBJ_INSTANCE): walk(node['child'],idx,world,scl)
            off=node['next']
    walk(root_off,None,None,None); return out

def _marker_bindings(self):
    if not self.has_public('map_head'): return []
    root=self.public_offset('map_head'); self._bounds(root,0x30,'map_head')
    table=self.archive.data_u32(root); count=self.archive.data_i32(root+4)
    if not 0<=count<=4096: raise ValueError(f'Unreasonable map_head marker table count: {count}')
    self._bounds(table,count*0x0C,'map_head marker table'); rows=[]
    for entry_i in range(count):
        eoff=table+entry_i*0x0C; joint=self.archive.data_u32(eoff); pairs=self.archive.data_u32(eoff+4); pair_count=self.archive.data_i32(eoff+8)
        if not joint or pair_count<=0: continue
        if pair_count>4096: raise ValueError('Unreasonable marker pair count')
        self._bounds(pairs,pair_count*4,'marker pair table'); flat=_flatten_joint_tree(self,joint)
        for j in range(pair_count):
            preorder,marker=struct.unpack_from('>hh',self.archive.raw,self.archive.data_start+pairs+j*4)
            if preorder<0 or preorder>=len(flat): raise ValueError(f'Marker {marker} references HSD_Joint preorder index {preorder}, tree has {len(flat)} nodes')
            rows.append({'marker_id':marker & 0xFFFF,'preorder_index':preorder,'entry_index':entry_i,'map_joint_offset':joint,'joint':flat[preorder],'flat':flat})
    return rows

def _markers(self):
    out=[]
    for b in _marker_bindings(self):
        j=b['joint']; p=j['position']; w=j['world_position']; mid=b['marker_id']
        out.append(StageMarker(mid,MARKER_NAMES.get(mid,f'Marker 0x{mid:02X}'),j['offset'],b['map_joint_offset'],b['preorder_index'],*p,*w))
    return sorted(out,key=lambda m:(m.marker_id,m.joint_offset))

def _set_marker_local(self,marker_id,x,y,z=0.0,occurrence=0):
    vals=[m for m in _markers(self) if m.marker_id==int(marker_id)]
    if not 0<=occurrence<len(vals): raise KeyError(f'Marker 0x{int(marker_id):02X} occurrence {occurrence} not found')
    if not all(math.isfinite(v) for v in (x,y,z)): raise ValueError('Marker coordinates must be finite')
    for i,v in enumerate((x,y,z)): self.archive.write_data_f32(vals[occurrence].joint_offset+0x2C+i*4,float(v))

def _set_marker_world(self,marker_id,x,y,z=0.0,occurrence=0):
    vals=[b for b in _marker_bindings(self) if b['marker_id']==int(marker_id)]
    if not 0<=occurrence<len(vals): raise KeyError(f'Marker 0x{int(marker_id):02X} occurrence {occurrence} not found')
    b=vals[occurrence]; j=b['joint']; pi=j['parent_index']; local=(x,y,z) if pi is None else _transform_point(_affine_inverse(b['flat'][pi]['world_matrix']),(x,y,z))
    _set_marker_local(self,marker_id,*local,occurrence=occurrence)

def _camera_blast(self):
    ms={m.marker_id:m for m in _markers(self)}; out={'camera':None,'blast':None}
    if all(k in ms for k in (0x94,0x95,0x96)):
        c,a,b=ms[0x94],ms[0x95],ms[0x96]; out['camera']={'center_x':c.world_x,'center_y':c.world_y,'left':min(a.world_x,b.world_x)-c.world_x,'right':max(a.world_x,b.world_x)-c.world_x,'bottom':min(a.world_y,b.world_y)-c.world_y,'top':max(a.world_y,b.world_y)-c.world_y}
    if out['camera'] and all(k in ms for k in (0x97,0x98)):
        a,b=ms[0x97],ms[0x98]; c=out['camera']; out['blast']={'left':min(a.world_x,b.world_x)-c['center_x'],'right':max(a.world_x,b.world_x)-c['center_x'],'bottom':min(a.world_y,b.world_y)-c['center_y'],'top':max(a.world_y,b.world_y)-c['center_y']}
    return out

def _set_camera_bounds(self,*,center_x,center_y,left,right,bottom,top):
    if left>=right or bottom>=top: raise ValueError('Camera bounds require left < right and bottom < top')
    _set_marker_world(self,0x94,center_x,center_y); _set_marker_world(self,0x95,center_x+left,center_y+bottom); _set_marker_world(self,0x96,center_x+right,center_y+top)

def _set_blast_bounds(self,*,left,right,bottom,top):
    cb=_camera_blast(self)['camera']
    if cb is None: raise ValueError('Camera center marker 0x94 is required before blast-zone editing')
    if left>=right or bottom>=top: raise ValueError('Blast bounds require left < right and bottom < top')
    cx,cy=cb['center_x'],cb['center_y']; _set_marker_world(self,0x97,cx+left,cy+bottom); _set_marker_world(self,0x98,cx+right,cy+top)

def _line_category(self,index):
    s=self.collision_summary()
    if s is None:return 'Unknown'
    for name,start,count in [('Floor',s.floor_start,s.floor_count),('Ceiling',s.ceiling_start,s.ceiling_count),('Right Wall',s.right_wall_start,s.right_wall_count),('Left Wall',s.left_wall_start,s.left_wall_count),('Dynamic',s.dynamic_start,s.dynamic_count)]:
        if start<=index<start+count:return name
    return 'Unclassified'

def _line_surface(self,index):
    lines=self.lines()
    if not 0<=index<len(lines):raise IndexError(index)
    ln=lines[index]; lo=ln['lo_flags']; hi=ln['hi_flags']
    return {'index':index,'category':_line_category(self,index),'kind_bits':hi&0xF,'kind':COLL_KIND_NAMES.get(hi&0xF,f'0x{hi&0xF:X}'),'material_id':lo&0xFF,'platform':bool(lo&0x100),'ledge':bool(lo&0x200),'dynamic_platform_source':bool(lo&0x400),'hi_flags':hi,'lo_flags':lo}

def _set_line_surface(self,index,*,material_id=None,platform=None,ledge=None,dynamic_platform_source=None):
    o=self._coll_root(); ptr=self.archive.data_u32(o+8); count=self.archive.data_i32(o+0xC)
    if not 0<=index<count:raise IndexError(index)
    p=self.archive.data_start+ptr+index*0x10+0x0E; lo=BE_U16.unpack_from(self.archive.raw,p)[0]
    if material_id is not None:
        if not 0<=int(material_id)<=255:raise ValueError('Material/surface lookup ID must be 0..255')
        lo=(lo&~0xFF)|int(material_id)
    for bit,val in ((0x100,platform),(0x200,ledge),(0x400,dynamic_platform_source)):
        if val is not None:lo=(lo|bit) if val else (lo&~bit)
    BE_U16.pack_into(self.archive.raw,p,lo)

def _map_joints(self):
    o=self._coll_root(); ptr=self.archive.data_u32(o+0x24); count=self.archive.data_i32(o+0x28)
    if not 0<=count<=4096:raise ValueError('Unreasonable collision joint count')
    self._bounds(ptr,count*0x28,'MapJoint array'); out=[]
    for idx in range(count):
        q=ptr+idx*0x28; vals=[BE_I16.unpack_from(self.archive.raw,self.archive.data_start+q+i*2)[0] for i in range(10)]; b=tuple(self.archive.data_f32(q+0x14+i*4) for i in range(4)); vs=BE_I16.unpack_from(self.archive.raw,self.archive.data_start+q+0x24)[0]; vc=BE_I16.unpack_from(self.archive.raw,self.archive.data_start+q+0x26)[0]
        out.append({'index':idx,'floor_start':vals[0],'floor_count':vals[1],'ceiling_start':vals[2],'ceiling_count':vals[3],'right_wall_start':vals[4],'right_wall_count':vals[5],'left_wall_start':vals[6],'left_wall_count':vals[7],'dynamic_start':vals[8],'dynamic_count':vals[9],'left_bound':b[0],'bottom_bound':b[1],'right_bound':b[2],'top_bound':b[3],'vtx_start':vs,'vtx_count':vc})
    return out

def _set_joint_bounds(self,index,left,bottom,right,top):
    if left>right or bottom>top:raise ValueError('Joint bounds require left <= right and bottom <= top')
    o=self._coll_root(); ptr=self.archive.data_u32(o+0x24); count=self.archive.data_i32(o+0x28)
    if not 0<=index<count:raise IndexError(index)
    q=ptr+index*0x28+0x14
    for i,v in enumerate((left,bottom,right,top)):
        if not math.isfinite(v):raise ValueError('Joint bounds must be finite')
        self.archive.write_data_f32(q+i*4,float(v))

def _translate_joint_vertices(self,index,dx,dy):
    joints=_map_joints(self)
    if not 0<=index<len(joints):raise IndexError(index)
    j=joints[index]; verts=self.vertices()
    if j['vtx_start']<0 or j['vtx_count']<0 or j['vtx_start']+j['vtx_count']>len(verts):raise ValueError('Collision joint vertex range is invalid')
    for vi in range(j['vtx_start'],j['vtx_start']+j['vtx_count']):
        x,y=verts[vi];self.set_vertex(vi,x+dx,y+dy)
    _set_joint_bounds(self,index,j['left_bound']+dx,j['bottom_bound']+dy,j['right_bound']+dx,j['top_bound']+dy)

def _clone_to(self,path):
    path=Path(path)
    if path.suffix.lower()!='.dat':path=path.with_suffix('.dat')
    path.write_bytes(self.bytes());return path

StageDAT.joint_record=_stage_joint_record; StageDAT.flatten_joint_tree=_flatten_joint_tree; StageDAT.marker_bindings=_marker_bindings; StageDAT.markers=_markers
StageDAT.set_marker_local=_set_marker_local; StageDAT.set_marker_world=_set_marker_world; StageDAT.camera_blast_bounds=_camera_blast; StageDAT.set_camera_bounds=_set_camera_bounds; StageDAT.set_blast_bounds=_set_blast_bounds
StageDAT.line_category=_line_category; StageDAT.line_surface=_line_surface; StageDAT.set_line_surface=_set_line_surface; StageDAT.map_joints=_map_joints; StageDAT.set_joint_bounds=_set_joint_bounds; StageDAT.translate_joint_vertices=_translate_joint_vertices; StageDAT.clone_to=_clone_to

# Enrich structural validation with Phase 15 stage-authoring structures.
_phase14_validate = StageDAT.validate
def _phase15_validate(self: StageDAT) -> dict[str, Any]:
    result = _phase14_validate(self)
    if self.has_public('map_head'):
        markers = self.markers()
        result['markers'] = {
            'count': len(markers),
            'ids': [m.marker_id for m in markers],
            'camera_blast': self.camera_blast_bounds(),
        }
    if self.has_public('coll_data'):
        result['collision']['joint_records'] = len(self.map_joints())
        result['collision']['surface_flags_checked'] = len(self.lines())
    return result
StageDAT.validate = _phase15_validate

# --- Phase 17: structural collision authoring --------------------------------
_COLL_CAT_REL = {
    'floor': 0x10,
    'ceiling': 0x14,
    'right wall': 0x18,
    'left wall': 0x1C,
    'dynamic': 0x20,
}

def _pack_map_line(row: dict[str, int]) -> bytes:
    return struct.pack('>HHhhhhHH',
        int(row['v0']), int(row['v1']),
        int(row['prev0']), int(row['next0']), int(row['prev1']), int(row['next1']),
        int(row['hi_flags']) & 0xFFFF, int(row['lo_flags']) & 0xFFFF)


def _add_collision_segment(self: StageDAT, *, joint_index: int, category: str,
                           x0: float, y0: float, x1: float, y1: float,
                           material_id: int = 0, platform: bool = False,
                           ledge: bool = False, dynamic_platform_source: bool = False) -> dict[str, Any]:
    """Insert a new two-vertex MapLine while preserving indexed collision tables.

    The line and its two vertices are inserted at the end of the selected
    MapJoint's contiguous ranges. All affected line/vertex indices, adjacency
    references, global category ranges, MapJoint ranges and target bounds are
    shifted together. The operation refuses a joint/category relationship that
    is not already contiguous in the vanilla topology rather than guessing.
    """
    category_key = category.strip().lower()
    if category_key not in _COLL_CAT_REL:
        raise ValueError('category must be Floor, Ceiling, Right Wall, Left Wall, or Dynamic')
    vals = (x0, y0, x1, y1)
    if not all(math.isfinite(float(v)) for v in vals):
        raise ValueError('Collision coordinates must be finite')
    if not 0 <= int(material_id) <= 255:
        raise ValueError('Material/surface lookup ID must be 0..255')

    summary = self.collision_summary()
    joints = self.map_joints()
    vertices = self.vertices()
    lines = self.lines()
    if summary is None:
        raise ValueError('Stage has no coll_data')
    if not 0 <= int(joint_index) < len(joints):
        raise IndexError(joint_index)
    j = joints[int(joint_index)]

    key_prefix = category_key.replace(' ', '_')
    start_key = key_prefix + '_start'
    count_key = key_prefix + '_count'
    if start_key not in j:
        raise ValueError(f'MapJoint has no {category} range')
    line_insert = j[start_key] + j[count_key]
    global_start = getattr(summary, start_key)
    global_count = getattr(summary, count_key)
    if not (global_start <= line_insert <= global_start + global_count):
        raise ValueError('Selected MapJoint category range is not contiguous with the global category range')

    vertex_insert = j['vtx_start'] + j['vtx_count']
    if not 0 <= vertex_insert <= len(vertices):
        raise ValueError('Selected MapJoint vertex range is invalid')

    # Insert vertices into the owning joint's contiguous vertex range.
    new_vertices = list(vertices)
    new_vertices[vertex_insert:vertex_insert] = [(float(x0), float(y0)), (float(x1), float(y1))]

    # Shift vertex and adjacency indices in existing lines before inserting one.
    shifted_lines: list[dict[str, int]] = []
    for row in lines:
        q = dict(row)
        for vk in ('v0', 'v1'):
            if q[vk] >= vertex_insert:
                q[vk] += 2
        for lk in ('prev0', 'next0', 'prev1', 'next1'):
            if q[lk] >= line_insert:
                q[lk] += 1
        shifted_lines.append(q)

    lo = int(material_id) & 0xFF
    if platform: lo |= 0x100
    if ledge: lo |= 0x200
    if dynamic_platform_source: lo |= 0x400
    kind_bits = {'floor':0, 'ceiling':1, 'right wall':2, 'left wall':3, 'dynamic':0}.get(category_key, 0)
    new_line = {'index': line_insert, 'v0': vertex_insert, 'v1': vertex_insert + 1,
                'prev0': -1, 'next0': -1, 'prev1': -1, 'next1': -1,
                'hi_flags': kind_bits, 'lo_flags': lo}
    shifted_lines[line_insert:line_insert] = [new_line]

    o = self._coll_root()
    vptr = self.archive.data_u32(o + 0x00)
    lptr = self.archive.data_u32(o + 0x08)
    old_v_bytes = len(vertices) * 8
    old_l_bytes = len(lines) * 0x10
    vb = b''.join(struct.pack('>ff', x, y) for x,y in new_vertices)
    lb = b''.join(_pack_map_line(row) for row in shifted_lines)
    self.archive.replace_data_ranges([(vptr, old_v_bytes, vb), (lptr, old_l_bytes, lb)], align_to=0x20)
    self._public = {p.name:p.offset for p in self.archive.publics}

    # Counts/ranges are integral metadata, not relocatable pointers.
    o = self._coll_root()
    self.archive.write_data_i32(o + 0x04, len(new_vertices))
    self.archive.write_data_i32(o + 0x0C, len(shifted_lines))
    category_rel = _COLL_CAT_REL[category_key]
    old_global = {}
    for ck, rel in _COLL_CAT_REL.items():
        st = BE_I16.unpack_from(self.archive.raw, self.archive.data_start + o + rel)[0]
        ct = BE_I16.unpack_from(self.archive.raw, self.archive.data_start + o + rel + 2)[0]
        old_global[ck] = [st, ct]
    # Values above were preserved from old archive. Shift all later category starts.
    for ck, (st, ct) in old_global.items():
        if ck == category_key:
            ct += 1
        elif st >= line_insert:
            st += 1
        BE_I16.pack_into(self.archive.raw, self.archive.data_start + o + _COLL_CAT_REL[ck], st)
        BE_I16.pack_into(self.archive.raw, self.archive.data_start + o + _COLL_CAT_REL[ck] + 2, ct)

    # Update every MapJoint's line and vertex ranges.
    jptr = self.archive.data_u32(o + 0x24)
    for idx, oldj in enumerate(joints):
        q = jptr + idx * 0x28
        for ci, ck in enumerate(('floor','ceiling','right wall','left wall','dynamic')):
            sk = ck.replace(' ','_') + '_start'; ck_count = ck.replace(' ','_') + '_count'
            st, ct = oldj[sk], oldj[ck_count]
            if idx == joint_index and ck == category_key:
                ct += 1
            elif st >= line_insert:
                st += 1
            BE_I16.pack_into(self.archive.raw, self.archive.data_start + q + ci*4, st)
            BE_I16.pack_into(self.archive.raw, self.archive.data_start + q + ci*4 + 2, ct)
        vst, vct = oldj['vtx_start'], oldj['vtx_count']
        if idx == joint_index:
            vct += 2
        elif vst >= vertex_insert:
            vst += 2
        BE_I16.pack_into(self.archive.raw, self.archive.data_start + q + 0x24, vst)
        BE_I16.pack_into(self.archive.raw, self.archive.data_start + q + 0x26, vct)

    # Expand the owner's base bounds to include the inserted segment.
    target = self.map_joints()[joint_index]
    self.set_joint_bounds(joint_index,
        min(target['left_bound'], x0, x1), min(target['bottom_bound'], y0, y1),
        max(target['right_bound'], x0, x1), max(target['top_bound'], y0, y1))
    self.validate()
    return {'joint_index': joint_index, 'category': category.title(),
            'line_index': line_insert, 'vertex_indices': [vertex_insert, vertex_insert+1],
            'new_vertex_count': len(new_vertices), 'new_line_count': len(shifted_lines)}

StageDAT.add_collision_segment = _add_collision_segment

STAGEDATA_SYMBOL_BY_FILENAME = {
    'griz.dat':'grIz_StageData','grps.dat':'grPs_StageData','grcs.dat':'grCs_StageData',
    'grkg.dat':'grKg_StageData','grze.dat':'grZe_StageData','grcn.dat':'grCn_StageData',
    'grst.dat':'grSt_StageData','grot.dat':'grOt_StageData','grmc.dat':'grMc_StageData',
    'grrc.dat':'grRc_StageData','grgd.dat':'grGd_StageData','grgb.dat':'grGb_StageData',
    'grsh.dat':'grSh_StageData','grkr.dat':'grKr_StageData','gryt.dat':'grYt_StageData',
    'grgr.dat':'grGr_StageData','grfs.dat':'grFs_StageData','gri1.dat':'grI1_StageData',
    'gri2.dat':'grI2_StageData','grpu.dat':'grPu_StageData','grbb.dat':'grBb_StageData',
    'grim.dat':'grIm_StageData','grfz.dat':'grFz_StageData','grop.dat':'grOp_StageData',
    'groy.dat':'grOy_StageData','grok.dat':'grOk_StageData','grnba.dat':'grNBa_StageData',
    'grnla.dat':'grNLa_StageData',
}

# --- Phase 18: collision topology editing -------------------------------------

def _collision_category_for_index(self: StageDAT, index: int) -> str:
    s=self.collision_summary()
    if s is None: raise ValueError('Stage has no collision data')
    for key in ('floor','ceiling','right_wall','left_wall','dynamic'):
        st=getattr(s,key+'_start'); ct=getattr(s,key+'_count')
        if st <= index < st+ct: return key.replace('_',' ')
    raise ValueError(f'Collision line {index} is outside every global category range')


def _replace_collision_arrays_phase18(self: StageDAT, old_vertices, old_lines, new_vertices, new_lines) -> None:
    o=self._coll_root(); vptr=self.archive.data_u32(o); lptr=self.archive.data_u32(o+8)
    vb=b''.join(struct.pack('>ff',float(x),float(y)) for x,y in new_vertices)
    lb=b''.join(_pack_map_line(r) for r in new_lines)
    self.archive.replace_data_ranges([(vptr,len(old_vertices)*8,vb),(lptr,len(old_lines)*0x10,lb)],align_to=0x20)
    self._public={p.name:p.offset for p in self.archive.publics}
    o=self._coll_root(); self.archive.write_data_i32(o+4,len(new_vertices)); self.archive.write_data_i32(o+0xC,len(new_lines))


def _delete_collision_line(self: StageDAT, line_index: int, *, remove_unused_vertices: bool=True) -> dict[str,Any]:
    """Delete one collision line and safely compact indexed topology.

    Adjacency references to the removed line are cleared to -1. Vertices used only
    by the removed line are optionally compacted as well. Global and MapJoint
    category/vertex ranges are adjusted together.
    """
    line_index=int(line_index); old_v=self.vertices(); old_l=self.lines(); joints=self.map_joints(); s=self.collision_summary()
    if s is None: raise ValueError('Stage has no collision data')
    if not 0<=line_index<len(old_l): raise IndexError(line_index)
    target=old_l[line_index]; cat=_collision_category_for_index(self,line_index)
    cat_key=cat.replace(' ','_')
    # Determine vertices that become unused after removing this line.
    candidate=sorted({target['v0'],target['v1']})
    used_elsewhere={r[k] for i,r in enumerate(old_l) if i!=line_index for k in ('v0','v1')}
    remove_v=[v for v in candidate if remove_unused_vertices and v not in used_elsewhere]
    keep_v=[i for i in range(len(old_v)) if i not in set(remove_v)]
    vmap={old:new for new,old in enumerate(keep_v)}
    new_v=[old_v[i] for i in keep_v]

    keep_l=[i for i in range(len(old_l)) if i!=line_index]
    lmap={old:new for new,old in enumerate(keep_l)}
    new_l=[]
    for oi in keep_l:
        q=dict(old_l[oi]); q['index']=lmap[oi]
        q['v0']=vmap[q['v0']]; q['v1']=vmap[q['v1']]
        for k in ('prev0','next0','prev1','next1'):
            val=q[k]
            if val==line_index: q[k]=-1
            elif val>=0: q[k]=lmap[val]
        new_l.append(q)

    # Save old metadata before replacing arrays.
    global_ranges={k:[getattr(s,k.replace(' ','_')+'_start'),getattr(s,k.replace(' ','_')+'_count')] for k in _COLL_CAT_REL}
    old_joint_rows=[dict(j) for j in joints]
    _replace_collision_arrays_phase18(self,old_v,old_l,new_v,new_l)
    o=self._coll_root()
    for key,(st,ct) in global_ranges.items():
        if key==cat: ct-=1
        elif st>line_index: st-=1
        rel=_COLL_CAT_REL[key]; struct.pack_into('>hh',self.archive.raw,self.archive.data_start+o+rel,st,ct)
    jptr=self.archive.data_u32(o+0x24)
    removed_set=set(remove_v)
    for ji,j in enumerate(old_joint_rows):
        q=jptr+ji*0x28
        for ci,key in enumerate(('floor','ceiling','right wall','left wall','dynamic')):
            sk=key.replace(' ','_')+'_start'; ck=key.replace(' ','_')+'_count'; st,ct=j[sk],j[ck]
            if st<=line_index<st+ct: ct-=1
            elif st>line_index: st-=1
            struct.pack_into('>hh',self.archive.raw,self.archive.data_start+q+ci*4,st,ct)
        vst,vct=j['vtx_start'],j['vtx_count']
        inside=sum(1 for v in remove_v if vst<=v<vst+vct)
        before=sum(1 for v in remove_v if v<vst)
        vst-=before; vct-=inside
        struct.pack_into('>hh',self.archive.raw,self.archive.data_start+q+0x24,vst,vct)
    self.validate()
    return {'deleted_line':line_index,'category':cat.title(),'removed_vertices':remove_v,
            'new_vertex_count':len(new_v),'new_line_count':len(new_l)}


def _split_collision_line(self: StageDAT, line_index: int, fraction: float=0.5) -> dict[str,Any]:
    """Split a line into two segments at an interpolated point, preserving surface flags."""
    line_index=int(line_index); fraction=float(fraction)
    if not 0.0<fraction<1.0: raise ValueError('Split fraction must be between 0 and 1')
    old_v=self.vertices(); old_l=self.lines(); joints=self.map_joints(); s=self.collision_summary()
    if s is None or not 0<=line_index<len(old_l): raise IndexError(line_index)
    row=old_l[line_index]; x0,y0=old_v[row['v0']]; x1,y1=old_v[row['v1']]
    mid=(x0+(x1-x0)*fraction,y0+(y1-y0)*fraction)
    cat=_collision_category_for_index(self,line_index); ck=cat.replace(' ','_')
    owner=next((i for i,j in enumerate(joints) if j[ck+'_start']<=line_index<j[ck+'_start']+j[ck+'_count']),None)
    if owner is None: raise ValueError('Could not resolve owning MapJoint for line')
    j=joints[owner]; v_insert=j['vtx_start']+j['vtx_count']; l_insert=line_index+1
    new_v=list(old_v); new_v.insert(v_insert,mid)
    def sv(v): return v+1 if v>=v_insert else v
    shifted=[]
    for i,r in enumerate(old_l):
        q=dict(r); q['v0']=sv(q['v0']); q['v1']=sv(q['v1'])
        for k in ('prev0','next0','prev1','next1'):
            if q[k]>=l_insert: q[k]+=1
        shifted.append(q)
    original=shifted[line_index]; old_end=original['v1']; original['v1']=v_insert
    second=dict(original); second['v0']=v_insert; second['v1']=old_end; second['index']=l_insert
    # Preserve the outer adjacency and connect the two split halves.
    second['prev0']=line_index; second['next0']=-1
    second['prev1']=-1; second['next1']=original['next1']
    original['next1']=l_insert
    shifted.insert(l_insert,second)
    for i,r in enumerate(shifted): r['index']=i
    global_ranges={k:[getattr(s,k.replace(' ','_')+'_start'),getattr(s,k.replace(' ','_')+'_count')] for k in _COLL_CAT_REL}
    old_j=[dict(x) for x in joints]
    _replace_collision_arrays_phase18(self,old_v,old_l,new_v,shifted)
    o=self._coll_root()
    for key,(st,ct) in global_ranges.items():
        if key==cat: ct+=1
        elif st>=l_insert: st+=1
        rel=_COLL_CAT_REL[key]; struct.pack_into('>hh',self.archive.raw,self.archive.data_start+o+rel,st,ct)
    jptr=self.archive.data_u32(o+0x24)
    for ji,x in enumerate(old_j):
        q=jptr+ji*0x28
        for ci,key in enumerate(('floor','ceiling','right wall','left wall','dynamic')):
            sk=key.replace(' ','_')+'_start'; nk=key.replace(' ','_')+'_count'; st,ct=x[sk],x[nk]
            if st<=line_index<st+ct: ct+=1
            elif st>=l_insert: st+=1
            struct.pack_into('>hh',self.archive.raw,self.archive.data_start+q+ci*4,st,ct)
        vst,vct=x['vtx_start'],x['vtx_count']
        if ji==owner: vct+=1
        elif vst>=v_insert: vst+=1
        struct.pack_into('>hh',self.archive.raw,self.archive.data_start+q+0x24,vst,vct)
    self.validate()
    return {'line_index':line_index,'new_line_index':l_insert,'new_vertex_index':v_insert,'point':mid,'category':cat.title()}


def _join_collision_lines(self: StageDAT, first_index: int, second_index: int) -> dict[str,Any]:
    """Join two same-surface lines that share one endpoint, then compact the unused midpoint."""
    first_index=int(first_index); second_index=int(second_index)
    lines=self.lines(); verts=self.vertices()
    if first_index==second_index or min(first_index,second_index)<0 or max(first_index,second_index)>=len(lines): raise IndexError((first_index,second_index))
    a,b=lines[first_index],lines[second_index]
    if self.line_category(first_index)!=self.line_category(second_index): raise ValueError('Lines must be in the same collision category')
    if (a['hi_flags'],a['lo_flags'])!=(b['hi_flags'],b['lo_flags']): raise ValueError('Lines must have matching surface/material flags')
    shared=set((a['v0'],a['v1'])) & set((b['v0'],b['v1']))
    if len(shared)!=1: raise ValueError('Lines must share exactly one vertex')
    mid=next(iter(shared)); enda=next(v for v in (a['v0'],a['v1']) if v!=mid); endb=next(v for v in (b['v0'],b['v1']) if v!=mid)
    # Rewrite the first line to span the two outer endpoints, preserving its orientation as much as possible.
    o=self._coll_root(); lptr=self.archive.data_u32(o+8); off=lptr+first_index*0x10
    if a['v1']==mid: new0,new1=enda,endb
    else: new0,new1=endb,enda
    struct.pack_into('>HH',self.archive.raw,self.archive.data_start+off,new0,new1)
    result=self.delete_collision_line(second_index,remove_unused_vertices=True)
    self.validate()
    return {'joined_into': first_index if first_index<second_index else first_index-1,'removed_line':second_index,'removed_midpoint':mid,**result}

StageDAT.collision_category_for_index=_collision_category_for_index
StageDAT.delete_collision_line=_delete_collision_line
StageDAT.split_collision_line=_split_collision_line
StageDAT.join_collision_lines=_join_collision_lines
