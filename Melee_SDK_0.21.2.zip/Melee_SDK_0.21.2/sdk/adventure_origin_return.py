"""HF29F: return Co-op Adventure to the major mode that launched it.

Retail Adventure hard-codes ``GM_MENU`` in three exit paths:

* ``gm_8017D7AC`` aborted/cancelled match path (includes normal LRA+Start exit)
* ``gm_801B4350`` Adventure CSS cancel path
* ``gm_801B4408`` completed-campaign / Coming Soon exit

That is correct when Adventure was entered from the retail 1-P menu, but it is
wrong for the SDK Stage Select gateway and for an eventual Slippi Direct launch.
Melee's own state machine already retains ``routing.prev_mode`` for the entire
lifetime of the current major mode, so no SDK-owned mutable origin state is
needed.  On these three Adventure-only call sites, replace the requested
``GM_MENU`` with retail ``prev_mode`` and then tail-enter the original routing
function.

Consequences:

* retail 1-P Adventure: prev_mode == GM_MENU -> behavior is byte-for-byte
  equivalent at the routing API boundary;
* VS Stage Select gateway: prev_mode == GM_VS -> returns to VS mode;
* future Slippi online/Direct integration: if Adventure is entered by a normal
  major-mode transition from the online major mode, that mode is returned to
  automatically rather than hard-coding VS or Menu.

The patch contains no mutable state, performs no allocation, and touches no
fighter, heap, stock, camera, Team-Kirby, or results logic.
"""
from __future__ import annotations

from .ppc import cmpwi, encode_branch, lbz, li
from .early_clear_failsafe import Asm

# Retail state_machine routing bytes (gm_1A3F.c / GALE01 v1.02).
STATE_MACHINE = 0x80479D30
CURRENT_MODE = STATE_MACHINE + 0x00
PREVIOUS_MODE = STATE_MACHINE + 0x02

GM_MENU = 1
GM_ADVENTURE = 4

GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE = 0x801A42F8
GM_SET_PENDING_GAME_MODE = 0x801A42E8

# Three source-grounded Adventure hard-coded GM_MENU exits.
ABORT_RETURN_CALL = 0x8017D8F0
CSS_CANCEL_RETURN_CALL = 0x801B4390
CAMPAIGN_COMPLETE_SET_PENDING_CALL = 0x801B4418

ABORT_EXPECTED = encode_branch(
    ABORT_RETURN_CALL, GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE, link=True)
CSS_CANCEL_EXPECTED = encode_branch(
    CSS_CANCEL_RETURN_CALL, GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE, link=True)
CAMPAIGN_COMPLETE_EXPECTED = encode_branch(
    CAMPAIGN_COMPLETE_SET_PENDING_CALL, GM_SET_PENDING_GAME_MODE, link=True)


def _wrapper(base: int, retail_target: int) -> bytes:
    """Rewrite only Adventure's requested GM_MENU to retail prev_mode.

    This wrapper replaces a linked call.  It makes no calls itself, so LR still
    contains the original call-site + 4.  Tail-entering the retail routing
    helper therefore returns directly to the original caller exactly as the
    displaced ``bl`` did.
    """
    a = Asm(base)

    # Fail closed unless this is exactly the expected Adventure -> GM_MENU
    # routing request.  This also makes the helper safe to reuse if a callsite
    # changes semantics in a later build.
    a.emit(cmpwi(3, GM_MENU, crf=7))
    a.branch('retail', 4, 30)  # requested mode != GM_MENU
    a.absolute(11, CURRENT_MODE, byte=True)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7))
    a.branch('retail', 4, 30)  # current mode != Adventure

    # Retail updates prev_mode only when a major mode finishes.  It therefore
    # remains the mode that launched Adventure for the whole campaign.
    a.absolute(11, PREVIOUS_MODE, byte=True)

    # A recursive Adventure origin is not a useful return target.  Fall back to
    # the original GM_MENU request rather than risk a mode loop.
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7))
    a.branch('retail', 12, 30)
    a.emit(li(3, 0))
    # mr r3,r11 == or r3,r11,r11.  Encode directly to keep ppc.py minimal.
    a.emit(bytes.fromhex('7d635b78'))

    a.label('retail')
    a.emit(encode_branch(base + len(a.data), retail_target))
    return a.finish()


def install(dol, runtime_index: int) -> dict:
    guards = {
        ABORT_RETURN_CALL: ABORT_EXPECTED,
        CSS_CANCEL_RETURN_CALL: CSS_CANCEL_EXPECTED,
        CAMPAIGN_COMPLETE_SET_PENDING_CALL: CAMPAIGN_COMPLETE_EXPECTED,
    }
    for site, expected in guards.items():
        got = dol.read_at_address(site, 4)
        if got != expected:
            raise ValueError(
                f'HF29F origin-return expected-byte guard failed at {site:#x}: '
                f'expected {expected.hex()}, got {got.hex()}')

    section = next(s for s in dol.sections
                   if s.kind == 'data' and s.index == int(runtime_index))
    base = section.address + ((section.size + 31) & ~31)
    change_stub = base + 0x20
    change_code = _wrapper(change_stub, GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE)
    pending_stub = base + 0x20 + ((len(change_code) + 31) & ~31)
    pending_code = _wrapper(pending_stub, GM_SET_PENDING_GAME_MODE)

    payload = bytearray(b'HF29FORG' + bytes(24))
    assert len(payload) == 0x20
    payload.extend(change_code)
    payload.extend(bytes((-len(payload)) % 32))
    assert base + len(payload) == pending_stub
    payload.extend(pending_code)
    payload.extend(bytes((-len(payload)) % 32))
    if base + len(payload) >= 0x804F4C00:
        raise ValueError('HF29F origin-return payload reaches reserved SDK arena boundary')

    added = dol.append_to_data_section(runtime_index, payload)
    assert added['address'] == base

    changes = []
    for name, site, expected, stub in (
        ('adventure_abort_return_origin', ABORT_RETURN_CALL, ABORT_EXPECTED, change_stub),
        ('adventure_css_cancel_return_origin', CSS_CANCEL_RETURN_CALL, CSS_CANCEL_EXPECTED, change_stub),
        ('adventure_complete_return_origin', CAMPAIGN_COMPLETE_SET_PENDING_CALL,
         CAMPAIGN_COMPLETE_EXPECTED, pending_stub),
    ):
        replacement = encode_branch(site, stub, link=True)
        dol.patch_at_address(site, replacement, expected=expected)
        changes.append({
            'name': name,
            'site_address': site,
            'expected': expected.hex(),
            'site_branch': replacement.hex(),
            'stub_address': stub,
        })

    return {
        'marker': 'HF29FORG',
        'section': added,
        'current_mode_address': CURRENT_MODE,
        'previous_mode_address': PREVIOUS_MODE,
        'change_mode_stub': change_stub,
        'set_pending_stub': pending_stub,
        'hooks': changes,
        'mutable_state': 'none; uses retail state_machine.routing.prev_mode',
        'scope': 'three Adventure-only hard-coded GM_MENU return paths',
        'behavior': 'return to retail previous major mode; normal menu Adventure remains Menu, VS gateway returns VS',
        'slippi_policy': 'origin is not hard-coded; future online launch returns to the online major mode if that mode directly launches Adventure',
        'runtime_validation': 'pending Dolphin VS gateway return test; Slippi Direct launch/rollback integration still requires separate validation',
    }
