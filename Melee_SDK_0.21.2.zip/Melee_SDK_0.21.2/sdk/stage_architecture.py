from __future__ import annotations

import math
from collections import Counter, defaultdict, deque
from dataclasses import dataclass, asdict
from typing import Any

from .stage import StageDAT

# Competitive reference stages used as familiar templates. This is a builder
# grouping, not a claim that the SDK enforces any tournament ruleset.
TOURNAMENT_REFERENCE_FILES = {
    'GrNBa.dat': 'Battlefield',
    'GrNLa.dat': 'Final Destination',
    'GrOp.dat': 'Dream Land (N64)',
    'GrSt.dat': "Yoshi's Story",
    'GrIz.dat': 'Fountain of Dreams',
    'GrPs.dat': 'Pokemon Stadium',
}

ARCHITECTURE_TYPE_LABELS = {
    'base_floor': 'Ground / Base Floor',
    'soft_platform': 'Soft / Drop-Through Platform',
    'solid_structure': 'Solid Structure / Platform',
    'dynamic_platform': 'Dynamic / Moving Platform Geometry',
    'ledge': 'Grab-Enabled Edge / Ledge',
    'ceiling': 'Ceiling',
    'wall': 'Wall',
    'slope': 'Slope / Ramp',
    'flat_surface': 'Flat Walkable Surface',
}

# User-facing line-asset library intentionally omits solid_structure: that key is
# an internal connected-component heuristic, not a source collision-line type.
ASSET_LIBRARY_TYPE_LABELS = {k:v for k,v in ARCHITECTURE_TYPE_LABELS.items() if k != 'solid_structure'}

MOTION_PATH_PRESETS = (
    {'key':'static','label':'Static','runtime_status':'READY','description':'No motion; fixed transform.'},
    {'key':'horizontal_ping_pong','label':'Horizontal Back-and-Forth','runtime_status':'PLANNED','description':'Constant-height linear path that reverses at each endpoint (Smashville-like).'},
    {'key':'vertical_ping_pong','label':'Vertical Back-and-Forth','runtime_status':'PLANNED','description':'Linear vertical path that reverses at each endpoint.'},
    {'key':'waypoint_loop','label':'Waypoint Loop','runtime_status':'PLANNED','description':'Moves through an ordered closed list of points.'},
    {'key':'rectangle_loop','label':'Rectangular Loop','runtime_status':'PLANNED','description':'Four-corner loop useful for Randall-like perimeter motion.'},
    {'key':'orbit','label':'Orbit','runtime_status':'PLANNED','description':'Circular/elliptical motion around a center point.'},
    {'key':'rotate_in_place','label':'Rotate in Place','runtime_status':'PLANNED','description':'Rotates a platform/object around its own pivot.'},
)


def _line_geom(stage: StageDAT, surf: dict[str, Any], line: dict[str, int], verts: list[tuple[float,float]]) -> dict[str, Any]:
    a=verts[line['v0']]; b=verts[line['v1']]
    dx=b[0]-a[0]; dy=b[1]-a[1]
    length=math.hypot(dx,dy)
    angle=math.degrees(math.atan2(dy,dx)) if length else 0.0
    # Normalize the visual angle to [-90,90] because reversing an edge should not
    # turn the same ramp into a 180-degree different asset class.
    while angle > 90: angle -= 180
    while angle < -90: angle += 180
    row=dict(surf)
    row.update({
        'v0':line['v0'],'v1':line['v1'],
        'p0':[a[0],a[1]],'p1':[b[0],b[1]],
        'length':length,'angle_deg':angle,
        'is_flat': abs(angle) <= 2.0,
        'is_slope': surf['category']=='Floor' and 2.0 < abs(angle) < 88.0,
    })
    return row


def collision_surface_inventory(stage: StageDAT) -> dict[str, Any]:
    """Return builder-oriented collision assets for one stage.

    This intentionally describes only semantics already represented by the
    collision records: floor/ceiling/wall/dynamic ranges plus platform, ledge,
    material and dynamic-source flags.  It does not infer fighter physics.
    """
    if not stage.has_public('coll_data'):
        return {'types':{},'components':[],'line_count':0,'vertex_count':0}
    verts=stage.vertices(); lines=stage.lines()
    rows=[_line_geom(stage,stage.line_surface(i),line,verts) for i,line in enumerate(lines)]

    types: dict[str,list[dict[str,Any]]] = defaultdict(list)
    for r in rows:
        cat=r['category']
        if cat=='Floor':
            # The source-known `platform` bit is the best safe discriminator for
            # one-way/drop-through surfaces. We call it soft platform in the UI,
            # while retaining the raw flag in every row.
            if r['platform']:
                types['soft_platform'].append(r)
            else:
                types['base_floor'].append(r)
            if r['is_slope']:
                types['slope'].append(r)
            elif r['is_flat']:
                types['flat_surface'].append(r)
        elif cat=='Ceiling':
            types['ceiling'].append(r)
        elif cat in ('Left Wall','Right Wall'):
            types['wall'].append(r)
        elif cat=='Dynamic':
            types['dynamic_platform'].append(r)
        if r['dynamic_platform_source'] and r not in types['dynamic_platform']:
            types['dynamic_platform'].append(r)
        if r['ledge']:
            types['ledge'].append(r)

    # Connected collision components are useful to distinguish a single soft
    # platform from a closed solid structure with floor/wall/ceiling geometry.
    by_vertex: dict[int,list[int]] = defaultdict(list)
    for i,l in enumerate(lines):
        by_vertex[l['v0']].append(i); by_vertex[l['v1']].append(i)
    seen=set(); components=[]
    for root in range(len(lines)):
        if root in seen: continue
        q=deque([root]); seen.add(root); ids=[]
        while q:
            i=q.popleft(); ids.append(i); l=lines[i]
            for v in (l['v0'],l['v1']):
                for j in by_vertex[v]:
                    if j not in seen:
                        seen.add(j); q.append(j)
        cr=[rows[i] for i in ids]
        cats=Counter(x['category'] for x in cr)
        has_soft=any(x['platform'] for x in cr)
        has_dynamic=any(x['category']=='Dynamic' or x['dynamic_platform_source'] for x in cr)
        if has_dynamic:
            ctype='dynamic_platform'
        elif has_soft and set(cats) <= {'Floor'}:
            ctype='soft_platform'
        elif cats.get('Ceiling',0) or cats.get('Left Wall',0) or cats.get('Right Wall',0):
            ctype='solid_structure'
        else:
            ctype='base_floor'
        xs=[p for x in cr for p in (x['p0'][0],x['p1'][0])]
        ys=[p for x in cr for p in (x['p0'][1],x['p1'][1])]
        components.append({
            'component_index':len(components),'type':ctype,'label':ARCHITECTURE_TYPE_LABELS[ctype],
            'line_indices':ids,'line_count':len(ids),'categories':dict(cats),
            'platform_flag_lines':sum(bool(x['platform']) for x in cr),
            'ledge_flag_lines':sum(bool(x['ledge']) for x in cr),
            'dynamic_source_lines':sum(bool(x['dynamic_platform_source']) for x in cr),
            'bounds':[min(xs),min(ys),max(xs),max(ys)] if xs else [0,0,0,0],
        })

    # Identify a builder-facing main floor structure. This is explicitly a
    # geometry heuristic: choose the widest non-soft/non-dynamic connected
    # structure containing floor collision. It is useful for asset browsing but
    # does not replace source stage semantics.
    candidates=[c for c in components if c['type'] in ('solid_structure','base_floor') and c['categories'].get('Floor',0)]
    if candidates:
        main=max(candidates,key=lambda c:(c['bounds'][2]-c['bounds'][0], c['line_count']))
        main['role']='base_floor_structure'; main['role_basis']='widest floor-containing static collision component (builder heuristic)'
    for c in components:
        if 'role' not in c:
            c['role']=c['type']; c['role_basis']='source collision category/flags'

    # Endpoints on ledge-enabled lines are candidates for reusable grab edges.
    degree=Counter(v for l in lines for v in (l['v0'],l['v1']))
    ledge_vertices=[]
    for r in types.get('ledge',[]):
        for k in ('v0','v1'):
            vi=r[k]
            item={'vertex_index':vi,'position':[verts[vi][0],verts[vi][1]],'line_index':r['index'],
                  'outer_endpoint':degree[vi]==1,'material_id':r['material_id']}
            if item not in ledge_vertices: ledge_vertices.append(item)

    return {
        'line_count':len(lines),'vertex_count':len(verts),
        'types':{k:v for k,v in types.items()},
        'type_counts':{k:len(v) for k,v in sorted(types.items())},
        'components':components,
        'component_type_counts':dict(Counter(c['type'] for c in components)),
        'component_role_counts':dict(Counter(c['role'] for c in components)),
        'ledge_vertices':ledge_vertices,
    }


def stage_architecture_report(stage: StageDAT) -> dict[str, Any]:
    inv=collision_surface_inventory(stage)
    return {
        'filename':stage.filename,
        'name':stage.catalog.name if stage.catalog else stage.filename,
        'reference_groups':['Tournament / competitive reference'] if stage.filename in TOURNAMENT_REFERENCE_FILES else [],
        'architecture':inv,
        'motion_authoring':{
            'status':'SCHEMA_ONLY',
            'presets':list(MOTION_PATH_PRESETS),
            'note':'The builder can describe/preview these paths, but safe AnimJoint/FObj runtime writing is not implemented yet.'
        },
    }
