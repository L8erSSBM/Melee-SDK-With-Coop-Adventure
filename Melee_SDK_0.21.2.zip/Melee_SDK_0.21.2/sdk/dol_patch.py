from __future__ import annotations

import json
import re
import struct
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

BE_U32 = struct.Struct('>I')


@dataclass(frozen=True)
class DOLSection:
    kind: str
    index: int
    file_offset: int
    address: int
    size: int

    @property
    def end_address(self) -> int:
        return self.address + self.size


@dataclass(frozen=True)
class Symbol:
    name: str
    section: str
    address: int
    size: int | None = None
    symbol_type: str | None = None
    scope: str | None = None


class SymbolMap:
    LINE_RE = re.compile(r'^([^=]+?)\s*=\s*([^:;]+):0x([0-9A-Fa-f]+);(?:\s*//\s*(.*))?$')

    def __init__(self, symbols: Iterable[Symbol]):
        self.symbols = list(symbols)
        self.by_name = {s.name: s for s in self.symbols}

    @classmethod
    def from_text(cls, text: str) -> 'SymbolMap':
        out=[]
        for raw in text.splitlines():
            line=raw.strip()
            if not line or line.startswith('#'):
                continue
            m=cls.LINE_RE.match(line)
            if not m:
                continue
            name, section, addr_hex, comment=m.groups()
            meta={}
            if comment:
                for part in comment.split():
                    if ':' in part:
                        k,v=part.split(':',1); meta[k]=v
            size=None
            if 'size' in meta:
                try: size=int(meta['size'],0)
                except ValueError: pass
            out.append(Symbol(name.strip(), section.strip(), int(addr_hex,16), size,
                              meta.get('type'), meta.get('scope')))
        return cls(out)

    @classmethod
    def from_file(cls, path: str | Path) -> 'SymbolMap':
        return cls.from_text(Path(path).read_text(encoding='utf-8', errors='replace'))

    def require(self, name: str) -> Symbol:
        if name not in self.by_name:
            raise KeyError(name)
        return self.by_name[name]


class DOLImage:
    """Minimal address-aware DOL image editor.

    Phase 14 does not inject new code yet. This backend establishes exact
    virtual-address mapping and expected-byte guarded patches so future action
    state and stage-runtime patches can be authored without hard-coded file
    offsets.
    """
    def __init__(self, raw_or_path: bytes | bytearray | str | Path):
        if isinstance(raw_or_path, (str, Path)):
            self.path=Path(raw_or_path)
            self.raw=bytearray(self.path.read_bytes())
        else:
            self.path=None
            self.raw=bytearray(raw_or_path)
        if len(self.raw) < 0x100:
            raise ValueError('DOL is too small')
        self.sections=self._parse_sections()

    def _parse_sections(self) -> list[DOLSection]:
        out=[]
        # 7 text sections
        for i in range(7):
            fo=BE_U32.unpack_from(self.raw, 0x00+i*4)[0]
            va=BE_U32.unpack_from(self.raw, 0x48+i*4)[0]
            sz=BE_U32.unpack_from(self.raw, 0x90+i*4)[0]
            if sz:
                if not fo or fo+sz > len(self.raw): raise ValueError(f'text{i} lies outside DOL')
                out.append(DOLSection('text',i,fo,va,sz))
        # 11 data sections
        for i in range(11):
            fo=BE_U32.unpack_from(self.raw, 0x1C+i*4)[0]
            va=BE_U32.unpack_from(self.raw, 0x64+i*4)[0]
            sz=BE_U32.unpack_from(self.raw, 0xAC+i*4)[0]
            if sz:
                if not fo or fo+sz > len(self.raw): raise ValueError(f'data{i} lies outside DOL')
                out.append(DOLSection('data',i,fo,va,sz))
        return out

    def section_for_address(self, address: int, size: int=1) -> DOLSection:
        address=int(address); size=int(size)
        for s in self.sections:
            if s.address <= address and address+size <= s.end_address:
                return s
        raise ValueError(f'RAM address 0x{address:08X}+0x{size:X} is not backed by a DOL text/data section')

    def file_offset_for_address(self, address: int, size: int=1) -> int:
        s=self.section_for_address(address,size)
        return s.file_offset + (int(address)-s.address)

    def read_at_address(self, address: int, size: int) -> bytes:
        off=self.file_offset_for_address(address,size)
        return bytes(self.raw[off:off+size])

    def patch_at_address(self, address: int, replacement: bytes,
                         expected: bytes | None=None) -> dict:
        replacement=bytes(replacement)
        off=self.file_offset_for_address(address,len(replacement))
        before=bytes(self.raw[off:off+len(replacement)])
        if expected is not None and before != bytes(expected):
            raise ValueError(f'Expected-byte guard failed at 0x{address:08X}')
        self.raw[off:off+len(replacement)]=replacement
        return {'address':address,'file_offset':off,'size':len(replacement),
                'before':before.hex(),'after':replacement.hex()}

    def patch_symbol(self, symbols: SymbolMap, name: str, replacement: bytes,
                     expected: bytes | None=None, offset: int=0) -> dict:
        sym=symbols.require(name)
        if sym.section == '.bss' or sym.section == 'bss':
            raise ValueError(f'{name} is BSS-only and has no bytes in the DOL file')
        if sym.size is not None and offset+len(replacement) > sym.size:
            raise ValueError(f'Patch exceeds declared symbol size for {name}')
        row=self.patch_at_address(sym.address+int(offset), replacement, expected)
        row.update({'symbol':name,'symbol_address':sym.address,'symbol_offset':int(offset)})
        return row

    def bss_range(self) -> tuple[int, int]:
        addr = BE_U32.unpack_from(self.raw, 0xD8)[0]
        size = BE_U32.unpack_from(self.raw, 0xDC)[0]
        return addr, size

    def add_data_section(self, payload: bytes | bytearray, *, address: int | None = None,
                         file_alignment: int = 0x20, address_alignment: int = 0x20) -> dict:
        """Append a new initialized DOL data section using an unused header slot.

        This is safer than treating an arbitrary zero run as a data cave. The
        loader will copy the new section normally. When no virtual address is
        supplied, allocation begins after both all existing text/data sections
        and BSS, aligned in MEM1. The method refuses overlap and MEM1 overflow.
        """
        payload = bytes(payload)
        if not payload:
            raise ValueError('Cannot add an empty DOL data section')
        free_index = None
        for i in range(11):
            sz = BE_U32.unpack_from(self.raw, 0xAC + i * 4)[0]
            if sz == 0:
                free_index = i
                break
        if free_index is None:
            raise ValueError('No unused DOL data-section header slots remain')
        if file_alignment <= 0 or file_alignment & (file_alignment - 1):
            raise ValueError('file_alignment must be a positive power of two')
        if address_alignment <= 0 or address_alignment & (address_alignment - 1):
            raise ValueError('address_alignment must be a positive power of two')

        def align(v: int, a: int) -> int:
            return (int(v) + a - 1) & ~(a - 1)

        file_off = align(len(self.raw), file_alignment)
        if file_off > len(self.raw):
            self.raw.extend(b'\0' * (file_off - len(self.raw)))

        if address is None:
            high = max(0x80003100, max((sec.end_address for sec in self.sections), default=0))
            bss_addr, bss_size = self.bss_range()
            high = max(high, bss_addr + bss_size)
            address = align(high, address_alignment)
        address = int(address)
        if address < 0x80000000 or address + len(payload) > 0x81800000:
            raise ValueError('New DOL data section would lie outside GameCube MEM1')
        for sec in self.sections:
            if not (address + len(payload) <= sec.address or address >= sec.end_address):
                raise ValueError(f'New DOL data section overlaps {sec.kind}{sec.index}')
        bss_addr, bss_size = self.bss_range()
        if bss_size and not (address + len(payload) <= bss_addr or address >= bss_addr + bss_size):
            raise ValueError('New DOL data section overlaps BSS')

        self.raw.extend(payload)
        BE_U32.pack_into(self.raw, 0x1C + free_index * 4, file_off)
        BE_U32.pack_into(self.raw, 0x64 + free_index * 4, address)
        BE_U32.pack_into(self.raw, 0xAC + free_index * 4, len(payload))
        self.sections = self._parse_sections()
        return {'kind': 'data', 'index': free_index, 'file_offset': file_off,
                'address': address, 'size': len(payload)}

    def find_data_section_prefix(self, prefix: bytes) -> DOLSection | None:
        """Return the first initialized data section whose bytes begin with *prefix*."""
        prefix = bytes(prefix)
        for sec in self.sections:
            if sec.kind != 'data' or sec.size < len(prefix):
                continue
            if bytes(self.raw[sec.file_offset:sec.file_offset + len(prefix)]) == prefix:
                return sec
        return None

    def append_to_data_section(self, index: int, payload: bytes | bytearray, *, alignment: int = 0x20) -> dict:
        """Append payload to an existing data section without consuming another DOL header slot.

        The target must be the physically last bytes in the DOL. This is intended
        for the SDK runtime arena: one loader-backed section can host multiple
        independently-authored payloads while preserving scarce DOL section slots.
        """
        payload = bytes(payload)
        if not payload:
            raise ValueError('Cannot append an empty payload')
        if alignment <= 0 or alignment & (alignment - 1):
            raise ValueError('alignment must be a positive power of two')
        sec = next((x for x in self.sections if x.kind == 'data' and x.index == int(index)), None)
        if sec is None:
            raise ValueError(f'DOL data section {index} does not exist')
        if sec.file_offset + sec.size != len(self.raw):
            raise ValueError('Target data section is not physically last in the DOL')

        def align(v: int, a: int) -> int:
            return (int(v) + a - 1) & ~(a - 1)

        rel = align(sec.size, alignment)
        pad = rel - sec.size
        address = sec.address + rel
        end_address = address + len(payload)
        if end_address > 0x81800000:
            raise ValueError('Extended DOL data section would lie outside GameCube MEM1')
        for other in self.sections:
            if other is sec:
                continue
            if not (end_address <= other.address or address >= other.end_address):
                raise ValueError(f'Extended DOL data section overlaps {other.kind}{other.index}')
        bss_addr, bss_size = self.bss_range()
        if bss_size and not (end_address <= bss_addr or address >= bss_addr + bss_size):
            raise ValueError('Extended DOL data section overlaps BSS')

        if pad:
            self.raw.extend(b'\0' * pad)
        file_offset = len(self.raw)
        self.raw.extend(payload)
        new_size = rel + len(payload)
        BE_U32.pack_into(self.raw, 0xAC + sec.index * 4, new_size)
        self.sections = self._parse_sections()
        return {
            'kind': 'data', 'index': sec.index, 'file_offset': file_offset,
            'address': address, 'size': len(payload), 'padding': pad,
            'section_address': sec.address, 'section_size': new_size,
            'shared_section': True,
        }

    def save_as(self, path: str | Path) -> Path:
        p=Path(path); p.write_bytes(self.raw); return p


def write_patch_manifest(path: str | Path, patches: list[dict], *, source: str='GALE01 1.02') -> Path:
    p=Path(path)
    p.write_text(json.dumps({'format':'melee-sdk-dol-patch-v1','source':source,'patches':patches}, indent=2), encoding='utf-8')
    return p
