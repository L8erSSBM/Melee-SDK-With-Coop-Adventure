"""Author separate arena archives without modifying the Adventure originals."""
from pathlib import Path
import struct
from .stage import StageDAT

def build_arenas(iso, output):
    reports=[]
    for i in range(7):
        yoshi=i==6;name='GrNKr.dat' if yoshi else 'GrNSr.dat'
        stage=StageDAT(iso.read_file(iso.find_file(name)))
        markers={m.marker_id:m for m in stage.markers()}
        spawn=markers[0xB3 if yoshi else 0xB3+i]
        event=markers[0xBD if yoshi else 0xBD+i]
        cx,cy=event.world_x,event.world_y+30
        # Routes have one human spawn. Rebind unused item-spawn nodes to the
        # missing versus markers, retaining the archive's pointer/relocation graph.
        missing=[n for n in range(8) if n not in markers]
        root=stage.public_offset('map_head');table=stage.archive.data_u32(root)
        for row in range(stage.archive.data_i32(root+4)):
            pairs=stage.archive.data_u32(table+12*row+4)
            for pair in range(stage.archive.data_i32(table+12*row+8)):
                address=stage.archive.data_start+pairs+4*pair+2
                mid=struct.unpack_from('>H',stage.archive.raw,address)[0]
                if missing and 0xDC<=mid<=0xE5:
                    struct.pack_into('>H',stage.archive.raw,address,missing.pop(0))
        if missing:raise ValueError('Insufficient unused spawn nodes for arena')
        def place(mid,x,y):
            count=sum(m.marker_id==mid for m in stage.markers())
            for occurrence in range(count):stage.set_marker_world(mid,x,y,0,occurrence=occurrence)
        # Native fight spawn markers sit above each arena's upper floor.
        for player in range(4):
            place(player,spawn.world_x+(-24,24,-42,42)[player],spawn.world_y)
            place(player+4,cx,spawn.world_y+40)
        width=155 if yoshi else 115
        # Retail uses 95/97 for upper-left and 96/98 for lower-right.
        for mid,x,y in ((0x94,cx,cy),(0x95,cx-width,cy+125),(0x96,cx+width,cy-85),
                        (0x97,cx-width-65,cy+190),(0x98,cx+width+65,cy-150)):
            place(mid,x,y)
        stage.set_fixed_camera(False)
        filename='GrSYs.dat' if yoshi else f'GrSL{i+1}.dat'
        path=Path(output)/filename;path.write_bytes(stage.archive.raw)
        # Reparse serialized output to validate the actual authored marker data.
        check=StageDAT(path);check.validate()
        reports.append({'filename':filename,'source':name,'arena_index':i,
                        'spawn':[spawn.world_x,spawn.world_y],
                        'camera_blast':check.camera_blast_bounds()})
    return reports
