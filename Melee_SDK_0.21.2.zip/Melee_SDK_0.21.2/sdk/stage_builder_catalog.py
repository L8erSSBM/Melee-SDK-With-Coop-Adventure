from __future__ import annotations

import csv
import json
import re
from collections import Counter
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable

from .stage import StageDAT, MARKER_NAMES
from .stage_assets import StageAssetEditor
from .stage_architecture import stage_architecture_report, ARCHITECTURE_TYPE_LABELS, ASSET_LIBRARY_TYPE_LABELS, TOURNAMENT_REFERENCE_FILES, MOTION_PATH_PRESETS

STATUS_EDITABLE = 'EDITABLE'
STATUS_PARTIAL = 'PARTIAL'
STATUS_INVENTORIED = 'INVENTORIED'
STATUS_EXTERNAL = 'EXTERNAL'
STATUS_UNDECODED = 'UNDECODED'


@dataclass(frozen=True)
class BuilderAssetClass:
    key: str
    label: str
    area: str
    status: str
    storage: str
    what_it_controls: str
    builder_support: str
    caveat: str = ''


# This is intentionally builder-facing rather than a list of C structs.  Every
# EDITABLE/PARTIAL claim maps to an existing source-guarded SDK operation.
ASSET_CLASSES: tuple[BuilderAssetClass, ...] = (
    BuilderAssetClass('runtime_identity', 'Stage identity & runtime routing', 'Project / Runtime', STATUS_PARTIAL,
        'DOL StageData + FST Gr*.dat identity', 'Template clone, independent Gr*.dat project resource, dormant Akaneia runtime slot, paged SSS bridge.',
        'Visible SSS presentation and runtime identity are separate systems.'),
    BuilderAssetClass('collision', 'Gameplay collision geometry', 'Layout', STATUS_EDITABLE,
        'coll_data / MapCollData', 'Floors, ceilings, left/right walls, pass-through platforms and dynamic collision segments.',
        'View/edit vertices; add/split/join/delete segments; topology is reindexed safely.'),
    BuilderAssetClass('surface_flags', 'Collision materials & behavior flags', 'Layout', STATUS_PARTIAL,
        'MapCollLine flags', 'Material lookup ID, pass-through/platform, ledge-grab and dynamic-source bits.',
        'Editable by exact source-confirmed bit fields.', 'Material ID names/physics meanings are not yet decoded into friendly presets.'),
    BuilderAssetClass('spawns', 'Player starts & respawn platform markers', 'Gameplay Markers', STATUS_EDITABLE,
        'map_head HSD_Joint marker IDs 0x00..0x07', 'P1–P4 starting points and respawn-platform positions.',
        'World-space marker inventory and position editing.'),
    BuilderAssetClass('camera', 'Camera frame & blast zones', 'Gameplay Markers', STATUS_EDITABLE,
        'map_head marker IDs 0x94..0x98', 'Camera center/range and KO blast boundaries.',
        'World-space bounds editor backed by marker JObjs.'),
    BuilderAssetClass('other_markers', 'Stage-specific marker IDs', 'Gameplay Markers', STATUS_INVENTORIED,
        'map_head marker pairs', 'Stage-specific path, object, route, target or hazard anchors.',
        'Every marker is inventoried and movable by ID.', 'Unknown marker IDs remain semantically unnamed until source-traced.'),
    BuilderAssetClass('dynamic_collision', 'Collision joints / moving-platform base geometry', 'Layout', STATUS_PARTIAL,
        'MapJoint[]', 'Collision subranges, bounds and vertex ownership used by dynamic stage pieces.',
        'Joint ranges/bounds are parsed; base collision can be translated.', 'Animation tracks that move the matching visual/collision object are not safely authored yet.'),
    BuilderAssetClass('models', 'Visual scene hierarchy', 'Visuals', STATUS_PARTIAL,
        'HSD_Joint / DObj trees reachable from map_head', 'Stage models, transform hierarchy and base placement.',
        'JObj inventory; position/rotation/scale writer available.', 'Mesh vertex/material authoring is not yet exposed as a safe high-level editor.'),
    BuilderAssetClass('textures', 'Textures', 'Visuals', STATUS_PARTIAL,
        'HSD_ImageDesc + *_image publics', 'Stage model and effect imagery.',
        'Dimensions/GX formats inventoried. Same-size PNG replacement supports I4/I8/IA4/IA8/RGB565/RGB5A3/RGBA8/CMPR.',
        'Paletted C4/C8/C14X2 and mipmapped textures are read-only until TLUT/mipmap regeneration is implemented.'),
    BuilderAssetClass('animation', 'Model / material animation tracks', 'Animation', STATUS_INVENTORIED,
        'HSD AnimJoint/FObj graph inside stage archive', 'Moving platforms, animated models/materials and other timed visual changes.',
        'Underlying archive structures are preserved and JObj base transforms are editable.',
        'Track-to-object semantics are not sufficiently mapped for a safe keyframe editor.'),
    BuilderAssetClass('ground_param', 'Global stage parameters', 'Gameplay', STATUS_PARTIAL,
        'grGroundParam', 'Stage-wide parameters read by ground/stage runtime.',
        'Stage scale and fixed-camera flag are source-confirmed and editable.', 'Remaining fields are preserved but not named without source evidence.'),
    BuilderAssetClass('yakumono', 'Stage-specific object / hazard parameters', 'Gameplay', STATUS_UNDECODED,
        'yakumono_param', 'Per-stage stage-object/hazard parameter payload.',
        'Presence and raw public symbol are catalogued.', 'Schema differs by stage and must be traced against each gr*.c module before semantic editing.'),
    BuilderAssetClass('itemdata', 'Stage item data', 'Gameplay', STATUS_UNDECODED,
        'itemdata', 'Stage-owned item-related data referenced by retail stage logic.',
        'Presence is catalogued.', 'No generic safe semantic editor yet.'),
    BuilderAssetClass('particles', 'Particles / stage effects', 'Effects', STATUS_INVENTORIED,
        'map_ptcl / archive effect descriptors when present', 'Visual particles/effects used by a stage.',
        'Presence and related public symbols/textures are catalogued.', 'Emitter/effect authoring is not decoded into builder controls yet.'),
    BuilderAssetClass('lights', 'Lighting', 'Visuals', STATUS_INVENTORIED,
        'map_plit and HSD scene descriptors when present', 'Stage lighting presentation.',
        'Presence is catalogued.', 'Light descriptor semantics are not yet exposed in the builder.'),
    BuilderAssetClass('texture_groups', 'Texture animation/group data', 'Visuals', STATUS_INVENTORIED,
        'map_texg when present', 'Stage-specific texture grouping/animation data.',
        'Presence is catalogued.', 'Not semantically editable yet.'),
    BuilderAssetClass('quake', 'Stage quake/camera-shake model set', 'Effects', STATUS_INVENTORIED,
        'quake_model_set when present', 'Stage-specific quake/shake-linked model set.',
        'Presence is catalogued.', 'Runtime meaning is preserved but not exposed as authored effects.'),
    BuilderAssetClass('sss', 'Stage Select icon / thumbnail / labels', 'Frontend', STATUS_PARTIAL,
        'MnSlMap.dat/.usd + paged SSS runtime data', 'How a custom stage appears and launches from Stage Select.',
        'Paged stage model and reusable retail tile mapping exist; custom thumbnail capability is registered.',
        'Frontend assets live outside Gr*.dat and should be edited as a separate presentation layer.'),
    BuilderAssetClass('music', 'Music / audio routing', 'Audio', STATUS_EXTERNAL,
        'Runtime stage/audio tables and audio resources, not generic Gr*.dat geometry', 'Stage music and audio selection.',
        'Not part of the current Gr*.dat asset editor.', 'Needs a separate source-grounded audio-routing editor.'),
    BuilderAssetClass('stage_code', 'Stage logic / hazards / callbacks', 'Runtime', STATUS_EXTERNAL,
        'DOL gr*.c StageData callbacks + stage-specific state', 'Hazards, transformations, scripted objects and stage behavior.',
        'A custom stage can reuse donor callbacks through the runtime slot author.',
        'Changing behavior safely requires source-grounded executable/runtime authoring, not DAT-only editing.'),
)

_COMMON_PUBLICS = {
    'map_head': 'Scene/marker root',
    'coll_data': 'Collision root',
    'grGroundParam': 'Global stage parameters',
    'yakumono_param': 'Stage-specific object/hazard parameters',
    'itemdata': 'Stage item data',
    'ALDYakuAll': 'Stage public data (opaque name retained)',
    'map_plit': 'Lighting-related stage public',
    'map_ptcl': 'Particle/effect-related stage public',
    'map_texg': 'Texture-group-related stage public',
    'quake_model_set': 'Quake/shake-linked model public',
}


def _family(stage: StageDAT) -> tuple[str, str]:
    if stage.catalog:
        return ('Versus stage' if stage.catalog.versus else 'Adventure route', 'source catalog')
    n = stage.filename
    if re.fullmatch(r'GrT[A-Za-z]{2}\.dat', n):
        return ('Target-test family', 'filename convention')
    if re.fullmatch(r'GrPs[1-4]\.dat', n):
        return ('Pokémon Stadium transformation resource', 'filename convention')
    return ('Other retail stage resource', 'uncatalogued')


def stage_builder_report(stage: StageDAT) -> dict[str, Any]:
    ed = StageAssetEditor(stage)
    syms = [p['name'] for p in stage.public_symbols()]
    symset = set(syms)
    family, basis = _family(stage)
    markers = stage.markers() if stage.has_public('map_head') else []
    known_markers = [m for m in markers if m.marker_id in MARKER_NAMES]
    unknown_markers = [m for m in markers if m.marker_id not in MARKER_NAMES]
    collision = stage.collision_summary() if stage.has_public('coll_data') else None
    joints = stage.map_joints() if collision else []
    collision_lines = stage.lines() if collision else []
    surface_rows = [stage.line_surface(i) for i in range(len(collision_lines))] if collision else []
    visual_joints = ed.joint_inventory() if stage.has_public('map_head') else []
    textures = ed.textures()
    gp = stage.ground_param() if stage.has_public('grGroundParam') else None
    camera = stage.camera_blast_bounds() if stage.has_public('map_head') else {'camera': None, 'blast': None}
    public_families = []
    for name, label in _COMMON_PUBLICS.items():
        public_families.append({'symbol': name, 'label': label, 'present': name in symset})
    extra_publics = [s for s in syms if s not in _COMMON_PUBLICS]
    image_publics = [s for s in extra_publics if s.endswith('_image')]
    tlut_publics = [s for s in extra_publics if s.endswith('_tlut') or s.endswith('_tlut_desc')]
    other_publics = [s for s in extra_publics if s not in image_publics and s not in tlut_publics]
    return {
        'format': 'melee-sdk-stage-builder-stage-report-v1',
        'filename': stage.filename,
        'name': stage.catalog.name if stage.catalog else Path(stage.filename).stem,
        'family': family,
        'classification_basis': basis,
        'stkind': stage.catalog.stkind if stage.catalog else None,
        'grkind': stage.catalog.grkind if stage.catalog else None,
        'source_module': stage.catalog.source_module if stage.catalog else None,
        'archive': {
            'bytes': len(stage.archive.raw),
            'data_bytes': stage.archive.header.data_size,
            'relocations': stage.archive.header.nb_reloc,
            'public_symbol_count': len(syms),
        },
        'layout': {
            'collision': asdict(collision) if collision else None,
            'map_joint_count': len(joints),
            'map_joints': joints,
            'surface_usage': {
                'material_id_line_counts': {str(k): v for k, v in sorted(Counter(x['material_id'] for x in surface_rows).items())},
                'platform_lines': sum(x['platform'] for x in surface_rows),
                'ledge_lines': sum(x['ledge'] for x in surface_rows),
                'dynamic_source_lines': sum(x['dynamic_platform_source'] for x in surface_rows),
                'category_line_counts': dict(sorted(Counter(x['category'] for x in surface_rows).items())),
            },
            'marker_count': len(markers),
            'known_markers': [
                {'id': m.marker_id, 'name': m.name, 'world': [m.world_x, m.world_y, m.world_z], 'joint_offset': m.joint_offset}
                for m in known_markers
            ],
            'unknown_marker_ids': sorted({m.marker_id for m in unknown_markers}),
            'camera_blast': camera,
        },
        'visuals': {
            'jobj_count': len(visual_joints),
            'jobj_with_dobj_count': sum(bool(j.get('has_dobj')) for j in visual_joints),
            'joints': visual_joints,
            'texture_count': len(textures),
            'png_replaceable_count': sum(t.png_replace_supported for t in textures),
            'texture_formats': dict(sorted(Counter(t.format_name for t in textures).items())),
            'textures': [asdict(t) for t in textures],
        },
        'gameplay': {
            'ground_param': gp,
            'yakumono_param_present': 'yakumono_param' in symset,
            'itemdata_present': 'itemdata' in symset,
        },
        'architecture_assets': stage_architecture_report(stage),
        'publics': {
            'common_families': public_families,
            'image_symbols': image_publics,
            'tlut_symbols': tlut_publics,
            'other_symbols': other_publics,
        },
    }


def scan_stage_corpus(folder: str | Path) -> dict[str, Any]:
    folder = Path(folder)
    paths = sorted(folder.rglob('Gr*.dat'), key=lambda p: p.name.lower())
    rows = []
    marker_counts: Counter[int] = Counter()
    format_counts: Counter[str] = Counter()
    public_counts: Counter[str] = Counter()
    architecture_counts: Counter[str] = Counter()
    component_counts: Counter[str] = Counter()
    failures = []
    for p in paths:
        try:
            report = stage_builder_report(StageDAT(p))
        except Exception as exc:
            failures.append({'filename': p.name, 'error': str(exc)})
            continue
        rows.append(report)
        marker_counts.update(m['id'] for m in report['layout']['known_markers'])
        marker_counts.update(report['layout']['unknown_marker_ids'])
        format_counts.update(report['visuals']['texture_formats'])
        syms = [x['symbol'] for x in report['publics']['common_families'] if x['present']]
        syms += report['publics']['image_symbols'] + report['publics']['tlut_symbols'] + report['publics']['other_symbols']
        public_counts.update(syms)
        architecture_counts.update(report['architecture_assets']['architecture']['type_counts'])
        component_counts.update(report['architecture_assets']['architecture']['component_type_counts'])
    return {
        'format': 'melee-sdk-stage-builder-corpus-v1',
        'stage_count': len(rows),
        'failure_count': len(failures),
        'failures': failures,
        'asset_classes': [asdict(x) for x in ASSET_CLASSES],
        'corpus_summary': {
            'known_marker_semantics': {f'0x{k:02X}': v for k, v in sorted(MARKER_NAMES.items())},
            'marker_id_stage_counts': {f'0x{k:02X}': v for k, v in sorted(marker_counts.items())},
            'texture_format_counts': dict(sorted(format_counts.items())),
            'public_symbol_stage_counts': dict(public_counts.most_common()),
            'architecture_line_type_counts': dict(sorted(architecture_counts.items())),
            'architecture_component_type_counts': dict(sorted(component_counts.items())),
            'tournament_reference_files': TOURNAMENT_REFERENCE_FILES,
            'motion_path_presets': list(MOTION_PATH_PRESETS),
        },
        'stages': rows,
    }


def _md_table(headers: list[str], rows: Iterable[Iterable[Any]]) -> str:
    out = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join('---' for _ in headers) + ' |']
    for row in rows:
        out.append('| ' + ' | '.join(str(x).replace('|', '\\|') for x in row) + ' |')
    return '\n'.join(out)


def write_catalog_bundle(folder: str | Path, output_dir: str | Path) -> dict[str, str]:
    data = scan_stage_corpus(folder)
    out = Path(output_dir); out.mkdir(parents=True, exist_ok=True)
    jp = out / 'stage_builder_asset_catalog.json'
    jp.write_text(json.dumps(data, indent=2), encoding='utf-8')
    cp = out / 'stage_builder_stage_index.csv'
    with cp.open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(['Filename','Name','Family','Reference Groups','StKind','GrKind','Collision Vertices','Collision Lines','Base Floor Lines','Soft Platform Lines','Dynamic Platform Lines','Ledge Lines','Ceiling Lines','Wall Lines','Map Joints','Markers','JObjs','Textures','PNG Replaceable','Unknown Marker IDs'])
        for s in data['stages']:
            c=s['layout']['collision'] or {}
            a=s['architecture_assets']; tc=a['architecture']['type_counts']; w.writerow([s['filename'],s['name'],s['family'],','.join(a['reference_groups']),s['stkind'],s['grkind'],c.get('vertex_count',''),c.get('line_count',''),tc.get('base_floor',0),tc.get('soft_platform',0),tc.get('dynamic_platform',0),tc.get('ledge',0),tc.get('ceiling',0),tc.get('wall',0),s['layout']['map_joint_count'],s['layout']['marker_count'],s['visuals']['jobj_count'],s['visuals']['texture_count'],s['visuals']['png_replaceable_count'],','.join(f"0x{x:02X}" for x in s['layout']['unknown_marker_ids'])])
    # Type-first library index: browse e.g. every ledge/soft-platform source, then drill into stage.
    type_index={k:[] for k in ASSET_LIBRARY_TYPE_LABELS}
    for st in data['stages']:
        arch=st['architecture_assets']['architecture']
        for key,label in ASSET_LIBRARY_TYPE_LABELS.items():
            rows=arch['types'].get(key,[])
            if rows:
                type_index[key].append({
                    'filename':st['filename'],'stage_name':st['name'],
                    'reference_groups':st['architecture_assets']['reference_groups'],
                    'line_count':len(rows),'lines':rows,
                })
    lp=out/'stage_architecture_asset_library.json'
    lp.write_text(json.dumps({
        'format':'melee-sdk-stage-architecture-library-v1',
        'organization':'asset_type_then_stage',
        'type_labels':ASSET_LIBRARY_TYPE_LABELS,
        'types':type_index,
        'motion_path_presets':list(MOTION_PATH_PRESETS),
    },indent=2),encoding='utf-8')
    lcsv=out/'stage_architecture_asset_library.csv'
    with lcsv.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.writer(f); w.writerow(['Asset Type','Asset Label','Stage','DAT','Reference Groups','Line Count','Line Indices'])
        for key,stages in type_index.items():
            for st in stages:
                w.writerow([key,ASSET_LIBRARY_TYPE_LABELS[key],st['stage_name'],st['filename'],','.join(st['reference_groups']),st['line_count'],','.join(str(x['index']) for x in st['lines'])])
    mp = out / 'STAGE_BUILDER_ASSET_CATALOG.md'
    lines = [
        '# Melee SDK — Stage Builder Asset Catalogue', '',
        f"Retail corpus scanned: **{data['stage_count']} Gr*.dat files**; failures: **{data['failure_count']}**.", '',
        'This document is organized by what a stage creator needs to change, not by reverse-engineering file order. The JSON beside it contains the full per-stage inventory.', '',
        '## Status legend', '',
        '- **EDITABLE** — the current SDK has a source-grounded writer for the asset.',
        '- **PARTIAL** — useful fields are editable, but the whole structure is not decoded.',
        '- **INVENTORIED** — the SDK can find/report it but does not yet offer a semantic writer.',
        '- **EXTERNAL** — the feature lives primarily outside the stage DAT (DOL/menu/audio/runtime).',
        '- **UNDECODED** — preserved and catalogued, but the semantics are not safe to guess.', '',
        '## Builder coverage', '',
        _md_table(['Area','Asset','Status','Storage','What you can do now'], ((x.area,x.label,x.status,x.storage,x.builder_support) for x in ASSET_CLASSES)), '',
        '## Known gameplay markers', '',
        _md_table(['ID','Meaning'], ((f'0x{k:02X}',v) for k,v in sorted(MARKER_NAMES.items()))), '',
        'All other marker IDs are retained in the per-stage inventory as **unknown/undecoded**, even though their world positions can be inspected. Do not assign a meaning to an unknown ID merely because it appears at an interesting location.', '',
        '## Texture coverage across the retail corpus', '',
        _md_table(['GX format','Descriptors found'], sorted(data['corpus_summary']['texture_format_counts'].items())), '',
        'Same-size PNG replacement is currently enabled for non-mipmapped I4, I8, IA4, IA8, RGB565, RGB5A3, RGBA8 and CMPR. Paletted C4/C8/C14X2 require TLUT rewriting first.', '',
        '## Stage architecture asset types', '',
        _md_table(['Type','Meaning','Retail line records'], ((ARCHITECTURE_TYPE_LABELS.get(k,k), k.replace('_',' '), v) for k,v in sorted(data['corpus_summary']['architecture_line_type_counts'].items()))), '',
        'Collision assets are now indexed both **by type** and **by source stage**. `platform` is retained as the source-known collision flag and is presented as a soft/drop-through platform surface; ceilings remain a distinct collision category so builders can avoid accidentally adding a combo-altering overhead surface.', '',
        '### Tournament / competitive reference templates', '',
        _md_table(['DAT','Reference stage'], sorted(TOURNAMENT_REFERENCE_FILES.items())), '',
        'These are convenience reference groups only; the SDK does not enforce a tournament ruleset.', '',
        '## Moving-platform authoring roadmap', '',
        _md_table(['Preset','Status','Purpose'], ((x['label'],x['runtime_status'],x['description']) for x in MOTION_PATH_PRESETS)), '',
        'The path presets are deliberately schema/preview targets until the AnimJoint/FObj track-to-object relationship is safe to write. Horizontal ping-pong is the intended Smashville-like first implementation; rectangle-loop is intended for Randall-like perimeter motion.', '',
        '## Retail stage index', '',
        _md_table(['DAT','Stage / resource','Family','Verts','Lines','Markers','JObjs','Textures','PNG-editable'], ((
            s['filename'],s['name'],s['family'],(s['layout']['collision'] or {}).get('vertex_count','—'),(s['layout']['collision'] or {}).get('line_count','—'),s['layout']['marker_count'],s['visuals']['jobj_count'],s['visuals']['texture_count'],s['visuals']['png_replaceable_count']) for s in data['stages'])), '',
        '## How the Stage Builder should be mentally organized', '',
        '1. **Identity** — choose a donor/template and decide whether this is a replacement or an independent runtime stage.',
        '2. **Layout** — edit collision, materials, platforms and dynamic collision ownership.',
        '3. **Gameplay Markers** — place player starts, respawns, camera and blast zones; inspect unknown stage-specific markers separately.',
        '4. **Visuals** — position JObjs and replace compatible textures without confusing visual meshes with gameplay collision.',
        '5. **Animation / Hazards** — keep donor behavior until animation tracks and stage-specific `yakumono_param` schemas are source-traced.',
        '6. **Presentation** — Stage Select tile/thumbnail/name and music are separate layers and should not be hidden inside the DAT editor.', '',
        '## Safety boundary', '',
        'The catalogue deliberately does **not** turn unknown public symbols, marker IDs, animation tracks, hazard payloads, or material IDs into friendly names without evidence. The builder should make unknowns visible, but never pretend they are understood.',
    ]
    mp.write_text('\n'.join(lines)+'\n', encoding='utf-8')
    return {'json': str(jp), 'csv': str(cp), 'architecture_json': str(lp), 'architecture_csv': str(lcsv), 'markdown': str(mp)}
