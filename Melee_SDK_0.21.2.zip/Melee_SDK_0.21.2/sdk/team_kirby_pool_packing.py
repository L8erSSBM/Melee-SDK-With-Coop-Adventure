"""Pack four retail SList nodes into one OS heap cell during Team Kirby.

Retail HSD_ObjAlloc refills an empty pool with one object. For SList's
8-byte, 4-byte-aligned nodes, both an 8-byte and a 32-byte request consume
the same OS heap cell: round_up(payload + 32, 32) == 64. Use the existing
HSD_ObjAllocAddFree(data, 4) implementation, including its linked free list,
accounting and scene lifetime. No new mutable state or custom arena.

This reduces allocator overhead; it is not an OOM recovery handler. It must
run before the heap is exhausted (cold boot, not an old crash savestate).
"""
from .ppc import cmpw, cmpwi, encode_branch, li, lwz
from .early_clear_failsafe import Asm

SITE = 0x8037ACBC
REFILL = 0x8037A968
SLIST_POOL = 0x804C2580
OBJ_HEAP = 0x80406E48
MODE = 0x80479D30
STATE = 0x80479D33
EXPECTED = encode_branch(SITE, REFILL, link=True)


def wrapper(base):
    # This replaces a BL. Tail-enter the original callee with LR untouched.
    # Only caller-volatile r11/r12/CR7 and the intended r4 argument change.
    a = Asm(base)
    a.constant(12, SLIST_POOL)
    a.emit(cmpw(3, 12, crf=7)); a.branch('retail', 4, 30)
    a.emit(cmpwi(4, 1, crf=7)); a.branch('retail', 4, 30)
    for address, value in ((MODE, 4), (STATE, 0x23)):
        a.absolute(11, address, byte=True)
        a.emit(cmpwi(11, value, crf=7)); a.branch('retail', 4, 30)
    # Only the ordinary OS-backed heap, never HSD's optional fixed arena.
    a.absolute(11, OBJ_HEAP)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('retail', 4, 30)
    # Fail closed if pool layout/limits differ from the verified retail pool.
    for offset, value in ((0, 0), (0x20, 8), (0x24, 3)):
        a.emit(lwz(11, offset, 3), cmpwi(11, value, crf=7))
        a.branch('retail', 4, 30)
    a.emit(li(4, 4))
    a.label('retail')
    a.emit(encode_branch(base + len(a.data), REFILL))
    return a.finish()


def install(dol, runtime_index):
    if dol.read_at_address(SITE, 4) != EXPECTED:
        raise ValueError('HF29D SList refill expected-byte guard failed')
    section = next(s for s in dol.sections
                   if s.kind == 'data' and s.index == int(runtime_index))
    base = section.address + ((section.size + 31) & ~31)
    stub = base + 32
    code = wrapper(stub)
    payload = b'HF29DSLP' + bytes(24) + code
    payload += bytes((-len(payload)) % 32)
    if base + len(payload) >= 0x804F4C00:
        raise ValueError('HF29D payload reaches reserved SDK arena boundary')
    added = dol.append_to_data_section(runtime_index, payload)
    assert added['address'] == base
    branch = encode_branch(SITE, stub, link=True)
    dol.patch_at_address(SITE, branch, expected=EXPECTED)
    return dict(marker='HF29DSLP', section=added, site_address=SITE,
                site_branch=branch.hex(), expected=EXPECTED.hex(),
                stub_address=stub, size=len(code), retail_refill=REFILL,
                pool_address=SLIST_POOL, node_bytes=8, refill_count=4,
                scope='Adventure Team Kirby; retail unrestricted SList pool on OS heap',
                mutable_state='retail SList descriptor and ordinary heap only',
                behavior='four nodes per minimum-size heap cell; retail pool ownership',
                runtime_validation='pending cold-boot gameplay and Slippi rollback tests')
