from __future__ import annotations

import copy
import hashlib
import json
import shutil
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

CURRENT_PROJECT_GENERATION = 27
CURRENT_MANIFEST_FORMAT = 1


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


@dataclass
class ProjectCompatibilityReport:
    compatible: bool
    manifest_format: int
    detected_generation: int
    target_generation: int
    needs_metadata_upgrade: bool
    resource_count: int
    fighter_count: int
    stage_count: int
    original_missing: list[str]
    working_missing: list[str]
    original_hash_mismatches: list[str]
    notes: list[str]

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


def detect_generation(manifest: dict[str, Any]) -> int:
    """Best-effort feature-generation detection without requiring historical version tags.

    Projects from Phase 18 onward all use manifest format 1. We therefore identify the
    newest feature block present and treat absent later blocks as optional rather than
    incompatible.
    """
    explicit = manifest.get('sdk_generation')
    if isinstance(explicit, int):
        return explicit
    if 'stage_select_pages' in manifest:
        return 25
    ra = manifest.get('runtime_authoring', {}) or {}
    if 'one_player_resources' in ra:
        return 23
    if 'event_match' in ra:
        return 21
    if 'dol_description' in ra or 'dol_source' in ra:
        return 20
    # Phase 18 used the same v1 core manifest and added resources opportunistically.
    return 18


def compatibility_report(project_root: str | Path, manifest: dict[str, Any]) -> ProjectCompatibilityReport:
    root = Path(project_root)
    fmt = int(manifest.get('format_version', 0) or 0)
    detected = detect_generation(manifest)
    resources = list(manifest.get('resources', []) or [])
    originals_missing: list[str] = []
    working_missing: list[str] = []
    hash_mismatch: list[str] = []
    for row in resources:
        name = str(row.get('filename', '')).strip()
        if not name:
            continue
        orig = root / 'Original' / name
        work = root / 'Working' / name
        if not orig.exists():
            originals_missing.append(name)
        if not work.exists():
            working_missing.append(name)
        expected = str(row.get('sha256', '')).strip().lower()
        if expected and orig.exists():
            try:
                if _sha256(orig).lower() != expected:
                    hash_mismatch.append(name)
            except OSError:
                hash_mismatch.append(name)

    compatible = fmt == CURRENT_MANIFEST_FORMAT and not originals_missing
    notes: list[str] = []
    if fmt != CURRENT_MANIFEST_FORMAT:
        notes.append(f'Unsupported manifest format {fmt}; expected {CURRENT_MANIFEST_FORMAT}.')
    if originals_missing:
        notes.append('One or more immutable Original/ resources are missing.')
    if working_missing:
        notes.append('Working/ is missing resources; these can usually be restored from Original/.')
    if hash_mismatch:
        notes.append('Original/ contains files whose hashes no longer match the project baseline.')
    if compatible and detected < CURRENT_PROJECT_GENERATION:
        notes.append('Project content is structurally compatible; only newer optional metadata/features are absent.')
    if compatible and not working_missing and not hash_mismatch:
        notes.append('Safe to open in the current SDK. No clean reset is required.')

    return ProjectCompatibilityReport(
        compatible=compatible,
        manifest_format=fmt,
        detected_generation=detected,
        target_generation=CURRENT_PROJECT_GENERATION,
        needs_metadata_upgrade=(compatible and detected < CURRENT_PROJECT_GENERATION),
        resource_count=len(resources),
        fighter_count=len(manifest.get('fighters', []) or []),
        stage_count=len(manifest.get('stages', []) or []),
        original_missing=sorted(originals_missing),
        working_missing=sorted(working_missing),
        original_hash_mismatches=sorted(hash_mismatch),
        notes=notes,
    )


def normalize_manifest(manifest: dict[str, Any], *, record_generation: bool = False) -> dict[str, Any]:
    """Return a backward-compatible normalized manifest without discarding old fields."""
    out = copy.deepcopy(manifest)
    out.setdefault('format_version', CURRENT_MANIFEST_FORMAT)
    out.setdefault('sdk_scope', 'fighter_and_stage_modding')
    out.setdefault('resources', [])
    out.setdefault('fighters', [])
    out.setdefault('stages', [])
    out.setdefault('runtime_overrides', {}).setdefault('fighter_states', {})
    out.setdefault('runtime_authoring', {})
    out.setdefault('build_targets', {})
    out.setdefault('project_history', [])
    if record_generation:
        out['sdk_generation'] = CURRENT_PROJECT_GENERATION
    return out


def upgrade_project_metadata(project_root: str | Path, manifest: dict[str, Any]) -> tuple[dict[str, Any], Path]:
    """Upgrade only metadata. Original/ and Working/ bytes are never changed."""
    root = Path(project_root)
    manifest_path = root / 'melee_project.json'
    report = compatibility_report(root, manifest)
    if not report.compatible:
        raise ValueError('Project is not safe to upgrade: ' + '; '.join(report.notes))

    stamp = datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')
    backup = root / f'melee_project.pre_phase27.{stamp}.json'
    if manifest_path.exists():
        shutil.copy2(manifest_path, backup)
    else:
        backup.write_text(json.dumps(manifest, indent=2), encoding='utf-8')

    upgraded = normalize_manifest(manifest, record_generation=True)
    upgraded.setdefault('project_history', []).append({
        'utc': datetime.now(timezone.utc).isoformat(),
        'action': 'metadata_upgrade',
        'from_generation': report.detected_generation,
        'to_generation': CURRENT_PROJECT_GENERATION,
        'note': 'Metadata-only upgrade; Original/ and Working/ file bytes were not changed.',
        'backup_manifest': backup.name,
    })
    manifest_path.write_text(json.dumps(upgraded, indent=2), encoding='utf-8')
    return upgraded, backup


def create_test_clone(project_root: str | Path, destination: str | Path, *, reset_build: bool = True) -> Path:
    """Clone a project for risky runtime testing while preserving the original project untouched."""
    src = Path(project_root).resolve()
    dst = Path(destination).resolve()
    if dst.exists() and any(dst.iterdir()):
        raise ValueError('Test clone destination must be empty or not yet exist.')
    if dst.exists():
        dst.rmdir()
    shutil.copytree(src, dst, ignore=shutil.ignore_patterns('__pycache__', '*.pyc', '.pytest_cache'))
    if reset_build:
        build = dst / 'Build'
        if build.exists():
            shutil.rmtree(build)
        build.mkdir(parents=True, exist_ok=True)
    mp = dst / 'melee_project.json'
    manifest = json.loads(mp.read_text(encoding='utf-8'))
    manifest = normalize_manifest(manifest, record_generation=True)
    manifest.setdefault('project_history', []).append({
        'utc': datetime.now(timezone.utc).isoformat(),
        'action': 'test_clone_created',
        'source_project': str(src),
        'note': 'Created for runtime/ISO hook testing. Source project remains untouched.',
    })
    mp.write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    return dst
