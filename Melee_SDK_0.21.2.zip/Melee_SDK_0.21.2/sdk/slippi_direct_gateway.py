"""SDK 0.20.21: Slippi Direct -> Co-op Adventure HUD-init bootstrap bridge.

0.20.17 proved the Direct Splash/preload producer. 0.20.21F then proved the
custom Direct stage page can intercept Slippi's lock-in translator, but runtime
evidence showed dormant StKind 0x15 does not survive as the finalized stage.
0.20.21G therefore uses a legal carrier stage plus Slippi's separately
synchronized Frozen Stadium mode byte as the explicit Adventure intent tag.

0.20.18 incorrectly tried to arm Slippi's Online-In-Game rollback/input hooks at
that Splash/preload boundary. Runtime evidence from YoshiStory.sav proved those
hooks are not installed yet: the Direct producer reached D4, but the netplay arm
stub stopped at SLNP E2/failure 0x21 because 0x80665540 still belonged to a
pre-game allocation rather than Slippi's Online-In-Game core.

0.20.19 therefore splits the handoff into two phases:

1. Splash/preload producer: validate the Direct sentinel, snapshot both player
   identities, and set a private bootstrap-pending byte. Do NOT leave Slippi.
2. Retail HUD-init producer: once the game is actually Online In-Game and the
   first version-scoped Slippi guard word has appeared, arm the live netplay
   bridge, set the existing gateway_pending contract, and request Adventure.
3. The bridge EXI wrapper waits for Slippi's connected frame-1 B0 input exchange
   and only then raises Melee's retail scene-exit flag. This avoids both the
   HUD-init timing reset and the LRA+Start abort path that disconnects netplay.

This gives Slippi one normal online scene initialization in which to allocate its
ODB and install the synchronized input/rollback runtime, while still converting
the tagged selection into Adventure before normal play proceeds. 0.20.21G
requires both carrier stage 0x08 and the private synchronized alt-stage marker,
so ordinary/random Yoshi's Story remains completely ordinary.
"""
from __future__ import annotations

from .early_clear_failsafe import Asm
from .ppc import (addi, blr, cmpw, cmpwi, encode_branch, lbz, li, lis, lwz, mflr,
                  mtlr, stb, stw, stwu)

# Phase-1 Direct/Splash producer.
HOOK = 0x80027168
EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0

# Phase-2 deferred bootstrap producer. Retail ifAll_802F390C is the in-game HUD initializer. It runs automatically
# after Slippi has installed its Online-In-Game runtime, unlike gm_801A4D34 which
# only became useful at scene exit (making LRA+Start accidentally trigger the handoff).
SCENE_LOOP_HOOK = 0x802F390C
SCENE_LOOP_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0; ifAll_802F390C HUD init
SCENE_EXIT_REQUEST = 0x801A4B60

GM_CURRENT_MODE_ADDR = 0x80479D30
GM_SCENE_BYTE3_ADDR = 0x80479D33
GM_ONLINE = 0x08
GM_ADVENTURE = 0x04
ONLINE_INGAME_BYTE3 = 0x02
GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE = 0x801A42F8

# First Slippi Online-In-Game guard observed in the supplied working Direct
# savestates. At Splash time YoshiStory.sav instead contains 0x6C633F80 here.
# The scene-loop shim waits until this exact live runtime signature appears
# before invoking the full version-scoped arm stub.
NETPLAY_READY_SITE = 0x80665540
NETPLAY_READY_WORD = 0x4082005C

# Current project-slippi/slippi-ssbm-asm Online/Online.s contract.
OFST_R13_ONLINE_MODE = -0x5060
ONLINE_MODE_DIRECT = 2
OFST_R13_GM_MAINLIB = -0x77C0
OFST_R13_ISWINNER = -0x5037
OFST_R13_CHOSESTAGE = -0x5036

# SplashSceneInit copies Match State into gmm_x0 + 1424 + 8 (0x598).
DIRECT_MATCH_DATA_OFFSET = 0x598
DIRECT_STAGE_LOW_BYTE = 0x0F  # u16 stage at +0x0E, big-endian low byte
P1 = 0x60
P2 = 0x84
PLAYER_TYPE = 0x01
CKIND = 0x00
COLOR = 0x03
SUBCOLOR = 0x07
NAMETAG = 0x0A
# 0.20.21G's Direct gateway uses a legal carrier stage and a separate
# synchronized alt-stage-mode byte as the actual Adventure discriminator.
# Keep the public historical name mapped to the carrier for compatibility.
LEGACY_SENTINEL_STAGE = 0x15
SENTINEL_STAGE = 0x08
CARRIER_STAGE = SENTINEL_STAGE
SLIPPI_ALT_MODE_HOOK = 0x801D457C
SLIPPI_ALT_MODE_STATIC = 0x80667A50
ADVENTURE_ALT_MARKER = 0xA5

# SlippiSavestate::initBackupLocs() snapshots the guest main-heap bounds when
# the first live online savestate pool is constructed.  The custom SSS commit
# hook only runs on the selecting peer, so heap coverage must be primed here,
# in the synchronized HUD-init path that both Direct peers execute before the
# first B0 frame-1 exchange.
MAIN_HEAP_END_ADDR = 0x804D76BC
FULL_ROLLBACK_HEAP_END = 0x817FE000

MARKER = b'DRCT'
STATE_SIZE = 0x10
S_TRACE = 0x04
# 0.21.1 reuses two formerly diagnostic-only bytes to preserve Direct's
# local stage-picker authority across a standalone carrier.
S_ONLINE_MODE = 0x05
S_MAJOR = 0x06
S_SELECTOR_ROLE = S_ONLINE_MODE
S_SELECTOR_CHOSE = S_MAJOR
S_STAGE = 0x07
S_P1_TYPE = 0x08
S_P2_TYPE = 0x09
S_REQUEST_COUNT = 0x0A
S_VERSION = 0x0B
S_NETPLAY_ARM_RESULT = 0x0C
S_BOOTSTRAP_PENDING = 0x0D
S_BOOTSTRAP_WAIT = 0x0E
S_ALT_MODE = 0x0F

# Breadcrumbs for a Direct savestate. Last successfully reached stage wins.
TRACE_HOOK_ONLINE = 0xD1
TRACE_DIRECT_MODE = 0xD2
TRACE_MATCH_BLOCK = 0xD3
TRACE_SENTINEL_HUMANS = 0xD4
TRACE_ADVENTURE_REQUESTED = 0xD5
TRACE_NETPLAY_ARMED = 0xD6
TRACE_BOOTSTRAP_QUEUED = 0xD7
TRACE_NETPLAY_REJECTED = 0xD8
TRACE_CARRIER_ORDINARY = 0xD9


def _store_abs_byte(a: Asm, addr: int, source: int, scratch: int = 12) -> None:
    a.emit(lis(scratch, ((addr + 0x8000) >> 16) & 0xFFFF), stb(source, addr & 0xFFFF, scratch))


def _load_abs_byte(a: Asm, addr: int, dst: int = 11) -> None:
    a.absolute(dst, addr, byte=True)


def _inc_abs_byte(a: Asm, addr: int, reg: int = 10) -> None:
    a.absolute(reg, addr, byte=True)
    a.emit(addi(reg, reg, 1))
    _store_abs_byte(a, addr, reg)


def _snapshot_identity(a: Asm, match_reg: int, *,
                       p1_ckind_addr: int, p1_color_addr: int,
                       p1_subcolor_addr: int, p1_nametag_addr: int,
                       p2_ckind_addr: int, p2_color_addr: int,
                       p2_subcolor_addr: int, p2_nametag_addr: int) -> None:
    for src_off, dst in (
        (P1 + CKIND, p1_ckind_addr),
        (P1 + COLOR, p1_color_addr),
        (P1 + SUBCOLOR, p1_subcolor_addr),
        (P1 + NAMETAG, p1_nametag_addr),
        (P2 + CKIND, p2_ckind_addr),
        (P2 + COLOR, p2_color_addr),
        (P2 + SUBCOLOR, p2_subcolor_addr),
        (P2 + NAMETAG, p2_nametag_addr),
    ):
        a.emit(lbz(11, src_off, match_reg)); _store_abs_byte(a, dst, 11)

    # Match the proven local gateway cosmetic rule: P2 subshade survives only
    # for an actual same-character + same-costume clone.
    a.emit(lbz(10, P1 + CKIND, match_reg), lbz(11, P2 + CKIND, match_reg),
           cmpw(10, 11, crf=7))
    a.branch('normalize_subcolor', 4, 30)
    a.emit(lbz(10, P1 + COLOR, match_reg), lbz(11, P2 + COLOR, match_reg),
           cmpw(10, 11, crf=7))
    a.branch('identity_ready', 12, 30)
    a.label('normalize_subcolor')
    a.emit(li(11, 0)); _store_abs_byte(a, p2_subcolor_addr, 11)
    a.label('identity_ready')


def build_wrapper(base: int, trampoline_addr: int, *, state_addr: int,
                  gateway_pending_addr: int,
                  p1_ckind_addr: int, p1_color_addr: int,
                  p1_subcolor_addr: int, p1_nametag_addr: int,
                  p2_identity_valid_addr: int,
                  p2_ckind_addr: int, p2_color_addr: int,
                  p2_subcolor_addr: int, p2_nametag_addr: int,
                  netplay_arm_addr: int | None = None,
                  canonical_valid_addr: int | None = None,
                  canonical_players_addr: int | None = None) -> bytes:
    """Capture a harmless carrier candidate before retail preload.

    The synchronized alt-stage marker is not guaranteed to be installed on the
    remote peer until Slippi's later Online-In-Game initialization. Therefore
    this phase only recognizes legal carrier stage 0x08 + two humans, snapshots
    identity, and queues a *candidate*. The HUD-init phase performs the real
    marker check after Slippi has synchronized both peers. Ordinary/random
    Yoshi's Story may briefly become a candidate but can never request Adventure.
    """
    a = Asm(base)
    a.emit(stwu(1, -0x40, 1), mflr(0), stw(0, 0x44, 1),
           stw(3, 0x08, 1), stw(4, 0x0C, 1), stw(5, 0x10, 1),
           li(10, 0), stw(10, 0x14, 1))  # recognized-two-human flag

    # Do not touch SDK state at all outside Slippi online Direct.
    a.absolute(11, GM_CURRENT_MODE_ADDR, byte=True)
    a.emit(cmpwi(11, GM_ONLINE, crf=7)); a.branch('call_retail', 4, 30)
    a.emit(li(10, 0)); _store_abs_byte(a, state_addr + S_BOOTSTRAP_PENDING, 10)
    _store_abs_byte(a, state_addr + S_BOOTSTRAP_WAIT, 10)
    a.emit(li(10, 0xFF)); _store_abs_byte(a, state_addr + S_NETPLAY_ARM_RESULT, 10)

    a.emit(lbz(11, OFST_R13_ONLINE_MODE, 13))
    a.emit(cmpwi(11, ONLINE_MODE_DIRECT, crf=7)); a.branch('call_retail', 4, 30)

    a.emit(lwz(8, OFST_R13_GM_MAINLIB, 13), cmpwi(8, 0, crf=7)); a.branch('call_retail', 12, 30)
    a.emit(addi(8, 8, DIRECT_MATCH_DATA_OFFSET))
    a.emit(lbz(11, DIRECT_STAGE_LOW_BYTE, 8))
    a.emit(cmpwi(11, CARRIER_STAGE, crf=7)); a.branch('call_retail', 4, 30)

    # Do not inspect the synchronized marker yet: the remote peer receives it in
    # InitOnlinePlay, after this preload boundary. Carrier 0x08 is only a
    # candidate here; the deferred HUD-init phase is the authoritative gate.
    a.emit(lbz(11, P1 + PLAYER_TYPE, 8))
    a.emit(cmpwi(11, 0, crf=7)); a.branch('call_retail', 4, 30)
    a.emit(lbz(11, P2 + PLAYER_TYPE, 8))
    a.emit(cmpwi(11, 0, crf=7)); a.branch('call_retail', 4, 30)

    # Snapshot the local Direct chooser role before the carrier. Slippi's
    # normal VSSceneDecide would update ISWINNER and clear CHOSESTAGE, but the
    # standalone challenge bypasses that scene entirely. The standalone exit
    # restores this role and clears CHOSESTAGE so exactly the same peer that
    # was entitled to SSS before the carrier remains the selector afterward.
    a.emit(lbz(11, OFST_R13_ISWINNER, 13)); _store_abs_byte(a, state_addr + S_SELECTOR_ROLE, 11)
    a.emit(lbz(11, OFST_R13_CHOSESTAGE, 13)); _store_abs_byte(a, state_addr + S_SELECTOR_CHOSE, 11)

    # K10: when the SSS latch is valid, source identity from the immutable
    # pre-carrier high-memory snapshot rather than the reordered carrier block.
    if canonical_valid_addr is not None:
        if canonical_players_addr is None:
            raise ValueError('canonical_players_addr required with canonical_valid_addr')
        _load_abs_byte(a, canonical_valid_addr, 11)
        a.emit(cmpwi(11, 1, crf=7)); a.branch('carrier_identity', 4, 30)
        a.constant(8, canonical_players_addr - P1)
        a.branch('snapshot_identity')
        a.label('carrier_identity')
    a.label('snapshot_identity')
    _snapshot_identity(
        a, 8,
        p1_ckind_addr=p1_ckind_addr, p1_color_addr=p1_color_addr,
        p1_subcolor_addr=p1_subcolor_addr, p1_nametag_addr=p1_nametag_addr,
        p2_ckind_addr=p2_ckind_addr, p2_color_addr=p2_color_addr,
        p2_subcolor_addr=p2_subcolor_addr, p2_nametag_addr=p2_nametag_addr)
    a.emit(li(10, 1), stw(10, 0x14, 1))
    if netplay_arm_addr is not None:
        # Queue *before* the displaced preload call. 0.20.19/20 queued after
        # retail returned, which could miss the first HUD-init pass and made
        # scene exit/LRA+Start appear to be the gateway trigger.
        a.emit(li(11, 1)); _store_abs_byte(a, state_addr + S_BOOTSTRAP_PENDING, 11)
        a.emit(li(11, TRACE_BOOTSTRAP_QUEUED)); _store_abs_byte(a, state_addr + S_TRACE, 11)

    a.label('call_retail')
    a.emit(lwz(3, 0x08, 1), lwz(4, 0x0C, 1), lwz(5, 0x10, 1))
    a.emit(encode_branch(base + len(a.data), trampoline_addr, link=True))
    a.emit(stw(3, 0x18, 1), lwz(10, 0x14, 1), cmpwi(10, 0, crf=7))
    a.branch('done', 12, 30)

    if netplay_arm_addr is not None:
        # The deferred bootstrap was queued before retail preload; no second
        # write here, otherwise a bootstrap that fired inside retail could be
        # accidentally re-armed on return.
        pass
    else:
        a.emit(li(11, 1))
        _store_abs_byte(a, p2_identity_valid_addr, 11)
        _store_abs_byte(a, gateway_pending_addr, 11)
        _inc_abs_byte(a, state_addr + S_REQUEST_COUNT)
        a.emit(li(11, TRACE_ADVENTURE_REQUESTED)); _store_abs_byte(a, state_addr + S_TRACE, 11)
        a.emit(li(3, GM_ADVENTURE))
        a.emit(encode_branch(base + len(a.data), GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE, link=True))

    a.label('done')
    a.emit(lwz(3, 0x18, 1), lwz(0, 0x44, 1), mtlr(0), addi(1, 1, 0x40), blr())
    return a.finish()


def build_ingame_bootstrap_wrapper(base: int, trampoline_addr: int, *,
                                   state_addr: int, gateway_pending_addr: int,
                                   p2_identity_valid_addr: int,
                                   netplay_arm_addr: int, early_exi_wrapper: int | None = None, standalone_stages: bool = False) -> bytes:
    """Resolve the synchronized tag, then arm Adventure after Slippi init."""
    a = Asm(base)
    a.emit(stwu(1, -0x40, 1), mflr(0), stw(0, 0x44, 1),
           stw(3, 0x08, 1), stw(4, 0x0C, 1), stw(5, 0x10, 1))

    if early_exi_wrapper is not None:
        from . import slippi_adventure_netplay_bridge as nb
        a.constant(12, nb.SLIPPI_EXI_VENEER)
        a.emit(lwz(10,0,12)); a.constant(11,int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED,'big'))
        a.emit(cmpw(10,11,crf=7)); a.branch('early_ready',4,30)
        a.constant(10,int.from_bytes(encode_branch(nb.SLIPPI_EXI_VENEER,early_exi_wrapper),'big'))
        a.emit(stw(10,0,12),nb._dcbst(0,12),nb._sync(),nb._icbi(0,12),nb._isync())
        a.label('early_ready')

    # Keep the compact DRCT state base in caller-saved r9 while polling. This
    # replaces repeated 32-bit absolute address materialization and preserves
    # the original boot-safe low-memory budget.
    a.constant(9, state_addr)
    a.emit(lbz(11, S_BOOTSTRAP_PENDING, 9), cmpwi(11, 0, crf=7))
    a.branch('retail', 12, 30)

    a.absolute(11, GM_CURRENT_MODE_ADDR, byte=True)
    a.emit(cmpwi(11, GM_ONLINE, crf=7)); a.branch('retail', 4, 30)
    a.absolute(11, GM_SCENE_BYTE3_ADDR, byte=True)
    a.emit(cmpwi(11, ONLINE_INGAME_BYTE3, crf=7)); a.branch('retail', 4, 30)

    # The failed 0.20.18 save proves this word is not ready during Splash.
    # Poll it from the in-game HUD initializer rather than treating a not-yet-
    # installed dynamic code block as an incompatible Slippi version.
    a.constant(12, NETPLAY_READY_SITE); a.emit(lwz(10, 0, 12))
    a.constant(11, NETPLAY_READY_WORD); a.emit(cmpw(10, 11, crf=7))
    a.branch('ready', 12, 30)
    a.emit(lbz(10, S_BOOTSTRAP_WAIT, 9), addi(10, 10, 1), stb(10, S_BOOTSTRAP_WAIT, 9))
    a.branch('retail')

    a.label('ready')
    # InitOnlinePlay has now loaded MSRB_ALT_STAGE_MODE into the current
    # version's Frozen Stadium static byte on both peers. This is the
    # authoritative Adventure discriminator. A normal/random Yoshi carrier has
    # the ordinary mode value here, never 0xA5.
    a.emit(lis(11, SLIPPI_ALT_MODE_STATIC >> 16),
           lbz(10, SLIPPI_ALT_MODE_STATIC & 0xFFFF, 11),
           stb(10, S_ALT_MODE, 9),
           cmpwi(10, ADVENTURE_ALT_MARKER, crf=7))
    if standalone_stages:
        a.branch('ordinary_carrier', 12, 28)
        a.emit(cmpwi(10, 0xB2, crf=7)); a.branch('ordinary_carrier',12,29)
    else:
        a.branch('ordinary_carrier', 4, 30)
    # Consume before leaving the online scene so no private marker can leak into
    # subsequent retail Frozen Stadium behavior.
    a.emit(li(10, 0), stb(10, SLIPPI_ALT_MODE_STATIC & 0xFFFF, 11))

    a.emit(encode_branch(base + len(a.data), netplay_arm_addr, link=True))
    # netplay_arm is an external call and may clobber volatile r9.
    a.constant(9, state_addr)
    a.emit(stb(3, S_NETPLAY_ARM_RESULT, 9), cmpwi(3, 1, crf=7))
    a.branch('arm_failed', 4, 30)

    # Arm succeeded while the peer session and ODB are live. Scope protection
    # before requesting scene exit so Slippi teardown cannot reclaim the session.
    a.emit(li(11, 1))
    _store_abs_byte(a, p2_identity_valid_addr, 11)
    _store_abs_byte(a, gateway_pending_addr, 11)
    a.emit(li(11, 0), stb(11, S_BOOTSTRAP_PENDING, 9),
           lbz(10, S_REQUEST_COUNT, 9), addi(10, 10, 1), stb(10, S_REQUEST_COUNT, 9),
           li(11, TRACE_NETPLAY_ARMED), stb(11, S_TRACE, 9),
           li(11, TRACE_ADVENTURE_REQUESTED), stb(11, S_TRACE, 9),
           li(3, GM_ADVENTURE))
    a.emit(encode_branch(base + len(a.data), GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE, link=True))
    # Do not call gm_801A4B60 here. HUD init is too early and its exit-flag write
    # is reset before the live scene loop. slippi_adventure_netplay_bridge raises
    # the same retail flag on the connected frame-1 B0 exchange instead.
    a.branch('retail')

    a.label('ordinary_carrier')
    # Carrier without our synchronized tag is just a normal Yoshi's Story
    # match. Consume the candidate and never touch gateway/session state.
    a.emit(li(11, 0), stb(11, S_BOOTSTRAP_PENDING, 9),
           li(11, TRACE_CARRIER_ORDINARY), stb(11, S_TRACE, 9))
    a.branch('retail')

    a.label('arm_failed')
    # A true arm failure after the Online-In-Game signature was present means
    # another version-scoped validation failed. Fail closed for this selection.
    a.emit(li(11, 0), stb(11, S_BOOTSTRAP_PENDING, 9),
           li(11, TRACE_NETPLAY_REJECTED), stb(11, S_TRACE, 9))

    a.label('retail')
    a.emit(lwz(3, 0x08, 1), lwz(4, 0x0C, 1), lwz(5, 0x10, 1),
           lwz(0, 0x44, 1), mtlr(0), addi(1, 1, 0x40))
    # Tail through a tiny trampoline that replays the displaced mflr r0 and
    # resumes retail ifAll_802F390C at +4.
    a.emit(encode_branch(base + len(a.data), trampoline_addr))
    return a.finish()

def install(dol, runtime_index: int, *, gateway_pending_addr: int,
            p1_ckind_addr: int, p1_color_addr: int,
            p1_subcolor_addr: int, p1_nametag_addr: int,
            p2_identity_valid_addr: int,
            p2_ckind_addr: int, p2_color_addr: int,
            p2_subcolor_addr: int, p2_nametag_addr: int,
            netplay_arm_addr: int | None = None,
            canonical_valid_addr: int | None = None,
            canonical_players_addr: int | None = None, early_exi_wrapper: int | None = None,
            standalone_stages: bool = False) -> dict:
    got = dol.read_at_address(HOOK, 4)
    if got != EXPECTED:
        raise ValueError(
            f'Slippi Direct gateway expected retail 0x{HOOK:08X}={EXPECTED.hex()}, got {got.hex()}')
    if netplay_arm_addr is not None:
        scene_got = dol.read_at_address(SCENE_LOOP_HOOK, 4)
        if scene_got != SCENE_LOOP_EXPECTED:
            raise ValueError(
                f'Slippi HUD-init bootstrap expected retail 0x{SCENE_LOOP_HOOK:08X}='
                f'{SCENE_LOOP_EXPECTED.hex()}, got {scene_got.hex()}')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == runtime_index)
    base = section.address + ((section.size + 31) & ~31)
    state_addr = base
    cursor = base + STATE_SIZE

    preload_trampoline_addr = cursor
    preload_trampoline = EXPECTED + encode_branch(preload_trampoline_addr + 4, HOOK + 4)
    cursor = (preload_trampoline_addr + len(preload_trampoline) + 0x1F) & ~0x1F
    preload_wrapper_addr = cursor
    preload_wrapper = build_wrapper(
        preload_wrapper_addr, preload_trampoline_addr, state_addr=state_addr,
        gateway_pending_addr=gateway_pending_addr,
        p1_ckind_addr=p1_ckind_addr, p1_color_addr=p1_color_addr,
        p1_subcolor_addr=p1_subcolor_addr, p1_nametag_addr=p1_nametag_addr,
        p2_identity_valid_addr=p2_identity_valid_addr,
        p2_ckind_addr=p2_ckind_addr, p2_color_addr=p2_color_addr,
        p2_subcolor_addr=p2_subcolor_addr, p2_nametag_addr=p2_nametag_addr,
        netplay_arm_addr=netplay_arm_addr,
        canonical_valid_addr=canonical_valid_addr,
        canonical_players_addr=canonical_players_addr)
    cursor = preload_wrapper_addr + len(preload_wrapper)

    scene_trampoline_addr = None
    scene_wrapper_addr = None
    scene_trampoline = b''
    scene_wrapper = b''
    if netplay_arm_addr is not None:
        scene_trampoline_addr = (cursor + 0x1F) & ~0x1F
        scene_trampoline = SCENE_LOOP_EXPECTED + encode_branch(
            scene_trampoline_addr + 4, SCENE_LOOP_HOOK + 4)
        scene_wrapper_addr = (scene_trampoline_addr + len(scene_trampoline) + 0x1F) & ~0x1F
        scene_wrapper = build_ingame_bootstrap_wrapper(
            scene_wrapper_addr, scene_trampoline_addr,
            state_addr=state_addr, gateway_pending_addr=gateway_pending_addr,
            p2_identity_valid_addr=p2_identity_valid_addr,
            netplay_arm_addr=netplay_arm_addr, early_exi_wrapper=early_exi_wrapper, standalone_stages=standalone_stages)
        cursor = scene_wrapper_addr + len(scene_wrapper)

    payload = bytearray(cursor - base)
    payload[0:4] = MARKER
    payload[S_TRACE] = 0
    payload[S_ONLINE_MODE] = 0xFF
    payload[S_MAJOR] = 0xFF
    payload[S_STAGE] = 0xFF
    payload[S_P1_TYPE] = 0xFF
    payload[S_P2_TYPE] = 0xFF
    payload[S_REQUEST_COUNT] = 0
    payload[S_VERSION] = 3
    payload[S_NETPLAY_ARM_RESULT] = 0xFF
    payload[S_BOOTSTRAP_PENDING] = 0
    payload[S_BOOTSTRAP_WAIT] = 0
    payload[S_ALT_MODE] = 0xFF
    payload[preload_trampoline_addr-base:preload_trampoline_addr-base+len(preload_trampoline)] = preload_trampoline
    payload[preload_wrapper_addr-base:preload_wrapper_addr-base+len(preload_wrapper)] = preload_wrapper
    if scene_trampoline_addr is not None and scene_wrapper_addr is not None:
        payload[scene_trampoline_addr-base:scene_trampoline_addr-base+len(scene_trampoline)] = scene_trampoline
        payload[scene_wrapper_addr-base:scene_wrapper_addr-base+len(scene_wrapper)] = scene_wrapper
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(runtime_index, payload, alignment=0x20)
    if added['address'] != base:
        raise ValueError('Slippi Direct gateway append address mismatch')

    site_branch = encode_branch(HOOK, preload_wrapper_addr)
    dol.patch_at_address(HOOK, site_branch, expected=EXPECTED)
    scene_branch = None
    if scene_wrapper_addr is not None:
        scene_branch = encode_branch(SCENE_LOOP_HOOK, scene_wrapper_addr)
        dol.patch_at_address(SCENE_LOOP_HOOK, scene_branch, expected=SCENE_LOOP_EXPECTED)

    return {
        'marker': MARKER.decode('ascii'),
        'hook': HOOK,
        'hook_expected': EXPECTED.hex(),
        'hook_branch': site_branch.hex(),
        'trampoline': preload_trampoline_addr,
        'wrapper': preload_wrapper_addr,
        'wrapper_size': len(preload_wrapper),
        'scene_loop_hook': SCENE_LOOP_HOOK if netplay_arm_addr is not None else None,
        'scene_loop_expected': SCENE_LOOP_EXPECTED.hex() if netplay_arm_addr is not None else None,
        'scene_loop_branch': scene_branch.hex() if scene_branch else None,
        'scene_loop_trampoline': scene_trampoline_addr,
        'scene_loop_wrapper': scene_wrapper_addr,
        'scene_loop_wrapper_size': len(scene_wrapper),
        'state_address': state_addr,
        'trace_address': state_addr + S_TRACE,
        'bootstrap_pending_address': state_addr + S_BOOTSTRAP_PENDING,
        'bootstrap_wait_address': state_addr + S_BOOTSTRAP_WAIT,
        'online_mode_addressing': 'lbz -0x5060(r13)',
        'required_online_mode': ONLINE_MODE_DIRECT,
        'required_major_mode': GM_ONLINE,
        'match_data_addressing': 'lwz -0x77C0(r13) + 0x598',
        'legacy_failed_sentinel_stage': LEGACY_SENTINEL_STAGE,
        'sentinel_stage': SENTINEL_STAGE,
        'carrier_stage': CARRIER_STAGE,
        'adventure_alt_marker': ADVENTURE_ALT_MARKER,
        'alt_mode_addressing': 'version-scoped Slippi Frozen Stadium byte 0x80667A50',
        'alt_mode_trace_address': state_addr + S_ALT_MODE,
        'gateway_stage_policy': 'preload queues carrier 0x08 as candidate; HUD-init requires synchronized alt marker 0xA5 before Adventure; ordinary/random Yoshi\'s Story is rejected',
        'human_player_offsets': [P1 + PLAYER_TYPE, P2 + PLAYER_TYPE],
        'gateway_pending_address': gateway_pending_addr,
        'netplay_arm_addr': netplay_arm_addr,
        'netplay_arm_result_address': state_addr + S_NETPLAY_ARM_RESULT,
        'netplay_ready_signature': {'address': NETPLAY_READY_SITE, 'word': f'{NETPLAY_READY_WORD:08x}'},
        'return_origin_contract': 'Adventure OnLoad captures routing.prev_mode == 0x08; existing Quit/LRA/GameOver/Completion wrappers return to captured origin',
        'rollback_status': ('K15 HUD bootstrap installs the early EXI map-prime wrapper; synchronized A5 arms engine-clock and SDK snapshot repair without fake warmup' if netplay_arm_addr is not None else 'legacy immediate entry only; no netplay arm stub supplied'),
        'trace_codes': {
            '0xD1': 'online-major preload function reached',
            '0xD2': 'Slippi Direct mode confirmed',
            '0xD3': 'committed Slippi match block resolved',
            '0xD4': 'carrier 0x08 + two Human players captured as deferred candidate',
            '0xD5': 'gateway_pending set; Adventure requested from Online-In-Game scene',
            '0xD6': 'Slippi Adventure netplay bridge armed successfully',
            '0xD7': 'carrier candidate queued for deferred Online-In-Game marker check',
            '0xD8': 'Online-In-Game runtime appeared but full netplay arm validation rejected it',
            '0xD9': 'carrier reached Online-In-Game without Adventure alt marker; ordinary Yoshi path',
        },
    }
