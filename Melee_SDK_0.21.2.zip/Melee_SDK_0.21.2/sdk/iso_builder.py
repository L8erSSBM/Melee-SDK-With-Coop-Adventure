# Historical regression compatibility literal only: 'sdk_version':'0.20.18'
from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path

from .adventure_install import install_phase29_runtime_framework
from .adventure_probe import install_phase30_coop_spawn_probe
from .gamecube_iso import GameCubeISO, fresh_rebuild, verify_melee_102, sha256_file
from .sss_visual_qol import patch_mnslmap_from_iso
from .sss_archive_isolation import stage_isolated_menus, isolate_menu_load_names

BUILD_VARIANTS=('framework','coop_spawn_probe','coop_showcase','coop_chaos')
ADVENTURE_DIFFICULTIES={'very_easy':0,'easy':1,'normal':2,'hard':3,'very_hard':4}


def build_test_iso(clean_iso: str | Path, output_iso: str | Path, *,
                   variant: str='coop_spawn_probe', symbols_path: str | Path='data/runtime_symbols_GALE01.txt',
                   content_dir: str | Path | None=None, work_dir: str | Path | None=None,
                   manifest_path: str | Path | None=None, scene_revive: bool=False,
                   test_shortcuts: bool=False, unlock_all: bool=False,
                   vs_p2_identity_bridge: bool=False, adventure_sss_gateway: bool=False,
                   friendly_fire: bool | None=None, adventure_difficulty: str='normal',
                   adventure_stocks: int=3, phase43_repairs: bool=True,
                   standalone_stages: bool=True) -> dict:
    """Build a new SDK test ISO from an untouched clean GALE01 v1.02 image.

    The source ISO is opened read-only by the build path and is never used as
    the output. Optional content_dir files are merged into the staging Build/
    before start.dol is generated; start.dol itself is always SDK-generated.
    """
    clean=Path(clean_iso).resolve(); output=Path(output_iso).resolve()
    if clean==output:
        raise ValueError('Output ISO must not overwrite the clean source ISO.')
    if variant not in BUILD_VARIANTS:
        raise ValueError(f'Unknown build variant {variant!r}; choose one of {BUILD_VARIANTS}')
    if adventure_difficulty not in ADVENTURE_DIFFICULTIES:
        raise ValueError(f'Unknown Adventure difficulty {adventure_difficulty!r}; choose one of {tuple(ADVENTURE_DIFFICULTIES)}')
    if not 1 <= int(adventure_stocks) <= 9:
        raise ValueError('Adventure stocks must be 1..9')
    effective_friendly_fire = (variant=='coop_chaos') if friendly_fire is None else bool(friendly_fire)
    verification=verify_melee_102(clean,full_hash=True)
    symbols=Path(symbols_path).resolve()
    if not symbols.is_file(): raise FileNotFoundError(symbols)

    managed_tmp=None
    if work_dir is None:
        managed_tmp=tempfile.TemporaryDirectory(prefix='melee_sdk_0205_')
        work=Path(managed_tmp.name)
    else:
        work=Path(work_dir).resolve(); work.mkdir(parents=True,exist_ok=True)
    build=work/'Build'; build.mkdir(parents=True,exist_ok=True)
    # Make work-dir reruns deterministic.
    for p in build.iterdir():
        if p.is_file(): p.unlink()
    if content_dir:
        for src in Path(content_dir).resolve().iterdir():
            if src.is_file() and src.name.lower() not in {'start.dol','build_manifest.json'}:
                shutil.copy2(src,build/src.name)

    clean_dol=work/'clean_main.dol'; GameCubeISO(clean).extract_dol(clean_dol)
    patched_dol=build/'start.dol'

    # K20Q resolves the real retail MnSlMap first. Slot 27 stays on its native
    # retail animation index. Co-op icon/title/footer payloads are appended and
    # copied into live menu texture buffers only while Page 2 is active; retail
    # Yoshi's Island (N64) icon/title data is never permanently repurposed.
    sss_visual_qol=None
    if adventure_sss_gateway:
        icon_source=Path(__file__).resolve().parent.parent/'assets'/'sss_qol'/'coop_adventure_icon_source.png'
        if not icon_source.is_file():
            raise FileNotFoundError(f'Required Co-op Adventure SSS icon is missing: {icon_source}')
        sss_visual_qol=stage_isolated_menus(GameCubeISO(clean),build,icon_source,standalone_stages=standalone_stages)
        if standalone_stages:
            from .standalone_stage_assets import build_arenas
            sss_visual_qol['arena_archives']=build_arenas(GameCubeISO(clean),build)

    if variant=='framework':
        runtime=install_phase29_runtime_framework(clean_dol,symbols,patched_dol)
    else:
        runtime=install_phase30_coop_spawn_probe(
            clean_dol, symbols, patched_dol, friendly_fire=effective_friendly_fire,
            enable_one_player_cstick=True, enable_either_player_pause=True,
            scene_revive=scene_revive, enable_test_shortcuts=test_shortcuts,
            enable_unlock_all=unlock_all, enable_vs_p2_identity_bridge=vs_p2_identity_bridge,
            enable_adventure_sss_gateway=adventure_sss_gateway,
            adventure_cpu_level=ADVENTURE_DIFFICULTIES[adventure_difficulty],
            adventure_stocks=int(adventure_stocks),
            enable_phase43_adventure_repairs=phase43_repairs,
            sss_visual_contract=sss_visual_qol,
            enable_standalone_stages=bool(adventure_sss_gateway and standalone_stages))

    if adventure_sss_gateway:
        isolated, name_changes = isolate_menu_load_names(patched_dol.read_bytes())
        patched_dol.write_bytes(isolated)
        runtime['sss_archive_name_patches'] = name_changes
        runtime['output_sha1'] = hashlib.sha1(isolated).hexdigest()

    output.parent.mkdir(parents=True,exist_ok=True)
    rebuild=fresh_rebuild(clean,output,build,verify_hash=False)
    if not output.is_file():
        raise ValueError('ISO rebuild returned without creating the requested output disc image')
    if output.suffix.lower() not in {'.iso', '.gcm'}:
        raise ValueError(f'Output must be a GameCube disc image (.iso/.gcm), got {output.name!r}')
    source_size=clean.stat().st_size
    output_size=output.stat().st_size
    if output_size != source_size:
        raise ValueError(f'Whole-disc size verification failed: source={source_size:,}, output={output_size:,}')
    with output.open('rb') as f:
        f.seek(0x1C)
        disc_magic=f.read(4)
    if disc_magic != bytes.fromhex('C2339F3D'):
        raise ValueError(f'Output is not a complete GameCube disc image: bad disc magic {disc_magic.hex()}')
    out_iso=GameCubeISO(output)
    embedded_sha1=out_iso.sha1_dol()
    patched_sha1=hashlib.sha1(patched_dol.read_bytes()).hexdigest()
    if embedded_sha1!=patched_sha1:
        raise ValueError(f'Post-build DOL verification failed: staged {patched_sha1}, embedded {embedded_sha1}')

    manifest={
        'format':'melee-sdk-iso-build-v2','sdk_version':'0.21.2','package_revision':'0.21.2','phase_history_base':43,'built_utc':datetime.now(timezone.utc).isoformat(),
        'variant':variant,'scene_revive':bool(scene_revive),'friendly_fire':effective_friendly_fire,'adventure_difficulty':adventure_difficulty,'adventure_cpu_level':ADVENTURE_DIFFICULTIES[adventure_difficulty],'adventure_stocks':int(adventure_stocks),'phase43_repairs':bool(phase43_repairs),'test_shortcuts':bool(test_shortcuts),'unlock_all':bool(unlock_all),'vs_p2_identity_bridge':bool(vs_p2_identity_bridge),'adventure_sss_gateway':bool(adventure_sss_gateway),'clean_iso':str(clean),'output_iso':str(output),
        'source_verification':verification,'source_preserved':True,
        'runtime':runtime,'rebuild':rebuild,'sss_visual_qol':sss_visual_qol,
        'verification':{
            'output_game_id':out_iso.game_id.decode('ascii',errors='replace'),
            'embedded_dol_sha1':embedded_sha1,'staged_dol_sha1':patched_sha1,
            'source_iso_size':source_size,'output_iso_size':output_size,
            'gamecube_disc_magic':disc_magic.hex().upper(),'complete_disc_image':True,
            'embedded_dol_matches_staged':True,
        },
        'test_instructions': (
            ['Boot ISO in Dolphin','Connect controllers in ports 1 and 2',
             'Retail-isolation check: enter 1-P > Adventure normally and verify only P1 is created',
             'Retail Continue check: lose all P1 stocks in normal 1-P Adventure and verify genuine retail Game Over/Continue appears',
             'Retail Yoshi check: in ordinary/local VS select Yoshi\'s Island (N64) and verify the retail stage loads normally; it is no longer an Adventure gateway',
             'Direct gateway check: in Slippi Direct press D-Pad Down on SSS for Page 2, verify the Default page shows the D-Pad Down / Co-op Page cue, the Co-op tile says Special Mode / Coop Adventure with a D-Pad Up / Default cue; D-Pad Up returns to Default and D-Pad Down does not open a duplicate retail-stage page; select Co-op Adventure and verify both selected characters start',
             'Active-P2 scripted spawn check: with both humans participating, verify Mushroom Kingdom Mario/Peach and both Corneria CPU fights use their normal scripted placements and are not relocated to either human',
             'Eliminated-P2 control check: eliminate P2 before Mushroom Kingdom and verify Mario/Peach remain correctly placed',
             'Survivor rebirth check: eliminate P2 fully, then KO P1 on a scrolling stage such as Big Blue; verify P1 regains Control and uses retail stage respawn rather than dead-P2 coordinates/camera',
             'Credits check: complete the campaign and verify both independent Staff Roll lenses move/shoot and credits exit normally',
             'Co-op failure check: eliminate both humans; verify Adventure returns to the captured launcher origin with no Continue screen',
             'Origin check: local VS returns to VS; Slippi Direct returns to Slippi online major 0x08; successful Completion uses the guarded GOver -> Adventure -> state 0x68 captured-origin bridge',
             'Record first stage/chapter where spawn, camera, HUD, death/recovery, or progression diverges'] + ([
             'TEST shortcuts: L+D-Pad Left=warp next scene to Bowser fight; Down=original stage-end clear; Right=KO P2; Up=restore stock state'] if test_shortcuts else []) + ([
             'TEST unlock-all: character/stage unlock queries are forced true for this ISO only; save data is not modified'] if unlock_all else []) + ([
             'Independent VS P2 identity bridge is active'] if vs_p2_identity_bridge else []) + ([
             f"SDK gateway: local/ordinary VS is retail, including Yoshi's Island (N64). Slippi Direct uses D-Pad Down on Stage Select -> Custom + Co-op -> Co-op Adventure. Ordinary Yoshi's Story is never a Direct gateway. Co-op Adventure starts on {adventure_difficulty.replace('_',' ').title()} with {adventure_stocks} stocks; friendly fire={'ON' if effective_friendly_fire else 'OFF'}; scene revive={'ON' if scene_revive else 'OFF'}"] if adventure_sss_gateway else [])
            if variant in {'coop_spawn_probe','coop_showcase','coop_chaos'} else
            ['Boot ISO in Dolphin','Verify menus and ordinary matches behave exactly like clean Melee']
        ),
    }
    if manifest_path is None:
        manifest_path=output.with_suffix(output.suffix+'.build_manifest.json')
    mp=Path(manifest_path); mp.parent.mkdir(parents=True,exist_ok=True)
    mp.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    manifest['manifest_path']=str(mp)
    if managed_tmp is not None: managed_tmp.cleanup()
    return manifest
