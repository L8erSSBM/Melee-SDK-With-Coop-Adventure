"""Melee Character SDK 0.20.0: Slippi boot/rollback isolation hardening.

HF29G made co-op behavior gateway-scoped, but its dispatch stubs still loaded the
SDK campaign-active byte before deciding whether the current scene should use
retail behavior.  The SDK runtime section starts at 0x804DEC00, which is also
the end of stock Slippi's static rollback backup region.  Therefore ordinary
VS/online scene traffic should avoid campaign RAM above that boundary entirely.

0.20.0 adds a *mode-first* front door to every HF29G behavior guard:

    non-Adventure -> exact displaced retail behavior, without touching SDK RAM
    Adventure      -> HF29G gateway_coop_active test -> proven HF29E/F handler

It also retires the six HF21 scene-transition trace hooks from the live runtime.
Those hooks were diagnostic-only and are no longer needed now that the
Team-Kirby transition work is validated.  Their historical source/data remains
in the project, but 0.20.0 restores the exact retail instruction at each site.

This is deliberately a compatibility hardening layer, not a claim that Slippi
Direct/rollback integration is complete.  In particular, future rollback-aware
co-op still needs a deliberate home for mutable campaign state.
"""
from __future__ import annotations

from dataclasses import dataclass
import struct

from .adventure_gateway_scope import (
    CURRENT_MODE, GM_ADVENTURE, _addr_parts, _retail_tail,
)
from .dol_patch import DOLImage
from .early_clear_failsafe import Asm
from .ppc import addi, cmpwi, decode_branch, encode_branch, lbz, lis, lwz, stw, stwu

SDK_VERSION = '0.20.0'
MARKER = b'MSDK020S'
# Current stock Slippi fullBackupRegions static Data/BSS range ends here.
SLIPPI_STATIC_BACKUP_END = 0x804DEC00
SDK_STACK_BOUNDARY = 0x804F4C00


@dataclass(frozen=True)
class GuardRow:
    name: str
    site: int
    old_guard: int
    active_target: int
    retail: bytes
    site_link: bool


def _load_byte_abs(out: bytearray, address: int, *, target: int = 11,
                   scratch: int = 12) -> None:
    hi, lo = _addr_parts(address)
    out += lis(scratch, hi)
    out += lbz(target, lo, scratch)


def _mode_first_guard(base: int, *, site: int, active_addr: int,
                      active_target: int, retail: bytes,
                      entry_link: bool) -> bytes:
    """Return retail before reading SDK state unless major mode is Adventure."""
    a = Asm(base)
    # Guard sites occur at arbitrary instructions/functions. Preserve scratch
    # regs exactly as HF29G did.
    a.emit(stwu(1, -0x10, 1), stw(11, 0x08, 1), stw(12, 0x0C, 1))

    # Critical 0.20 ordering: CURRENT_MODE is retail/static state below the
    # Slippi rollback boundary.  Do not read gateway_coop_active until this
    # proves we are in Adventure.
    _load_byte_abs(a.data, CURRENT_MODE)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7))
    a.branch('retail', 4, 30)  # bne

    _load_byte_abs(a.data, active_addr)
    a.emit(cmpwi(11, 1, crf=7))
    a.branch('retail', 4, 30)  # bne

    a.emit(lwz(11, 0x08, 1), lwz(12, 0x0C, 1), addi(1, 1, 0x10))
    a.emit(encode_branch(base + len(a.data), active_target))

    a.label('retail')
    a.emit(lwz(11, 0x08, 1), lwz(12, 0x0C, 1), addi(1, 1, 0x10))
    a.emit(_retail_tail(base + len(a.data), site, retail,
                        entry_link=entry_link))
    return a.finish()


def _parse_guard_rows(gateway_scope: dict) -> list[GuardRow]:
    rows = []
    for row in gateway_scope.get('guarded_hooks', []):
        rows.append(GuardRow(
            name=str(row['name']),
            site=int(row['site_address']),
            old_guard=int(row['guard_stub']),
            active_target=int(row['hf29f_target']),
            retail=bytes.fromhex(row['retail_instruction']),
            site_link=bool(row['site_link']),
        ))
    if not rows:
        raise ValueError('SDK 0.20 requires HF29G guarded_hooks metadata')
    return rows


def install(dol: DOLImage, runtime_index: int, *, gateway_scope: dict,
            legacy_trace_hooks: list[dict] | None = None,
            known_mutable_addresses: dict[str, int] | None = None,
            allow_campaign_credits_cross_mode: bool = False) -> dict:
    """Install mode-first Slippi isolation over the gateway scope layer.

    Historical 0.20 behavior is the default. Current SDK builds may exempt the
    staff-roll input hook because staff roll runs outside GM_ADVENTURE while a
    gateway campaign is still active; its HF29G active-only guard is retained.
    """
    guards = _parse_guard_rows(gateway_scope)
    active_addr = int(gateway_scope['gateway_coop_active_address'])

    # Verify we really are composing on the exact HF29G dispatch layer.
    current_site_words: dict[int, bytes] = {}
    for row in guards:
        raw = dol.read_at_address(row.site, 4)
        dec = decode_branch(row.site, raw)
        if int(dec['target']) != row.old_guard or bool(dec['link']) != row.site_link:
            raise ValueError(
                f'SDK 0.20 expected HF29G guard {row.old_guard:#x} at '
                f'{row.site:#x}; got {raw.hex()} -> {dec}')
        current_site_words[row.site] = raw

    # Verify legacy diagnostic hooks before restoring retail instructions.
    traces = []
    for item in legacy_trace_hooks or []:
        site = int(item['site_address'])
        expected = bytes.fromhex(item['expected'])
        raw = dol.read_at_address(site, 4)
        dec = decode_branch(site, raw)
        if int(dec['target']) != int(item['stub_address']):
            raise ValueError(
                f'SDK 0.20 expected HF21 trace wrapper at {site:#x}; '
                f'got {raw.hex()} -> {dec}')
        traces.append((item, raw, expected))

    section = next(s for s in dol.sections
                   if s.kind == 'data' and s.index == int(runtime_index))
    base = section.address + ((section.size + 31) & ~31)
    cursor = base + 0x20
    blobs: list[tuple[str, int, bytes]] = []

    def add_blob(name: str, builder) -> int:
        nonlocal cursor
        cursor = (cursor + 31) & ~31
        addr = cursor
        blob = builder(addr)
        blobs.append((name, addr, blob))
        cursor = addr + len(blob)
        return addr

    new_guards: dict[int, int] = {}
    guard_manifest = []
    cross_mode_campaign_guards = []
    for row in guards:
        if allow_campaign_credits_cross_mode and row.name == 'dual_player_credits_input':
            # Staff roll is a different major mode. Keep the already-installed
            # HF29G active-byte guard so P2 input remains available through the
            # campaign credits sequence; inactive/non-campaign staff roll is
            # still exact retail through that guard.
            cross_mode_campaign_guards.append({
                'name': row.name,
                'site_address': row.site,
                'hf29g_guard_stub': row.old_guard,
                'hf29ef_active_target': row.active_target,
                'retail_instruction': row.retail.hex(),
                'site_link': row.site_link,
                'policy': 'retain gateway-active guard across staff-roll major mode',
            })
            continue
        addr = add_blob(
            row.name,
            lambda at, row=row: _mode_first_guard(
                at, site=row.site, active_addr=active_addr,
                active_target=row.active_target, retail=row.retail,
                entry_link=row.site_link))
        new_guards[row.site] = addr
        guard_manifest.append({
            'name': row.name,
            'site_address': row.site,
            'hf29g_guard_stub': row.old_guard,
            'hf29ef_active_target': row.active_target,
            'retail_instruction': row.retail.hex(),
            'site_link': row.site_link,
            'mode_first_guard': addr,
        })

    payload = bytearray(MARKER + bytes(24))
    assert len(payload) == 0x20
    for name, addr, blob in blobs:
        wanted = addr - base
        if len(payload) > wanted:
            raise ValueError(f'SDK 0.20 payload layout overlap before {name}')
        payload.extend(bytes(wanted - len(payload)))
        payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    if base + len(payload) >= SDK_STACK_BOUNDARY:
        raise ValueError('SDK 0.20 payload reaches reserved SDK arena boundary')

    added = dol.append_to_data_section(runtime_index, payload)
    assert int(added['address']) == base

    for row in guards:
        if row.site not in new_guards:
            continue
        patched = encode_branch(row.site, new_guards[row.site], link=row.site_link)
        dol.patch_at_address(row.site, patched,
                             expected=current_site_words[row.site])

    retired = []
    for item, old_branch, expected in traces:
        site = int(item['site_address'])
        dol.patch_at_address(site, expected, expected=old_branch)
        retired.append({
            'name': item['name'],
            'site_address': site,
            'hf21_wrapper': int(item['stub_address']),
            'restored_retail_instruction': expected.hex(),
        })

    mutable = {str(k): int(v) for k, v in (known_mutable_addresses or {}).items()}
    outside = {k: v for k, v in mutable.items() if v >= SLIPPI_STATIC_BACKUP_END}

    return {
        'version': SDK_VERSION,
        'marker': MARKER.decode('ascii'),
        'section': added,
        'gateway_coop_active_address': active_addr,
        'mode_first_guards': guard_manifest,
        'cross_mode_campaign_guards': cross_mode_campaign_guards,
        'retired_hf21_scene_trace_hooks': retired,
        'slippi_static_backup_end': SLIPPI_STATIC_BACKUP_END,
        'runtime_section_address': section.address,
        'runtime_section_end': int(added['section_address']) + int(added['section_size']),
        'known_mutable_addresses': mutable,
        'mutable_addresses_outside_stock_slippi_static_backup': outside,
        'boot_isolation_policy': (
            'outside GM_ADVENTURE, behavior dispatches return to exact retail before '
            'reading campaign state; when enabled, staff-roll dual-input is the one '
            'intentional cross-mode exception and remains gated by gateway_coop_active'
            if allow_campaign_credits_cross_mode else
            'outside GM_ADVENTURE, every HF29G behavior dispatch returns to exact '
            'retail behavior before reading gateway_coop_active or other campaign state'),
        'diagnostic_cleanup_policy': (
            'HF21 scene-transition trace hooks restored to exact retail instructions; '
            'historical trace code remains archived but no longer executes'),
        'rollback_status': (
            'boot-isolation candidate only; future Slippi Direct co-op rollback still '
            'requires rollback-backed placement/synchronization of mutable campaign state'),
    }
