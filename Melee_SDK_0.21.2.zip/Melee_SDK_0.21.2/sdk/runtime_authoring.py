from __future__ import annotations

import json
import shutil
from pathlib import Path
from typing import Any

from .dol_patch import DOLImage, SymbolMap
from .gamecube_iso import GameCubeISO
from .stage import STAGEDATA_SYMBOL_BY_FILENAME
from .stage_slot import StageSlotAuthor
from .character_slot import CharacterSlotAuthor, FT_KIND_BOY, FT_KIND_GIRL
from .workspace import sha256_file

FIGHTER_KIND_BY_NAME = {
    'Mario':0x00,'Fox':0x01,'Captain':0x02,'Donkey':0x03,'Kirby':0x04,'Koopa':0x05,
    'Link':0x06,'Seak':0x07,'Ness':0x08,'Peach':0x09,'Popo':0x0A,'Nana':0x0B,
    'Pikachu':0x0C,'Samus':0x0D,'Yoshi':0x0E,'Purin':0x0F,'Mewtwo':0x10,
    'Luigi':0x11,'Mars':0x12,'Zelda':0x13,'Clink':0x14,'Drmario':0x15,
    'Falco':0x16,'Pichu':0x17,'Gamewatch':0x18,'Ganon':0x19,'Emblem':0x1A,
    'MasterH':0x1B,'CrezyH':0x1C,'Boy':0x1D,'Girl':0x1E,'GKoops':0x1F,'Sandbag':0x20,
}


def bundled_symbol_map() -> SymbolMap:
    path = Path(__file__).resolve().parent.parent / 'data' / 'runtime_symbols_GALE01.txt'
    return SymbolMap.from_file(path)


def _ensure_original_dol(project, iso: GameCubeISO) -> Path:
    orig = project.original_dir / 'start.dol'
    if not orig.exists():
        iso.extract_dol(orig)
        rows = project.manifest.setdefault('resources', [])
        rows.append({'filename':'start.dol','source_relative':'<clean ISO main.dol>',
                     'sha256':sha256_file(orig),'size':orig.stat().st_size})
        project.manifest['resources'] = sorted(rows,key=lambda x:x['filename'].lower())
        project.save_manifest()
    return orig


def _composable_dol_path(project, iso: GameCubeISO) -> Path:
    """Return the evolving build DOL, seeding it from Original only once.

    Runtime authoring features must compose on the same Working/start.dol.
    Reopening Original/start.dol for every operation silently discards earlier
    runtime patches when multiple SDK architectures are enabled together.
    """
    orig = _ensure_original_dol(project, iso)
    work = project.working_dir / 'start.dol'
    if not work.exists():
        work.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(orig, work)
    return work


def install_authored_stage_runtime(project, clean_iso: str | Path,
                                   authored_filename: str,
                                   donor_stage_filename: str) -> dict[str, Any]:
    """Prepare a buildable new-stage runtime slot in Working/.

    The authored Gr*.dat is kept under its own FST filename. The clean main.dol
    is snapshotted to Original/start.dol, a new loader-backed data section is
    appended, and dormant StKind 0x15 / GrKind 0x1A is activated against the
    authored filename. Build/ then contains both the new FST file and start.dol.
    """
    iso = GameCubeISO(clean_iso)
    work = _composable_dol_path(project, iso)
    stage = project.stage_by_filename(authored_filename)
    meta = next((r for r in project.manifest.get('resources',[]) if r['filename'].lower()==stage.filename.lower()),None)
    if not meta or not (meta.get('authored_new') or str(meta.get('source_relative','')).startswith('<authored')):
        raise ValueError('Install-as-new-slot requires an authored stage variant, not a vanilla replacement resource.')
    donor_sym = STAGEDATA_SYMBOL_BY_FILENAME.get(donor_stage_filename.lower())
    if not donor_sym:
        raise ValueError(f'No source-validated StageData symbol mapping for {donor_stage_filename}')
    dol = DOLImage(work)
    sm = bundled_symbol_map()
    result = StageSlotAuthor(dol, sm).inject_hidden_stage_slot_expanded(donor_sym, '/' + stage.filename)
    dol.save_as(work)
    plan = {
        'status':'runtime_slot_installed', 'stkind':result.stkind, 'grkind':result.grkind,
        'stage_filename':stage.filename, 'donor_stage_filename':donor_stage_filename,
        'template_symbol':donor_sym, 'stage_data_address':result.stage_data_address,
        'filename_address':result.filename_address,
        'sss_visibility':'runtime slot works independently; vanilla SSS still needs a menu bridge/icon patch',
    }
    project.manifest.setdefault('runtime_authoring',{})['stage_slot'] = plan
    project.save_manifest()
    return plan


def install_fighter_prototype_runtime(project, clean_iso: str | Path,
                                      donor_fighter_name: str, target: str='Boy') -> dict[str, Any]:
    """Prepare a Boy/Girl prototype fighter plus donor callback-table patches."""
    target_key=target.strip().lower()
    if target_key not in ('boy','girl'):
        raise ValueError('target must be Boy or Girl')
    assets = project.create_wireframe_prototype(donor_fighter_name, target)
    donor_kind=FIGHTER_KIND_BY_NAME.get(donor_fighter_name)
    if donor_kind is None:
        raise ValueError(f'No FighterKind mapping for {donor_fighter_name}')
    target_kind=FT_KIND_BOY if target_key=='boy' else FT_KIND_GIRL
    iso=GameCubeISO(clean_iso)
    work=_composable_dol_path(project,iso)
    dol=DOLImage(work)
    sm=bundled_symbol_map()
    author=CharacterSlotAuthor(dol,sm)
    patches=author.clone_ftkind_callback_tables(donor_kind,target_kind)
    dol.save_as(work)
    plan={**assets,'status':'prototype_assets_and_callback_tables_installed',
          'donor_kind':donor_kind,'target_kind':target_kind,'dol_patch_count':len(patches),
          'css_visibility':'not yet added to normal CSS; use debug/forced CharacterKind path until CSS bridge is implemented',
          'model_note':'reserved Boy/Girl costume/model identity is retained; final model/skeleton/animation authoring remains separate'}
    project.manifest.setdefault('runtime_authoring',{}).setdefault('fighter_prototypes',{})[target_key]=plan
    project.save_manifest()
    return plan
