from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable

from .adventure_coop import CoopAdventureCampaign
from .dol_patch import DOLImage, SymbolMap
from .gamecube_iso import GALE01_102_DOL_SHA1
from .stage import StageDAT
from .adventure_legacy import legacy_analysis


ROUTE_STAGE_FILES = ('GrNKr.dat', 'GrNSr.dat', 'GrNZr.dat', 'GrNBr.dat')


@dataclass(frozen=True)
class AdventureRuntimeTouchpoint:
    symbol: str
    category: str
    retail_behavior: str
    coop_requirement: str
    severity: str = 'required'


# Curated from the decompiled GALE01 1.02 source.  This is deliberately a
# conservative list of confirmed P1-only assumptions, not a claim that every
# co-op concern has already been solved.
RUNTIME_TOUCHPOINTS: tuple[AdventureRuntimeTouchpoint, ...] = (
    AdventureRuntimeTouchpoint(
        'gm_8017CE34', 'match-init',
        'Builds StartMeleeData with one human in players[0], then allocates enemies after it.',
        'Reserve players[0] and players[1] for P1/P2 before CPU allocation; keep CPU/wave slots in 2/3.'),
    AdventureRuntimeTouchpoint(
        'gm_8017D7AC', 'progression',
        'Reads player_standings[0] for time/stocks/ftkind and writes the persistent Adventure stock count from P1 only.',
        'Evaluate the human team and define an explicit shared-stock/continue policy instead of assuming standings[0].'),
    AdventureRuntimeTouchpoint(
        'gm_8017E7A0', 'route-timeout',
        'On route timeout calls Player_LoseStock(0) and updates HUD/status for port 0 only.',
        'Apply route timeout to the co-op team according to the configured stock policy.'),
    AdventureRuntimeTouchpoint(
        'gm_801B4064', 'adventure-vs-entry',
        'Adventure VS scene funnels retail encounter data into gm_8017CE34.',
        'Use as the Adventure-specific activation gate so Classic/All-Star remain untouched.'),
    AdventureRuntimeTouchpoint(
        'gm_801B42E8', 'css-entry',
        'Adventure CSS initializes the retail single-player selector from one persistent character record.',
        'Preserve P1 retail selection while supplying a deterministic P2 profile until two-cursor CSS support exists.'),
    AdventureRuntimeTouchpoint(
        'gm_801B4350', 'css-exit',
        'Writes the one selected character/color/nametag/CPU-level record back to Adventure state.',
        'Persist the P2 co-op profile separately without corrupting retail Adventure save/progression fields.'),
)


@dataclass
class RoutePartnerProfile:
    filename: str
    stage_name: str
    p1_spawn: tuple[float, float, float]
    p2_spawn: tuple[float, float, float]
    p2_ground_y: float | None
    p2_offset_x: float
    checkpoints: list[dict]
    camera: dict | None
    blast: dict | None
    has_native_p2_spawn: bool
    warnings: list[str]

    def to_dict(self) -> dict:
        return asdict(self)


def _floor_y_at(stage: StageDAT, x: float, y_hint: float, *, max_above: float = 8.0,
                max_drop: float = 80.0) -> float | None:
    verts = stage.vertices()
    best = None
    for line in stage.lines():
        try:
            surface = stage.line_surface(line['index'])
        except Exception:
            continue
        if surface['category'] not in ('Floor', 'Dynamic') and not surface.get('platform'):
            continue
        x0, y0 = verts[line['v0']]
        x1, y1 = verts[line['v1']]
        lo, hi = sorted((x0, x1))
        if x < lo - 1e-5 or x > hi + 1e-5:
            continue
        if abs(x1 - x0) < 1e-6:
            yy = max(y0, y1)
        else:
            t = (x - x0) / (x1 - x0)
            yy = y0 + (y1 - y0) * t
        delta = y_hint - yy
        if delta < -max_above or delta > max_drop:
            continue
        score = abs(delta)
        if best is None or score < best[0]:
            best = (score, yy)
    return None if best is None else float(best[1])


def build_route_partner_profile(path: str | Path) -> RoutePartnerProfile:
    stage = StageDAT(path)
    markers = stage.markers()
    spawns = [m for m in markers if 0 <= m.marker_id <= 3]
    if not spawns:
        raise ValueError(f'{stage.filename} has no player spawn marker')
    p1 = next((m for m in spawns if m.marker_id == 0), spawns[0])
    native_p2 = next((m for m in spawns if m.marker_id == 1), None)
    warnings: list[str] = []

    if native_p2 is not None:
        p2 = (native_p2.world_x, native_p2.world_y, native_p2.world_z)
        ground_y = _floor_y_at(stage, p2[0], p2[1])
        offset_x = p2[0] - p1.world_x
    else:
        # Retail Adventure route stages are authored for one human and normally
        # expose only marker 0. Pick a conservative nearby partner X coordinate
        # that is supported by collision, without mutating the DAT.
        candidate_offsets = (8.0, -8.0, 12.0, -12.0, 5.0, -5.0, 16.0, -16.0)
        chosen = None
        for dx in candidate_offsets:
            cx = p1.world_x + dx
            gy = _floor_y_at(stage, cx, p1.world_y)
            if gy is not None:
                chosen = (dx, cx, gy)
                break
        if chosen is None:
            offset_x = 8.0
            p2 = (p1.world_x + offset_x, p1.world_y, p1.world_z)
            ground_y = None
            warnings.append('No nearby supporting collision was found for the automatic P2 spawn; runtime/manual tuning required.')
        else:
            offset_x, cx, ground_y = chosen
            p2 = (cx, p1.world_y, p1.world_z)
            if abs(p1.world_y - ground_y) > 25:
                warnings.append('Automatic P2 spawn is supported by collision, but the vertical gap is large; verify in-game.')

    checkpoints = []
    checkpoint_keys = set()
    for m in markers:
        if 4 <= m.marker_id <= 7:
            key=(m.marker_id, round(m.world_x, 5), round(m.world_y, 5), round(m.world_z, 5))
            if key in checkpoint_keys:
                continue
            checkpoint_keys.add(key)
            checkpoints.append({'marker_id': m.marker_id, 'name': m.name,
                                'x': m.world_x, 'y': m.world_y, 'z': m.world_z})
    if not checkpoints:
        warnings.append('No standard respawn/checkpoint markers (4..7) were found; partner recovery must use a runtime fallback.')
    cb = stage.camera_blast_bounds()
    if cb.get('camera') is None:
        warnings.append('No standard camera-bound marker set was resolved; route camera behavior must stay stage-native.')
    return RoutePartnerProfile(
        stage.filename,
        stage.catalog.name if stage.catalog else stage.filename,
        (p1.world_x, p1.world_y, p1.world_z),
        tuple(float(v) for v in p2),
        ground_y,
        float(offset_x),
        checkpoints,
        cb.get('camera'),
        cb.get('blast'),
        native_p2 is not None,
        warnings,
    )


def build_route_partner_atlas(stage_folder: str | Path) -> dict:
    folder = Path(stage_folder)
    profiles = []
    missing = []
    for name in ROUTE_STAGE_FILES:
        p = folder / name
        if not p.exists():
            missing.append(name)
            continue
        profiles.append(build_route_partner_profile(p).to_dict())
    return {
        'format': 'melee-sdk-coop-route-atlas-v1',
        'required_files': list(ROUTE_STAGE_FILES),
        'missing_files': missing,
        'profiles': profiles,
        'status': 'PASS' if not missing and len(profiles) == len(ROUTE_STAGE_FILES) else 'INCOMPLETE',
        'note': 'P2 coordinates are runtime spawn recommendations. Retail route DATs are not structurally rewritten just to add a marker.',
    }


def runtime_touchpoint_report() -> dict:
    return {
        'format': 'melee-sdk-coop-runtime-touchpoints-v1',
        'target': 'GALE01 1.02',
        'touchpoints': [asdict(x) for x in RUNTIME_TOUCHPOINTS],
        'required_symbols': [x.symbol for x in RUNTIME_TOUCHPOINTS],
        'phase28_legacy_research': legacy_analysis(),
        'phase28_policy': {
            'activation_gate': 'SDK Co-op Adventure mode only',
            'spawn': 'two humans through normal StartMeleeData/PlayerInitData path',
            'enemy_slots': [2, 3],
            'global_legacy_patches': False,
            'raw_player_slots_4_manufacturing': False,
            'route_spawn_source': 'Phase 24 route partner atlas + normal Player coordinate APIs',
            'progression_scope': 'human team',
        },
    }


def preflight_runtime_dol(dol_path: str | Path, symbols_path: str | Path, *,
                          require_clean: bool = False, window_size: int = 0x40) -> dict:
    dol_path = Path(dol_path)
    raw = dol_path.read_bytes()
    digest = hashlib.sha1(raw).hexdigest()
    if require_clean and digest.lower() != GALE01_102_DOL_SHA1.lower():
        raise ValueError(f'start.dol is not the canonical GALE01 1.02 main.dol: expected {GALE01_102_DOL_SHA1}, got {digest}')
    dol = DOLImage(raw)
    symbols = SymbolMap.from_file(symbols_path)
    hooks = []
    for tp in RUNTIME_TOUCHPOINTS:
        sym = symbols.require(tp.symbol)
        if sym.section in ('.bss', 'bss'):
            raise ValueError(f'{tp.symbol} resolves to BSS, expected executable code')
        size = min(window_size, sym.size or window_size)
        code = dol.read_at_address(sym.address, size)
        hooks.append({
            'symbol': tp.symbol,
            'address': sym.address,
            'declared_size': sym.size,
            'section': sym.section,
            'capture_size': size,
            'sha256': hashlib.sha256(code).hexdigest(),
            'bytes': code.hex(),
            'category': tp.category,
        })
    return {
        'format': 'melee-sdk-coop-runtime-preflight-v1',
        'target': 'GALE01 1.02',
        'dol_sha1': digest,
        'canonical_clean': digest.lower() == GALE01_102_DOL_SHA1.lower(),
        'dol_size': len(raw),
        'hooks': hooks,
        'status': 'PASS',
        'note': 'This is a guarded hook-site capture/preflight. It does not claim the final PowerPC co-op runtime patch is installed.',
    }


def write_runtime_prep_bundle(directory: str | Path, *, campaign: CoopAdventureCampaign | None = None,
                              stage_folder: str | Path | None = None,
                              dol_path: str | Path | None = None,
                              symbols_path: str | Path | None = None) -> Path:
    root = Path(directory)
    root.mkdir(parents=True, exist_ok=True)
    campaign = campaign or CoopAdventureCampaign.vanilla_sequence()
    campaign.save(root / 'coop_adventure.json')
    (root / 'runtime_plan.json').write_text(json.dumps(campaign.runtime_plan(), indent=2), encoding='utf-8')
    (root / 'runtime_touchpoints.json').write_text(json.dumps(runtime_touchpoint_report(), indent=2), encoding='utf-8')
    if stage_folder is not None:
        atlas = build_route_partner_atlas(stage_folder)
        (root / 'route_partner_atlas.json').write_text(json.dumps(atlas, indent=2), encoding='utf-8')
    if dol_path is not None and symbols_path is not None:
        pf = preflight_runtime_dol(dol_path, symbols_path)
        (root / 'runtime_dol_preflight.json').write_text(json.dumps(pf, indent=2), encoding='utf-8')
    return root
