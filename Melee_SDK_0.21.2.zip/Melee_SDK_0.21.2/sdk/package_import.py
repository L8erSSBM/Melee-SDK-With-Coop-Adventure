from __future__ import annotations

import io, shutil, tempfile, zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .melee_dat import FighterDAT, HSDArchive, rename_hsd_public_symbol
from .stage import StageDAT
from .workspace import sha256_file

@dataclass
class PackageFile:
    name: str
    kind: str
    size: int
    valid: bool
    note: str=''


def _iter_package_files(path: str|Path):
    p=Path(path)
    if p.is_dir():
        for f in p.rglob('*'):
            if f.is_file():
                yield f.name, f.read_bytes()
    elif p.suffix.lower()=='.zip':
        with zipfile.ZipFile(p) as z:
            for n in z.namelist():
                if n.endswith('/'): continue
                yield Path(n).name, z.read(n)
    elif p.is_file():
        yield p.name,p.read_bytes()
    else:
        raise FileNotFoundError(p)


def inspect_mod_package(path: str|Path) -> dict[str,Any]:
    files=[]; stages=[]; fighters=[]
    for name,data in _iter_package_files(path):
        lo=name.lower(); kind='other'; valid=False; note=''
        if lo.startswith('gr') and lo.endswith('.dat'):
            kind='stage'
            try:
                s=StageDAT(data); s.validate(); valid=True; stages.append(name)
            except Exception as e: note=str(e)
        elif lo.startswith('pl') and lo.endswith('.dat'):
            kind='fighter_resource'
            try:
                HSDArchive(data); valid=True
                stem=Path(name).stem
                if len(stem)==4:
                    try:
                        f=FighterDAT(data); fighters.append({'file':name,'fighter_name':f.fighter_name})
                    except Exception: pass
            except Exception as e: note=str(e)
        files.append(asdict(PackageFile(name,kind,len(data),valid,note)))
    return {'path':str(path),'files':files,'stages':stages,'fighters':fighters,
            'stage_count':len(stages),'fighter_base_count':len(fighters)}


def import_stage_package(project, package: str|Path, *, target_filename: str|None=None,
                         as_new: bool=False, new_filename: str|None=None) -> dict[str,Any]:
    candidates=[]
    for name,data in _iter_package_files(package):
        if name.lower().startswith('gr') and name.lower().endswith('.dat'):
            try: StageDAT(data).validate()
            except Exception: continue
            candidates.append((name,data))
    if not candidates: raise ValueError('No valid Gr*.dat stage archive was found in the package')
    if len(candidates)>1 and not target_filename and not new_filename:
        raise ValueError('Package contains multiple stage DATs; choose a target or new filename')
    src_name,data=candidates[0]
    if as_new:
        fn=Path(new_filename or src_name).name
        if not fn.lower().startswith('gr') or not fn.lower().endswith('.dat'): raise ValueError('New stage filename must be Gr*.dat')
        if any(s.filename.lower()==fn.lower() for s in project.stages): raise ValueError(f'{fn} already exists in this project')
        orig=project.original_dir/fn; work=project.working_dir/fn; orig.write_bytes(data); work.write_bytes(data)
        project.manifest.setdefault('resources',[]).append({'filename':fn,'source_relative':f'<imported stage package {Path(package).name}>','sha256':sha256_file(orig),'size':len(data),'authored_new':True})
        project.manifest.setdefault('stages',[]).append({'filename':fn,'display_name':Path(fn).stem,'source_relative':f'<imported stage package {Path(package).name}>'})
        project.manifest['resources']=sorted(project.manifest['resources'],key=lambda x:x['filename'].lower())
        project.manifest['stages']=sorted(project.manifest['stages'],key=lambda x:x['display_name'].lower())
        project.save_manifest(); project.stages=project._load_stages()
        # Stage packages may carry arbitrary content, but never controller
        # ownership of the SDK SSS pager. Rebuild the canonical page set and
        # force the reserved D-Pad Down/Up navigation contract.
        from .stage_select_pages import enforce_project_page_navigation
        enforce_project_page_navigation(project, rebuild=True)
        return {'mode':'new_stage','source_file':src_name,'installed_file':fn,'size':len(data)}
    if not target_filename: target_filename=src_name
    target=project.stage_by_filename(target_filename)
    (project.working_dir/target.filename).write_bytes(data)
    from .stage_select_pages import enforce_project_page_navigation
    enforce_project_page_navigation(project, rebuild=False)
    return {'mode':'replace_stage','source_file':src_name,'installed_file':target.filename,'size':len(data)}


def import_fighter_package(project, package: str|Path, *, target_prefix: str|None=None) -> dict[str,Any]:
    """Install a drop-in PlXX* fighter package into Working/.

    If target_prefix is omitted, files keep their package basenames and therefore
    replace the matching fighter identity. Cross-identity remapping is intentionally
    limited to base/AJ/neutral-model prototype workflows elsewhere in the SDK.
    """
    package_files=[]
    for name,data in _iter_package_files(package):
        if name.lower().startswith('pl') and name.lower().endswith('.dat'):
            try: HSDArchive(data)
            except Exception: continue
            package_files.append((name,data))
    if not package_files: raise ValueError('No valid Pl*.dat fighter resources were found in the package')
    installed=[]; skipped=[]
    if target_prefix is not None:
        target_prefix=target_prefix.strip()
        if len(target_prefix)!=4 or not target_prefix.lower().startswith('pl'): raise ValueError('target_prefix must look like PlFx or PlBo')
        source_prefixes={Path(n).stem[:4] for n,_ in package_files if len(Path(n).stem)>=4}
        if len(source_prefixes)!=1: raise ValueError('Cross-identity import requires a package with one fighter prefix')
        source_prefix=next(iter(source_prefixes))
    else:
        source_prefix=None
    known={r['filename'].lower():r for r in project.manifest.get('resources',[])}
    for name,data in package_files:
        outname=name
        if target_prefix:
            stem=Path(name).stem
            if not stem.startswith(source_prefix): continue
            outname=target_prefix+stem[4:]+'.dat'
        if outname.lower() not in known:
            skipped.append(outname); continue
        (project.working_dir/outname).write_bytes(data); installed.append(outname)
    if not installed: raise ValueError('Package did not match any registered fighter resources in this project')
    return {'mode':'fighter_dropin','installed':installed,'skipped_unregistered':skipped,'count':len(installed)}
