from __future__ import annotations

import json
import struct
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Iterable

from .dol_patch import DOLImage, SymbolMap

CLASSIC_SYMBOL = 'gmTraining_ClassicStages'
ADVENTURE_SYMBOL = 'lbl_803D7AC0'
CLASSIC_ENTRY_SIZE = 0x10
CLASSIC_ENTRY_COUNT = 65
ADVENTURE_ENTRY_SIZE = 0x1A
ADVENTURE_ENTRY_COUNT = 110


@dataclass
class ClassicStageEntry:
    index: int
    stage_kind: int
    scale0_pct: int
    scale1_pct: int
    payload: bytes

    @property
    def group(self) -> int:
        return self.index // 5

    @property
    def slot(self) -> int:
        return self.index % 5

    @property
    def opponent_triplets(self) -> list[tuple[int, int, int]]:
        # Source accessors read pad_6[idx*3 + 0/1/2].  We deliberately keep
        # semantic names conservative until every caller has been traced.
        b = self.payload[:9]
        return [tuple(b[i:i+3]) for i in range(0, 9, 3)]

    def to_bytes(self) -> bytes:
        if not 0 <= self.stage_kind <= 0xFF:
            raise ValueError('stage_kind must fit in u8')
        if not 0 <= self.scale0_pct <= 0xFFFF or not 0 <= self.scale1_pct <= 0xFFFF:
            raise ValueError('scale percentages must fit in u16')
        if len(self.payload) != 10:
            raise ValueError('Classic payload must be exactly 10 bytes')
        return bytes([self.stage_kind, 0]) + struct.pack('>HH', self.scale0_pct, self.scale1_pct) + self.payload


@dataclass
class AdventureStageEntry:
    index: int
    stage_kind: int
    scale0_pct: int
    scale1_pct: int
    payload: bytes

    @property
    def group(self) -> int:
        return self.index // 5

    @property
    def slot(self) -> int:
        return self.index % 5

    def to_bytes(self) -> bytes:
        if not 0 <= self.stage_kind <= 0xFF:
            raise ValueError('stage_kind must fit in u8')
        if not 0 <= self.scale0_pct <= 0xFFFF or not 0 <= self.scale1_pct <= 0xFFFF:
            raise ValueError('scale percentages must fit in u16')
        if len(self.payload) != 20:
            raise ValueError('Adventure payload must be exactly 20 bytes')
        return bytes([self.stage_kind, 0]) + struct.pack('>HH', self.scale0_pct, self.scale1_pct) + self.payload


class OnePlayerModeEditor:
    """Source-grounded editor for GALE01 Classic/Adventure encounter tables.

    Only fields whose meaning is explicit in the decomp are exposed as named
    editable values: stage_kind, scale0_pct, scale1_pct. Remaining bytes are
    preserved verbatim, though Classic's 3-byte access pattern is inspectable.
    """

    def __init__(self, dol: DOLImage, symbols: SymbolMap):
        self.dol = dol
        self.symbols = symbols
        self._check_symbol(CLASSIC_SYMBOL, CLASSIC_ENTRY_SIZE * CLASSIC_ENTRY_COUNT)
        self._check_symbol(ADVENTURE_SYMBOL, ADVENTURE_ENTRY_SIZE * ADVENTURE_ENTRY_COUNT)

    def _check_symbol(self, name: str, expected_size: int) -> None:
        s = self.symbols.require(name)
        if s.size is not None and s.size != expected_size:
            raise ValueError(f'{name}: expected 0x{expected_size:X} bytes from source, symbol map reports 0x{s.size:X}')
        self.dol.section_for_address(s.address, expected_size)

    def classic_entries(self) -> list[ClassicStageEntry]:
        s = self.symbols.require(CLASSIC_SYMBOL)
        raw = self.dol.read_at_address(s.address, CLASSIC_ENTRY_COUNT * CLASSIC_ENTRY_SIZE)
        out=[]
        for i in range(CLASSIC_ENTRY_COUNT):
            x=raw[i*16:(i+1)*16]
            out.append(ClassicStageEntry(i, x[0], int.from_bytes(x[2:4],'big'), int.from_bytes(x[4:6],'big'), bytes(x[6:16])))
        return out

    def adventure_entries(self) -> list[AdventureStageEntry]:
        s = self.symbols.require(ADVENTURE_SYMBOL)
        raw = self.dol.read_at_address(s.address, ADVENTURE_ENTRY_COUNT * ADVENTURE_ENTRY_SIZE)
        out=[]
        for i in range(ADVENTURE_ENTRY_COUNT):
            x=raw[i*26:(i+1)*26]
            out.append(AdventureStageEntry(i, x[0], int.from_bytes(x[2:4],'big'), int.from_bytes(x[4:6],'big'), bytes(x[6:26])))
        return out

    def patch_classic(self, index: int, *, stage_kind: int|None=None,
                      scale0_pct: int|None=None, scale1_pct: int|None=None) -> dict:
        entries=self.classic_entries(); e=entries[int(index)]
        before=e.to_bytes()
        if stage_kind is not None: e.stage_kind=int(stage_kind)
        if scale0_pct is not None: e.scale0_pct=int(scale0_pct)
        if scale1_pct is not None: e.scale1_pct=int(scale1_pct)
        s=self.symbols.require(CLASSIC_SYMBOL)
        return self.dol.patch_at_address(s.address+e.index*16, e.to_bytes(), expected=before)

    def patch_adventure(self, index: int, *, stage_kind: int|None=None,
                        scale0_pct: int|None=None, scale1_pct: int|None=None) -> dict:
        entries=self.adventure_entries(); e=entries[int(index)]
        before=e.to_bytes()
        if stage_kind is not None: e.stage_kind=int(stage_kind)
        if scale0_pct is not None: e.scale0_pct=int(scale0_pct)
        if scale1_pct is not None: e.scale1_pct=int(scale1_pct)
        s=self.symbols.require(ADVENTURE_SYMBOL)
        return self.dol.patch_at_address(s.address+e.index*26, e.to_bytes(), expected=before)

    def export_tables(self, path: str|Path) -> Path:
        p=Path(path)
        data={
            'format':'melee-sdk-1p-tables-v1',
            'classic':[{'index':e.index,'group':e.group,'slot':e.slot,'stage_kind':e.stage_kind,
                        'scale0_pct':e.scale0_pct,'scale1_pct':e.scale1_pct,
                        'opponent_triplets':[list(x) for x in e.opponent_triplets],
                        'opaque_tail':e.payload[9:].hex()} for e in self.classic_entries()],
            'adventure':[{'index':e.index,'group':e.group,'slot':e.slot,'stage_kind':e.stage_kind,
                          'scale0_pct':e.scale0_pct,'scale1_pct':e.scale1_pct,
                          'opaque_payload':e.payload.hex()} for e in self.adventure_entries()],
        }
        p.write_text(json.dumps(data,indent=2),encoding='utf-8')
        return p


@dataclass
class ModePlayer:
    controller_port: int
    role: str = 'human'   # human / cpu / disabled
    team: int = 0
    fighter_kind: int | None = None
    cpu_level: int | None = None


@dataclass
class CustomModeRecipe:
    """SDK-level recipe for future custom 1P/co-op/duo runtime modes.

    This is intentionally not represented as an already-playable DOL mode.
    It gives the project a stable authoring format while runtime scene/code
    hooks are developed in later phases.
    """
    name: str
    mode_type: str = 'duo_challenge'
    players: list[ModePlayer] = field(default_factory=lambda: [
        ModePlayer(0,'human',0), ModePlayer(1,'human',0),
        ModePlayer(2,'cpu',1,cpu_level=5), ModePlayer(3,'disabled',1)
    ])
    stage_kinds: list[int] = field(default_factory=list)
    stock_count: int = 4
    time_limit_seconds: int = 0
    notes: str = ''

    def validate(self) -> None:
        if not self.name.strip(): raise ValueError('Mode recipe needs a name')
        if len(self.players) > 4: raise ValueError('Melee supports at most four fighter slots')
        ports=[p.controller_port for p in self.players]
        if len(set(ports)) != len(ports) or any(p < 0 or p > 3 for p in ports):
            raise ValueError('Controller ports must be unique values 0..3')
        if sum(p.role=='human' for p in self.players) < 1: raise ValueError('Recipe needs at least one human')
        if not 1 <= int(self.stock_count) <= 99: raise ValueError('stock_count must be 1..99')
        for s in self.stage_kinds:
            if not 0 <= int(s) <= 0xFF: raise ValueError('stage kind must fit in u8')

    def save(self, path: str|Path) -> Path:
        self.validate(); p=Path(path)
        p.write_text(json.dumps({'format':'melee-sdk-custom-mode-v1', **asdict(self)},indent=2),encoding='utf-8')
        return p

    @classmethod
    def load(cls, path: str|Path) -> 'CustomModeRecipe':
        data=json.loads(Path(path).read_text(encoding='utf-8'))
        if data.get('format')!='melee-sdk-custom-mode-v1': raise ValueError('Unsupported mode recipe format')
        obj=cls(data['name'],data.get('mode_type','duo_challenge'),
                [ModePlayer(**x) for x in data.get('players',[])],
                list(data.get('stage_kinds',[])),int(data.get('stock_count',4)),
                int(data.get('time_limit_seconds',0)),data.get('notes',''))
        obj.validate(); return obj
