from __future__ import annotations

import copy
import json
import os
import struct
import math
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable

from .character_schemas import CHARACTER_ATTR_SCHEMAS

BE_U32 = struct.Struct('>I')
BE_I32 = struct.Struct('>i')
BE_F32 = struct.Struct('>f')

# ftAction_803C0870, indexed by fighter subaction opcode - 10.
# Values are command sizes in 32-bit words. This is copied from the decompiled
# source rather than guessed from binary patterns.
FIGHTER_EVENT_WORD_LENGTHS = [
    5, 5, 1, 1, 1, 1, 1, 3, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 3, 1, 1, 1, 7, 4, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 3, 3, 2, 1, 4,
]


# Common command opcodes 0..9 are normally one word, except Subroutine and
# Goto. The decompiled lbCommand implementation advances past the opcode word
# before reading Command_05.ptr / Command_07.ptr, so those commands occupy a
# second relocated pointer word in the on-disc HSD archive.
CONTROL_EVENT_WORD_LENGTHS = {5: 2, 7: 2}


def _fighter_event_word_length(opcode: int) -> int:
    opcode = int(opcode)
    if 0 <= opcode < 10:
        return CONTROL_EVENT_WORD_LENGTHS.get(opcode, 1)
    if 10 <= opcode <= 58:
        return FIGHTER_EVENT_WORD_LENGTHS[opcode - 10]
    raise ValueError(f'Invalid fighter-script opcode {opcode}')

EVENT_NAMES = {
    0: 'End/Reset',
    1: 'Synchronous Timer',
    2: 'Asynchronous Timer',
    3: 'Set Loop',
    4: 'Execute Loop',
    5: 'Subroutine',
    6: 'Return',
    7: 'Goto',
    8: 'Set Timer Animation',
    9: 'Background Flash',
    10: 'Spawn GFX',
    11: 'Spawn Hitbox',
    12: 'Adjust Hitbox Damage',
    13: 'Adjust Hitbox Size',
    14: 'Set Hitbox Flags',
    15: 'Deactivate Hitbox',
    16: 'Deactivate All Hitboxes',
    17: 'Play Sound Effect',
    18: 'Play Smash SFX',
    19: 'Set Command Variable',
    20: 'Set Throw Flag / Timer',
    21: 'Set Throw Flag B1',
    22: 'Set Throw Flag B2',
    23: 'Allow Interrupt',
    24: 'Set Throw Flag B0',
    25: 'Set Airborne/Ground State',
    26: 'Set Collision State',
    27: 'Set Collision State 2',
    28: 'Set Hurtbox State',
    29: 'Enable Jab Combo',
    30: 'Set Rapid Jab State',
    31: 'Set Model Part',
    32: 'Restore Model Parts',
    33: 'Hide Model Parts',
    34: 'Set Throw Hitbox',
    35: 'Set Parasol State',
    36: 'Set Article Visibility',
    37: 'Set Fighter Visibility',
    38: 'Pseudo-random Sound Effect',
    39: 'Directional / Stage SFX',
    40: 'Set Texture Animation',
    41: 'Apply Part Animation',
    42: 'Set Parasol Animation Speed',
    43: 'Start Rumble',
    44: 'Stop Rumble',
    45: 'Set Sword Item Animation',
    46: 'Start Color Animation',
    47: 'Stop Color Animation',
    48: 'Set Fighter Script Flag',
    49: 'Set Model State',
    50: 'Toggle Bone Dynamics',
    51: 'Apply Self Damage',
    52: 'Set Fighter Model Flags',
    53: 'Set Fighter State Flag',
    54: 'Footstep SFX / GFX',
    55: 'Spawn Fighter Effect / SFX',
    56: 'Start Smash Charge',
    57: 'Set Smash Vibration',
    58: 'Create Wind Effect',
}

# Scalar, named fields from ftCo_DatAttrs. Unknown/nested blocks are omitted
# deliberately so the editor does not pretend to understand them.


# Validated global fighter mechanics from ftCommonData in PlCo.dat.
# The offsets below are relative to the ftCommonData table reached through
# ftLoadCommonData[0]. They are taken from src/melee/ft/types.h and the
# corresponding behavior in ftCo_EscapeAir.c.
GLOBAL_FIGHTER_ATTRS = [
    # Controller / input thresholds
    ('horizontal_stick_deadzone', 0x000, 'float'),
    ('vertical_stick_deadzone', 0x004, 'float'),
    ('shield_press_threshold', 0x018, 'float'),
    ('walk_stick_threshold', 0x024, 'float'),
    ('dash_smash_stick_threshold', 0x03C, 'float'),
    ('dash_smash_window', 0x040, 'int'),
    ('tap_jump_threshold', 0x070, 'float'),
    ('tap_jump_window', 0x074, 'int'),
    ('tap_jump_release_threshold', 0x07C, 'float'),
    ('relaxed_tap_jump_threshold', 0x080, 'float'),

    # Knockback / movement common mechanics
    ('kb_min', 0x104, 'float'),
    ('kb_squat_mul', 0x124, 'float'),
    ('max_grounded_kb_on_landing', 0x164, 'float'),
    ('aerial_friction_oob', 0x1FC, 'float'),
    ('knockback_frame_decay', 0x204, 'float'),

    # Shield / defensive common mechanics
    ('start_shield_health', 0x260, 'float'),
    ('powershield_input_window', 0x2A0, 'int'),

    # Air dodge
    ('escapeair_deadzone_x', 0x32C, 'float'),
    ('escapeair_deadzone_y', 0x330, 'float'),
    ('escapeair_timer', 0x334, 'int'),
    ('escapeair_force', 0x338, 'float'),
    ('escapeair_decay', 0x33C, 'float'),

    # Grab / shield knockback
    ('grab_timer_decrement', 0x3A4, 'float'),
    ('shield_knockback_frame_decay', 0x3E8, 'float'),
    ('shield_ground_friction_multiplier', 0x3EC, 'float'),

    # Ledge / DI
    ('teeter_walk_threshold', 0x474, 'float'),
    ('ledge_cooldown', 0x498, 'int'),
    ('sdi_min_stick_mag', 0x4B0, 'float'),
    ('sdi_stick_window', 0x4B4, 'int'),
    ('sdi_pos_scale', 0x4B8, 'float'),

    # Global status / modifier mechanics
    ('metal_armor', 0x6F0, 'float'),
    ('kb_ice_mul', 0x718, 'float'),
    ('passive_wall_vel_y_base', 0x778, 'float'),
    ('damageice_gravity_mult', 0x77C, 'float'),
    ('kb_smashcharge_mul', 0x7C4, 'float'),
    ('hit_weight_mul', 0x7D4, 'float'),
]

COMMON_ATTRS = [
    ('walk_accel_mul', 0x000, 'float'),
    ('walk_accel_base', 0x004, 'float'),
    ('walk_max_vel', 0x008, 'float'),
    ('slow_walk_max', 0x00C, 'float'),
    ('mid_walk_point', 0x010, 'float'),
    ('fast_walk_min', 0x014, 'float'),
    ('ground_friction', 0x018, 'float'),
    ('dash_initial_velocity', 0x01C, 'float'),
    ('dash_accel_mul', 0x020, 'float'),
    ('dash_accel_base', 0x024, 'float'),
    ('dash_max_velocity', 0x028, 'float'),
    ('run_animation_scaling', 0x02C, 'float'),
    ('max_run_brake_frames', 0x030, 'float'),
    ('ground_max_horizontal_velocity', 0x034, 'float'),
    ('jump_startup_time', 0x038, 'float'),
    ('jump_h_initial_velocity', 0x03C, 'float'),
    ('jump_v_initial_velocity', 0x040, 'float'),
    ('ground_to_air_jump_momentum_multiplier', 0x044, 'float'),
    ('jump_h_max_velocity', 0x048, 'float'),
    ('hop_v_initial_velocity', 0x04C, 'float'),
    ('air_jump_v_multiplier', 0x050, 'float'),
    ('air_jump_h_multiplier', 0x054, 'float'),
    ('max_jumps', 0x058, 'int'),
    ('gravity', 0x05C, 'float'),
    ('terminal_velocity', 0x060, 'float'),
    ('air_drift_stick_mul', 0x064, 'float'),
    ('aerial_drift_base', 0x068, 'float'),
    ('air_drift_max', 0x06C, 'float'),
    ('aerial_friction', 0x070, 'float'),
    ('fast_fall_velocity', 0x074, 'float'),
    ('air_max_horizontal_velocity', 0x078, 'float'),
    ('jab_2_input_window', 0x07C, 'float'),
    ('jab_3_input_window', 0x080, 'float'),
    ('standing_turn_frames', 0x084, 'float'),
    ('weight', 0x088, 'float'),
    ('model_scaling', 0x08C, 'float'),
    ('initial_shield_size', 0x090, 'float'),
    ('shield_break_initial_velocity', 0x094, 'float'),
    ('rapid_jab_window', 0x098, 'int'),
    ('clank_animation_length', 0x09C, 'float'),
    ('hit_spark_variant', 0x0A0, 'int'),
    ('ledge_jump_horizontal_velocity', 0x0A8, 'float'),
    ('ledge_jump_vertical_velocity', 0x0AC, 'float'),
    ('item_throw_velocity_multiplier', 0x0B0, 'float'),
    ('heavy_throw_velocity_multiplier', 0x0B4, 'float'),
    ('specials_ground_speed_retention', 0x0B8, 'float'),
    ('kirby_b_star_damage', 0x0E0, 'float'),
    ('normal_landing_lag', 0x0E4, 'float'),
    ('landingairn_lag', 0x0E8, 'float'),
    ('landingairf_lag', 0x0EC, 'float'),
    ('landingairb_lag', 0x0F0, 'float'),
    ('landingairhi_lag', 0x0F4, 'float'),
    ('landingairlw_lag', 0x0F8, 'float'),
    ('name_tag_height', 0x0FC, 'float'),
    ('passivewall_vel_x', 0x100, 'float'),
    ('wall_jump_horizontal_velocity', 0x104, 'float'),
    ('wall_jump_vertical_velocity', 0x108, 'float'),
    ('passiveceil_vel_x', 0x10C, 'float'),
    ('trophy_scale', 0x110, 'float'),
    ('screw_attack_launch_velocity', 0x140, 'float'),
    ('wall_jump_min_approach_speed', 0x148, 'float'),
    ('damageice_ice_size', 0x14C, 'float'),
    ('damageicejump_vel_y', 0x158, 'float'),
    ('damageicejump_vel_x_mult', 0x15C, 'float'),
    ('respawn_platform_scale', 0x160, 'float'),
    ('warp_star_hitbox_scale', 0x164, 'float'),
    ('camera_zoom_target_bone', 0x16C, 'int'),
]


def _u32(buf: bytes | bytearray, off: int) -> int:
    return BE_U32.unpack_from(buf, off)[0]


def _i32(buf: bytes | bytearray, off: int) -> int:
    return BE_I32.unpack_from(buf, off)[0]


def _f32(buf: bytes | bytearray, off: int) -> float:
    return BE_F32.unpack_from(buf, off)[0]


def _s16(v: int) -> int:
    return v - 0x10000 if v & 0x8000 else v


def _s8(v: int) -> int:
    return v - 0x100 if v & 0x80 else v


def _set_bits(word: int, shift: int, bits: int, value: int) -> int:
    mask = ((1 << bits) - 1) << shift
    return (word & ~mask) | ((int(value) & ((1 << bits) - 1)) << shift)


def _align(value: int, alignment: int = 0x20) -> int:
    return (int(value) + alignment - 1) & ~(alignment - 1)


def _encode_wait_varint(value: int) -> bytes:
    """Encode HSD FObj's unsigned 7-bit continuation integer."""
    value = int(value)
    if value < 0:
        raise ValueError('Animation wait must be non-negative')
    out = bytearray()
    while True:
        b = value & 0x7F
        value >>= 7
        if value:
            out.append(b | 0x80)
        else:
            out.append(b)
            return bytes(out)


def _decode_wait_varint(buf: bytes, pos: int) -> tuple[int, int]:
    value = 0
    shift = 0
    while True:
        if pos >= len(buf):
            raise ValueError('Truncated FObj wait value')
        b = buf[pos]
        pos += 1
        value |= (b & 0x7F) << shift
        if not (b & 0x80):
            return value, pos
        shift += 7
        if shift > 28:
            raise ValueError('FObj wait value is unreasonably large')


def _frac_storage_size(frac: int) -> int:
    mode = frac & 0xE0
    if mode == 0x00:
        return 4
    if mode in (0x20, 0x40):
        return 2
    if mode in (0x60, 0x80):
        return 1
    raise ValueError(f'Unsupported FObj fraction descriptor 0x{frac:02X}')


def _parse_fobj_pack_header(buf: bytes, pos: int) -> tuple[int, int, int, bytes]:
    start = pos
    if pos >= len(buf):
        raise ValueError('Missing FObj pack header')
    d = buf[pos]
    pos += 1
    opcode = d & 0x0F
    count = ((d >> 4) & 0x7) + 1
    shift = 3
    if d & 0x80:
        while True:
            if pos >= len(buf):
                raise ValueError('Truncated FObj pack count')
            d = buf[pos]
            pos += 1
            count += (d & 0x7F) << shift
            shift += 7
            if not (d & 0x80):
                break
    return opcode, count, pos, buf[start:pos]


def _retime_fobj_stream(stream: bytes, frac_value: int, frac_slope: int,
                         time_factor: float) -> tuple[bytes, int, int]:
    """Scale the temporal waits in one FigaTrack stream.

    The decompiled HSD_FObj interpreter proves that opcodes 1,2,3,4,6 are
    followed by a variable-length wait, while opcode 5 (slope-only) is not.
    Value/slope samples are deliberately left byte-identical; only the time
    domain is rescaled. This is the same animation curve evaluated over a new
    keyframe schedule, without inventing or deleting pose samples.
    """
    pos = 0
    out = bytearray()
    waits_changed = 0
    waits_total = 0
    while pos < len(stream):
        opcode, count, pos, header = _parse_fobj_pack_header(stream, pos)
        if opcode not in (1, 2, 3, 4, 5, 6):
            raise ValueError(f'Unsupported FObj interpolation opcode {opcode}')
        out += header
        for _ in range(count):
            if opcode in (1, 2, 3, 4, 6):
                n = _frac_storage_size(frac_value)
                if pos + n > len(stream):
                    raise ValueError('Truncated FObj value sample')
                out += stream[pos:pos+n]
                pos += n
            if opcode in (4, 5):
                n = _frac_storage_size(frac_slope)
                if pos + n > len(stream):
                    raise ValueError('Truncated FObj slope sample')
                out += stream[pos:pos+n]
                pos += n
            if opcode != 5:
                wait, pos = _decode_wait_varint(stream, pos)
                new_wait = max(0, int(math.floor(wait * time_factor + 0.5)))
                out += _encode_wait_varint(new_wait)
                waits_total += 1
                if new_wait != wait:
                    waits_changed += 1
    return bytes(out), waits_changed, waits_total


@dataclass
class ArchiveHeader:
    file_size: int
    data_size: int
    nb_reloc: int
    nb_public: int
    nb_extern: int
    version: str


@dataclass
class PublicSymbol:
    offset: int
    name: str


@dataclass
class AnimEntry:
    index: int
    symbol: str
    anim_archive_offset: int
    anim_archive_size: int
    script_offset: int
    flags: int
    loaded_ptr: int

    @property
    def action_name(self) -> str:
        if '_ACTION_' in self.symbol:
            return self.symbol.split('_ACTION_', 1)[1].rsplit('_figatree', 1)[0]
        return self.symbol or f'Animation {self.index}'


class HSDArchive:
    def __init__(self, raw: bytes | bytearray):
        self.raw = raw if isinstance(raw, bytearray) else bytearray(raw)
        if len(self.raw) < 0x20:
            raise ValueError('File is too small to be an HSD archive')
        file_size, data_size, nr, np, ne = struct.unpack_from('>5I', self.raw, 0)
        version = bytes(self.raw[0x14:0x18]).decode('ascii', 'replace')
        if file_size != len(self.raw):
            raise ValueError(f'HSD header file_size={file_size} but actual size={len(self.raw)}')
        self.header = ArchiveHeader(file_size, data_size, nr, np, ne, version)
        self.data_start = 0x20
        self.data_end = self.data_start + data_size
        off = self.data_end
        self.relocations = [_u32(self.raw, off + i * 4) for i in range(nr)]
        off += nr * 4
        public_raw = [struct.unpack_from('>II', self.raw, off + i * 8) for i in range(np)]
        off += np * 8
        extern_raw = [struct.unpack_from('>II', self.raw, off + i * 8) for i in range(ne)]
        off += ne * 8
        self.symbol_table_offset = off
        self._symbol_bytes = bytes(self.raw[off:])
        self.publics = [PublicSymbol(o, self.cstring(s)) for o, s in public_raw]
        self.externs = [(o, self.cstring(s)) for o, s in extern_raw]

    @classmethod
    def from_file(cls, path: str | os.PathLike[str]) -> 'HSDArchive':
        return cls(Path(path).read_bytes())

    def cstring(self, symbol_off: int) -> str:
        if symbol_off < 0 or symbol_off >= len(self._symbol_bytes):
            return ''
        end = self._symbol_bytes.find(b'\0', symbol_off)
        if end < 0:
            end = len(self._symbol_bytes)
        return self._symbol_bytes[symbol_off:end].decode('ascii', 'replace')

    def data_u32(self, off: int) -> int:
        return _u32(self.raw, self.data_start + off)

    def data_i32(self, off: int) -> int:
        return _i32(self.raw, self.data_start + off)

    def data_f32(self, off: int) -> float:
        return _f32(self.raw, self.data_start + off)

    def data_bytes(self, off: int, size: int) -> bytes:
        return bytes(self.raw[self.data_start + off:self.data_start + off + size])

    def write_data_u32(self, off: int, value: int) -> None:
        BE_U32.pack_into(self.raw, self.data_start + off, value & 0xFFFFFFFF)

    def write_data_i32(self, off: int, value: int) -> None:
        BE_I32.pack_into(self.raw, self.data_start + off, int(value))

    def write_data_f32(self, off: int, value: float) -> None:
        BE_F32.pack_into(self.raw, self.data_start + off, float(value))

    def write_file(self, path: str | os.PathLike[str]) -> None:
        Path(path).write_bytes(self.raw)

    def replace_data_ranges(self, replacements: list[tuple[int, int, bytes]],
                            align_to: int = 0x20,
                            new_relocation_offsets: Iterable[int] = (),
                            interior_target_map: dict[int, int] | None = None) -> dict[str, Any]:
        """Rebuild the archive after replacing one or more data-section ranges.

        Offsets are relative to the HSD data section. Relocation locations,
        relocated pointer targets, public roots, and external-reference chains
        are shifted consistently. This is the primitive Phase 12 uses for
        variable-size fighter scripts and variable-size embedded AJ archives.

        A relocated pointer may target the *start* of a replaced range; that is
        mapped to the replacement's start. Pointers into the middle of replaced
        bytes are rejected because silently retargeting them would be unsafe.
        """
        if not replacements:
            return {'old_size': len(self.raw), 'new_size': len(self.raw), 'delta': 0}
        repl = sorted((int(s), int(n), bytes(b)) for s, n, b in replacements)
        last_end = 0
        for start, old_len, new_bytes in repl:
            if start < 0 or old_len < 0 or start + old_len > self.header.data_size:
                raise ValueError('HSD replacement range is outside the data section')
            if start < last_end:
                raise ValueError('HSD replacement ranges overlap')
            last_end = start + old_len

        old_raw = bytes(self.raw)
        old_data = old_raw[self.data_start:self.data_end]
        mapping_rows: list[tuple[int, int, int, int, int]] = []
        pieces: list[bytes] = []
        cursor = 0
        new_cursor = 0
        for start, old_len, new_bytes in repl:
            pieces.append(old_data[cursor:start])
            new_cursor += start - cursor
            mapping_rows.append((start, start + old_len, new_cursor, len(new_bytes), old_len))
            pieces.append(new_bytes)
            new_cursor += len(new_bytes)
            cursor = start + old_len
        pieces.append(old_data[cursor:])
        new_data = bytearray(b''.join(pieces))

        def map_offset(value: int, allow_replacement_start: bool = True) -> int:
            delta = 0
            for start, end, new_start, new_len, old_len in mapping_rows:
                if value < start:
                    return value + delta
                if start <= value < end:
                    if interior_target_map is not None and value in interior_target_map:
                        return int(interior_target_map[value])
                    if allow_replacement_start and value == start:
                        return new_start
                    raise ValueError(
                        f'Pointer/offset 0x{value:X} lands inside replaced HSD data '
                        f'0x{start:X}..0x{end:X}'
                    )
                delta += new_len - old_len
            return value + delta

        # Preserve raw symbol offsets from metadata; HSDArchive.publics/externs
        # intentionally resolve those offsets to names and therefore lose them.
        meta = self.data_end
        old_reloc = [struct.unpack_from('>I', old_raw, meta + i * 4)[0]
                     for i in range(self.header.nb_reloc)]
        meta += self.header.nb_reloc * 4
        public_pairs = [struct.unpack_from('>II', old_raw, meta + i * 8)
                        for i in range(self.header.nb_public)]
        meta += self.header.nb_public * 8
        extern_pairs = [struct.unpack_from('>II', old_raw, meta + i * 8)
                        for i in range(self.header.nb_extern)]
        meta += self.header.nb_extern * 8
        symbol_bytes = old_raw[meta:]

        new_reloc: list[int] = []
        for location in old_reloc:
            try:
                new_location = map_offset(location, allow_replacement_start=False)
            except ValueError:
                # A relocation word owned by the replaced region is removed with
                # that region. The script assembler currently refuses pointer-
                # bearing control-flow commands, so it never needs to add one.
                continue
            target = struct.unpack_from('>I', old_data, location)[0]
            new_target = 0 if target == 0 else map_offset(target, True)
            struct.pack_into('>I', new_data, new_location, new_target)
            new_reloc.append(new_location)

        # External references are linked lists whose nodes live in the data
        # section and contain the next node's data-relative offset or 0xFFFFFFFF.
        for location, _sym in extern_pairs:
            node = location
            seen: set[int] = set()
            while node != 0xFFFFFFFF and 0 <= node < self.header.data_size and node not in seen:
                seen.add(node)
                new_node = map_offset(node, False)
                nxt = struct.unpack_from('>I', old_data, node)[0]
                new_next = 0xFFFFFFFF if nxt == 0xFFFFFFFF else map_offset(nxt, False)
                struct.pack_into('>I', new_data, new_node, new_next)
                if nxt == 0xFFFFFFFF:
                    break
                node = nxt

        # Structural script assembly can introduce relocated pointer words
        # (Subroutine/Goto). Their locations are supplied in rebuilt-data
        # coordinates after the replacement splice. Existing relocation words
        # owned by replaced ranges were removed above.
        for location in new_relocation_offsets:
            location = int(location)
            if location < 0 or location + 4 > len(new_data):
                raise ValueError(f'New relocation 0x{location:X} is outside rebuilt HSD data')
            new_reloc.append(location)
        new_reloc = sorted(set(new_reloc))

        reloc_bytes = b''.join(struct.pack('>I', x) for x in new_reloc)
        public_bytes = b''.join(
            struct.pack('>II', map_offset(offset, True), symbol)
            for offset, symbol in public_pairs
        )
        extern_bytes = b''.join(
            struct.pack('>II', map_offset(offset, False), symbol)
            for offset, symbol in extern_pairs
        )

        header = bytearray(old_raw[:0x20])
        rebuilt = header + new_data + reloc_bytes + public_bytes + extern_bytes + symbol_bytes
        if align_to and len(rebuilt) != len(old_raw):
            rebuilt += b'\0' * ((-len(rebuilt)) % int(align_to))
        struct.pack_into('>I', rebuilt, 0x00, len(rebuilt))
        struct.pack_into('>I', rebuilt, 0x04, len(new_data))
        struct.pack_into('>I', rebuilt, 0x08, len(new_reloc))

        old_size = len(self.raw)
        self.__init__(rebuilt)
        return {
            'old_size': old_size,
            'new_size': len(self.raw),
            'delta': len(self.raw) - old_size,
            'map_offset': map_offset,
        }


def rename_hsd_public_symbol(raw: bytes | bytearray, new_name: str, index: int = 0) -> bytes:
    """Append a public-symbol name and retarget one HSD public entry to it.

    Symbol strings live after relocation/public/external metadata, so appending
    a new NUL-terminated name does not move data-section pointers. This is used
    by same-fighter full-move cloning so a copied FigaTree remains loadable
    through the destination action's existing symbol name.
    """
    arc = HSDArchive(raw)
    index = int(index)
    if not 0 <= index < arc.header.nb_public:
        raise IndexError('HSD public symbol index is out of range')
    encoded = str(new_name).encode('ascii') + b'\0'
    old = bytes(arc.raw)
    symbol_offset = len(arc._symbol_bytes)
    out = bytearray(old + encoded)
    public_table = arc.data_end + arc.header.nb_reloc * 4
    struct.pack_into('>I', out, public_table + index * 8 + 4, symbol_offset)
    struct.pack_into('>I', out, 0x00, len(out))
    check = HSDArchive(out)
    if check.publics[index].name != new_name:
        raise ValueError('HSD public-symbol rename verification failed')
    return bytes(out)


def analyze_figatree_archive(raw: bytes | bytearray) -> dict[str, Any]:
    """Inspect one embedded fighter AJ HSD archive / FigaTree."""
    arc = HSDArchive(raw)
    if len(arc.publics) != 1:
        raise ValueError(f'Expected one FigaTree public root, found {len(arc.publics)}')
    root = arc.publics[0].offset
    if root + 0x14 > arc.header.data_size:
        raise ValueError('FigaTree root is outside the HSD data section')
    tree_type, flags, frames, nodes_off, tracks_off = struct.unpack(
        '>IIfII', arc.data_bytes(root, 0x14)
    )
    if not (0 <= nodes_off < arc.header.data_size and 0 <= tracks_off < arc.header.data_size):
        raise ValueError('FigaTree nodes/tracks pointer is outside the HSD data section')
    nodes: list[int] = []
    cursor = nodes_off
    while cursor < arc.header.data_size and len(nodes) < 0x400:
        b = arc.data_bytes(cursor, 1)[0]
        value = b - 0x100 if b & 0x80 else b
        nodes.append(value)
        cursor += 1
        if value == -1:
            break
    if not nodes or nodes[-1] != -1:
        raise ValueError('FigaTree node list does not terminate with -1')
    track_count = sum(x for x in nodes if x >= 0)
    if tracks_off + track_count * 0x0C > arc.header.data_size:
        raise ValueError('FigaTree track table extends beyond the HSD data section')
    tracks = []
    waits = 0
    for i in range(track_count):
        off = tracks_off + i * 0x0C
        length, startframe, obj_type, frac_value, frac_slope, pad, ad_head = struct.unpack(
            '>HHBBBBI', arc.data_bytes(off, 0x0C)
        )
        if ad_head + length > arc.header.data_size:
            raise ValueError(f'FigaTrack {i} animation data extends beyond the HSD data section')
        # Parse once to prove the command stream is understood.
        _, _changed, count = _retime_fobj_stream(arc.data_bytes(ad_head, length), frac_value, frac_slope, 1.0)
        waits += count
        tracks.append({
            'index': i, 'offset': off, 'length': length, 'startframe': startframe,
            'obj_type': obj_type, 'frac_value': frac_value, 'frac_slope': frac_slope,
            'pad': pad, 'ad_head': ad_head,
        })
    return {
        'symbol': arc.publics[0].name,
        'root_offset': root,
        'type': tree_type,
        'flags': flags,
        'frames': float(frames),
        'nodes_offset': nodes_off,
        'tracks_offset': tracks_off,
        'node_count': len(nodes) - 1,
        'track_count': track_count,
        'wait_count': waits,
        'tracks': tracks,
    }


def retime_figatree_archive(raw: bytes | bytearray, time_factor: float) -> tuple[bytes, dict[str, Any]]:
    """Rescale a fighter FigaTree's actual keyframe time domain.

    Unlike fighter-script timer scaling, this edits the embedded animation
    archive itself: FigaTree.frames, every track startframe, and every encoded
    FObj wait. Pose/value samples stay byte-identical. Variable-length wait
    growth is handled by rebuilding HSD offsets/relocations safely.
    """
    time_factor = float(time_factor)
    if not math.isfinite(time_factor) or time_factor <= 0:
        raise ValueError('Animation time factor must be finite and greater than zero')
    arc = HSDArchive(raw)
    info = analyze_figatree_archive(arc.raw)
    tracks = info['tracks']

    transformed: dict[tuple[int, int], bytes] = {}
    waits_changed = 0
    for tr in tracks:
        key = (tr['ad_head'], tr['length'])
        original = arc.data_bytes(tr['ad_head'], tr['length'])
        new_stream, changed, _total = _retime_fobj_stream(
            original, tr['frac_value'], tr['frac_slope'], time_factor
        )
        waits_changed += changed
        prior = transformed.get(key)
        if prior is not None and prior != new_stream:
            raise ValueError('Shared FObj stream has inconsistent track descriptors')
        transformed[key] = new_stream

    ranges = sorted((start, length) for start, length in transformed)
    for (start, length), (next_start, _next_len) in zip(ranges, ranges[1:]):
        if start + length > next_start:
            raise ValueError('Overlapping FObj animation-data streams are not safe to rebuild')

    replacements = [
        (start, length, transformed[(start, length)])
        for start, length in ranges
        if transformed[(start, length)] != arc.data_bytes(start, length)
    ]
    rebuild = arc.replace_data_ranges(replacements)
    map_offset = rebuild.get('map_offset', lambda x, *_: x)

    new_root = map_offset(info['root_offset'], True)
    old_frames = info['frames']
    new_frames = max(0.0, old_frames * time_factor)
    arc.write_data_f32(new_root + 0x08, new_frames)

    # Track table can shift when any variable-length wait changes. Re-address
    # each original entry through the archive rebuild's offset map.
    for tr in tracks:
        new_track_off = map_offset(tr['offset'], False)
        new_len = len(transformed[(tr['ad_head'], tr['length'])])
        new_start = max(0, min(0xFFFF, int(math.floor(tr['startframe'] * time_factor + 0.5))))
        struct.pack_into('>H', arc.raw, arc.data_start + new_track_off + 0x00, new_len)
        struct.pack_into('>H', arc.raw, arc.data_start + new_track_off + 0x02, new_start)

    # Reparse after writing lengths/startframes so any structural mistake fails
    # here rather than reaching the user's Working/ folder.
    verified = analyze_figatree_archive(arc.raw)
    return bytes(arc.raw), {
        'symbol': info['symbol'],
        'old_frames': old_frames,
        'new_frames': verified['frames'],
        'track_count': verified['track_count'],
        'wait_count': info['wait_count'],
        'waits_changed': waits_changed,
        'old_size': len(raw),
        'new_size': len(arc.raw),
        'size_delta': len(arc.raw) - len(raw),
        'time_factor': time_factor,
    }


class CommonFighterDAT:
    """Read/edit the global fighter common-data archive PlCo.dat.

    ftLoadCommonData is an array of pointers. fighter.c assigns p_ftCommonData
    from element zero, so global mechanics are addressed relative to that table.
    Current writes are conservative in-place scalar edits only.
    """

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)
        self.archive = HSDArchive.from_file(path)
        roots = [p for p in self.archive.publics if p.name == 'ftLoadCommonData']
        if len(roots) != 1:
            raise ValueError(f'Expected ftLoadCommonData in PlCo.dat, found {[p.name for p in self.archive.publics]}')
        self.root = roots[0]
        self.common_data_offset = self.archive.data_u32(self.root.offset)
        if not self.common_data_offset or self.common_data_offset >= self.archive.header.data_size:
            raise ValueError('ftLoadCommonData[0] does not point to a valid ftCommonData table')

    def attributes(self) -> dict[str, dict[str, Any]]:
        out = {}
        for name, off, typ in GLOBAL_FIGHTER_ATTRS:
            if typ == 'float':
                val = self.archive.data_f32(self.common_data_offset + off)
            else:
                val = self.archive.data_i32(self.common_data_offset + off)
            out[name] = {'offset': off, 'type': typ, 'value': val}
        return out

    def set_attribute(self, name: str, value: float | int) -> None:
        spec = next((x for x in GLOBAL_FIGHTER_ATTRS if x[0] == name), None)
        if spec is None:
            raise KeyError(name)
        _, off, typ = spec
        if typ == 'float':
            self.archive.write_data_f32(self.common_data_offset + off, float(value))
        else:
            self.archive.write_data_i32(self.common_data_offset + off, int(value))

    def save_as(self, path: str | os.PathLike[str]) -> None:
        self.archive.write_file(path)


class FighterDAT:
    """Read/edit the standard fighter DAT (PlFx.dat, PlMr.dat, etc.).

    Scalar attributes/hitboxes support conservative in-place writes. Phase 12+
    can also rebuild HSD data for resized scripts, and Phase 13 relocates
    Subroutine/Goto pointer words through a graph-aware script assembler.
    """

    def __init__(self, path: str | os.PathLike[str]):
        self.path = Path(path)
        self.archive = HSDArchive.from_file(path)
        roots = [p for p in self.archive.publics if p.name.startswith('ftData') and 'Copy' not in p.name]
        if len(roots) != 1:
            raise ValueError(f'Expected one standard ftData public symbol, found {[p.name for p in roots]}')
        self.root = roots[0]
        r = self.root.offset
        self.common_attrs_offset = self.archive.data_u32(r + 0x00)
        self.ext_attrs_offset = self.archive.data_u32(r + 0x04)
        self.anim_table_offset = self.archive.data_u32(r + 0x0C)
        self.demo_anim_table_offset = self.archive.data_u32(r + 0x14)
        if not self.anim_table_offset or not self.demo_anim_table_offset:
            raise ValueError('ftData animation table pointers are null')
        span = self.demo_anim_table_offset - self.anim_table_offset
        if span <= 0 or span % 0x18:
            raise ValueError(f'Animation table span is not a multiple of 0x18: 0x{span:X}')
        self.anim_count = span // 0x18
        self.animations = self._read_anim_entries()

    def _refresh_from_archive(self) -> None:
        roots = [p for p in self.archive.publics if p.name.startswith('ftData') and 'Copy' not in p.name]
        if len(roots) != 1:
            raise ValueError(f'Expected one standard ftData public symbol, found {[p.name for p in roots]}')
        self.root = roots[0]
        r = self.root.offset
        self.common_attrs_offset = self.archive.data_u32(r + 0x00)
        self.ext_attrs_offset = self.archive.data_u32(r + 0x04)
        self.anim_table_offset = self.archive.data_u32(r + 0x0C)
        self.demo_anim_table_offset = self.archive.data_u32(r + 0x14)
        span = self.demo_anim_table_offset - self.anim_table_offset
        if span <= 0 or span % 0x18:
            raise ValueError(f'Animation table span is not a multiple of 0x18: 0x{span:X}')
        self.anim_count = span // 0x18
        self.animations = self._read_anim_entries()

    @property
    def fighter_name(self) -> str:
        return self.root.name.removeprefix('ftData')

    def _data_cstring(self, ptr: int) -> str:
        if not ptr or ptr >= self.archive.header.data_size:
            return ''
        raw = self.archive.raw
        start = self.archive.data_start + ptr
        end = raw.find(0, start, self.archive.data_end)
        if end < 0:
            return ''
        return bytes(raw[start:end]).decode('ascii', 'replace')

    def _read_anim_entries(self) -> list[AnimEntry]:
        out = []
        for i in range(self.anim_count):
            off = self.anim_table_offset + i * 0x18
            vals = struct.unpack('>6I', self.archive.data_bytes(off, 0x18))
            out.append(AnimEntry(i, self._data_cstring(vals[0]), vals[1], vals[2], vals[3], vals[4], vals[5]))
        return out

    def common_attributes(self) -> dict[str, dict[str, Any]]:
        out: dict[str, dict[str, Any]] = {}
        for name, off, typ in COMMON_ATTRS:
            if typ == 'float':
                val = self.archive.data_f32(self.common_attrs_offset + off)
            else:
                val = self.archive.data_i32(self.common_attrs_offset + off)
            out[name] = {'offset': off, 'type': typ, 'value': val}
        return out

    def character_attributes(self) -> dict[str, dict[str, Any]]:
        schema = CHARACTER_ATTR_SCHEMAS.get(self.fighter_name, [])
        out: dict[str, dict[str, Any]] = {}
        for name, off, typ in schema:
            if typ == 'float':
                val = self.archive.data_f32(self.ext_attrs_offset + off)
            else:
                val = self.archive.data_i32(self.ext_attrs_offset + off)
            out[name] = {'offset': off, 'type': typ, 'value': val}
        return out

    def set_character_attribute(self, name: str, value: float | int) -> None:
        schema = CHARACTER_ATTR_SCHEMAS.get(self.fighter_name, [])
        spec = next((x for x in schema if x[0] == name), None)
        if spec is None:
            raise KeyError(f'No validated {self.fighter_name} character-specific field named {name}')
        _, off, typ = spec
        if typ == 'float':
            self.archive.write_data_f32(self.ext_attrs_offset + off, float(value))
        else:
            self.archive.write_data_i32(self.ext_attrs_offset + off, int(value))

    def set_common_attribute(self, name: str, value: float | int) -> None:
        spec = next((x for x in COMMON_ATTRS if x[0] == name), None)
        if spec is None:
            raise KeyError(name)
        _, off, typ = spec
        if typ == 'float':
            self.archive.write_data_f32(self.common_attrs_offset + off, float(value))
        else:
            self.archive.write_data_i32(self.common_attrs_offset + off, int(value))

    def find_moves(self, text: str = '') -> list[AnimEntry]:
        q = text.lower().strip()
        return [a for a in self.animations if a.symbol and (not q or q in a.action_name.lower() or q in a.symbol.lower())]

    def _decode_event_at(self, off: int, frame: float = 0.0) -> dict[str, Any]:
        """Decode exactly one fighter command from a data-relative offset."""
        off = int(off)
        if off < 0 or off + 4 > self.archive.header.data_size:
            raise ValueError(f'Fighter command offset 0x{off:X} is outside HSD data')
        word = self.archive.data_u32(off)
        opcode = word >> 26
        try:
            nwords = _fighter_event_word_length(opcode)
        except ValueError:
            return {'offset': off, 'opcode': opcode, 'name': 'Invalid/Unknown',
                    'words': [word], 'frame': frame, 'byte_size': 4}
        if off + nwords * 4 > self.archive.header.data_size:
            raise ValueError(f'Truncated {EVENT_NAMES.get(opcode, opcode)} at 0x{off:X}')
        words = [self.archive.data_u32(off + j * 4) for j in range(nwords)]
        ev: dict[str, Any] = {
            'offset': off, 'opcode': opcode,
            'name': EVENT_NAMES.get(opcode, f'Opcode {opcode}'),
            'words': words, 'frame': float(frame), 'byte_size': nwords * 4,
        }
        if opcode in (1, 2):
            value = word & 0x03FFFFFF
            ev['timer_value'] = value
            ev['frame_after'] = float(frame + value if opcode == 1 else value)
        elif opcode == 3:
            ev['event_details'] = {'loop_count': word & 0x03FFFFFF}
        elif opcode in (5, 7):
            target = words[1]
            ev['pointer_target'] = target
            ev['pointer_location'] = off + 4
            ev['pointer_relocated'] = (off + 4) in self.archive.relocations
            ev['null_pointer_target'] = (target == 0)
            ev['event_details'] = {
                'target_offset': target,
                'relocated_pointer_word': ev['pointer_relocated'],
            }
        elif opcode == 11 and len(words) == 5:
            ev['hitbox'] = decode_hitbox(words)
        elif opcode == 12:
            ev['hitbox_adjust'] = {'id': (word >> 23) & 7, 'damage': word & 0x7FFFFF}
        elif opcode == 13:
            ev['hitbox_adjust'] = {'id': (word >> 23) & 7, 'size': (word & 0x7FFFFF) / 256.0}
        elif opcode == 15:
            ev['hitbox_id'] = word & 0x03FFFFFF
        elif opcode == 14:
            ev['event_details'] = {'hitbox_id': (word >> 2) & 0xFFFFFF,
                                   'flag_selector': (word >> 1) & 1,
                                   'enabled': bool(word & 1)}
        elif opcode == 19:
            ev['event_details'] = {'variable': (word >> 24) & 0x3, 'value': word & 0xFFFFFF}
        elif opcode in (20, 21, 22, 24):
            ev['event_details'] = {'value': word & 0x03FFFFFF}
        elif opcode == 25:
            state = word & 0x03FFFFFF
            ev['event_details'] = {'state': state, 'meaning': {0:'engine state 0',1:'engine state 1',2:'engine state 2'}.get(state,'unknown')}
        elif opcode == 28:
            ev['event_details'] = {'bone': (word >> 18) & 0xFF, 'hurtbox_state': word & 0x3FFFF}
        elif opcode == 29:
            ev['event_details'] = {'disabled': bool(word & 0x03FFFFFF)}
        elif opcode == 30:
            ev['event_details'] = {'state': word & 0x03FFFFFF}
        elif opcode == 31:
            ev['event_details'] = {'model_index': (word >> 19) & 0x7F, 'model_value_raw': word & 0x7FFFF}
        elif opcode in (36, 37):
            ev['event_details'] = {'visible': bool(word & 0x03FFFFFF), 'raw_value': word & 0x03FFFFFF}
        elif opcode == 40:
            ev['event_details'] = {'two_parts': bool((word >> 25) & 1), 'part_1': (word >> 18) & 0x7F,
                                   'part_2': (word >> 11) & 0x7F, 'frame': word & 0x7FF}
        elif opcode == 41:
            ev['event_details'] = {'part': (word >> 19) & 0x7F, 'animation': (word >> 12) & 0x7F,
                                   'blend_raw': word & 0xFFF}
        elif opcode == 42:
            ev['event_details'] = {'parasol_state': (word >> 13) & 0x1FFF, 'speed_divisor_raw': word & 0x1FFF}
        elif opcode == 43:
            ev['event_details'] = {'all_fighters': bool((word >> 25) & 1), 'rumble_id': (word >> 13) & 0xFFF,
                                   'duration_or_parameter': word & 0x1FFF}
        elif opcode == 44:
            ev['event_details'] = {'rumble_id': word & 0x03FFFFFF}
        elif opcode == 45:
            ev['event_details'] = {'mode': (word >> 24) & 0x3, 'animation_or_state': (word >> 14) & 0x3FF,
                                   'parameter_raw': word & 0x3FFF}
        elif opcode == 46:
            ev['event_details'] = {'color_animation_id': (word >> 18) & 0xFF, 'persistent': bool(word & 0x3FFFF)}
        elif opcode == 47:
            ev['event_details'] = {'color_animation_id': (word >> 18) & 0xFF}
        elif opcode == 48:
            ev['event_details'] = {'enabled': bool(word & 0x03FFFFFF), 'raw_value': word & 0x03FFFFFF}
        elif opcode == 49:
            raw = word & 0x03FFFFFF
            ev['event_details'] = {'flag': bool((raw >> 25) & 1), 'state_raw': raw & 0x1FFFFFF}
        elif opcode == 50:
            ev['event_details'] = {'fighter_part': word & 0x03FFFFFF}
        elif opcode == 51:
            raw = word & 0x03FFFFFF
            if raw & (1 << 25): raw -= 1 << 26
            ev['event_details'] = {'damage': raw}
        elif opcode == 52:
            ev['event_details'] = {'flags': word & 0x03FFFFFF}
        elif opcode == 53:
            ev['event_details'] = {'enabled': bool(word & 0x03FFFFFF), 'raw_value': word & 0x03FFFFFF}
        elif opcode == 54:
            ev['event_details'] = {'bone': (word >> 18) & 0xFF, 'use_alt_bone': bool((word >> 17) & 1)}
        elif opcode == 55:
            ev['event_details'] = {'effect_id': (word >> 10) & 0xFFFF, 'flags': word & 0x3FF}
        elif opcode == 56 and len(words) >= 2:
            ev['event_details'] = {'charge_frames': (word >> 16) & 0x3FF,
                                   'damage_multiplier': (word & 0xFFFF) / 256.0,
                                   'color_animation': (words[1] >> 24) & 0xFF}
        elif opcode == 57:
            ev['event_details'] = {'enabled': bool((word >> 25) & 1), 'vibration_frames': (word >> 17) & 0xFF}
        elif opcode == 58 and len(words) >= 4:
            ev['event_details'] = {
                'bone': word & 0xFF,
                'x': _s16((words[1] >> 16) & 0xFFFF) / 256.0,
                'y': _s16(words[1] & 0xFFFF) / 256.0,
                'magnitude': _s16((words[2] >> 16) & 0xFFFF) / 256.0,
                'decay_amount': _s16(words[2] & 0xFFFF) / 256.0,
                'timer': _s16((words[3] >> 16) & 0xFFFF),
                'angle': _s16(words[3] & 0xFFFF) / 256.0,
            }
        return ev

    def parse_script(self, anim: int | AnimEntry, max_events: int = 1000) -> list[dict[str, Any]]:
        """Parse the action's *root storage stream* without following branches.

        Phase 13 fixes a long-standing decoder issue: Subroutine (5) and Goto
        (7) are two-word commands whose second word is an HSD-relocated target.
        Root parsing stops at End, Return, or Goto. Use trace_script_execution()
        when you want the actual reachable command path including helpers/loops.
        """
        entry = self.animations[anim] if isinstance(anim, int) else anim
        off = entry.script_offset
        if off == 0:
            return []
        events: list[dict[str, Any]] = []
        frame = 0.0
        seen_bytes = 0
        while 0 <= off < self.archive.header.data_size and len(events) < max_events and seen_bytes < 0x10000:
            ev = self._decode_event_at(off, frame)
            events.append(ev)
            if ev['opcode'] in (1, 2):
                frame = float(ev['frame_after'])
            step = int(ev.get('byte_size', len(ev['words']) * 4))
            off += step
            seen_bytes += step
            if ev['opcode'] in (0, 6, 7) or ev['name'] == 'Invalid/Unknown':
                break
        return events

    def trace_script_execution(self, anim: int | AnimEntry, max_steps: int = 50000) -> list[dict[str, Any]]:
        """Interpret reachable control flow using the decompiled lbCommand rules.

        SetLoop stores the address after itself plus a finite repeat count;
        ExecuteLoop decrements that count. Subroutine/Goto targets come from the
        relocated second word. The trace is bounded so malformed/custom cycles
        fail safely instead of hanging the editor.
        """
        entry = self.animations[anim] if isinstance(anim, int) else anim
        pc = int(entry.script_offset)
        if not pc:
            return []
        frame = 0.0
        loops: list[list[int]] = []  # [body_pc, remaining]
        calls: list[int] = []
        out: list[dict[str, Any]] = []
        for step_no in range(int(max_steps)):
            ev = self._decode_event_at(pc, frame)
            ev = dict(ev)
            ev['trace_step'] = step_no
            ev['call_depth'] = len(calls)
            ev['loop_depth'] = len(loops)
            out.append(ev)
            opcode = ev['opcode']
            next_pc = pc + int(ev['byte_size'])
            if opcode in (1, 2):
                frame = float(ev['frame_after'])
                pc = next_pc
            elif opcode == 0:
                return out
            elif opcode == 3:
                count = int(ev['words'][0] & 0x03FFFFFF)
                loops.append([next_pc, count])
                pc = next_pc
            elif opcode == 4:
                if not loops:
                    raise ValueError(f'Execute Loop at 0x{pc:X} has no matching Set Loop')
                loops[-1][1] -= 1
                if loops[-1][1] != 0:
                    pc = loops[-1][0]
                else:
                    loops.pop()
                    pc = next_pc
            elif opcode == 5:
                if not ev.get('pointer_relocated'):
                    raise ValueError(f'Subroutine pointer at 0x{pc+4:X} is not in the HSD relocation table')
                calls.append(next_pc)
                pc = int(ev['pointer_target'])
            elif opcode == 6:
                if not calls:
                    # A helper root can legitimately terminate with Return.
                    return out
                pc = calls.pop()
            elif opcode == 7:
                if int(ev.get('pointer_target', 0)) == 0:
                    return out
                if not ev.get('pointer_relocated'):
                    raise ValueError(f'Goto pointer at 0x{pc+4:X} is not in the HSD relocation table')
                pc = int(ev['pointer_target'])
            else:
                pc = next_pc
            if not (0 <= pc < self.archive.header.data_size):
                raise ValueError(f'Control flow jumped outside HSD data to 0x{pc:X}')
        raise ValueError(f'Script execution exceeded {max_steps:,} commands; possible infinite control-flow cycle')

    def analyze_script_control_flow(self, anim: int | AnimEntry,
                                    max_nodes: int = 5000) -> dict[str, Any]:
        """Build a bounded static CFG for one action plus referenced helpers.

        This does not unroll loops. Subroutine contributes both a call edge and
        a fallthrough/return continuation; Goto contributes only its target.
        Return/End terminate a path. It is therefore suitable for validating
        large portions of the roster without executing intentionally cyclic
        animation scripts forever.
        """
        entry = self.animations[anim] if isinstance(anim, int) else anim
        root = int(entry.script_offset)
        if not root:
            return {'root': 0, 'nodes': [], 'edges': [], 'cycles': [], 'pointer_events': 0}
        queue = [root]
        decoded: dict[int, dict[str, Any]] = {}
        edges: list[dict[str, Any]] = []
        adjacency: dict[int, set[int]] = {}
        while queue:
            pc = queue.pop()
            if pc in decoded:
                continue
            if len(decoded) >= int(max_nodes):
                raise ValueError(f'Control-flow graph exceeded {max_nodes:,} unique commands')
            ev = self._decode_event_at(pc, 0.0)
            if ev['name'] == 'Invalid/Unknown':
                raise ValueError(f'Invalid opcode {ev["opcode"]} at 0x{pc:X}')
            decoded[pc] = ev
            op = int(ev['opcode'])
            nxt = pc + int(ev['byte_size'])
            successors: list[tuple[int, str]] = []
            if op in (0, 6):
                successors = []
            elif op == 7:
                if int(ev.get('pointer_target', 0)) == 0:
                    successors = []
                else:
                    if not ev.get('pointer_relocated'):
                        raise ValueError(f'Goto target word at 0x{pc+4:X} is not relocated')
                    successors = [(int(ev['pointer_target']), 'goto')]
            elif op == 5:
                if not ev.get('pointer_relocated'):
                    raise ValueError(f'Subroutine target word at 0x{pc+4:X} is not relocated')
                successors = [(int(ev['pointer_target']), 'call'), (nxt, 'return-continuation')]
            else:
                successors = [(nxt, 'next')]
            for target, kind in successors:
                if not (0 <= target < self.archive.header.data_size):
                    raise ValueError(f'{kind} edge from 0x{pc:X} targets outside HSD data: 0x{target:X}')
                adjacency.setdefault(pc, set()).add(target)
                edges.append({'from': pc, 'to': target, 'kind': kind})
                if target not in decoded:
                    queue.append(target)

        # Tarjan is overkill here; DFS back-edges are enough to flag reachable
        # cycles for authoring diagnostics without claiming strongly-connected
        # component semantics.
        visiting: set[int] = set(); visited: set[int] = set(); cycles: list[tuple[int,int]] = []
        def dfs(node: int):
            if node in visited: return
            visiting.add(node)
            for target in adjacency.get(node, ()):
                if target in visiting:
                    cycles.append((node, target))
                elif target not in visited:
                    dfs(target)
            visiting.discard(node); visited.add(node)
        dfs(root)
        return {
            'root': root,
            'nodes': [decoded[k] for k in sorted(decoded)],
            'edges': edges,
            'cycles': [{'from': a, 'to': b} for a,b in cycles],
            'pointer_events': sum(1 for e in decoded.values() if e['opcode'] in (5,7)),
            'subroutines': sum(1 for e in decoded.values() if e['opcode'] == 5),
            'gotos': sum(1 for e in decoded.values() if e['opcode'] == 7),
            'loops': sum(1 for e in decoded.values() if e['opcode'] == 3),
            'returns': sum(1 for e in decoded.values() if e['opcode'] == 6),
        }

    def script_editor_model(self, anim: int | AnimEntry) -> list[dict[str, Any]]:
        """Return a lossless graph-aware model of the action's root stream."""
        events = self.parse_script(anim)
        if not events:
            return []
        if events[-1]['opcode'] not in (0, 6, 7):
            raise ValueError('Root script has no safe End/Return/Goto terminator')
        offsets = {int(e['offset']): i for i, e in enumerate(events)}
        model: list[dict[str, Any]] = []
        for i, e in enumerate(events):
            row = {
                'opcode': int(e['opcode']), 'name': e['name'],
                'words': [int(w) for w in e['words']],
                'source_offset': int(e['offset']), 'label': f'L{i:03d}',
            }
            if e['opcode'] in (5, 7):
                if not e.get('pointer_relocated') and not (e['opcode'] == 7 and int(e.get('pointer_target', 0)) == 0):
                    raise ValueError(f"{e['name']} target word at 0x{e['offset']+4:X} is not relocated")
                target = int(e['pointer_target'])
                row['target'] = target
                if target in offsets:
                    row['target_label'] = f'L{offsets[target]:03d}'
            model.append(row)
        self._validate_graph_model(model)
        return model

    @staticmethod
    def _validate_graph_model(model: list[dict[str, Any]]) -> None:
        if not model:
            raise ValueError('A fighter script cannot be empty')
        labels = [str(x.get('label', '')) for x in model]
        if any(not x for x in labels) or len(set(labels)) != len(labels):
            raise ValueError('Every assembled event needs a unique symbolic label')
        label_set = set(labels)
        loop_depth = 0
        for i, item in enumerate(model):
            words = [int(w) & 0xFFFFFFFF for w in item.get('words', [])]
            if not words:
                raise ValueError(f'Assembler event {i} has no words')
            opcode = words[0] >> 26
            expected = _fighter_event_word_length(opcode)
            if len(words) != expected:
                raise ValueError(f'Opcode {opcode} requires {expected} word(s), got {len(words)}')
            if opcode == 3:
                count = words[0] & 0x03FFFFFF
                if count < 1:
                    raise ValueError('Set Loop repeat count must be at least 1')
                loop_depth += 1
            elif opcode == 4:
                if loop_depth <= 0:
                    raise ValueError('Execute Loop has no preceding unmatched Set Loop')
                loop_depth -= 1
            if opcode in (5, 7) and item.get('target_label') and item['target_label'] not in label_set:
                raise ValueError(f"{EVENT_NAMES[opcode]} targets missing label {item['target_label']}")
            if opcode in (0, 6, 7) and i != len(model) - 1:
                raise ValueError(f'{EVENT_NAMES[opcode]} may only terminate the root stream at the final row')
        if loop_depth:
            raise ValueError('Set Loop block is missing Execute Loop')
        if (model[-1]['words'][0] >> 26) not in (0, 6, 7):
            raise ValueError('Assembled root must end in End/Reset, Return, or Goto')

    @staticmethod
    def event_words_to_bytes(words: Iterable[int]) -> bytes:
        vals = [int(x) & 0xFFFFFFFF for x in words]
        return b''.join(BE_U32.pack(x) for x in vals)

    @staticmethod
    def make_timer_words(opcode: int, value: int) -> list[int]:
        opcode = int(opcode); value = int(value)
        if opcode not in (1, 2):
            raise ValueError('Timer opcode must be 1 (synchronous) or 2 (asynchronous)')
        if not 0 <= value <= 0x03FFFFFF:
            raise ValueError('Timer value must fit the 26-bit fighter-script field')
        return [(opcode << 26) | value]

    @staticmethod
    def make_loop_words(count: int) -> list[int]:
        count = int(count)
        if not 1 <= count <= 0x03FFFFFF:
            raise ValueError('Loop count must be 1..67108863')
        return [(3 << 26) | count]

    @staticmethod
    def make_simple_event_words(opcode: int, value: int = 0) -> list[int]:
        opcode = int(opcode)
        if opcode in (5, 7):
            raise ValueError('Subroutine/Goto require a target and the graph assembler')
        if not 0 <= opcode <= 58:
            raise ValueError('Fighter event opcode must be between 0 and 58')
        nwords = _fighter_event_word_length(opcode)
        if nwords != 1:
            raise ValueError(f'{EVENT_NAMES.get(opcode, opcode)} is a {nwords}-word event and needs a dedicated encoder')
        return [(opcode << 26) | (int(value) & 0x03FFFFFF)]

    def replace_script_graph(self, anim: int | AnimEntry,
                             model: Iterable[dict[str, Any]]) -> dict[str, Any]:
        """Assemble a root script with symbolic control-flow relocation."""
        entry = self.animations[anim] if isinstance(anim, int) else anim
        old_model = self.script_editor_model(entry)
        old_events = self.parse_script(entry)
        if not old_events:
            raise ValueError('Action has no script')
        old_start = int(entry.script_offset)
        old_end = int(old_events[-1]['offset'] + old_events[-1]['byte_size'])
        old_len = old_end - old_start

        rows = [copy.deepcopy(x) for x in model]
        self._validate_graph_model(rows)
        # Compute new event offsets before encoding pointers.
        cursor = old_start
        new_offsets: dict[str, int] = {}
        old_to_new: dict[int, int] = {}
        for row in rows:
            label = str(row['label'])
            new_offsets[label] = cursor
            if row.get('source_offset') is not None:
                old_to_new[int(row['source_offset'])] = cursor
            cursor += len(row['words']) * 4
        new_len = cursor - old_start
        delta = new_len - old_len

        # Preserve externally shared entry points into the old root when the
        # corresponding event survived/reordered. This also lets the generic
        # HSD relocation rebuild retarget incoming pointers safely.
        interior_map = dict(old_to_new)
        interior_map[old_start] = old_start

        encoded: list[bytes] = []
        new_relocs: list[int] = []
        for row in rows:
            words = [int(w) & 0xFFFFFFFF for w in row['words']]
            opcode = words[0] >> 26
            event_off = new_offsets[str(row['label'])]
            if opcode in (5, 7):
                if row.get('target_label'):
                    target = new_offsets[str(row['target_label'])]
                else:
                    target = int(row.get('target', words[1]))
                    if old_start <= target < old_end:
                        if target not in interior_map:
                            raise ValueError(f'Control-flow target 0x{target:X} points inside removed script bytes')
                        target = interior_map[target]
                    elif target >= old_end:
                        target += delta
                words[1] = target & 0xFFFFFFFF
                if not (opcode == 7 and target == 0):
                    new_relocs.append(event_off + 4)
            encoded.append(self.event_words_to_bytes(words))
        new_bytes = b''.join(encoded)

        # Any outside relocation targeting a deleted interior command must be
        # rejected rather than silently redirected.
        old_data = bytes(self.archive.raw[self.archive.data_start:self.archive.data_end])
        for loc in self.archive.relocations:
            if old_start <= loc < old_end:
                continue
            target = _u32(old_data, loc)
            if old_start < target < old_end and target not in interior_map:
                raise ValueError(f'External pointer at 0x{loc:X} targets deleted interior command 0x{target:X}')

        old_archive_size = len(self.archive.raw)
        old_data_size = self.archive.header.data_size
        self.archive.replace_data_ranges(
            [(old_start, old_len, new_bytes)],
            new_relocation_offsets=new_relocs,
            interior_target_map=interior_map,
        )
        self._refresh_from_archive()
        verify_model = self.script_editor_model(self.animations[entry.index])
        # Static CFG validation is authoritative because many idle/walk scripts
        # intentionally end in a Goto cycle. Finite graphs are additionally
        # execution-traced to exercise loop/subroutine return semantics.
        cfg = self.analyze_script_control_flow(self.animations[entry.index])
        trace_count = None
        if not cfg['cycles']:
            try:
                trace_count = len(self.trace_script_execution(self.animations[entry.index]))
            except ValueError:
                trace_count = None
        return {
            'action_index': entry.index,
            'old_script_bytes': old_len, 'new_script_bytes': new_len,
            'script_delta': delta, 'old_data_size': old_data_size,
            'new_data_size': self.archive.header.data_size,
            'old_archive_size': old_archive_size, 'new_archive_size': len(self.archive.raw),
            'event_count': len(verify_model), 'trace_event_count': trace_count,
            'cfg_nodes': len(cfg['nodes']), 'cfg_edges': len(cfg['edges']),
            'cfg_cycles': len(cfg['cycles']),
            'control_flow_relocations': len(new_relocs),
        }

    def replace_linear_script(self, anim: int | AnimEntry,
                              event_word_lists: Iterable[Iterable[int]]) -> dict[str, Any]:
        """Compatibility wrapper for callers that only supply raw event words."""
        current = self.script_editor_model(anim)
        lists = [[int(w) & 0xFFFFFFFF for w in words] for words in event_word_lists]
        rows = []
        for i, words in enumerate(lists):
            row = {'words': words, 'label': f'L{i:03d}'}
            if i < len(current):
                row['source_offset'] = current[i].get('source_offset')
                if (words[0] >> 26) in (5, 7):
                    row['target'] = current[i].get('target', words[1] if len(words)>1 else 0)
                    if current[i].get('target_label'):
                        row['target_label'] = current[i]['target_label']
            rows.append(row)
        return self.replace_script_graph(anim, rows)

    def insert_event(self, anim: int | AnimEntry, index: int,
                     words: Iterable[int]) -> dict[str, Any]:
        model = self.script_editor_model(anim)
        index = int(index)
        if not 0 <= index <= len(model) - 1:
            raise ValueError('Insert position must be before the root terminator')
        existing = {x['label'] for x in model}
        n = 0
        while f'N{n:03d}' in existing: n += 1
        model.insert(index, {'words': [int(w) & 0xFFFFFFFF for w in words], 'label': f'N{n:03d}'})
        return self.replace_script_graph(anim, model)

    def insert_loop_block(self, anim: int | AnimEntry, index: int, count: int) -> dict[str, Any]:
        model = self.script_editor_model(anim)
        index = int(index)
        if not 0 <= index <= len(model) - 1:
            raise ValueError('Loop insertion position must be before the root terminator')
        labels = {x['label'] for x in model}
        def fresh(prefix):
            i=0
            while f'{prefix}{i:03d}' in labels: i+=1
            label=f'{prefix}{i:03d}'; labels.add(label); return label
        model.insert(index, {'words': self.make_loop_words(count), 'label': fresh('LOOP')})
        model.insert(index+1, {'words': self.make_simple_event_words(4, 0), 'label': fresh('ENDL')})
        return self.replace_script_graph(anim, model)

    def wrap_event_in_loop(self, anim: int | AnimEntry, index: int, count: int) -> dict[str, Any]:
        """Wrap one root-stream event in a validated SetLoop/ExecuteLoop pair."""
        model = self.script_editor_model(anim); index = int(index); count = int(count)
        if not 0 <= index < len(model) - 1:
            raise ValueError('Select a non-terminator root event to loop')
        if (model[index]['words'][0] >> 26) in (3, 4, 5, 6, 7):
            raise ValueError('Wrap a normal/timer/hitbox event; nested control-flow authoring should use JSON/graph editing')
        if not 1 <= count <= 0x03FFFFFF:
            raise ValueError('Loop count must be 1..67108863')
        labels = {x['label'] for x in model}
        def fresh(prefix):
            n=0
            while f'{prefix}{n:03d}' in labels: n += 1
            out=f'{prefix}{n:03d}'; labels.add(out); return out
        model.insert(index, {'words': self.make_loop_words(count), 'label': fresh('LOOP')})
        model.insert(index + 2, {'words': self.make_simple_event_words(4, 0), 'label': fresh('ENDL')})
        return self.replace_script_graph(anim, model)

    def delete_event(self, anim: int | AnimEntry, index: int) -> dict[str, Any]:
        model = self.script_editor_model(anim); index = int(index)
        if not 0 <= index < len(model) - 1:
            raise ValueError('Cannot delete the root terminator')
        label = model[index]['label']
        if any(x.get('target_label') == label for x in model):
            raise ValueError(f'Cannot delete {label}; a Subroutine/Goto targets it')
        del model[index]
        return self.replace_script_graph(anim, model)

    def move_event(self, anim: int | AnimEntry, index: int, delta: int) -> dict[str, Any]:
        model = self.script_editor_model(anim); index = int(index); target = index + int(delta)
        if not 0 <= index < len(model) - 1 or not 0 <= target < len(model) - 1:
            raise ValueError('Event cannot be moved past the root boundaries or terminator')
        event = model.pop(index); model.insert(target, event)
        return self.replace_script_graph(anim, model)

    def duplicate_event(self, anim: int | AnimEntry, index: int) -> dict[str, Any]:
        model = self.script_editor_model(anim); index = int(index)
        if not 0 <= index < len(model) - 1:
            raise ValueError('Select a non-terminator event to duplicate')
        clone = copy.deepcopy(model[index])
        clone.pop('source_offset', None)
        used = {x['label'] for x in model}; n=0
        while f'COPY{n:03d}' in used: n+=1
        clone['label'] = f'COPY{n:03d}'
        model.insert(index + 1, clone)
        return self.replace_script_graph(anim, model)

    def add_hitbox_phase(self, anim: int | AnimEntry, frame: int, duration: int,
                         template_event_offset: int | None = None) -> dict[str, Any]:
        entry = self.animations[anim] if isinstance(anim, int) else anim
        events = self.parse_script(entry)
        model = self.script_editor_model(entry)
        frame = int(frame); duration = int(duration)
        if frame < 0 or duration < 1:
            raise ValueError('Hitbox phase frame must be >= 0 and duration must be >= 1')
        hit_events = [e for e in self.trace_script_execution(entry) if e.get('opcode') == 11 and 'hitbox' in e]
        if not hit_events:
            raise ValueError('This action has no reachable Spawn Hitbox to use as a safe template')
        template = next((e for e in hit_events if e['offset'] == int(template_event_offset or -1)), hit_events[0])
        # Only clone the hitbox words; insert into the root before terminator.
        insert_at = len(model) - 1
        sequence = [self.make_timer_words(2, frame), list(template['words']),
                    self.make_timer_words(1, duration), self.make_simple_event_words(16, 0)]
        labels = {x['label'] for x in model}; counter=0
        for words in sequence:
            while f'NEW{counter:03d}' in labels: counter += 1
            model.insert(insert_at, {'words': words, 'label': f'NEW{counter:03d}'})
            labels.add(f'NEW{counter:03d}'); insert_at += 1; counter += 1
        result = self.replace_script_graph(entry, model)
        result.update({'phase_frame': frame, 'phase_duration': duration, 'inserted_events': 4})
        return result

    def hitboxes_for_animation(self, anim: int | AnimEntry) -> list[dict[str, Any]]:
        return [e for e in self.parse_script(anim) if 'hitbox' in e]

    def analyze_move_timing(self, anim: int | AnimEntry) -> dict[str, Any]:
        """Derive editor-friendly timing milestones from reachable script execution.

        Frames are the script interpreter's frame counter. Active intervals are
        represented as half-open ``[start, end)`` ranges so a hitbox created on
        frame 6 and cleared on frame 9 is active on frames 6, 7, and 8.

        This deliberately reports what the command stream proves. It does not
        claim the AJ animation's true visual length when the script ends earlier
        or later than the animation resource.
        """
        try:
            events = self.trace_script_execution(anim, max_steps=20000)
        except ValueError:
            # Some idle/ambient scripts intentionally cycle forever. Frame-data
            # editing remains useful for their root stream without hanging.
            events = self.parse_script(anim)
        active: dict[int, float] = {}
        intervals: list[dict[str, Any]] = []
        first_interrupt = None
        last_frame = 0.0

        for ev in events:
            frame = float(ev.get('frame', 0.0))
            last_frame = max(last_frame, frame, float(ev.get('frame_after', frame)))
            opcode = ev.get('opcode')
            if opcode == 11 and 'hitbox' in ev:
                hid = int(ev['hitbox']['id'])
                # Re-spawning the same ID replaces it. Close the previous span.
                if hid in active and active[hid] < frame:
                    intervals.append({'hitbox_id': hid, 'start': active[hid], 'end': frame})
                active[hid] = frame
            elif opcode == 15:
                hid = int(ev.get('hitbox_id', -1))
                if hid in active:
                    intervals.append({'hitbox_id': hid, 'start': active.pop(hid), 'end': frame})
            elif opcode == 16:
                for hid, start in list(active.items()):
                    intervals.append({'hitbox_id': hid, 'start': start, 'end': frame})
                active.clear()
            elif opcode == 23 and first_interrupt is None:
                first_interrupt = frame

        for hid, start in active.items():
            intervals.append({'hitbox_id': hid, 'start': start, 'end': last_frame})

        positive = [x for x in intervals if x['end'] >= x['start']]
        active_start = min((x['start'] for x in positive), default=None)
        active_end = max((x['end'] for x in positive), default=None)

        # Collapse overlapping hitbox-ID spans into overall active windows.
        windows = []
        for x in sorted(positive, key=lambda y: (y['start'], y['end'])):
            st, en = float(x['start']), float(x['end'])
            if not windows or st > windows[-1][1]:
                windows.append([st, en])
            else:
                windows[-1][1] = max(windows[-1][1], en)

        return {
            'events': events,
            'script_end': last_frame,
            'first_active': active_start,
            'active_end': active_end,  # first inactive frame after the last tracked active span
            'active_windows': [{'start': a, 'end': b} for a, b in windows],
            'interrupt_frame': first_interrupt,
            'startup': active_start,
            'recovery': (last_frame - active_end) if active_end is not None else None,
        }

    def _retime_event_frame(self, anim: int | AnimEntry, event_offset: int, target_frame: int,
                            shift_later_absolute: bool = True) -> list[tuple[int, int, int]]:
        """Move a command milestone by editing existing timer words only.

        The nearest preceding timer command is the timing anchor for the target
        command in a linear script. If it is synchronous, its wait duration is
        changed by the requested delta. If it is asynchronous, its absolute
        frame target is changed directly. Later asynchronous anchors are shifted
        by the same delta so downstream relative timing remains intact.

        No commands are inserted/deleted and the DAT size never changes.
        """
        target_frame = int(target_frame)
        if target_frame < 0:
            raise ValueError('Target frame must be 0 or greater')
        events = self.parse_script(anim)
        idx = next((i for i, e in enumerate(events) if e['offset'] == event_offset), None)
        if idx is None:
            raise ValueError(f'Event offset 0x{event_offset:X} is not part of this action')
        current = int(round(float(events[idx]['frame'])))
        delta = target_frame - current
        if delta == 0:
            return []

        anchor_i = None
        for i in range(idx - 1, -1, -1):
            if events[i].get('opcode') in (1, 2):
                anchor_i = i
                break
        if anchor_i is None:
            raise ValueError('This event has no preceding timer anchor and cannot be retimed safely')

        snapshot = bytes(self.archive.raw)
        changes: list[tuple[int, int, int]] = []
        try:
            anchor = events[anchor_i]
            old = int(anchor['timer_value'])
            if anchor['opcode'] == 1:
                new = old + delta
                if new < 0:
                    raise ValueError('Requested frame would require a negative synchronous wait')
            else:
                new = old + delta
                if new < 0:
                    raise ValueError('Requested frame would require a negative asynchronous target')
            if new > 0x03FFFFFF:
                raise ValueError('Requested frame exceeds the 26-bit timer range')
            self.set_timer_event(anchor['offset'], new)
            changes.append((anchor['offset'], old, new))

            if shift_later_absolute:
                for later in events[anchor_i + 1:]:
                    if later.get('opcode') != 2:
                        continue
                    old_abs = int(later['timer_value'])
                    # Absolute targets before the milestone are control-flow anchors
                    # and are not part of the downstream phase being shifted.
                    if old_abs < current:
                        continue
                    new_abs = old_abs + delta
                    if not (0 <= new_abs <= 0x03FFFFFF):
                        raise ValueError('A downstream asynchronous timer would leave its valid range')
                    if new_abs != old_abs:
                        self.set_timer_event(later['offset'], new_abs)
                        changes.append((later['offset'], old_abs, new_abs))

            check = self.parse_script(anim)
            moved = next(e for e in check if e['offset'] == event_offset)
            if int(round(float(moved['frame']))) != target_frame:
                raise ValueError('Timer edit did not resolve to the requested frame; edit rolled back')
            return changes
        except Exception:
            self.archive.raw[:] = snapshot
            raise

    def set_first_active_frame(self, anim: int | AnimEntry, target_frame: int) -> list[tuple[int, int, int]]:
        timing = self.analyze_move_timing(anim)
        first = timing['first_active']
        if first is None:
            raise ValueError('This action has no decoded Spawn Hitbox event')
        event = next(e for e in timing['events'] if 'hitbox' in e and e['frame'] == first)
        return self._retime_event_frame(anim, event['offset'], target_frame, True)

    def set_active_end_frame(self, anim: int | AnimEntry, target_frame: int) -> list[tuple[int, int, int]]:
        """Set the first inactive frame after the final decoded hitbox window."""
        timing = self.analyze_move_timing(anim)
        old_end = timing['active_end']
        if old_end is None:
            raise ValueError('This action has no decoded active hitbox window')
        # Prefer an explicit clear-all/specific-clear command at the current end.
        candidates = [e for e in timing['events'] if e.get('opcode') in (15, 16) and float(e['frame']) == float(old_end)]
        if not candidates:
            raise ValueError('The final active window is not closed by an editable deactivate command')
        return self._retime_event_frame(anim, candidates[-1]['offset'], target_frame, True)

    def set_interrupt_frame(self, anim: int | AnimEntry, target_frame: int) -> list[tuple[int, int, int]]:
        timing = self.analyze_move_timing(anim)
        old = timing['interrupt_frame']
        if old is None:
            raise ValueError('This action has no Allow Interrupt command in the decoded script')
        event = next(e for e in timing['events'] if e.get('opcode') == 23 and float(e['frame']) == float(old))
        return self._retime_event_frame(anim, event['offset'], target_frame, False)

    def set_script_end_frame(self, anim: int | AnimEntry, target_frame: int) -> list[tuple[int, int, int]]:
        """Move the linear script's End/Reset command using its preceding timer anchor."""
        events = self.parse_script(anim)
        ends = [e for e in events if e.get('opcode') == 0]
        if not ends:
            raise ValueError('This action has no decoded End/Reset command')
        return self._retime_event_frame(anim, ends[-1]['offset'], target_frame, False)

    def set_timer_event(self, event_offset: int, value: int) -> dict[str, Any]:
        """Edit one fighter-script timer in place.

        Opcodes 1 and 2 store a 26-bit timer value in the low bits of a single
        word. Opcode 1 is a relative/synchronous wait; opcode 2 is an absolute
        asynchronous frame target. No command sizes or relocation data change.
        """
        word = self.archive.data_u32(event_offset)
        opcode = word >> 26
        if opcode not in (1, 2):
            raise ValueError(f'Offset 0x{event_offset:X} is not a timer command')
        value = int(value)
        if not (0 <= value <= 0x03FFFFFF):
            raise ValueError('Timer value must be between 0 and 67,108,863')
        self.archive.write_data_u32(event_offset, (opcode << 26) | value)
        return {'offset': event_offset, 'opcode': opcode, 'timer_value': value}

    def scale_script_timing(self, anim: int | AnimEntry, factor: float) -> list[tuple[int, int, int]]:
        """Scale timer values in one action script without resizing it.

        Relative timer durations and absolute asynchronous frame targets are
        multiplied by ``factor`` and rounded to the nearest frame. This moves
        script events (hitboxes, effects, flags, etc.) earlier/later, but it does
        NOT rescale the underlying AJ animation or the action state's animation
        duration. Returns ``(offset, old, new)`` for changed timer commands.
        """
        factor = float(factor)
        if not math.isfinite(factor) or factor <= 0:
            raise ValueError('Timing scale must be a finite number greater than 0')
        changes = []
        for ev in self.parse_script(anim):
            if ev.get('opcode') not in (1, 2):
                continue
            old = int(ev['timer_value'])
            new = int(math.floor(old * factor + 0.5))
            if old > 0:
                new = max(1, new)
            new = max(0, min(0x03FFFFFF, new))
            if new != old:
                self.set_timer_event(ev['offset'], new)
                changes.append((ev['offset'], old, new))
        return changes

    def retime_full_move(self, anim: int | AnimEntry, aj_bytes: bytes | bytearray,
                         speed_multiplier: float) -> tuple[bytes, dict[str, Any]]:
        """Retimes both fighter commands and the real AJ FigaTree animation.

        ``speed_multiplier=1.30`` means approximately 30% faster, so both
        timelines use a time factor of 1/1.30. The selected embedded HSD archive
        may grow/shrink; all later AJ offsets and all entries sharing the same
        animation chunk are updated in the fighter DAT.
        """
        speed_multiplier = float(speed_multiplier)
        if not math.isfinite(speed_multiplier) or speed_multiplier <= 0:
            raise ValueError('Move speed multiplier must be finite and greater than zero')
        entry = self.animations[anim] if isinstance(anim, int) else anim
        action_index = entry.index
        old_archive = bytes(self.archive.raw)
        old_aj = bytes(aj_bytes)
        time_factor = 1.0 / speed_multiplier
        try:
            # Script timing follows the same time domain as frame_speed_mul.
            script_changes = self.scale_script_timing(self.animations[action_index], time_factor)
            entry = self.animations[action_index]
            start = entry.anim_archive_offset
            old_size = entry.anim_archive_size
            if not start or not old_size:
                raise ValueError('Selected action has no referenced AJ animation chunk')
            if start + old_size > len(old_aj):
                raise ValueError('Selected AJ chunk extends beyond the supplied AJ file')
            chunk = old_aj[start:start + old_size]
            new_chunk, anim_result = retime_figatree_archive(chunk, time_factor)
            new_aj = old_aj[:start] + new_chunk + old_aj[start + old_size:]
            delta = len(new_chunk) - old_size

            # x4/x8 in Fighter_WaitAnimData are AJ-file offset/size scalars,
            # not HSD pointers. Update every entry against the pre-edit layout.
            original_entries = list(self.animations)
            shared = 0
            shifted = 0
            for a in original_entries:
                row = self.anim_table_offset + a.index * 0x18
                if a.anim_archive_offset == start and a.anim_archive_size == old_size:
                    self.archive.write_data_u32(row + 0x04, start)
                    self.archive.write_data_u32(row + 0x08, len(new_chunk))
                    shared += 1
                elif a.anim_archive_offset > start:
                    self.archive.write_data_u32(row + 0x04, a.anim_archive_offset + delta)
                    shifted += 1
            self._refresh_from_archive()

            # Validate the edited selected chunk again from its new table entry.
            selected = self.animations[action_index]
            check_chunk = new_aj[selected.anim_archive_offset:selected.anim_archive_offset + selected.anim_archive_size]
            check = analyze_figatree_archive(check_chunk)
            if abs(check['frames'] - anim_result['new_frames']) > 0.001:
                raise ValueError('AJ verification disagreed with the requested animation retime')
            return new_aj, {
                'action_index': action_index,
                'speed_multiplier': speed_multiplier,
                'time_factor': time_factor,
                'script_timers_changed': len(script_changes),
                'animation': anim_result,
                'shared_entries_updated': shared,
                'later_aj_offsets_shifted': shifted,
                'aj_old_size': len(old_aj),
                'aj_new_size': len(new_aj),
                'aj_size_delta': len(new_aj) - len(old_aj),
            }
        except Exception:
            self.archive = HSDArchive(old_archive)
            self._refresh_from_archive()
            raise

    def clone_full_move(self, source_anim: int | AnimEntry, target_anim: int | AnimEntry,
                        aj_bytes: bytes | bytearray) -> tuple[bytes, dict[str, Any]]:
        """Clone script + animation into another action slot of the same fighter.

        The source command graph is assembled into the destination root with
        control-flow targets relocated. The source AJ FigaTree is copied to a
        new 0x20-aligned AJ slot and its public symbol is renamed to the target
        action's expected symbol, keeping the clone independent for later edits.
        """
        source = self.animations[source_anim] if isinstance(source_anim, int) else source_anim
        target = self.animations[target_anim] if isinstance(target_anim, int) else target_anim
        if source.index == target.index:
            raise ValueError('Source and target actions are the same')
        old_archive = bytes(self.archive.raw); old_aj = bytes(aj_bytes)
        if not source.anim_archive_offset or not source.anim_archive_size:
            raise ValueError('Source action has no AJ animation chunk')
        if source.anim_archive_offset + source.anim_archive_size > len(old_aj):
            raise ValueError('Source AJ animation chunk lies outside the supplied AJ file')
        source_model = self.script_editor_model(source)
        # Destination assembly must not interpret source byte locations as
        # destination interior labels. Symbolic labels and pointer targets remain.
        cloned_model = copy.deepcopy(source_model)
        for row in cloned_model:
            row.pop('source_offset', None)
        source_chunk = old_aj[source.anim_archive_offset:source.anim_archive_offset + source.anim_archive_size]
        try:
            script_result = self.replace_script_graph(self.animations[target.index], cloned_model)
            target = self.animations[target.index]
            cloned_chunk = rename_hsd_public_symbol(source_chunk, target.symbol)
            pad = (-len(old_aj)) % 0x20
            new_offset = len(old_aj) + pad
            new_aj = old_aj + (b'\0' * pad) + cloned_chunk
            row = self.anim_table_offset + target.index * 0x18
            self.archive.write_data_u32(row + 0x04, new_offset)
            self.archive.write_data_u32(row + 0x08, len(cloned_chunk))
            self._refresh_from_archive()
            verify_target = self.animations[target.index]
            check = analyze_figatree_archive(new_aj[verify_target.anim_archive_offset:
                                                     verify_target.anim_archive_offset + verify_target.anim_archive_size])
            if check['symbol'] != verify_target.symbol:
                raise ValueError('Cloned animation public symbol does not match destination action symbol')
            return new_aj, {
                'source_action_index': source.index,
                'target_action_index': target.index,
                'source_action': source.action_name,
                'target_action': verify_target.action_name,
                'script': script_result,
                'aj_old_size': len(old_aj), 'aj_new_size': len(new_aj),
                'aj_size_delta': len(new_aj) - len(old_aj),
                'animation_offset': new_offset, 'animation_size': len(cloned_chunk),
                'alignment_padding': pad,
                'animation_frames': check['frames'],
            }
        except Exception:
            self.archive = HSDArchive(old_archive)
            self._refresh_from_archive()
            raise

    def set_hitbox(self, event_offset: int, updates: dict[str, Any]) -> dict[str, Any]:
        words = [self.archive.data_u32(event_offset + i * 4) for i in range(5)]
        if words[0] >> 26 != 11:
            raise ValueError(f'Offset 0x{event_offset:X} is not a Spawn Hitbox command')
        hit = decode_hitbox(words)
        hit.update(updates)
        new_words = encode_hitbox(hit, original_words=words)
        for i, w in enumerate(new_words):
            self.archive.write_data_u32(event_offset + i * 4, w)
        return decode_hitbox(new_words)

    def validate_animation_archive(self, aj_path: str | os.PathLike[str]) -> dict[str, Any]:
        aj = Path(aj_path).read_bytes()
        checked = valid = 0
        errors = []
        unique = set()
        for a in self.animations:
            if not a.symbol or not a.anim_archive_size:
                continue
            key = (a.anim_archive_offset, a.anim_archive_size)
            if key in unique:
                continue
            unique.add(key)
            checked += 1
            start, size = key
            if start < 0 or start + size > len(aj) or size < 0x20:
                errors.append(f'anim {a.index}: chunk 0x{start:X}+0x{size:X} outside AJ size 0x{len(aj):X}')
                continue
            embedded_size = _u32(aj, start)
            if embedded_size != size:
                errors.append(f'anim {a.index}: chunk header size 0x{embedded_size:X} != table size 0x{size:X}')
                continue
            valid += 1
        return {'checked_unique_chunks': checked, 'valid_chunks': valid, 'errors': errors, 'aj_size': len(aj)}

    def export_summary(self) -> dict[str, Any]:
        moves = []
        for a in self.animations:
            if not a.symbol:
                continue
            hbs = self.hitboxes_for_animation(a)
            moves.append({
                'index': a.index,
                'action': a.action_name,
                'symbol': a.symbol,
                'script_offset': a.script_offset,
                'animation_archive_offset': a.anim_archive_offset,
                'animation_archive_size': a.anim_archive_size,
                'hitbox_events': hbs,
            })
        return {
            'file': self.path.name,
            'fighter': self.fighter_name,
            'ftdata_symbol': self.root.name,
            'ftdata_offset': self.root.offset,
            'common_attrs_offset': self.common_attrs_offset,
            'ext_attrs_offset': self.ext_attrs_offset,
            'animation_table_offset': self.anim_table_offset,
            'animation_count': self.anim_count,
            'common_attributes': self.common_attributes(),
            'character_attributes': self.character_attributes(),
            'moves': moves,
        }

    def save_as(self, path: str | os.PathLike[str]) -> None:
        self.archive.write_file(path)


def decode_hitbox(words: Iterable[int]) -> dict[str, Any]:
    w = list(words)
    if len(w) != 5:
        raise ValueError('Fighter hitbox command must contain exactly five 32-bit words')
    if w[0] >> 26 != 11:
        raise ValueError('Not a Spawn Hitbox event')
    return {
        'id': (w[0] >> 23) & 0x7,
        'hit_group': (w[0] >> 20) & 0x7,
        'only_hit_grabbed': (w[0] >> 19) & 0x1,
        'bone': (w[0] >> 11) & 0xFF,
        'use_common_bone_ids': (w[0] >> 10) & 0x1,
        'damage': w[0] & 0x3FF,
        'size': ((w[1] >> 16) & 0xFFFF) / 256.0,
        # These names follow the actual assignments in ftAction_8007121C,
        # not the misleading decomp struct member names.
        'offset_x': _s16(w[1] & 0xFFFF) / 256.0,
        'offset_y': _s16((w[2] >> 16) & 0xFFFF) / 256.0,
        'offset_z': _s16(w[2] & 0xFFFF) / 256.0,
        'angle': (w[3] >> 23) & 0x1FF,
        'knockback_growth': (w[3] >> 14) & 0x1FF,
        'weight_set_knockback': (w[3] >> 5) & 0x1FF,
        'item_hit_interaction': (w[3] >> 4) & 0x1,
        'ignore_thrown_fighters': (w[3] >> 3) & 0x1,
        'ignore_fighter_scale': (w[3] >> 2) & 0x1,
        'clank': (w[3] >> 1) & 0x1,
        'rebound': w[3] & 0x1,
        'base_knockback': (w[4] >> 23) & 0x1FF,
        'element': (w[4] >> 18) & 0x1F,
        'shield_damage': _s8((w[4] >> 10) & 0xFF),
        'hit_sfx_severity': (w[4] >> 7) & 0x7,
        'hit_sfx_kind': (w[4] >> 2) & 0x1F,
        'hit_grounded': (w[4] >> 1) & 0x1,
        'hit_aerial': w[4] & 0x1,
    }


def encode_hitbox(hit: dict[str, Any], original_words: Iterable[int] | None = None) -> list[int]:
    w = list(original_words) if original_words is not None else [11 << 26, 0, 0, 0, 0]
    if len(w) != 5:
        raise ValueError('original_words must contain five words')
    w[0] = _set_bits(w[0], 26, 6, 11)
    w[0] = _set_bits(w[0], 23, 3, hit['id'])
    w[0] = _set_bits(w[0], 20, 3, hit['hit_group'])
    w[0] = _set_bits(w[0], 19, 1, hit['only_hit_grabbed'])
    w[0] = _set_bits(w[0], 11, 8, hit['bone'])
    w[0] = _set_bits(w[0], 10, 1, hit['use_common_bone_ids'])
    w[0] = _set_bits(w[0], 0, 10, hit['damage'])

    size = round(float(hit['size']) * 256)
    ox = round(float(hit['offset_x']) * 256)
    oy = round(float(hit['offset_y']) * 256)
    oz = round(float(hit['offset_z']) * 256)
    w[1] = _set_bits(w[1], 16, 16, size)
    w[1] = _set_bits(w[1], 0, 16, ox)
    w[2] = _set_bits(w[2], 16, 16, oy)
    w[2] = _set_bits(w[2], 0, 16, oz)

    w[3] = _set_bits(w[3], 23, 9, hit['angle'])
    w[3] = _set_bits(w[3], 14, 9, hit['knockback_growth'])
    w[3] = _set_bits(w[3], 5, 9, hit['weight_set_knockback'])
    w[3] = _set_bits(w[3], 4, 1, hit['item_hit_interaction'])
    w[3] = _set_bits(w[3], 3, 1, hit['ignore_thrown_fighters'])
    w[3] = _set_bits(w[3], 2, 1, hit['ignore_fighter_scale'])
    w[3] = _set_bits(w[3], 1, 1, hit['clank'])
    w[3] = _set_bits(w[3], 0, 1, hit['rebound'])

    w[4] = _set_bits(w[4], 23, 9, hit['base_knockback'])
    w[4] = _set_bits(w[4], 18, 5, hit['element'])
    w[4] = _set_bits(w[4], 10, 8, hit['shield_damage'])
    w[4] = _set_bits(w[4], 7, 3, hit['hit_sfx_severity'])
    w[4] = _set_bits(w[4], 2, 5, hit['hit_sfx_kind'])
    w[4] = _set_bits(w[4], 1, 1, hit['hit_grounded'])
    w[4] = _set_bits(w[4], 0, 1, hit['hit_aerial'])
    return [x & 0xFFFFFFFF for x in w]


def scan_fighter_directory(folder: str | os.PathLike[str]) -> list[dict[str, Any]]:
    folder = Path(folder)
    rows = []
    for p in sorted(folder.glob('Pl??.dat')):
        try:
            f = FighterDAT(p)
        except Exception:
            continue
        aj = p.with_name(p.stem + 'AJ.dat')
        validation = f.validate_animation_archive(aj) if aj.exists() else None
        rows.append({
            'file': p.name,
            'fighter': f.fighter_name,
            'animation_count': f.anim_count,
            'common_attrs_offset': f.common_attrs_offset,
            'ext_attrs_offset': f.ext_attrs_offset,
            'aj_file': aj.name if aj.exists() else None,
            'aj_validation': validation,
        })
    return rows
