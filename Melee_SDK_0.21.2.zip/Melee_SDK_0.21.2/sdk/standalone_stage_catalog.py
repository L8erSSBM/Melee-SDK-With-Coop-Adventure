"""Page 2's source-verified Adventure/Classic launch contracts.

Arena entries are versus matches; the other entries retain one-player challenge
rules with the SDK's two-human support. IDs are part of the peer wire protocol.
"""
from dataclasses import asdict, dataclass

CAMPAIGN_MARKER = 0xA5
FIRST_MARKER = 0xA6


@dataclass(frozen=True)
class StandaloneStage:
    key: str
    title: str
    subtitle: str
    filename: str
    stkind: int
    entry_state: int
    play_state: int
    mode: str = 'challenge'
    arena_index: int | None = None


STAGES = (
    StandaloneStage('mushroom_route','Mushroom Kingdom','Reach the flagpole','GrNKr.dat',0x3B,0x00,0x01),
    StandaloneStage('underground_maze','Underground Maze','Find the Triforce','GrNSr.dat',0x3F,0x10,0x11),
    StandaloneStage('brinstar_escape','Brinstar Escape','Escape from Brinstar','GrNZr.dat',0x42,0x1A,0x1B),
    StandaloneStage('corneria_2','Corneria Part 2','Survive the Arwings','GrCn.dat',0x47,0x2A,0x2B),
    StandaloneStage('fzero_route','F-Zero Grand Prix','Reach the finish line','GrNBr.dat',0x49,0x38,0x3A),
    # Race to the Finish is PushOn (GrNPo), not Poke Floats (GrPu).
    StandaloneStage('race_to_finish','Race to the Finish','Reach the exit','GrNPo.dat',0x52,0x12,0x12),
    *(StandaloneStage(f'link_arena_{n+1}',f'Link Arena {n+1}','Underground Maze',
                      'GrNSr.dat',0x3F,0x11,0x11,'versus',n) for n in range(6)),
    StandaloneStage('yoshi_arena','Yoshi Arena','Mushroom Kingdom','GrNKr.dat',0x3B,0x01,0x01,'versus',0),
)
LAST_MARKER = FIRST_MARKER+len(STAGES)-1


def resolve_marker(marker: int) -> StandaloneStage | None:
    if not FIRST_MARKER <= marker <= LAST_MARKER:
        return None
    return STAGES[marker-FIRST_MARKER]


def page_entries() -> list[dict]:
    return [dict(asdict(s),grid_slot=i,wire_marker=FIRST_MARKER+i,
                 return_destination='direct_stage_select') for i,s in enumerate(STAGES)]


def audit_resources(iso) -> list[dict]:
    return [dict(filename=name,bytes=iso.find_file(name).size)
            for name in sorted({s.filename for s in STAGES})]
