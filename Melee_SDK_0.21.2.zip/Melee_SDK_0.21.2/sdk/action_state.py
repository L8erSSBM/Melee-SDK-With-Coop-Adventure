from __future__ import annotations

import struct
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .dol_patch import DOLImage, SymbolMap

ENTRY_SIZE = 0x20
BE_8U32 = struct.Struct('>8I')


@dataclass(frozen=True)
class MotionStateEntry:
    index: int
    address: int
    anim_id: int
    state_flags: int
    move_flags: int
    anim_cb: int
    input_cb: int
    phys_cb: int
    coll_cb: int
    cam_cb: int

    def as_dict(self) -> dict[str, Any]:
        return asdict(self)


class MotionStateTableEditor:
    """Address-aware editor for the decomp-defined MotionState[ ] tables.

    This deliberately edits only entries already backed by DOL data. Creating a
    genuinely larger table still requires executable/data-section expansion and
    loader-count patching; Phase 15 exposes that boundary instead of silently
    writing past a symbol.
    """

    def __init__(self, dol: DOLImage, symbols: SymbolMap):
        self.dol = dol
        self.symbols = symbols

    def table_capacity(self, symbol_name: str) -> int:
        sym = self.symbols.require(symbol_name)
        if sym.size is None:
            raise ValueError(f'{symbol_name} has no declared size in the symbol map')
        if sym.size % ENTRY_SIZE:
            raise ValueError(f'{symbol_name} size 0x{sym.size:X} is not a whole MotionState table')
        return sym.size // ENTRY_SIZE

    def read_table(self, symbol_name: str, count: int | None = None) -> list[MotionStateEntry]:
        sym = self.symbols.require(symbol_name)
        cap = self.table_capacity(symbol_name)
        count = cap if count is None else int(count)
        if not 0 <= count <= cap:
            raise ValueError(f'Requested count {count} exceeds table capacity {cap}')
        raw = self.dol.read_at_address(sym.address, count * ENTRY_SIZE)
        out=[]
        for i in range(count):
            vals=BE_8U32.unpack_from(raw,i*ENTRY_SIZE)
            out.append(MotionStateEntry(i,sym.address+i*ENTRY_SIZE,*vals))
        return out

    def validate_table(self, symbol_name: str, count: int | None = None) -> dict[str, Any]:
        entries=self.read_table(symbol_name,count)
        callback_fields=('anim_cb','input_cb','phys_cb','coll_cb','cam_cb')
        bad=[]
        for e in entries:
            for key in callback_fields:
                ptr=getattr(e,key)
                if ptr == 0:
                    continue
                try:
                    sec=self.dol.section_for_address(ptr,4)
                except Exception:
                    bad.append({'index':e.index,'field':key,'address':ptr})
                else:
                    if sec.kind != 'text':
                        bad.append({'index':e.index,'field':key,'address':ptr,'section':sec.kind})
        return {'symbol':symbol_name,'entries':len(entries),'callback_errors':bad,'status':'PASS' if not bad else 'FAIL'}

    def clone_entry(self, symbol_name: str, source_index: int, destination_index: int) -> dict[str, Any]:
        cap=self.table_capacity(symbol_name)
        if not (0 <= source_index < cap and 0 <= destination_index < cap):
            raise IndexError('MotionState index outside existing table capacity')
        sym=self.symbols.require(symbol_name)
        src_addr=sym.address+source_index*ENTRY_SIZE
        dst_addr=sym.address+destination_index*ENTRY_SIZE
        data=self.dol.read_at_address(src_addr,ENTRY_SIZE)
        expected=self.dol.read_at_address(dst_addr,ENTRY_SIZE)
        row=self.dol.patch_at_address(dst_addr,data,expected)
        row.update({'table':symbol_name,'source_index':source_index,'destination_index':destination_index})
        return row

    def set_callback(self, symbol_name: str, index: int, callback: str, target_symbol: str | None) -> dict[str, Any]:
        fields={'anim':0x0C,'iasa':0x10,'input':0x10,'phys':0x14,'coll':0x18,'camera':0x1C,'cam':0x1C}
        if callback not in fields:
            raise KeyError(callback)
        cap=self.table_capacity(symbol_name)
        if not 0 <= index < cap:
            raise IndexError(index)
        table=self.symbols.require(symbol_name)
        addr=table.address+index*ENTRY_SIZE+fields[callback]
        target=0 if target_symbol is None else self.symbols.require(target_symbol).address
        if target:
            sec=self.dol.section_for_address(target,4)
            if sec.kind != 'text':
                raise ValueError(f'Callback target {target_symbol} is not in a DOL text section')
        expected=self.dol.read_at_address(addr,4)
        row=self.dol.patch_at_address(addr,struct.pack('>I',target),expected)
        row.update({'table':symbol_name,'index':index,'callback':callback,'target_symbol':target_symbol,'target_address':target})
        return row

    def set_anim_id(self, symbol_name: str, index: int, anim_id: int) -> dict[str, Any]:
        cap=self.table_capacity(symbol_name)
        if not 0 <= index < cap: raise IndexError(index)
        table=self.symbols.require(symbol_name); addr=table.address+index*ENTRY_SIZE
        expected=self.dol.read_at_address(addr,4)
        row=self.dol.patch_at_address(addr,struct.pack('>I',int(anim_id)&0xFFFFFFFF),expected)
        row.update({'table':symbol_name,'index':index,'anim_id':int(anim_id)})
        return row
