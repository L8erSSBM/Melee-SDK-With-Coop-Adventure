from __future__ import annotations

from dataclasses import dataclass, asdict
from typing import Any

from .stage import StageDAT


@dataclass(frozen=True)
class CollisionPrimitive:
    key: str
    label: str
    category: str
    x0: float
    y0: float
    x1: float
    y1: float
    platform: bool = False
    ledge: bool = False
    dynamic_platform_source: bool = False
    description: str = ''


PRIMITIVES = (
    CollisionPrimitive('floor', 'Floor / Ground', 'Floor', -20.0, 0.0, 20.0, 0.0,
                       description='A normal solid walkable floor segment.'),
    CollisionPrimitive('slope', 'Slope / Ramp', 'Floor', -20.0, 0.0, 20.0, 10.0,
                       description='A normal solid floor segment with an incline.'),
    CollisionPrimitive('soft_platform', 'Soft / Drop-Through Platform', 'Floor', -15.0, 18.0, 15.0, 18.0,
                       platform=True,
                       description='One-way/drop-through floor using the source-known platform flag; no underside ceiling or side walls are created.'),
    CollisionPrimitive('ledge_floor', 'Grab-Enabled Floor', 'Floor', -18.0, 0.0, 18.0, 0.0,
                       ledge=True,
                       description='Floor with the source-known ledge/grab flag. Exact endpoint behavior remains available in Advanced Collision.'),
    CollisionPrimitive('right_wall', 'Right Wall', 'Right Wall', 0.0, -15.0, 0.0, 15.0,
                       description='Explicit right-wall collision; no floor or ceiling is implied.'),
    CollisionPrimitive('left_wall', 'Left Wall', 'Left Wall', 0.0, -15.0, 0.0, 15.0,
                       description='Explicit left-wall collision; no floor or ceiling is implied.'),
    CollisionPrimitive('ceiling', 'Ceiling', 'Ceiling', -18.0, 15.0, 18.0, 15.0,
                       description='Explicit ceiling collision; no floor or wall is implied.'),
)
PRIMITIVE_BY_KEY = {p.key: p for p in PRIMITIVES}


def primitive_catalog() -> list[dict[str, Any]]:
    return [asdict(p) for p in PRIMITIVES]


def compatible_joint_indices(stage: StageDAT, category: str) -> list[int]:
    """Return MapJoints whose insertion point lies inside the global category range.

    This is the same structural precondition used by StageDAT.add_collision_segment,
    exposed to the friendly builder so it can avoid presenting obviously invalid
    owners. It does not infer gameplay ownership or animation semantics.
    """
    summary = stage.collision_summary()
    if summary is None:
        return []
    key = category.strip().lower().replace(' ', '_')
    start_name = key + '_start'
    count_name = key + '_count'
    if not hasattr(summary, start_name):
        return []
    gs = getattr(summary, start_name)
    gc = getattr(summary, count_name)
    out = []
    for i, j in enumerate(stage.map_joints()):
        if start_name not in j or count_name not in j:
            continue
        insert = j[start_name] + j[count_name]
        if gs <= insert <= gs + gc:
            out.append(i)
    return out


def suggested_joint_index(stage: StageDAT, category: str) -> int:
    candidates = compatible_joint_indices(stage, category)
    if not candidates:
        raise ValueError(f'No structurally compatible MapJoint is available for {category} collision.')
    key = category.strip().lower().replace(' ', '_')
    count_name = key + '_count'
    joints = stage.map_joints()
    # Prefer an owner already containing this collision category, then the owner
    # with the broadest vertex range. This is only a builder convenience choice;
    # the user can override it in Advanced mode.
    return max(candidates, key=lambda i: (joints[i].get(count_name, 0), joints[i].get('vtx_count', 0)))


def add_primitive(stage: StageDAT, primitive_key: str, *, joint_index: int | None = None,
                  x0: float | None = None, y0: float | None = None,
                  x1: float | None = None, y1: float | None = None,
                  material_id: int = 0, platform: bool | None = None,
                  ledge: bool | None = None, dynamic_platform_source: bool | None = None) -> dict[str, Any]:
    if primitive_key not in PRIMITIVE_BY_KEY:
        raise KeyError(primitive_key)
    p = PRIMITIVE_BY_KEY[primitive_key]
    if joint_index is None:
        joint_index = suggested_joint_index(stage, p.category)
    result = stage.add_collision_segment(
        joint_index=int(joint_index), category=p.category,
        x0=p.x0 if x0 is None else float(x0), y0=p.y0 if y0 is None else float(y0),
        x1=p.x1 if x1 is None else float(x1), y1=p.y1 if y1 is None else float(y1),
        material_id=int(material_id),
        platform=p.platform if platform is None else bool(platform),
        ledge=p.ledge if ledge is None else bool(ledge),
        dynamic_platform_source=p.dynamic_platform_source if dynamic_platform_source is None else bool(dynamic_platform_source),
    )
    result.update({'primitive_key': p.key, 'primitive_label': p.label})
    return result


def add_library_collision_line(stage: StageDAT, row: dict[str, Any], *, joint_index: int | None = None,
                               offset_x: float = 0.0, offset_y: float = 0.0,
                               scale_x: float = 1.0, scale_y: float = 1.0,
                               flip_x: bool = False) -> dict[str, Any]:
    """Copy one catalogued retail collision record into the working stage.

    Deliberately collision-only: no JObj, material display object, texture, or
    animation ownership is guessed or transplanted. This makes the operation
    useful today while keeping visual/animated asset bundles for a later,
    source-grounded layer.
    """
    if not isinstance(row, dict) or 'p0' not in row or 'p1' not in row or 'category' not in row:
        raise ValueError('Asset-library row is missing collision geometry metadata.')
    category = str(row['category'])
    # Horizontal reflection changes the semantic facing of explicit wall
    # collision. Keep that source-known distinction intact.
    if flip_x and category == 'Right Wall':
        category = 'Left Wall'
    elif flip_x and category == 'Left Wall':
        category = 'Right Wall'
    if joint_index is None:
        joint_index = suggested_joint_index(stage, category)
    sx = -float(scale_x) if flip_x else float(scale_x)
    sy = float(scale_y)
    if sx == 0 or sy == 0:
        raise ValueError('Asset scale cannot be zero.')
    p0, p1 = row['p0'], row['p1']
    x0 = float(p0[0]) * sx + float(offset_x)
    y0 = float(p0[1]) * sy + float(offset_y)
    x1 = float(p1[0]) * sx + float(offset_x)
    y1 = float(p1[1]) * sy + float(offset_y)
    result = stage.add_collision_segment(
        joint_index=int(joint_index), category=category,
        x0=x0, y0=y0, x1=x1, y1=y1,
        material_id=int(row.get('material_id', 0)),
        platform=bool(row.get('platform', False)),
        ledge=bool(row.get('ledge', False)),
        dynamic_platform_source=bool(row.get('dynamic_platform_source', False)),
    )
    result.update({'library_copy': True, 'source_line_index': row.get('index')})
    return result
