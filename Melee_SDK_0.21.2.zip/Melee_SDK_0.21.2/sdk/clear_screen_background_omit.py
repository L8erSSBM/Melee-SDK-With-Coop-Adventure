"""HF29E: omit the optional captured-results background for Co-op Team Kirby.

HF29C proved that omitting the optional captured-gameplay background is the
right way to preserve Results renderer headroom for the double-Icies stress
case. ``DoubleSheik(1).sav`` then proved the scope was too narrow: the failing
double-Sheik Team-Kirby clear still contained a full 640x480 RGB5A3 captured
background (614,400 bytes) and the active OS heap had no free-list cells left.
The panic occurs later while HSD_SListAlloc/HSD_ObjAlloc is loading required
Results PObj/envelope data through lbRefract_PObjLoad.

The captured gameplay background in ``fn_80180630`` is optional presentation:
``lbl_80472D28`` is zeroed at entry, and the callback that dereferences x2C is
installed only on the background GObj created by the skipped block. HF29D
therefore applies the same omission to any established Co-op Adventure
Team-Kirby campaign, independent of fighter choice. It still requires the exact
640x480 RGB5A3 allocation signature and resumes at 0x80180A50, preserving the
Results model, score text, audio, and normal scene progression.

Outside that exact Co-op Team-Kirby path the original allocation call is
tail-entered unchanged.
"""
from __future__ import annotations

import struct

from .ppc import addi, cmpwi, encode_bc, encode_branch, lbz, lis, lwz, stw

ALLOC_SITE = 0x80180A08
ALLOC_RETAIL = 0x800121FC
BACKGROUND_CONTINUE = 0x80180A50
ADVENTURE_MODE_ADDR = 0x80479D30
ADVENTURE_STATE_ADDR = 0x80479D33
GM_ADVENTURE = 4
TEAM_KIRBY_FIGHT_STATE = 0x23


def _word(value: int) -> bytes:
    return struct.pack('>I', value & 0xFFFFFFFF)


class Asm:
    def __init__(self, base: int):
        self.base = int(base)
        self.data = bytearray()
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str, int, int]] = []

    def emit(self, *chunks: bytes) -> None:
        for chunk in chunks:
            self.data.extend(chunk)

    def constant(self, reg: int, value: int) -> None:
        value &= 0xFFFFFFFF
        self.emit(lis(reg, (value + 0x8000) >> 16),
                  addi(reg, reg, value & 0xFFFF))

    def load_byte_abs(self, reg: int, address: int) -> None:
        self.constant(12, address)
        self.emit(lbz(reg, 0, 12))

    def label(self, name: str) -> None:
        self.labels[name] = len(self.data)

    def branch(self, label: str, *, bo: int = 20, bi: int = 0) -> None:
        self.fixups.append((len(self.data), label, bo, bi))
        self.emit(bytes(4))

    def finish(self) -> bytes:
        for off, label, bo, bi in self.fixups:
            self.data[off:off + 4] = encode_bc(
                self.base + off, self.base + self.labels[label], bo=bo, bi=bi)
        return bytes(self.data)


def wrapper(base: int, coop_campaign_valid_addr: int, skip_counter_addr: int) -> bytes:
    """Return a leaf/tail wrapper for the retail image allocation call.

    The hook is entered by ``bl`` from fn_80180630.  The retail path tail-branches
    into lb_800121FC so its return lands at the original callsite+4.  The skip
    path instead jumps directly inside fn_80180630 after the optional background
    block.  No stack frame is needed and only volatile registers r11/r12 are
    used for gating/diagnostics.
    """
    a = Asm(base)

    # Exact narrow scope: Adventure + established co-op campaign + Team Kirby
    # + the original 640x480 RGB5A3 allocation signature.
    a.load_byte_abs(11, ADVENTURE_MODE_ADDR)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7)); a.branch('retail', bo=4, bi=30)
    a.load_byte_abs(11, coop_campaign_valid_addr)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('retail', bo=4, bi=30)
    a.load_byte_abs(11, ADVENTURE_STATE_ADDR)
    a.emit(cmpwi(11, TEAM_KIRBY_FIGHT_STATE, crf=7)); a.branch('retail', bo=4, bi=30)
    for reg, value in ((4, 640), (5, 480), (6, 5), (7, 0)):
        a.emit(cmpwi(reg, value, crf=7)); a.branch('retail', bo=4, bi=30)

    # Durable diagnostic: count only deliberate background omissions.
    a.constant(12, skip_counter_addr)
    a.emit(lwz(11, 0, 12), addi(11, 11, 1), stw(11, 0, 12))
    a.emit(encode_branch(base + len(a.data), BACKGROUND_CONTINUE))

    a.label('retail')
    a.emit(encode_branch(base + len(a.data), ALLOC_RETAIL))
    return a.finish()


def install(dol, runtime_index: int, coop_campaign_valid_addr: int) -> dict:
    expected = encode_branch(ALLOC_SITE, ALLOC_RETAIL, link=True)
    got = dol.read_at_address(ALLOC_SITE, 4)
    if got != expected:
        raise ValueError(
            f'HF29E background-omit expected retail allocation call at '
            f'{ALLOC_SITE:#x}; got {got.hex()}')

    section = next(s for s in dol.sections
                   if s.kind == 'data' and s.index == int(runtime_index))
    base = section.address + ((section.size + 31) & ~31)
    payload = bytearray(b'HF29CBGO' + bytes(24))
    skip_counter_addr = base + 0x10
    stub_addr = base + 0x20
    blob = wrapper(stub_addr, coop_campaign_valid_addr, skip_counter_addr)
    payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(runtime_index, payload)
    assert added['address'] == base

    site_branch = encode_branch(ALLOC_SITE, stub_addr, link=True)
    dol.patch_at_address(ALLOC_SITE, site_branch, expected=expected)
    return {
        'marker': 'HF29CBGO',
        'section': added,
        'site_address': ALLOC_SITE,
        'site_branch': site_branch.hex(),
        'stub_address': stub_addr,
        'skip_counter': skip_counter_addr,
        'background_continue': BACKGROUND_CONTINUE,
        'retail_allocation': ALLOC_RETAIL,
        'scope': 'established Co-op Adventure Team-Kirby clear only; fighter-independent',
        'behavior': 'omit optional captured gameplay background; preserve results model/text/audio and retail progression',
        'reason': 'DoubleSheik(1).sav: full 640x480 results capture remained allocated and active heap free-list was empty before required Results PObj/SList allocation; generalize proven HF29C omission from Icies-only to all co-op Team-Kirby clears',
        'runtime_validation': 'pending Dolphin reproduction',
    }
