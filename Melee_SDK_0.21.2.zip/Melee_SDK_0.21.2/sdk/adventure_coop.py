from __future__ import annotations

import json
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Iterable

from .one_player_resources import ADVENTURE_STAGE_RESOURCES, adventure_resource_audit

# Source-grounded retail Adventure stage identities.  The StKind indices
# 59..81 come from gr/stage.c::stage_id_map; filenames come from the StageData
# declarations in the corresponding gr modules.  These are existing retail
# resources, not SDK-created replacement stages.
ADVENTURE_STAGE_CATALOG = [
    (stkind, name, ('platform' if encounter_type == 'route' else 'battle'), grkind, filename)
    for stkind, _chapter, name, filename, grkind, encounter_type in ADVENTURE_STAGE_RESOURCES
]

# A single linear campaign preserving the retail Adventure chapter order.  Some
# chapters contain multiple scene/match phases; those remain under one chapter.
CHAPTERS = [
    (1, 'Mushroom Kingdom', [59, 60]),
    (2, 'Kongo Jungle', [61, 62]),
    (3, 'Underground Maze', [63, 64]),
    (4, 'Brinstar', [65, 66]),
    (5, 'Green Greens', [67, 68, 69]),
    (6, 'Corneria', [70, 71]),
    (7, 'Pokemon Stadium', [72]),
    (8, 'F-Zero Grand Prix', [73, 74]),
    (9, 'Onett', [75]),
    (10, 'Icicle Mountain', [76, 77]),
    (11, 'Battlefield', [78, 79]),
    (12, 'Final Destination', [80, 81]),
]

@dataclass
class CoopRules:
    p1_port: int = 0
    p2_port: int = 1
    shared_team: int = 0
    enemy_team: int = 1
    friendly_fire: bool = False
    shared_stocks: bool = True
    p2_character_kind: int | None = None
    p2_color: int = 1
    max_simultaneous_enemies: int = 2
    camera_policy: str = 'native_multiplayer'
    offscreen_policy: str = 'respawn_near_partner'

    def validate(self):
        if self.p1_port == self.p2_port: raise ValueError('P1 and P2 ports must differ')
        if self.p1_port not in range(4) or self.p2_port not in range(4): raise ValueError('ports must be 0..3')
        if self.max_simultaneous_enemies not in (1,2):
            raise ValueError('4-slot StartMeleeData leaves at most two simultaneous enemy slots in 2P co-op')

@dataclass
class AdventureSegment:
    stkind: int
    name: str
    kind: str
    grkind_name: str
    enabled: bool = True
    notes: str = ''
    filename: str | None = None

@dataclass
class AdventureChapter:
    number: int
    name: str
    segments: list[AdventureSegment] = field(default_factory=list)

@dataclass
class CoopAdventureCampaign:
    name: str = 'Co-op Adventure'
    format: str = 'melee-sdk-coop-adventure-v1'
    rules: CoopRules = field(default_factory=CoopRules)
    chapters: list[AdventureChapter] = field(default_factory=list)
    continue_between_chapters: bool = True
    preserve_cutscenes: bool = True
    preserve_special_routes: bool = True

    @classmethod
    def vanilla_sequence(cls, name='Co-op Adventure') -> 'CoopAdventureCampaign':
        by_id = {x[0]: x for x in ADVENTURE_STAGE_CATALOG}
        chapters=[]
        for num, title, ids in CHAPTERS:
            seg=[]
            for sid in ids:
                st,name2,kind,gr,filename=by_id[sid]
                seg.append(AdventureSegment(st,name2,kind,gr,filename=filename))
            chapters.append(AdventureChapter(num,title,seg))
        c=cls(name=name,chapters=chapters); c.validate(); return c

    def validate(self):
        self.rules.validate()
        if not self.chapters: raise ValueError('campaign must contain at least one chapter')
        seen=[]
        for ch in self.chapters:
            for s in ch.segments:
                if s.enabled: seen.append(s.stkind)
                if s.kind not in ('platform','battle'): raise ValueError(f'bad segment kind {s.kind}')
        if not seen: raise ValueError('campaign has no enabled segments')

    def to_dict(self):
        return asdict(self)

    def save(self, path: str|Path) -> Path:
        self.validate(); p=Path(path); p.write_text(json.dumps(self.to_dict(),indent=2),encoding='utf-8'); return p

    @classmethod
    def load(cls, path: str|Path) -> 'CoopAdventureCampaign':
        d=json.loads(Path(path).read_text(encoding='utf-8'))
        if d.get('format')!='melee-sdk-coop-adventure-v1': raise ValueError('unsupported campaign format')
        rules=CoopRules(**d['rules'])
        chapters=[AdventureChapter(c['number'],c['name'],[AdventureSegment(**s) for s in c['segments']]) for c in d['chapters']]
        obj=cls(d['name'],d['format'],rules,chapters,d.get('continue_between_chapters',True),d.get('preserve_cutscenes',True),d.get('preserve_special_routes',True))
        obj.validate(); return obj

    def linear_segments(self) -> list[AdventureSegment]:
        return [s for c in self.chapters for s in c.segments if s.enabled]

    def compatibility_report(self) -> list[dict]:
        out=[]
        for ch in self.chapters:
            for s in ch.segments:
                risk='normal'
                reason='standard battle setup; reserve P1/P2 and up to two enemy slots'
                if s.kind=='platform':
                    risk='special-route'
                    reason='route stage needs two-player spawn/camera/checkpoint handling'
                if s.stkind in (68,72,78):
                    risk='wave-battle'
                    reason='retail encounter uses multi-enemy/wave behavior; co-op runtime must preserve waves while reserving P2'
                if s.stkind in (80,81):
                    risk='boss/final'
                    reason='final encounter has boss/result assumptions that must treat both humans as the player team'
                out.append({'chapter':ch.number,'stkind':s.stkind,'name':s.name,'risk':risk,'reason':reason})
        return out

    def runtime_plan(self) -> dict:
        """Return a source-grounded implementation plan, not fake executable code."""
        self.validate()
        return {
            'format':'melee-sdk-coop-adventure-runtime-plan-v1',
            'campaign':self.name,
            'entry_mode':'GM_ADVENTURE',
            'sequence':[s.stkind for s in self.linear_segments()],
            'source_hooks':[
                {'symbol':'gm_801B4064','purpose':'Adventure VS scene setup; calls gm_8017CE34'},
                {'symbol':'gm_8017CE34','purpose':'Builds StartMeleeData; retail creates P1 then enemy slots'},
                {'symbol':'gm_8017D7AC','purpose':'1P match completion/progression accounting'},
                {'symbol':'gm_8017E7A0','purpose':'route-stage timeout stock handling currently hardcodes player 0'},
            ],
            'required_runtime_changes':[
                'reserve StartMeleeData.players[0] and [1] for two humans before enemy allocation',
                'limit simultaneous CPU allocation to players[2] and [3] and preserve wave spawning for team battles',
                'make stock/result/progression checks operate on the human team rather than only player_standings[0]',
                'spawn P2 on route stages and add partner recovery/offscreen policy',
                'keep the retail Adventure GameModeState sequence so all chapters run as one continuous mode',
            ],
            'retail_resource_model':'uses Melee retail Adventure stages/resources in-place; SDK does not recreate the Adventure stages',
            'required_stage_files': sorted({s.filename for s in self.linear_segments() if s.filename}),
            'hard_limit':'StartMeleeData has four PlayerInitData records; two-human co-op leaves two simultaneous CPU slots.',
        }


def write_campaign_bundle(directory: str|Path, campaign: CoopAdventureCampaign|None=None) -> Path:
    root=Path(directory); root.mkdir(parents=True,exist_ok=True)
    campaign=campaign or CoopAdventureCampaign.vanilla_sequence()
    campaign.save(root/'coop_adventure.json')
    (root/'runtime_plan.json').write_text(json.dumps(campaign.runtime_plan(),indent=2),encoding='utf-8')
    (root/'compatibility.json').write_text(json.dumps(campaign.compatibility_report(),indent=2),encoding='utf-8')
    return root
