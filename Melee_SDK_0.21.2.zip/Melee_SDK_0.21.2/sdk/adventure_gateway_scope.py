"""HF29G: scope Co-op Adventure to an explicit gateway launch.

HF29F made Adventure *returns* origin-aware, but the Phase-43 co-op handlers
were still gated primarily by ``current_mode == GM_ADVENTURE``.  That meant an
ordinary retail 1-P Adventure campaign could enter P2/event/camera handlers
that only make sense for the SDK two-human gateway.

This layer deliberately does not rewrite the proven HF29E/F handlers.  It adds
one campaign boolean, captured at Adventure OnLoad from the gateway's existing
one-shot ``gateway_pending`` byte, and installs small dispatch guards in front
of every behavior-changing co-op hook.  Inactive campaigns execute the exact
retail instruction/callee.  Active campaigns tail-enter the already-installed
handler unchanged.

The same boolean scopes the Team-Kirby memory protections.  Finally, the
zero-team-stock Game Over call is redirected to retail ``routing.prev_mode``
only while gateway co-op is active; ordinary 1-P continues into the retail
Adventure Game Over / Continue state unchanged.
"""
from __future__ import annotations

from dataclasses import dataclass
import struct

from .early_clear_failsafe import Asm
from .ppc import (addi, cmpwi, decode_branch, encode_bc, encode_branch, lbz,
                  lis, lwz, mtlr, stb, stw, stwu)

# Retail state-machine routing.
STATE_MACHINE = 0x80479D30
CURRENT_MODE = STATE_MACHINE + 0x00
PREVIOUS_MODE = STATE_MACHINE + 0x02
GM_ADVENTURE = 4
GM_ADVENTURE_GOVER = 0x16
GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE = 0x801A42F8
GM_SET_NEXT_GAME_MODE_STATE_ID = 0x801A42A0
GM_SET_GAME_MODE_STATE_ID = 0x801A428C

# Existing gateway entry point.  HF29G captures gateway_pending here *before*
# the HF29F/Phase-43 gateway wrapper consumes and clears it.
ADVENTURE_ONLOAD = 0x801B5214

# SDK 0.20.13: retail gm_Mode_Adventure_OnLoad finishes by loading state 0x70
# (Back to CSS) into r3 and calling gm_SetGameModeStateId here.  0.20.12
# attempted to force state 0x68 at the *start* of OnLoad, but this final retail
# call overwrote it.  Intercept the commit point instead.
ADVENTURE_ONLOAD_FINAL_STATE_CALL = 0x801B5304
ADVENTURE_ONLOAD_FINAL_STATE_EXPECTED = encode_branch(
    ADVENTURE_ONLOAD_FINAL_STATE_CALL, GM_SET_GAME_MODE_STATE_ID, link=True)

# Zero representative-stock path in gm_8017D7AC.  Retail calls
# gm_SetNextGameModeStateId here, which enters Adventure Game Over/Continue.
GAME_OVER_STATE_CALL = 0x8017D984
GAME_OVER_STATE_EXPECTED = encode_branch(
    GAME_OVER_STATE_CALL, GM_SET_NEXT_GAME_MODE_STATE_ID, link=True)

# HF29F's three origin-aware exits.  HF29G makes those origin rewrites
# explicitly gateway-co-op-only; inactive retail 1-P tail-enters the original
# retail routing helper instead.
ABORT_RETURN_CALL = 0x8017D8F0
CSS_CANCEL_RETURN_CALL = 0x801B4390
CAMPAIGN_COMPLETE_SET_PENDING_CALL = 0x801B4418
GM_SET_PENDING_GAME_MODE = 0x801A42E8
GM_SET_NEW_GAME_MODE_PENDING = 0x801A42D4

# SDK 0.20.7: normal Adventure completion exits Staff Roll through the shared
# GOver congratulations callback.  On its no-challenger path this linked call
# receives the GOver scene exit mode and is immediately followed by retail
# gm_SetNewGameModePending().  Override only this call while a captured gateway
# campaign is active; do not treat it as the same lifecycle as Quit/Game Over.
POST_STAFFROLL_RETURN_CALL = 0x801BEF24
POST_STAFFROLL_RETURN_RETAIL = encode_branch(
    POST_STAFFROLL_RETURN_CALL, GM_SET_PENDING_GAME_MODE, link=True)

ABORT_RETAIL = encode_branch(
    ABORT_RETURN_CALL, GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE, link=True)
CSS_CANCEL_RETAIL = encode_branch(
    CSS_CANCEL_RETURN_CALL, GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE, link=True)
CAMPAIGN_COMPLETE_RETAIL = encode_branch(
    CAMPAIGN_COMPLETE_SET_PENDING_CALL, GM_SET_PENDING_GAME_MODE, link=True)

# Memory protections layered after Phase-43 core hooks.
CLEAR_BACKGROUND_SITE = 0x80180A08
CLEAR_BACKGROUND_RETAIL = 0x800121FC
CLEAR_BACKGROUND_EXPECTED = encode_branch(
    CLEAR_BACKGROUND_SITE, CLEAR_BACKGROUND_RETAIL, link=True)
SLIST_REFILL_SITE = 0x8037ACBC
SLIST_REFILL_RETAIL = 0x8037A968
SLIST_REFILL_EXPECTED = encode_branch(
    SLIST_REFILL_SITE, SLIST_REFILL_RETAIL, link=True)


@dataclass(frozen=True)
class GuardSpec:
    name: str
    site: int
    retail: bytes


# Every gameplay-changing Phase-43 co-op hook that must be transparent during
# a normal retail 1-P Adventure run.  Test-only 1P C-stick remains intentionally
# global to 1P modes.  HF21 transition tracing is diagnostic-only and therefore
# does not belong in this behavior gate.
CORE_GUARDS = (
    GuardSpec('p2_setup', 0x8017D194, bytes.fromhex('3b830001')),
    GuardSpec('spawn_multislot_gate', 0x8016E2F8, bytes.fromhex('4182015c')),
    GuardSpec('singleplayer_p2_loader', 0x8016DEA4, bytes.fromhex('3be00001')),
    GuardSpec('survivor_respawn_anchor', 0x80167248, bytes.fromhex('4becbb39')),
    GuardSpec('ffa_team_stock_outcome', 0x8016BFA0, bytes.fromhex('4bec7cad')),
    GuardSpec('team_team_stock_outcome', 0x8016C0F4, bytes.fromhex('4bec7b59')),
    GuardSpec('ground_control_owner', 0x801C57A4, bytes.fromhex('7c0802a6')),
    GuardSpec('camera_control_owner', 0x8002B23C, bytes.fromhex('48008ed5')),
    GuardSpec('cross_chapter_stock_capture', 0x8017D90C, bytes.fromhex('881d006c')),
    GuardSpec('event_allocator_reserve_humans', 0x8016A0D8, bytes.fromhex('3bc00000')),
    GuardSpec('dynamic_enemy_slot_marker', 0x8016A5A4, bytes.fromhex('48058781')),
    GuardSpec('team_kirby_event_manager_repair', 0x8016A4C8, bytes.fromhex('7c0802a6')),
    GuardSpec('team_kirby_bonus_guard', 0x80039618, bytes.fromhex('7c0802a6')),
    GuardSpec('adventure_hud_capacity', 0x8016E9B0, bytes.fromhex('48187cad')),
    GuardSpec('dual_player_credits_input', 0x801BF010, bytes.fromhex('3c60804a')),
    GuardSpec('either_human_ground_events', 0x801C0C2C, bytes.fromhex('7c0802a6')),
    GuardSpec('wireframe_human_physics_guard', 0x80034B0C, bytes.fromhex('7c0802a6')),
    GuardSpec('presentation_p2_start', 0x801A36A0, bytes.fromhex('5460063e')),
    GuardSpec('luigi_cpu_substitution', 0x801B461C, bytes.fromhex('7c0802a6')),
    GuardSpec('falco_cpu_substitution', 0x801B4DAC, bytes.fromhex('7c0802a6')),
    GuardSpec('team_kirby_non_giant_exit', 0x801B4C5C, bytes.fromhex('7c0802a6')),
    GuardSpec('either_player_pause_mode', 0x8016BC8C, bytes.fromhex('48038685')),
    GuardSpec('team_kirby_results_background_omit', CLEAR_BACKGROUND_SITE,
              CLEAR_BACKGROUND_EXPECTED),
    GuardSpec('team_kirby_slist_pool_packing', SLIST_REFILL_SITE,
              SLIST_REFILL_EXPECTED),
)

# SDK 0.20.5 extends the validated HF29G guard set without redefining the
# historical 24-hook HF29G contract used by archival regression manifests.
SDK0205_EXTRA_GUARDS = (
    GuardSpec('static_fighter_spawn_slot_remap', 0x8016E48C, bytes.fromhex('387c0000')),
    GuardSpec('rebirth_owner_preflight', 0x8016719C, bytes.fromhex('7c0802a6')),
)
ACTIVE_GUARDS = CORE_GUARDS + SDK0205_EXTRA_GUARDS


def _addr_parts(address: int) -> tuple[int, int]:
    lo = int(address) & 0xFFFF
    signed_lo = lo - 0x10000 if lo & 0x8000 else lo
    hi = ((int(address) - signed_lo) >> 16) & 0xFFFF
    return hi, signed_lo


def _load_active(out: bytearray, active_addr: int, target: int = 11,
                 scratch: int = 12) -> None:
    hi, lo = _addr_parts(active_addr)
    out += lis(scratch, hi)
    out += lbz(target, lo, scratch)


def _store_active(out: bytearray, active_addr: int, source: int = 11,
                  scratch: int = 12) -> None:
    hi, lo = _addr_parts(active_addr)
    out += lis(scratch, hi)
    out += stb(source, lo, scratch)


def _retail_tail(base: int, site: int, retail: bytes, *, entry_link: bool) -> bytes:
    """Emit exact displaced retail behavior then continue/return normally."""
    word = struct.unpack('>I', retail)[0]
    opcode = word >> 26
    if opcode == 18:  # b/bl
        decoded = decode_branch(site, retail)
        target = decoded['target']
        if not decoded['link'] or entry_link:
            # A retail B is always a tail branch.  A retail BL can also be
            # tail-entered when this guard itself was entered by BL, because
            # LR already contains the original site+4 return address.
            return encode_branch(base, target)
        # Some Phase-43 wrappers replaced a retail BL with a plain B and own
        # the continuation themselves (dynamic enemy spawn is one).  Inactive
        # retail must therefore perform the call here and then resume site+4.
        out = bytearray()
        out += encode_branch(base + len(out), target, link=True)
        hi, lo = _addr_parts(site + 4)
        out += lis(12, hi) + addi(12, 12, lo) + mtlr(12)
        out += encode_branch(base + len(out), site + 4)
        return bytes(out)
    if opcode == 16:  # bc: reproduce CR-dependent branch using a local island.
        bo = (word >> 21) & 31
        bi = (word >> 16) & 31
        aa = bool(word & 2)
        bd = word & 0xFFFC
        if bd & 0x8000:
            bd -= 0x10000
        target = (bd if aa else site + bd) & 0xFFFFFFFF
        # bc -> local taken; b fallthrough; taken: b retail target
        taken = base + 8
        return (encode_bc(base, taken, bo=bo, bi=bi) +
                encode_branch(base + 4, site + 4) +
                encode_branch(base + 8, target))
    # Ordinary displaced instruction.
    return retail + encode_branch(base + 4, site + 4)


def _guard_wrapper(base: int, *, site: int, active_addr: int,
                   active_target: int, retail: bytes, entry_link: bool) -> bytes:
    """Dispatch active co-op to existing handler, inactive to exact retail."""
    a = Asm(base)
    # These guards can live at arbitrary instruction sites, so preserve the two
    # scratch registers and restore r1 before either tail path.
    a.emit(stwu(1, -0x10, 1), stw(11, 0x08, 1), stw(12, 0x0C, 1))
    _load_active(a.data, active_addr)
    a.emit(cmpwi(11, 1, crf=7))
    a.branch('retail', 4, 30)  # != active

    a.emit(lwz(11, 0x08, 1), lwz(12, 0x0C, 1), addi(1, 1, 0x10))
    a.emit(encode_branch(base + len(a.data), active_target))

    a.label('retail')
    a.emit(lwz(11, 0x08, 1), lwz(12, 0x0C, 1), addi(1, 1, 0x10))
    a.emit(_retail_tail(base + len(a.data), site, retail, entry_link=entry_link))
    return a.finish()


def _onload_capture_wrapper(base: int, *, pending_addr: int, active_addr: int,
                            old_target: int, origin_addr: int | None = None,
                            return_pending_addr: int | None = None) -> bytes:
    """Promote a fresh gateway launch without erasing an in-flight campaign.

    Historical HF29G (``origin_addr is None``) retains its original byte layout
    for archival reproducibility.  The captured-origin SDK path adds one crucial
    lifecycle rule: a retail Staff Roll -> Adventure re-entry must preserve an
    already-active gateway campaign even though the one-shot ``gateway_pending``
    byte has already been consumed.

    Captured-origin policy:
      * pending == 1: start a fresh gateway campaign and capture prev_mode;
      * pending != 1 + active == 1: preserve active/origin across Adventure
        re-entry (notably Staff Roll -> winning/Coming-Soon sequence);
      * otherwise: clear stale inactive state and remain retail.

    Quit, both-zero Game Over, and the successful final origin return clear the
    lifecycle bytes explicitly, so this preservation cannot leak into a later
    unrelated Adventure session.
    """
    if origin_addr is None:
        # Preserve historical HF29G byte-for-byte when captured-origin state is
        # not requested.
        out = bytearray()
        out += stwu(1, -0x10, 1)
        out += stw(11, 0x08, 1) + stw(12, 0x0C, 1)
        hi, lo = _addr_parts(pending_addr)
        out += lis(12, hi) + lbz(11, lo, 12)
        out += cmpwi(11, 1, crf=7)
        b_eq_off = len(out); out += bytes(4)
        out += addi(11, 0, 0)
        b_store_off = len(out); out += bytes(4)
        active_label = base + len(out)
        out += addi(11, 0, 1)
        store_label = base + len(out)
        out[b_eq_off:b_eq_off+4] = encode_bc(
            base + b_eq_off, active_label, bo=12, bi=30)
        out[b_store_off:b_store_off+4] = encode_branch(
            base + b_store_off, store_label)
        _store_active(out, active_addr)
        out += lwz(11, 0x08, 1) + lwz(12, 0x0C, 1) + addi(1, 1, 0x10)
        out += encode_branch(base + len(out), old_target)
        return bytes(out)

    out = bytearray()
    out += stwu(1, -0x10, 1)
    out += stw(11, 0x08, 1) + stw(12, 0x0C, 1)

    # Fresh gateway launch?
    hi, lo = _addr_parts(pending_addr)
    out += lis(12, hi) + lbz(11, lo, 12)
    out += cmpwi(11, 1, crf=7)
    b_fresh = len(out); out += bytes(4)

    # No fresh pending token. Preserve an already-active campaign.  Do not
    # select the completion state here: retail gm_Mode_Adventure_OnLoad still
    # has initialization work to do and ends by committing state 0x70.  SDK
    # 0.20.13 performs the 0x70 -> 0x68 substitution at that final commit call.
    _load_active(out, active_addr)
    out += cmpwi(11, 1, crf=7)
    b_preserve = len(out); out += bytes(4)

    # Inactive/stale path: normalize both lifecycle bytes to zero.
    out += addi(11, 0, 0)
    _store_active(out, active_addr)
    _store_active(out, origin_addr)
    if return_pending_addr is not None:
        _store_active(out, return_pending_addr)
    b_done_clear = len(out); out += bytes(4)

    # Fresh gateway path: establish active and snapshot the launcher origin.
    fresh_label = base + len(out)
    out += addi(11, 0, 1)
    _store_active(out, active_addr)
    hi, lo = _addr_parts(PREVIOUS_MODE)
    out += lis(12, hi) + lbz(11, lo, 12)
    _store_active(out, origin_addr)
    if return_pending_addr is not None:
        out += addi(0, 0, 0)
        _store_active(out, return_pending_addr, source=0)
    b_done_fresh = len(out); out += bytes(4)

    # Existing active campaign: preserve active/origin only.  The final state
    # commit wrapper decides whether this particular re-entry is the GOver
    # completion bridge; Challenger/other re-entries remain retail.
    preserve_label = base + len(out)

    done_label = base + len(out)
    out[b_fresh:b_fresh+4] = encode_bc(
        base + b_fresh, fresh_label, bo=12, bi=30)
    out[b_preserve:b_preserve+4] = encode_bc(
        base + b_preserve, preserve_label, bo=12, bi=30)
    out[b_done_clear:b_done_clear+4] = encode_branch(
        base + b_done_clear, done_label)
    out[b_done_fresh:b_done_fresh+4] = encode_branch(
        base + b_done_fresh, done_label)

    out += lwz(11, 0x08, 1) + lwz(12, 0x0C, 1) + addi(1, 1, 0x10)
    out += encode_branch(base + len(out), old_target)
    return bytes(out)


def _adventure_final_state_wrapper(base: int, *, active_addr: int) -> bytes:
    """Commit 0x68 only after retail Adventure OnLoad has fully initialized.

    Retail enters this BL site with r3=0x70 (Adventure Back-to-CSS).  The
    0.20.12 bridge changed the state too early, before retail's own final
    gm_SetGameModeStateId(0x70) call.  For an active gateway campaign returning
    specifically from Adventure GOver, substitute only that exact 0x70 request
    with 0x68 (Coming Soon).  All other callers/arguments tail-enter retail
    unchanged.
    """
    a = Asm(base)

    # Fail closed unless this is the exact retail Adventure OnLoad 0x70 commit.
    a.emit(cmpwi(3, 0x70, crf=7)); a.branch('retail', 4, 30)

    _load_active(a.data, active_addr)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('retail', 4, 30)

    hi, lo = _addr_parts(PREVIOUS_MODE)
    a.emit(lis(12, hi), lbz(11, lo, 12),
           cmpwi(11, GM_ADVENTURE_GOVER, crf=7))
    a.branch('retail', 4, 30)

    a.emit(addi(3, 0, 0x68))

    a.label('retail')
    # The original site is BL. LR already points to 0x801B5308, so a tail
    # branch reproduces the retail call/return contract exactly.
    a.emit(encode_branch(base + len(a.data), GM_SET_GAME_MODE_STATE_ID))
    return a.finish()


def _exit_scope_wrapper(base: int, *, active_addr: int, old_target: int,
                        retail_target: int, origin_addr: int | None = None,
                        return_pending_addr: int | None = None) -> bytes:
    """Return active gateway co-op to its captured launcher, otherwise retail.

    Historical HF29G delegates to HF29F when ``origin_addr`` is omitted. The
    SDK 0.20.5 path instead uses the origin captured at Adventure OnLoad, so
    campaign completion after staff roll does not depend on CURRENT_MODE or a
    late routing.prev_mode value.
    """
    a = Asm(base)
    _load_active(a.data, active_addr)
    a.emit(cmpwi(11, 1, crf=7))
    a.branch('retail', 4, 30)
    if origin_addr is None:
        a.emit(addi(11, 0, 0))
        _store_active(a.data, active_addr)
        a.emit(encode_branch(base + len(a.data), old_target))
    else:
        _load_active(a.data, origin_addr)
        # Origin 0 or Adventure itself is invalid/fail-closed to exact retail.
        a.emit(cmpwi(11, 0, crf=7)); a.branch('retail', 12, 30)
        a.emit(cmpwi(11, GM_ADVENTURE, crf=7)); a.branch('retail', 12, 30)
        # r3 = captured origin; clear campaign scope before tail-entering the
        # retail routing helper. LR already contains the original call return.
        a.emit(bytes.fromhex('7d635b78'))  # mr r3,r11
        a.emit(addi(0, 0, 0))
        _store_active(a.data, active_addr, source=0)
        _store_active(a.data, origin_addr, source=0)
        if return_pending_addr is not None:
            a.emit(addi(0, 0, 1))
            _store_active(a.data, return_pending_addr, source=0)
        a.emit(encode_branch(base + len(a.data), retail_target))
    a.label('retail')
    a.emit(encode_branch(base + len(a.data), retail_target))
    return a.finish()



def _staffroll_completion_wrapper(base: int, *, active_addr: int,
                                  origin_addr: int) -> bytes:
    """Route normal post-Staff-Roll completion with retail pending semantics.

    This wrapper replaces only the no-challenger ``gm_SetPendingGameMode`` call
    in ``gm_801BEE9C``.  Retail still owns the Congratulations/GOver teardown and
    still performs its existing ``gm_SetNewGameModePending`` immediately after
    this call.  For an active gateway campaign we change only the requested next
    major mode: GOver returns to Adventure instead of consuming its retail
    one-player/menu exit_data.

    The campaign scope is deliberately *not* cleared here.  Adventure OnLoad
    preserves the campaign scope; its final state-commit call recognizes
    ``prev_mode == GM_ADVENTURE_GOVER`` and substitutes state 0x68 (Coming
    Soon) for retail state 0x70. That state's already-guarded exit substitutes the
    captured launcher origin and clears scope.  This keeps the fragile
    GOver->VS major-mode jump out of Staff Roll while guaranteeing that the
    proven Adventure-origin return hook actually executes.

    Challenger completion deliberately bypasses this no-challenger call.  Its
    existing guarded Adventure completion path remains the fallback.
    """
    a = Asm(base)
    _load_active(a.data, active_addr)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('retail', 4, 30)

    hi, lo = _addr_parts(CURRENT_MODE)
    a.emit(lis(12, hi), lbz(11, lo, 12), cmpwi(11, GM_ADVENTURE_GOVER, crf=7))
    a.branch('retail', 4, 30)

    # SDK 0.20.12 completion bridge. Retail Congratulations normally requests
    # the 1P/menu destination stored in its exit_data.  For an active gateway
    # campaign, request Adventure instead, but DO NOT clear active/origin here.
    # Adventure OnLoad preserves the scope; its final state commit recognizes
    # prev_mode == GM_ADVENTURE_GOVER and replaces retail 0x70 with 0x68;
    # gm_801B4408 then performs the captured-origin
    # transition after the GOver major mode has fully torn down.
    a.emit(addi(3, 0, GM_ADVENTURE))

    a.label('retail')
    # BL site supplied LR=site+4. Tail-entering preserves the retail call/return
    # contract, after which gm_801BEE9C performs gm_SetNewGameModePending().
    a.emit(encode_branch(base + len(a.data), GM_SET_PENDING_GAME_MODE))
    return a.finish()

def _game_over_wrapper(base: int, *, active_addr: int,
                       origin_addr: int | None = None,
                       return_pending_addr: int | None = None) -> bytes:
    """Gateway co-op both-zero -> launcher origin; retail 1-P -> Continue."""
    a = Asm(base)
    _load_active(a.data, active_addr)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('retail', 4, 30)

    # Active must still be Adventure. Fail closed to retail state selection if
    # the byte somehow leaked into another major mode.
    hi, lo = _addr_parts(CURRENT_MODE)
    a.emit(lis(12, hi), lbz(11, lo, 12), cmpwi(11, GM_ADVENTURE, crf=7))
    a.branch('retail', 4, 30)

    if origin_addr is None:
        hi, lo = _addr_parts(PREVIOUS_MODE)
        a.emit(lis(12, hi), lbz(11, lo, 12), cmpwi(11, GM_ADVENTURE, crf=7))
        a.branch('retail', 12, 30)  # recursive Adventure origin -> retail fail-closed
    else:
        _load_active(a.data, origin_addr)
        a.emit(cmpwi(11, 0, crf=7)); a.branch('retail', 12, 30)
        a.emit(cmpwi(11, GM_ADVENTURE, crf=7)); a.branch('retail', 12, 30)

    if origin_addr is None:
        # Preserve historical HF29G byte layout/order exactly.
        hi, lo = _addr_parts(active_addr)
        a.emit(lis(12, hi), addi(0, 0, 0), stb(0, lo, 12))
        a.emit(bytes.fromhex('7d635b78'))  # mr r3,r11
    else:
        # Save captured origin into r3, then clear both lifecycle bytes.
        a.emit(bytes.fromhex('7d635b78'))  # mr r3,r11
        a.emit(addi(0, 0, 0))
        _store_active(a.data, active_addr, source=0)
        _store_active(a.data, origin_addr, source=0)
        if return_pending_addr is not None:
            a.emit(addi(0, 0, 1))
            _store_active(a.data, return_pending_addr, source=0)
    a.emit(encode_branch(base + len(a.data), GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE))

    a.label('retail')
    a.emit(encode_branch(base + len(a.data), GM_SET_NEXT_GAME_MODE_STATE_ID))
    return a.finish()


def _current_branch_target(dol, site: int, *, require_link: bool | None = None) -> tuple[bytes, int, bool]:
    raw = dol.read_at_address(site, 4)
    try:
        dec = decode_branch(site, raw)
    except ValueError as exc:
        raise ValueError(f'HF29G expected an installed branch at {site:#x}; got {raw.hex()}') from exc
    if require_link is not None and bool(dec['link']) != bool(require_link):
        raise ValueError(f'HF29G branch-link guard failed at {site:#x}: {raw.hex()}')
    return raw, int(dec['target']), bool(dec['link'])


def install(dol, runtime_index: int, *, gateway_pending_addr: int,
            enable_sdk0205_extras: bool = False,
            capture_origin: bool = False) -> dict:
    """Install HF29G, optionally enabling SDK 0.20.5 lifecycle hardening.

    Defaults intentionally reproduce historical HF29G byte-for-byte for the
    archival regression suite. Current SDK builds opt into the two 0.20.5 extra
    guards and captured-origin lifecycle explicitly.
    """
    # Capture all existing proven targets before appending anything.
    onload_raw, onload_old, onload_link = _current_branch_target(dol, ADVENTURE_ONLOAD)
    if onload_link:
        raise ValueError('HF29G expected Adventure OnLoad to use a non-linked entry branch')

    old_hooks = []
    skipped_hooks = []
    guard_specs = ACTIVE_GUARDS if enable_sdk0205_extras else CORE_GUARDS
    for spec in guard_specs:
        got = dol.read_at_address(spec.site, 4)
        # Optional Phase-43 features can be disabled by builder flags.  If the
        # site is still exactly retail there is nothing to scope; leave it
        # untouched instead of requiring a handler that was never installed.
        if got == spec.retail:
            skipped_hooks.append({
                'name': spec.name,
                'site_address': spec.site,
                'reason': 'feature not installed; site already exact retail',
            })
            continue
        raw, target, link = _current_branch_target(dol, spec.site)
        old_hooks.append((spec, raw, target, link))

    origin_specs = (
        ('abort_origin_return', ABORT_RETURN_CALL, ABORT_RETAIL,
         GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE),
        ('css_cancel_origin_return', CSS_CANCEL_RETURN_CALL, CSS_CANCEL_RETAIL,
         GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE),
        ('campaign_complete_origin_return', CAMPAIGN_COMPLETE_SET_PENDING_CALL,
         CAMPAIGN_COMPLETE_RETAIL, GM_SET_PENDING_GAME_MODE),
    )
    origin_old = []
    for name, site, retail_expected, retail_target in origin_specs:
        raw, target, link = _current_branch_target(dol, site, require_link=True)
        if raw == retail_expected:
            raise ValueError(f'HF29G requires HF29F origin wrapper at {site:#x}; found retail call')
        origin_old.append((name, site, raw, target, retail_target))

    if dol.read_at_address(GAME_OVER_STATE_CALL, 4) != GAME_OVER_STATE_EXPECTED:
        got = dol.read_at_address(GAME_OVER_STATE_CALL, 4)
        raise ValueError(
            f'HF29G Game Over expected-byte guard failed: expected '
            f'{GAME_OVER_STATE_EXPECTED.hex()}, got {got.hex()}')

    post_staffroll_raw = None
    final_state_raw = None
    if capture_origin:
        post_staffroll_raw = dol.read_at_address(POST_STAFFROLL_RETURN_CALL, 4)
        if post_staffroll_raw != POST_STAFFROLL_RETURN_RETAIL:
            raise ValueError(
                f'SDK 0.20.7 post-Staff-Roll expected-byte guard failed: expected '
                f'{POST_STAFFROLL_RETURN_RETAIL.hex()}, got {post_staffroll_raw.hex()}')
        final_state_raw = dol.read_at_address(ADVENTURE_ONLOAD_FINAL_STATE_CALL, 4)
        if final_state_raw != ADVENTURE_ONLOAD_FINAL_STATE_EXPECTED:
            raise ValueError(
                f'SDK 0.20.13 Adventure final-state expected-byte guard failed: expected '
                f'{ADVENTURE_ONLOAD_FINAL_STATE_EXPECTED.hex()}, got {final_state_raw.hex()}')

    section = next(s for s in dol.sections
                   if s.kind == 'data' and s.index == int(runtime_index))
    base = section.address + ((section.size + 31) & ~31)
    active_addr = base + 0x10
    origin_addr = base + 0x11 if capture_origin else None
    # One-shot handoff latch. Set only when an SDK-scoped Adventure/standalone
    # session is actually returning to its captured launcher. The Slippi EXI
    # bridge consumes this at the first Online-side CleanupConnections so a
    # stale Adventure teardown packet cannot destroy the Direct render/session.
    return_pending_addr = base + 0x12 if capture_origin else None
    cursor = base + 0x20
    blobs: list[tuple[str, int, bytes]] = []

    def add_blob(name: str, builder) -> int:
        nonlocal cursor
        cursor = (cursor + 31) & ~31
        address = cursor
        blob = builder(address)
        blobs.append((name, address, blob))
        cursor = address + len(blob)
        return address

    onload_stub = add_blob(
        'gateway_onload_scope_capture',
        lambda addr: _onload_capture_wrapper(
            addr, pending_addr=gateway_pending_addr,
            active_addr=active_addr, old_target=onload_old,
            origin_addr=origin_addr, return_pending_addr=return_pending_addr))

    guard_rows = []
    guard_stubs = {}
    for spec, raw, target, link in old_hooks:
        stub = add_blob(
            spec.name,
            lambda addr, spec=spec, target=target: _guard_wrapper(
                addr, site=spec.site, active_addr=active_addr,
                active_target=target, retail=spec.retail, entry_link=link))
        guard_stubs[spec.site] = stub
        guard_rows.append({
            'name': spec.name,
            'site_address': spec.site,
            'hf29f_branch': raw.hex(),
            'hf29f_target': target,
            'retail_instruction': spec.retail.hex(),
            'guard_stub': stub,
            'site_link': link,
        })

    origin_rows = []
    origin_stubs = {}
    for name, site, raw, old_target, retail_target in origin_old:
        stub = add_blob(
            name,
            lambda addr, old_target=old_target, retail_target=retail_target:
                _exit_scope_wrapper(
                    addr, active_addr=active_addr, old_target=old_target,
                    retail_target=retail_target, origin_addr=origin_addr,
                    return_pending_addr=return_pending_addr))
        origin_stubs[site] = stub
        origin_rows.append({
            'name': name, 'site_address': site,
            'hf29f_branch': raw.hex(), 'hf29f_target': old_target,
            'retail_target': retail_target, 'guard_stub': stub,
        })

    game_over_stub = add_blob(
        'coop_game_over_origin_return',
        lambda addr: _game_over_wrapper(
            addr, active_addr=active_addr, origin_addr=origin_addr,
            return_pending_addr=return_pending_addr))

    post_staffroll_stub = None
    final_state_stub = None
    if capture_origin:
        assert origin_addr is not None
        post_staffroll_stub = add_blob(
            'post_staffroll_completion_origin_return',
            lambda addr: _staffroll_completion_wrapper(
                addr, active_addr=active_addr, origin_addr=origin_addr))
        final_state_stub = add_blob(
            'adventure_completion_final_state_commit',
            lambda addr: _adventure_final_state_wrapper(
                addr, active_addr=active_addr))

    payload = bytearray(b'HF29GSCP' + bytes(24))
    assert len(payload) == 0x20
    for name, address, blob in blobs:
        wanted = address - base
        if len(payload) > wanted:
            raise ValueError(f'HF29G payload layout overlap before {name}')
        payload.extend(bytes(wanted - len(payload)))
        payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    if base + len(payload) >= 0x804F4C00:
        raise ValueError('HF29G payload reaches reserved SDK arena boundary')

    added = dol.append_to_data_section(runtime_index, payload)
    assert added['address'] == base

    # Patch OnLoad first: this is the only producer of campaign-active state.
    dol.patch_at_address(
        ADVENTURE_ONLOAD, encode_branch(ADVENTURE_ONLOAD, onload_stub),
        expected=onload_raw)

    # Behavior-changing co-op hooks. Preserve whether the original site was a
    # call (BL) or an instruction/function-entry branch (B).
    for spec, raw, target, link in old_hooks:
        dol.patch_at_address(
            spec.site, encode_branch(spec.site, guard_stubs[spec.site], link=link),
            expected=raw)

    # HF29F's three origin-return wrappers are active only for gateway co-op.
    for name, site, raw, old_target, retail_target in origin_old:
        dol.patch_at_address(
            site, encode_branch(site, origin_stubs[site], link=True), expected=raw)

    # Both-human-zero failure path: active co-op exits the Adventure major mode;
    # inactive retail 1-P still selects the original Adventure Game Over state.
    game_over_branch = encode_branch(
        GAME_OVER_STATE_CALL, game_over_stub, link=True)
    dol.patch_at_address(
        GAME_OVER_STATE_CALL, game_over_branch,
        expected=GAME_OVER_STATE_EXPECTED)

    post_staffroll_branch = None
    final_state_branch = None
    if capture_origin:
        assert post_staffroll_stub is not None and post_staffroll_raw is not None
        assert final_state_stub is not None and final_state_raw is not None
        post_staffroll_branch = encode_branch(
            POST_STAFFROLL_RETURN_CALL, post_staffroll_stub, link=True)
        dol.patch_at_address(
            POST_STAFFROLL_RETURN_CALL, post_staffroll_branch,
            expected=post_staffroll_raw)

        # SDK 0.20.13: patch the final retail state commit, not the beginning of
        # Adventure OnLoad. This prevents retail's own 0x70 write from undoing
        # the completion bridge's 0x68 selection.
        final_state_branch = encode_branch(
            ADVENTURE_ONLOAD_FINAL_STATE_CALL, final_state_stub, link=True)
        dol.patch_at_address(
            ADVENTURE_ONLOAD_FINAL_STATE_CALL, final_state_branch,
            expected=final_state_raw)

    return {
        'marker': 'HF29GSCP',
        'section': added,
        'gateway_pending_address': gateway_pending_addr,
        'gateway_coop_active_address': active_addr,
        'gateway_origin_address': origin_addr,
        'gateway_return_pending_address': return_pending_addr,
        'sdk0205_extra_guards_enabled': bool(enable_sdk0205_extras),
        'captured_origin_enabled': bool(capture_origin),
        'onload_hook': {
            'site_address': ADVENTURE_ONLOAD,
            'previous_branch': onload_raw.hex(),
            'previous_target': onload_old,
            'scope_stub': onload_stub,
        },
        'guarded_hooks': guard_rows,
        'skipped_retail_hooks': skipped_hooks,
        'origin_return_guards': origin_rows,
        'game_over': {
            'site_address': GAME_OVER_STATE_CALL,
            'retail_call': GAME_OVER_STATE_EXPECTED.hex(),
            'scope_stub': game_over_stub,
            'site_branch': game_over_branch.hex(),
            'active_behavior': ('clear gateway co-op scope and return to captured launcher origin' if capture_origin else 'clear gateway co-op scope and return to retail routing.prev_mode'),
            'inactive_behavior': 'tail-enter retail gm_SetNextGameModeStateId; Adventure Continue untouched',
        },
        'post_staffroll_completion': ({
            'site_address': POST_STAFFROLL_RETURN_CALL,
            'retail_call': POST_STAFFROLL_RETURN_RETAIL.hex(),
            'scope_stub': post_staffroll_stub,
            'site_branch': post_staffroll_branch.hex() if post_staffroll_branch else None,
            'gate': 'gateway active + current mode GM_ADVENTURE_GOVER',
            'active_behavior': 'replace GOver exit_data destination with GM_ADVENTURE, preserve scope, and let retail gm_SetNewGameModePending commit the bridge',
            'challenger_behavior': 'retail challenger branch bypasses this no-challenger hook; captured scope survives for the guarded Adventure completion fallback',
            'inactive_behavior': 'exact retail gm_SetPendingGameMode argument and lifecycle',
        } if capture_origin else None),
        'completion_final_state_commit': ({
            'site_address': ADVENTURE_ONLOAD_FINAL_STATE_CALL,
            'retail_call': ADVENTURE_ONLOAD_FINAL_STATE_EXPECTED.hex(),
            'scope_stub': final_state_stub,
            'site_branch': final_state_branch.hex() if final_state_branch else None,
            'gate': 'incoming state 0x70 + gateway active + routing.prev_mode GM_ADVENTURE_GOVER',
            'active_behavior': 'substitute state 0x68 only at retail Adventure OnLoad final commit',
            'inactive_behavior': 'tail-enter retail gm_SetGameModeStateId with the original r3 argument',
        } if capture_origin else None),
        'scope': 'gateway sentinel + two Humans only; captured from existing gateway_pending at Adventure OnLoad',
        'retail_1p_policy': 'exact retail instruction/callee path at all behavior-changing co-op hooks; genuine retail Game Over/Continue preserved',
        'co_op_policy': 'existing HF29E/F handlers unchanged behind one campaign-active dispatch layer',
        'slippi_policy': ('captured launcher origin is Direct-ready, but online rollback synchronization remains separately unvalidated' if capture_origin else 'future Direct launcher must establish the same gateway_pending contract; no Direct compatibility claim in HF29G'),
        'runtime_validation': 'requires Dolphin: retail 1P no P2 + retail Continue; VS sentinel two-Human co-op; both-zero returns VS; normal Staff Roll completion returns origin; challenger completion fallback; sentinel with P2 CPU loads retail Yoshi',
    }
