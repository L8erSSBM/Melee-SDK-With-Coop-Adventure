from __future__ import annotations

import hashlib
import json
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

GALE01_GAME_ID = b'GALE01'
# doldecomp/melee canonical NTSC-U 1.02 raw disc SHA-1.
GALE01_102_DOL_SHA1 = '08e0bf20134dfcb260699671004527b2d6bb1a45'
# Backward-compatible alias used by older UI/project code. This is the *main.dol* hash, not a whole-disc ISO hash.
GALE01_102_SHA1 = GALE01_102_DOL_SHA1
STATE_NAME = '.melee_sdk_iso_state.json'


def _u32be(data: bytes, off: int) -> int:
    return int.from_bytes(data[off:off+4], 'big')


def sha1_file(path: str | Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha1()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(chunk_size), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_file(path: str | Path, chunk_size: int = 8 * 1024 * 1024) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(chunk_size), b''):
            h.update(chunk)
    return h.hexdigest()


@dataclass(frozen=True)
class FSTFile:
    path: str
    offset: int
    size: int
    index: int = -1


class GameCubeISO:
    """GameCube ISO reader, exact patcher, and Phase 13 FST repacker.

    Exact-size edits still use the fast in-place path. Resized DAT/AJ resources
    can be rebuilt from a clean source image by repacking FST file data and
    rewriting file offsets/sizes without moving the DOL or FST system regions.
    """

    def __init__(self, path: str | Path):
        self.path = Path(path).resolve()
        if not self.path.is_file():
            raise FileNotFoundError(self.path)
        with self.path.open('rb') as f:
            header = f.read(0x430)
        if len(header) < 0x430:
            raise ValueError('File is too small to be a GameCube disc image.')
        self.game_id = header[:6]
        self.dol_offset = _u32be(header, 0x420)
        self.fst_offset = _u32be(header, 0x424)
        self.fst_size = _u32be(header, 0x428)
        if not self.fst_offset or not self.fst_size:
            raise ValueError('Disc header does not contain a valid FST location.')
        if self.fst_offset + self.fst_size > self.path.stat().st_size:
            raise ValueError('FST lies outside the disc image.')
        self.files = self._read_fst()
        self._by_lower_path = {x.path.lower(): x for x in self.files}
        self._by_lower_name: dict[str, list[FSTFile]] = {}
        for item in self.files:
            self._by_lower_name.setdefault(Path(item.path).name.lower(), []).append(item)

    def _read_fst(self) -> list[FSTFile]:
        with self.path.open('rb') as f:
            f.seek(self.fst_offset)
            fst = f.read(self.fst_size)
        if len(fst) < 12:
            raise ValueError('FST is truncated.')
        root_word = _u32be(fst, 0)
        if not (root_word & 0x01000000):
            raise ValueError('FST root entry is not a directory.')
        entry_count = _u32be(fst, 8)
        table_size = entry_count * 12
        if entry_count < 1 or table_size > len(fst):
            raise ValueError('Invalid FST entry count.')
        strings = fst[table_size:]

        def name_at(off: int) -> str:
            if off >= len(strings):
                raise ValueError('Invalid FST string offset.')
            end = strings.find(b'\0', off)
            if end < 0:
                end = len(strings)
            return strings[off:end].decode('shift_jis', errors='replace')

        # stack entries are (directory path, exclusive next entry index)
        stack: list[tuple[str, int]] = [('', entry_count)]
        out: list[FSTFile] = []
        for i in range(1, entry_count):
            while len(stack) > 1 and i >= stack[-1][1]:
                stack.pop()
            w0 = _u32be(fst, i * 12)
            w1 = _u32be(fst, i * 12 + 4)
            w2 = _u32be(fst, i * 12 + 8)
            is_dir = bool(w0 & 0x01000000)
            name = name_at(w0 & 0x00FFFFFF)
            parent_path = stack[-1][0]
            full = f'{parent_path}/{name}' if parent_path else name
            if is_dir:
                if w2 <= i or w2 > entry_count:
                    raise ValueError(f'Invalid directory next index for {full}.')
                stack.append((full, w2))
            else:
                if w1 + w2 > self.path.stat().st_size:
                    raise ValueError(f'FST file lies outside image: {full}')
                out.append(FSTFile(full, w1, w2, i))
        return out

    def find_file(self, name_or_path: str) -> FSTFile:
        key = name_or_path.replace('\\', '/').lstrip('/').lower()
        if key in self._by_lower_path:
            return self._by_lower_path[key]
        name = Path(key).name
        matches = self._by_lower_name.get(name, [])
        if len(matches) == 1:
            return matches[0]
        if not matches:
            raise KeyError(f'{name_or_path} was not found in the disc FST.')
        raise KeyError(f'{name_or_path} is ambiguous in the disc FST: ' + ', '.join(x.path for x in matches))

    def read_file(self, entry: FSTFile) -> bytes:
        with self.path.open('rb') as f:
            f.seek(entry.offset)
            return f.read(entry.size)

    def replace_file_exact(self, name_or_path: str, replacement: str | Path) -> FSTFile:
        entry = self.find_file(name_or_path)
        replacement = Path(replacement)
        new_size = replacement.stat().st_size
        if new_size != entry.size:
            raise ValueError(
                f'{entry.path}: replacement is {new_size:,} bytes but the ISO slot is {entry.size:,} bytes. '
                'Phase 7 only performs exact-size replacements; a future repacker will handle resized resources.'
            )
        with replacement.open('rb') as src, self.path.open('r+b') as dst:
            dst.seek(entry.offset)
            shutil.copyfileobj(src, dst, length=1024 * 1024)
        return entry


    def _raw_fst_parts(self) -> tuple[bytearray, bytes, int]:
        with self.path.open('rb') as f:
            f.seek(self.fst_offset)
            fst = f.read(self.fst_size)
        entry_count = _u32be(fst, 8)
        table_size = entry_count * 12
        return bytearray(fst[:table_size]), bytes(fst[table_size:]), entry_count

    def extract_dol(self, output_path: str | Path) -> Path:
        output = Path(output_path)
        output.parent.mkdir(parents=True, exist_ok=True)
        with self.path.open('rb') as src, output.open('wb') as dst:
            src.seek(self.dol_offset)
            remaining = self.dol_size()
            while remaining:
                chunk = src.read(min(1024 * 1024, remaining))
                if not chunk:
                    raise IOError('Unexpected EOF while extracting main.dol')
                dst.write(chunk)
                remaining -= len(chunk)
        return output

    def repack_files(self, output_path: str | Path,
                     replacements: dict[str, str | Path],
                     alignment: int = 0x20,
                     additions: dict[str, str | Path] | None = None,
                     dol_replacement: str | Path | None = None) -> dict:
        """Rebuild the GameCube filesystem with resize *and root-file insertion*.

        ``additions`` maps new root-level FST names to payload files.  This is
        sufficient for Melee's Gr*.dat / Pl*.dat / menu archives, which live in
        the disc root.  The FST itself may grow; the header's FST offset/size/max
        fields are rewritten and all file data is packed after the enlarged FST
        and optional resized DOL.
        """
        output = Path(output_path).resolve()
        if output == self.path:
            raise ValueError('Repacked output must not overwrite the clean source ISO.')
        alignment = int(alignment)
        if alignment <= 0 or alignment & (alignment - 1):
            raise ValueError('Repack alignment must be a positive power of two')
        additions = additions or {}

        resolved: dict[str, Path] = {}
        for key, value in replacements.items():
            ent = self.find_file(key)
            src = Path(value).resolve()
            if not src.is_file():
                raise FileNotFoundError(src)
            resolved[ent.path.lower()] = src

        existing_names = {Path(x.path).name.lower() for x in self.files}
        new_files: list[tuple[str, Path]] = []
        for name, value in additions.items():
            clean_name = str(name).replace('\\', '/').lstrip('/')
            if '/' in clean_name or not clean_name:
                raise ValueError('Phase 17 FST insertion currently supports root-level filenames only.')
            if clean_name.lower() in existing_names:
                raise ValueError(f'Cannot add {clean_name}: that FST filename already exists.')
            if any(clean_name.lower() == n.lower() for n, _ in new_files):
                raise ValueError(f'Duplicate new FST filename: {clean_name}')
            try:
                clean_name.encode('shift_jis')
            except UnicodeEncodeError as exc:
                raise ValueError(f'FST filename is not Shift-JIS encodable: {clean_name}') from exc
            src = Path(value).resolve()
            if not src.is_file():
                raise FileNotFoundError(src)
            new_files.append((clean_name, src))

        dol_path = Path(dol_replacement).resolve() if dol_replacement else None
        if dol_path is not None and not dol_path.is_file():
            raise FileNotFoundError(dol_path)
        dol_size = dol_path.stat().st_size if dol_path else self.dol_size()

        def align(v: int) -> int:
            return (int(v) + alignment - 1) & ~(alignment - 1)

        # Build an enlarged FST table. Existing name offsets remain valid because
        # they are relative to the beginning of the string table, not file offsets.
        old_table, old_strings, old_count = self._raw_fst_parts()
        appended_names = bytearray()
        new_name_offsets: list[int] = []
        for name, _src in new_files:
            new_name_offsets.append(len(old_strings) + len(appended_names))
            appended_names += name.encode('shift_jis') + b'\0'
        new_count = old_count + len(new_files)
        struct_table = bytearray(old_table)
        # Root directory's third word is the exclusive end index / entry count.
        struct_table[8:12] = int(new_count).to_bytes(4, 'big')
        for name_off in new_name_offsets:
            if name_off >= 0x01000000:
                raise ValueError('FST string table exceeded 24-bit name-offset capacity.')
            struct_table += int(name_off).to_bytes(4, 'big') + b'\0' * 8
        new_fst = struct_table + old_strings + appended_names

        # Keep the FST at its canonical disc-header location when possible.
        # A resized DOL may extend into the retail FST region (GALE01 1.02 has
        # only 0x20 bytes between the end of main.dol and the FST).  In that
        # case relocate the FST after the replacement DOL instead of writing
        # the FST back over the tail of the DOL.  All file payloads are already
        # repacked below, so relocating the FST is safe as long as the disc
        # header is updated to the new location.
        new_fst_size = len(new_fst)
        dol_end = self.dol_offset + dol_size
        if dol_path and dol_end > self.fst_offset:
            new_fst_offset = align(dol_end)
        else:
            new_fst_offset = self.fst_offset
        data_start = align(new_fst_offset + new_fst_size)

        placements: list[tuple[str, int, int, Path | None, FSTFile | None, int]] = []
        cursor = data_start
        for ent in sorted(self.files, key=lambda x: x.index):
            cursor = align(cursor)
            repl = resolved.get(ent.path.lower())
            size = repl.stat().st_size if repl else ent.size
            placements.append((ent.path, cursor, size, repl, ent, ent.index))
            cursor += size
        for n, src in new_files:
            cursor = align(cursor)
            idx = old_count + len([x for x in placements if x[4] is None])
            placements.append((n, cursor, src.stat().st_size, src, None, idx))
            cursor += src.stat().st_size
        if cursor > self.path.stat().st_size:
            raise ValueError(
                f'Repacked filesystem needs {cursor:,} bytes but the disc image is only '
                f'{self.path.stat().st_size:,} bytes. This build exceeds available ISO space.'
            )

        # Patch FST file offsets/sizes now that placements are known.
        for path, new_off, new_size, _src, _ent, idx in placements:
            off = idx * 12
            struct_table[off + 4:off + 8] = int(new_off).to_bytes(4, 'big')
            struct_table[off + 8:off + 12] = int(new_size).to_bytes(4, 'big')
        new_fst = bytes(struct_table + old_strings + appended_names)

        output.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(self.path, output)
        fst_updates = []
        with self.path.open('rb') as clean, output.open('r+b') as dst:
            # Optional resized DOL is written before the relocated/repacked FST data.
            if dol_path:
                dst.seek(self.dol_offset)
                with dol_path.open('rb') as src:
                    shutil.copyfileobj(src, dst, length=1024 * 1024)
            dst.seek(new_fst_offset)
            dst.write(new_fst)
            # Disc header: FST offset, actual size, max size. We own the rebuilt FST.
            dst.seek(0x424)
            dst.write(int(new_fst_offset).to_bytes(4, 'big'))
            dst.write(int(new_fst_size).to_bytes(4, 'big'))
            dst.write(int(new_fst_size).to_bytes(4, 'big'))

            for path, new_off, new_size, src_path, ent, idx in placements:
                if src_path:
                    with src_path.open('rb') as src:
                        dst.seek(new_off)
                        shutil.copyfileobj(src, dst, length=1024 * 1024)
                else:
                    assert ent is not None
                    clean.seek(ent.offset)
                    dst.seek(new_off)
                    remaining = ent.size
                    while remaining:
                        chunk = clean.read(min(1024 * 1024, remaining))
                        if not chunk:
                            raise IOError(f'Unexpected EOF while copying {ent.path}')
                        dst.write(chunk)
                        remaining -= len(chunk)
                fst_updates.append({
                    'disc_path': path,
                    'old_offset': ent.offset if ent else None,
                    'new_offset': new_off,
                    'old_size': ent.size if ent else None,
                    'new_size': new_size,
                    'replaced': bool(src_path and ent is not None),
                    'added': ent is None,
                })

        check = GameCubeISO(output)
        for path, _new_off, new_size, src_path, _ent, _idx in placements:
            got = check.find_file(path)
            if got.size != new_size:
                raise ValueError(f'FST verification failed for {path}')
            if src_path and hashlib.sha256(check.read_file(got)).digest() != hashlib.sha256(src_path.read_bytes()).digest():
                raise ValueError(f'Repacked payload verification failed for {path}')
        if dol_path:
            with output.open('rb') as f:
                f.seek(self.dol_offset)
                if f.read(dol_size) != dol_path.read_bytes():
                    raise ValueError('Resized DOL verification failed')
        return {
            'output_iso': str(output), 'alignment': alignment,
            'fst_old_size': self.fst_size, 'fst_new_size': new_fst_size,
            'fst_entries_old': old_count, 'fst_entries_new': new_count,
            'data_start': data_start, 'data_end': cursor,
            'free_tail_bytes': self.path.stat().st_size - cursor,
            'files_repacked': len(placements),
            'replacements': [x for x in fst_updates if x['replaced']],
            'additions': [x for x in fst_updates if x['added']],
            'dol_replaced': bool(dol_path),
            'dol_resized': bool(dol_path and dol_size != self.dol_size()),
            'fst_updates': fst_updates,
        }

    def replace_dol_exact(self, replacement: str | Path) -> tuple[int, int]:
        replacement = Path(replacement)
        current_size = self.dol_size()
        if replacement.stat().st_size != current_size:
            raise ValueError(
                f'start.dol replacement is {replacement.stat().st_size:,} bytes but disc DOL is {current_size:,} bytes. '
                'Phase 7 only supports exact-size DOL replacement.'
            )
        with replacement.open('rb') as src, self.path.open('r+b') as dst:
            dst.seek(self.dol_offset)
            shutil.copyfileobj(src, dst, length=1024 * 1024)
        return self.dol_offset, current_size

    def dol_size(self) -> int:
        # DOL header: 7 text offsets, 11 data offsets, 7 text sizes, 11 data sizes.
        with self.path.open('rb') as f:
            f.seek(self.dol_offset)
            hdr = f.read(0x100)
        if len(hdr) < 0xE4:
            raise ValueError('DOL header is truncated.')
        offsets = [_u32be(hdr, i * 4) for i in range(18)]
        sizes = [_u32be(hdr, 0x90 + i * 4) for i in range(18)]
        end = 0
        for off, size in zip(offsets, sizes):
            if off and size:
                end = max(end, off + size)
        if not end:
            raise ValueError('Could not determine DOL size.')
        return end

    def sha1_dol(self, chunk_size: int = 1024 * 1024) -> str:
        """SHA-1 the embedded main.dol only.

        doldecomp/melee publishes 08e0... as the hash of main.dol, not the
        complete GameCube disc image. Hashing the entire ISO against that
        value is incorrect and caused Phase 7 clean-ISO verification to fail.
        """
        remaining = self.dol_size()
        h = hashlib.sha1()
        with self.path.open('rb') as f:
            f.seek(self.dol_offset)
            while remaining:
                chunk = f.read(min(chunk_size, remaining))
                if not chunk:
                    raise IOError('Unexpected EOF while hashing main.dol.')
                h.update(chunk)
                remaining -= len(chunk)
        return h.hexdigest()


def verify_melee_102(path: str | Path, full_hash: bool = True) -> dict:
    """Verify a Melee US 1.02 disc by Game ID and embedded main.dol.

    The doldecomp project publishes the SHA-1 of main.dol. It does not publish
    that value as the SHA-1 of the complete ISO. Phase 7 incorrectly hashed
    the whole ISO; Phase 7.1 checks the DOL stored at the disc header's DOL
    offset instead.
    """
    iso = GameCubeISO(path)
    result = {
        'path': str(iso.path),
        'game_id': iso.game_id.decode('ascii', errors='replace'),
        'dol_sha1': None,
        # Retain sha1 for project-manifest compatibility; it means DOL SHA-1.
        'sha1': None,
        'canonical': False,
    }
    if iso.game_id != GALE01_GAME_ID:
        raise ValueError(f'Expected GALE01, found {result["game_id"]!r}.')
    if full_hash:
        digest = iso.sha1_dol()
        result['dol_sha1'] = digest
        result['sha1'] = digest
        result['canonical'] = digest.lower() == GALE01_102_DOL_SHA1
        if not result['canonical']:
            raise ValueError(
                'The selected disc is GALE01, but its embedded main.dol does not match the canonical NTSC-U 1.02 executable.\n\n'
                f'Expected main.dol SHA-1: {GALE01_102_DOL_SHA1}\n'
                f'Found main.dol SHA-1:    {digest}\n\n'
                'Use an unmodified NTSC-U Melee 1.02 disc image as the build source.'
            )
    return result


def _build_files(build_dir: str | Path) -> list[Path]:
    build_dir = Path(build_dir)
    ignore = {'build_manifest.json', STATE_NAME}
    return sorted(
        [p for p in build_dir.iterdir() if p.is_file() and p.name not in ignore],
        key=lambda p: p.name.lower(),
    )


def _apply_build_to_iso(iso_path: str | Path, build_dir: str | Path) -> list[dict]:
    iso = GameCubeISO(iso_path)
    applied: list[dict] = []
    for src in _build_files(build_dir):
        if src.name.lower() == 'start.dol':
            off, size = iso.replace_dol_exact(src)
            applied.append({'filename': src.name, 'disc_path': 'start.dol', 'offset': off, 'size': size})
        else:
            entry = iso.replace_file_exact(src.name, src)
            applied.append({'filename': src.name, 'disc_path': entry.path, 'offset': entry.offset, 'size': entry.size})
    return applied



def _build_replacements_for_iso(iso: GameCubeISO, build_dir: str | Path) -> tuple[dict[str, Path], dict[str, Path], Path | None]:
    replacements: dict[str, Path] = {}
    additions: dict[str, Path] = {}
    dol: Path | None = None
    existing = {Path(x.path).name.lower(): x for x in iso.files}
    for src in _build_files(build_dir):
        if src.name.lower() == 'start.dol':
            dol = src
        elif src.name.lower() in existing:
            ent = existing[src.name.lower()]
            replacements[ent.path] = src
        else:
            additions[src.name] = src
    return replacements, additions, dol


def build_requires_repack(clean_iso: str | Path, build_dir: str | Path) -> bool:
    iso = GameCubeISO(clean_iso)
    replacements, additions, dol = _build_replacements_for_iso(iso, build_dir)
    if additions:
        return True
    if dol is not None and dol.stat().st_size != iso.dol_size():
        return True
    return any(src.stat().st_size != iso.find_file(path).size for path, src in replacements.items())


def repack_rebuild(clean_iso: str | Path, output_iso: str | Path, build_dir: str | Path,
                   verify_hash: bool = True, alignment: int = 0x20) -> dict:
    clean_iso = Path(clean_iso).resolve(); output_iso = Path(output_iso).resolve()
    if clean_iso == output_iso:
        raise ValueError('Output ISO must not overwrite the clean source ISO.')
    verify = verify_melee_102(clean_iso, full_hash=verify_hash)
    clean = GameCubeISO(clean_iso)
    replacements, additions, dol = _build_replacements_for_iso(clean, build_dir)
    repack = clean.repack_files(output_iso, replacements, alignment=alignment,
                                additions=additions, dol_replacement=dol)
    applied = []
    for x in repack['replacements']:
        applied.append({'filename': Path(x['disc_path']).name, 'disc_path': x['disc_path'],
                        'offset': x['new_offset'], 'size': x['new_size'],
                        'old_size': x['old_size'], 'resized': x['old_size'] != x['new_size'], 'added': False})
    for x in repack['additions']:
        applied.append({'filename': Path(x['disc_path']).name, 'disc_path': x['disc_path'],
                        'offset': x['new_offset'], 'size': x['new_size'],
                        'old_size': None, 'resized': True, 'added': True})
    if dol is not None:
        applied.append({'filename': dol.name, 'disc_path': 'start.dol', 'offset': clean.dol_offset,
                        'size': dol.stat().st_size, 'old_size': clean.dol_size(),
                        'resized': dol.stat().st_size != clean.dol_size(), 'added': False})
    result = {
        'mode': 'repack_rebuild', 'built_utc': datetime.now(timezone.utc).isoformat(),
        'clean_iso': str(clean_iso), 'output_iso': str(output_iso),
        'source_verification': verify, 'applied_files': applied, 'repack': repack,
    }
    _write_iso_state(output_iso, clean_iso, applied, layout='repacked')
    return result


def fresh_rebuild(clean_iso: str | Path, output_iso: str | Path, build_dir: str | Path, verify_hash: bool = True) -> dict:
    clean_iso = Path(clean_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if clean_iso == output_iso:
        raise ValueError('Output ISO must not overwrite the clean source ISO.')
    verify = verify_melee_102(clean_iso, full_hash=verify_hash)
    if build_requires_repack(clean_iso, build_dir):
        return repack_rebuild(clean_iso, output_iso, build_dir, verify_hash=False)
    output_iso.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(clean_iso, output_iso)
    applied = _apply_build_to_iso(output_iso, build_dir)
    result = {
        'mode': 'fresh_rebuild',
        'built_utc': datetime.now(timezone.utc).isoformat(),
        'clean_iso': str(clean_iso),
        'output_iso': str(output_iso),
        'source_verification': verify,
        'applied_files': applied,
    }
    _write_iso_state(output_iso, clean_iso, applied)
    return result


def _state_path(output_iso: Path) -> Path:
    return output_iso.parent / (output_iso.name + STATE_NAME)


def _write_iso_state(output_iso: Path, clean_iso: Path, applied: list[dict], layout: str = 'exact') -> None:
    state = {
        'format_version': 1,
        'updated_utc': datetime.now(timezone.utc).isoformat(),
        'output_iso': str(output_iso),
        'clean_iso': str(clean_iso),
        'clean_size': clean_iso.stat().st_size,
        'layout': layout,
        'applied_files': [x['filename'] for x in applied],
    }
    _state_path(output_iso).write_text(json.dumps(state, indent=2), encoding='utf-8')


def quick_update(clean_iso: str | Path, output_iso: str | Path, build_dir: str | Path, verify_hash: bool = True) -> dict:
    """Update an existing test ISO without recopying the whole image.

    Files that were modified by the previous SDK update but are no longer in
    the current Build/ are restored directly from the clean ISO first.
    """
    clean_iso = Path(clean_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if clean_iso == output_iso:
        raise ValueError('Output ISO must not overwrite the clean source ISO.')
    verify = verify_melee_102(clean_iso, full_hash=verify_hash)
    if build_requires_repack(clean_iso, build_dir):
        return repack_rebuild(clean_iso, output_iso, build_dir, verify_hash=False)
    if not output_iso.exists():
        return fresh_rebuild(clean_iso, output_iso, build_dir, verify_hash=False)
    if output_iso.stat().st_size != clean_iso.stat().st_size:
        raise ValueError('Existing test ISO has a different size than the selected clean ISO. Use Fresh Rebuild.')
    out_iso = GameCubeISO(output_iso)
    clean = GameCubeISO(clean_iso)
    if out_iso.game_id != GALE01_GAME_ID:
        raise ValueError('Existing output is not a GALE01 GameCube image.')

    current = {p.name for p in _build_files(build_dir)}
    previous: set[str] = set()
    state_path = _state_path(output_iso)
    previous_layout = 'exact'
    if state_path.exists():
        try:
            state_data = json.loads(state_path.read_text(encoding='utf-8'))
            previous = set(state_data.get('applied_files', []))
            previous_layout = state_data.get('layout', 'exact')
        except Exception:
            previous = set()
    if previous_layout == 'repacked':
        # Returning from a repacked layout to exact-size resources is safest as
        # a clean rebuild; stale FST offsets should never be patched in place.
        return fresh_rebuild(clean_iso, output_iso, build_dir, verify_hash=False)

    restored: list[str] = []
    # Restore no-longer-modified SDK files from clean image byte-for-byte.
    for filename in sorted(previous - current):
        if filename.lower() == 'start.dol':
            size = clean.dol_size()
            if size != out_iso.dol_size():
                raise ValueError('DOL layouts differ; use Fresh Rebuild.')
            with clean_iso.open('rb') as src, output_iso.open('r+b') as dst:
                src.seek(clean.dol_offset); dst.seek(out_iso.dol_offset)
                remaining = size
                while remaining:
                    data = src.read(min(1024 * 1024, remaining))
                    if not data: raise IOError('Unexpected EOF while restoring DOL.')
                    dst.write(data); remaining -= len(data)
        else:
            c = clean.find_file(filename)
            o = out_iso.find_file(filename)
            if c.size != o.size:
                raise ValueError(f'{filename} slot sizes differ; use Fresh Rebuild.')
            with clean_iso.open('rb') as src, output_iso.open('r+b') as dst:
                src.seek(c.offset); dst.seek(o.offset)
                remaining = c.size
                while remaining:
                    data = src.read(min(1024 * 1024, remaining))
                    if not data: raise IOError(f'Unexpected EOF while restoring {filename}.')
                    dst.write(data); remaining -= len(data)
        restored.append(filename)

    applied = _apply_build_to_iso(output_iso, build_dir)
    _write_iso_state(output_iso, clean_iso, applied)
    return {
        'mode': 'quick_update',
        'built_utc': datetime.now(timezone.utc).isoformat(),
        'clean_iso': str(clean_iso),
        'output_iso': str(output_iso),
        'source_verification': verify,
        'restored_files': restored,
        'applied_files': applied,
    }


def locate_xdelta3(explicit: str | Path | None = None) -> Path | None:
    if explicit:
        p = Path(explicit)
        if p.is_file():
            return p.resolve()
    found = shutil.which('xdelta3') or shutil.which('xdelta3.exe')
    return Path(found).resolve() if found else None


def export_xdelta_package(clean_iso: str | Path, modded_iso: str | Path, package_dir: str | Path,
                          xdelta3: str | Path | None = None, patch_name: str = 'MeleeMod.xdelta',
                          verify_hash: bool = True) -> dict:
    clean_iso = Path(clean_iso).resolve()
    modded_iso = Path(modded_iso).resolve()
    package_dir = Path(package_dir).resolve()
    tool = locate_xdelta3(xdelta3)
    if not tool:
        raise FileNotFoundError(
            'xdelta3 was not found. Install/provide xdelta3.exe, then select it in the SDK. '
            'The SDK does not bundle third-party executables.'
        )
    if not modded_iso.exists():
        raise FileNotFoundError('The modded ISO does not exist. Build or quick-update it first.')
    verify_melee_102(clean_iso, full_hash=verify_hash)
    package_dir.mkdir(parents=True, exist_ok=True)
    patch_path = package_dir / patch_name
    cmd = [str(tool), '-f', '-e', '-s', str(clean_iso), str(modded_iso), str(patch_path)]
    proc = subprocess.run(cmd, capture_output=True, text=True)
    if proc.returncode != 0:
        raise RuntimeError('xdelta3 failed:\n' + (proc.stderr or proc.stdout or f'exit code {proc.returncode}'))

    clean_sha1 = sha1_file(clean_iso)
    mod_sha256 = sha256_file(modded_iso)
    patch_sha256 = sha256_file(patch_path)
    bat = package_dir / 'Apply_Patch.bat'
    bat.write_text(r'''@echo off
setlocal
cd /d "%~dp0"
if "%~1"=="" (
  echo Drag a clean NTSC-U Melee 1.02 ISO onto this BAT file.
  echo.
  pause
  exit /b 1
)
set "BASE=%~1"
set "OUT=%~dpn1_MODDED.iso"
set "XDELTA=xdelta3.exe"
if not exist "%XDELTA%" (
  where xdelta3 >nul 2>nul
  if errorlevel 1 (
    echo xdelta3.exe was not found next to this BAT or on PATH.
    echo Place xdelta3.exe in this folder and try again.
    echo.
    pause
    exit /b 1
  )
  set "XDELTA=xdelta3"
)
"%XDELTA%" -f -d -s "%BASE%" "%~dp0''' + patch_path.name + r'''" "%OUT%"
if errorlevel 1 (
  echo.
  echo Patch failed.
  pause
  exit /b 1
)
echo.
echo Created: "%OUT%"
pause
''', encoding='utf-8')
    readme = package_dir / 'README.txt'
    readme.write_text(
        'Melee Character SDK patch package\n\n'
        'Base required: unmodified NTSC-U Super Smash Bros. Melee 1.02 (GALE01)\n'
        f'Expected embedded main.dol SHA-1: {GALE01_102_DOL_SHA1}\n\n'
        'Usage:\n'
        '1. Put xdelta3.exe in this folder (or have xdelta3 on PATH).\n'
        '2. Drag your clean Melee 1.02 ISO onto Apply_Patch.bat.\n'
        '3. A new *_MODDED.iso will be created next to your clean ISO.\n\n'
        'The clean ISO is never modified.\n',
        encoding='utf-8'
    )
    manifest = {
        'created_utc': datetime.now(timezone.utc).isoformat(),
        'base_sha1': clean_sha1,
        'modded_iso_sha256': mod_sha256,
        'patch_sha256': patch_sha256,
        'patch_file': patch_path.name,
    }
    (package_dir / 'patch_manifest.json').write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    return {'patch': str(patch_path), 'package_dir': str(package_dir), **manifest}
