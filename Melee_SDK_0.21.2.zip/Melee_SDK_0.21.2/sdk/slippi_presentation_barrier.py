"""Direct-origin Adventure presentation synchronization barrier for SDK 0.20.21.

The old co-op presentation helper mirrors raw P2 Start into P1, which is useful
for local VS but wrong for Slippi once raw physical-port ownership differs on
both peers.  For a gateway campaign whose captured origin is GM_ONLINE (0x08),
this outer accessor wrapper auto-injects Start only in known Adventure
presentation states.  Both peers therefore cross cutscenes/overview screens at
the same deterministic point without consulting raw local pad ownership.
"""
from __future__ import annotations

from .early_clear_failsafe import Asm
from .ppc import (addi, blr, cmpwi, encode_branch, lbz, li, lwz, mflr, mtlr,
                  ori, stw, stwu, lis)

GM_GET_BUTTONS_TRIGGERED_HOOK = 0x801A36A0
GM_CURRENT_MODE_ADDR = 0x80479D30
GM_ADVENTURE = 4
GM_ONLINE = 8
PAD_BUTTON_START = 0x1000
ADVENTURE_PRESENTATION_STATES = (
    0x00,0x02,0x08,0x10,0x18,0x1A,0x1C,0x20,0x22,0x24,0x28,0x2A,
    0x30,0x38,0x39,0x40,0x48,0x50,0x52,0x58,0x5A,0x5B,0x5D,
)
MARKER = b'PBRR'


def build_wrapper(base: int, leaf_addr: int, *, active_addr: int, origin_addr: int) -> bytes:
    a=Asm(base)
    a.emit(stwu(1,-0x30,1),mflr(0),stw(0,0x34,1),stw(3,0x08,1))
    # Preserve the complete accessor chain first. In current builds leaf_addr
    # is the already-installed gateway-scope guard stub, which in turn dispatches
    # active co-op to the presentation leaf and inactive campaigns to exact retail.
    a.emit(encode_branch(base+len(a.data),leaf_addr,link=True))
    # Only pad-0 queries drive Adventure presentation.
    a.emit(lwz(10,0x08,1),cmpwi(10,0,crf=7)); a.branch('done',4,30)
    a.emit(lis(12,((active_addr)+0x8000)>>16),lbz(11,(active_addr)&0xFFFF,12)); a.emit(cmpwi(11,1,crf=7)); a.branch('done',4,30)
    a.emit(lis(12,((origin_addr)+0x8000)>>16),lbz(11,(origin_addr)&0xFFFF,12)); a.emit(cmpwi(11,GM_ONLINE,crf=7)); a.branch('done',4,30)
    a.emit(lis(12,((GM_CURRENT_MODE_ADDR)+0x8000)>>16),lbz(11,(GM_CURRENT_MODE_ADDR)&0xFFFF,12)); a.emit(cmpwi(11,GM_ADVENTURE,crf=7)); a.branch('done',4,30)
    a.emit(lis(12,((GM_CURRENT_MODE_ADDR+3)+0x8000)>>16),lbz(11,(GM_CURRENT_MODE_ADDR+3)&0xFFFF,12))
    for i,state in enumerate(ADVENTURE_PRESENTATION_STATES):
        a.emit(cmpwi(11,state,crf=7)); a.branch('force',12,30)
    a.branch('done')
    a.label('force'); a.emit(ori(4,4,PAD_BUTTON_START))
    a.label('done'); a.emit(lwz(0,0x34,1),mtlr(0),addi(1,1,0x30),blr())
    return a.finish()


def install(dol,runtime_index:int,*,leaf_addr:int,active_addr:int,origin_addr:int)->dict:
    expected=encode_branch(GM_GET_BUTTONS_TRIGGERED_HOOK,leaf_addr)
    got=dol.read_at_address(GM_GET_BUTTONS_TRIGGERED_HOOK,4)
    if got!=expected:
        raise ValueError(f'presentation barrier expected accessor hook {expected.hex()}, got {got.hex()}')
    section=next(s for s in dol.sections if s.kind=='data' and s.index==runtime_index)
    base=section.address+((section.size+31)&~31)
    wrapper=base+len(MARKER)
    blob=build_wrapper(wrapper,leaf_addr,active_addr=active_addr,origin_addr=origin_addr)
    payload=MARKER+blob
    payload+=bytes((-len(payload))%32)
    added=dol.append_to_data_section(runtime_index,payload,alignment=0x20)
    # branch target must be aligned; marker length is 4, so wrapper is aligned.
    branch=encode_branch(GM_GET_BUTTONS_TRIGGERED_HOOK,wrapper)
    dol.patch_at_address(GM_GET_BUTTONS_TRIGGERED_HOOK,branch,expected=expected)
    return {
        'marker':MARKER.decode('ascii'),'section':added,'wrapper':wrapper,
        'hook':GM_GET_BUTTONS_TRIGGERED_HOOK,'leaf':leaf_addr,
        'gateway_active_address':active_addr,'gateway_origin_address':origin_addr,
        'states':list(ADVENTURE_PRESENTATION_STATES),
        'policy':'wrap existing gateway-scope accessor guard; Direct-origin presentation auto-advances on both peers; retail 1-P/local VS dispatch remains intact',
    }
