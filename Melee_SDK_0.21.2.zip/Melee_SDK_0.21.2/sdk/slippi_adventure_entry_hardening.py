from __future__ import annotations

import hashlib
import struct

from .ppc import decode_branch, encode_branch

MARKER = b'MSDK021P'
GM_GET_BUTTONS_TRIGGERED_HOOK = 0x801A36A0
RETAIL_CONTINUE = GM_GET_BUTTONS_TRIGGERED_HOOK + 4

# Complete retail gm input accessor beginning at 0x801A36A0.  The 0.20.0
# presentation hook previously replayed only the first instruction in a tiny
# trampoline at 0x804DFB40 and then branched back to RETAIL_CONTINUE.  Runtime
# Slippi evidence showed that exact trampoline had been clobbered (0x2D/zeroes)
# before Adventure presentation code called it.  0.20.1 therefore copies the
# complete retail accessor into already-retired HF21 storage and calls that
# self-contained copy instead.
RETAIL_ACCESSOR = bytes.fromhex(
    '5460063e'  # rlwinm r0,r3,0,24,31
    '1c000030'  # mulli  r0,r0,0x30
    '3c608048'  # lis    r3,0x8048
    '38639c30'  # addi   r3,r3,0x9c30
    '7c830214'  # add    r4,r3,r0
    '80640008'  # lwz    r3,8(r4)
    '8084000c'  # lwz    r4,0xc(r4)
    '4e800020'  # blr
)


def install(dol, runtime_index: int, *, presentation_wrapper_addr: int,
            old_trampoline_addr: int, retired_trace_hooks: list[dict],
            wrapper_capacity: int = 0x140) -> dict:
    if not retired_trace_hooks:
        raise ValueError('SDK 0.20.1 requires at least one retired HF21 trace block')

    # Reuse the first retired HF21 wrapper. Its retail hook site was restored by
    # SDK 0.20.0, so this block is dead storage in production and costs no new
    # runtime section or hook site.
    safe_copy_addr = int(retired_trace_hooks[0]['hf21_wrapper'])
    dol.patch_at_address(safe_copy_addr, RETAIL_ACCESSOR)
    dol.patch_at_address(safe_copy_addr + len(RETAIL_ACCESSOR), MARKER)

    # The presentation wrapper has two BLs to the old tiny trampoline: once for
    # P1's retail result and once for P2's retail result. Retarget exactly those
    # calls, leaving every other instruction byte-identical to 0.20.0.
    call_sites = []
    for addr in range(presentation_wrapper_addr, presentation_wrapper_addr + wrapper_capacity, 4):
        raw = dol.read_at_address(addr, 4)
        try:
            dec = decode_branch(addr, raw)
        except Exception:
            continue
        if dec and dec.get('target') == old_trampoline_addr and dec.get('link'):
            dol.patch_at_address(addr, encode_branch(addr, safe_copy_addr, link=True))
            call_sites.append(addr)
    if len(call_sites) != 2:
        raise ValueError(f'expected exactly two presentation trampoline calls, found {len(call_sites)}')

    # Deliberately leave the old 0x804DFB40 trampoline bytes untouched in the
    # DOL. Nothing references them after this patch; preserving them makes the
    # binary delta narrow and lets runtime screenshots prove whether Slippi is
    # independently overwriting that address.
    return {
        'marker': MARKER.decode('ascii'),
        'safe_retail_accessor_copy': safe_copy_addr,
        'safe_retail_accessor_size': len(RETAIL_ACCESSOR),
        'old_clobbered_trampoline': old_trampoline_addr,
        'presentation_wrapper': presentation_wrapper_addr,
        'retargeted_call_sites': call_sites,
        'policy': 'preserve P2 Adventure presentation START mirror while removing all live execution through the runtime-clobbered 0x804DFB40 trampoline',
        'runtime_evidence': 'Slippi cold boot succeeds; Yoshi two-human Adventure entry reaches presentation wrapper then reports unknown instructions at 0x804DFB44..0x804DFB58; LR=0x804DFB74',
    }
