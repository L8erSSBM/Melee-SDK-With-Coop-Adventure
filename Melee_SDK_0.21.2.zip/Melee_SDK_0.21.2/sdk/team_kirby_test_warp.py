"""HF27: developer-only direct warp to the Team-Kirby fight.

HF26 made the Team-Kirby L+D-Pad Down force-clear wait for retail event cleanup,
but reaching the fight normally is too slow for repeated Dolphin reproduction.
HF27 repurposes L+D-Pad Left (formerly the P1 blast-zone KO shortcut) as a
Team-Kirby test warp while preserving every production path.

The shortcut deliberately does *not* poke Adventure's current-state byte.  It
requests an ordinary 1P stage-end scene exit, latches a test flag, and a second
guarded hook applies the requested Team-Kirby route only after the current
Adventure state's normal on_exit handler has completed.  This prevents states
such as Mushroom Kingdom from overwriting the test route with their own normal
next-state selection.

L+D-Pad Left does nothing when already in Team-Kirby, so it can no longer drain
P1's stock there.  L+D-Pad Right and Up continue to delegate through HF26 to the
existing developer helper, and L+D-Pad Down remains HF26's clean Team-Kirby
force-clear command.
"""
from __future__ import annotations

from .ppc import andi_dot, blr, cmpwi, encode_branch, lbz, li
from .team_kirby_force_clear import Asm, _addr_parts

ADVENTURE_MODE_ADDR = 0x80479D30
ADVENTURE_STATE_ADDR = 0x80479D33
ADVENTURE_NEXT_STATE_ADDR = 0x80479D35
GM_ADVENTURE = 4
TEAM_KIRBY_FIGHT_STATE = 0x23
# The routing engine stores target+1, then subtracts one after state on_exit.
TEAM_KIRBY_NEXT_ROUTE_BYTE = TEAM_KIRBY_FIGHT_STATE + 1

HSD_PAD_COPY_STATUS = 0x804C20BC
PAD_STATUS_STRIDE = 0x44
PAD_BUTTON_OFF = 0x00
PAD_TRIGGER_OFF = 0x08
PAD_BUTTON_DLEFT = 0x0001
PAD_BUTTON_L = 0x0040

VS_SCENE_CONTROLLER = 0x8046B6A0
VS_TERMINATE_MATCH_ADDR = VS_SCENE_CONTROLLER + 0x06
VS_MATCH_RESULT_ADDR = VS_SCENE_CONTROLLER + 0x08
MATCH_OUTCOME_1P_STAGE_END = 6

# gm_801A4014: immediately after state->on_exit(state), before the routing
# engine copies curr->prev and consumes next_state_id.
ROUTING_HOOK = 0x801A4148
ROUTING_RETURN = ROUTING_HOOK + 4
ROUTING_EXPECTED = lbz(0, 3, 31)


def shortcut_wrapper(base: int, *, hf26_stub: int, warp_flag_addr: int,
                     request_counter_addr: int) -> bytes:
    """Intercept only L+Left; tail-delegate all other shortcuts to HF26."""
    a = Asm(base)

    a.load_abs(11, ADVENTURE_MODE_ADDR, byte=True)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7)); a.branch('delegate', bo=4, bi=30)

    for pad_index in (0, 1):
        pad = HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE * pad_index
        hi, lo = _addr_parts(pad)
        from .ppc import lis, lwz
        a.emit(lis(12, hi), lwz(11, lo + PAD_BUTTON_OFF, 12),
               andi_dot(10, 11, PAD_BUTTON_L))
        a.branch(f'pad{pad_index}_next', bo=12, bi=2)  # no L
        a.emit(lwz(11, lo + PAD_TRIGGER_OFF, 12),
               andi_dot(10, 11, PAD_BUTTON_DLEFT))
        a.branch('warp', bo=4, bi=2)  # D-left triggered
        a.label(f'pad{pad_index}_next')

    a.label('delegate')
    a.emit(encode_branch(base + len(a.data), hf26_stub))

    a.label('warp')
    # Left is no longer a P1 KO.  While already at Team Kirby it is a no-op,
    # avoiding the same premature-results condition this test path is meant to
    # diagnose.
    a.load_abs(11, ADVENTURE_STATE_ADDR, byte=True)
    a.emit(cmpwi(11, TEAM_KIRBY_FIGHT_STATE, crf=7)); a.branch('return', bo=12, bi=30)

    a.emit(li(11, 1)); a.store_abs(11, warp_flag_addr, byte=True)
    a.inc_counter(request_counter_addr, 'terminate')

    a.label('terminate')
    a.emit(li(11, MATCH_OUTCOME_1P_STAGE_END)); a.store_abs(11, VS_MATCH_RESULT_ADDR, byte=True)
    a.emit(li(11, 1)); a.store_abs(11, VS_TERMINATE_MATCH_ADDR, byte=True)
    a.label('return')
    a.emit(blr())
    return a.finish()


def routing_wrapper(base: int, *, warp_flag_addr: int,
                    applied_counter_addr: int) -> bytes:
    """Apply the warp after the current state's retail on_exit has finished."""
    a = Asm(base)
    a.load_abs(11, warp_flag_addr, byte=True)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('replay', bo=12, bi=30)

    # Consume the one-shot request and override any next-state choice made by
    # the state that is currently exiting.  0x24 is consumed as target 0x23.
    a.emit(li(11, 0)); a.store_abs(11, warp_flag_addr, byte=True)
    a.emit(li(11, TEAM_KIRBY_NEXT_ROUTE_BYTE)); a.store_abs(11, ADVENTURE_NEXT_STATE_ADDR, byte=True)
    a.inc_counter(applied_counter_addr, 'replay')

    a.label('replay')
    a.emit(ROUTING_EXPECTED)
    a.emit(encode_branch(base + len(a.data), ROUTING_RETURN))
    return a.finish()


def install(dol, index: int, *, old_shortcut_addr: int, hf26_stub: int) -> dict:
    """Append HF27 to an HF26 DOL and install two expected-byte guarded hooks."""
    expected_shortcut = encode_branch(old_shortcut_addr, hf26_stub)
    got_shortcut = dol.read_at_address(old_shortcut_addr, 4)
    if got_shortcut != expected_shortcut:
        raise ValueError(
            'HF27 expected the HF26 shortcut redirect at '
            f'0x{old_shortcut_addr:08X}: expected {expected_shortcut.hex()}, '
            f'got {got_shortcut.hex()}')

    got_route = dol.read_at_address(ROUTING_HOOK, 4)
    if got_route != ROUTING_EXPECTED:
        raise ValueError(
            f'HF27 routing hook expected {ROUTING_EXPECTED.hex()} at '
            f'0x{ROUTING_HOOK:08X}, got {got_route.hex()}')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)
    # 0x00 marker, 0x10 flag, 0x14 requested counter, 0x18 applied counter,
    # 0x20 shortcut wrapper, routing wrapper follows aligned to 0x20.
    payload = bytearray(b'HF27TKWP' + bytes(24))
    warp_flag = base + 0x10
    request_counter = base + 0x14
    applied_counter = base + 0x18
    shortcut_stub = base + 0x20
    sw = shortcut_wrapper(shortcut_stub, hf26_stub=hf26_stub,
                          warp_flag_addr=warp_flag,
                          request_counter_addr=request_counter)
    payload.extend(sw)
    payload.extend(bytes((-len(payload)) % 32))
    routing_stub = base + len(payload)
    rw = routing_wrapper(routing_stub, warp_flag_addr=warp_flag,
                         applied_counter_addr=applied_counter)
    payload.extend(rw)
    payload.extend(bytes((-len(payload)) % 32))

    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base

    shortcut_branch = encode_branch(old_shortcut_addr, shortcut_stub)
    route_branch = encode_branch(ROUTING_HOOK, routing_stub)
    dol.patch_at_address(old_shortcut_addr, shortcut_branch, expected=expected_shortcut)
    dol.patch_at_address(ROUTING_HOOK, route_branch, expected=ROUTING_EXPECTED)

    return {
        'marker': 'HF27TKWP',
        'section': added,
        'shortcut_entry': old_shortcut_addr,
        'shortcut_stub': shortcut_stub,
        'hf26_delegate_stub': hf26_stub,
        'routing_hook': ROUTING_HOOK,
        'routing_stub': routing_stub,
        'warp_flag': warp_flag,
        'request_counter': request_counter,
        'applied_counter': applied_counter,
        'target_state': TEAM_KIRBY_FIGHT_STATE,
        'scope': 'developer test shortcuts only; Adventure',
        'behavior': (
            'L+DLeft exits the current playable Adventure match normally, then '
            'overrides post-on_exit routing to Team-Kirby state 0x23; L+DLeft '
            'is a no-op once already in Team Kirby'),
    }
