from __future__ import annotations

import hashlib
import struct
from dataclasses import dataclass, asdict
from pathlib import Path

from .dol_patch import DOLImage
from .ppc import encode_branch, decode_branch


@dataclass(frozen=True)
class HookSite:
    name: str
    address: int
    expected: bytes


@dataclass
class InstalledHook:
    name: str
    site_address: int
    stub_address: int
    original_instruction: str
    site_branch: str
    return_branch: str


class RuntimeHookInstaller:
    """Expected-byte guarded PPC hook installer for appended DOL sections.

    Phase 29 first installs transparent trampolines: each hook branches into an
    appended loader-backed section, executes the exact displaced instruction,
    then returns to site+4.  This proves the executable transport and gives later
    co-op/Stage Hub/Stock Run payloads a shared safe hook substrate without
    changing retail behavior merely because the framework is present.
    """

    MAGIC = b'MSDKRT29'

    def __init__(self, dol: DOLImage):
        self.dol = dol

    def install_transparent_hooks(self, sites: list[HookSite], *, flags: int = 0, address: int | None = None) -> dict:
        if not sites:
            raise ValueError('At least one hook site is required')
        for site in sites:
            if len(site.expected) != 4:
                raise ValueError(f'{site.name}: transparent hooks displace exactly one instruction')
            actual=self.dol.read_at_address(site.address,4)
            if actual != site.expected:
                raise ValueError(f'{site.name}: expected-byte guard failed at 0x{site.address:08X}: '
                                 f'expected {site.expected.hex()}, got {actual.hex()}')

        # 0x20 header, then two instructions per hook: displaced op + b site+4.
        payload = bytearray(0x20 + len(sites)*8)
        payload[0:8] = self.MAGIC
        struct.pack_into('>IIIIII', payload, 8, 1, int(flags), len(sites), 0, 0, 0)
        sec = self.dol.add_data_section(payload, address=address, address_alignment=0x20)
        base = sec['address']
        installed=[]
        for i,site in enumerate(sites):
            stub=base+0x20+i*8
            off=self.dol.file_offset_for_address(stub,8)
            self.dol.raw[off:off+4]=site.expected
            back=encode_branch(stub+4, site.address+4)
            self.dol.raw[off+4:off+8]=back
            site_branch=encode_branch(site.address,stub)
            self.dol.patch_at_address(site.address,site_branch,expected=site.expected)
            installed.append(InstalledHook(site.name,site.address,stub,site.expected.hex(),
                                           site_branch.hex(),back.hex()))
        # Rewrite section bytes are already in self.raw; return a reproducible manifest.
        return {
            'format':'melee-sdk-runtime-hook-install-v1',
            'section':sec,
            'runtime_magic':self.MAGIC.decode('ascii'),
            'flags':int(flags),
            'hooks':[asdict(x) for x in installed],
            'post_sha1':hashlib.sha1(bytes(self.dol.raw)).hexdigest(),
            'behavior':'transparent-trampoline-framework',
        }
