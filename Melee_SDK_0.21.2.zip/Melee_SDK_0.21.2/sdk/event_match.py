from __future__ import annotations

import json
import struct
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

from .melee_dat import HSDArchive

EVENT_PUBLIC = 'sqEventInitDataLevelTbl'
EVENT_COUNT = 51
PLAYER_RECORD_SIZE = 0x1C
EVINIT_SIZE = 0x28
MAX_EVENT_PLAYER_POINTERS = 6

# Source: melee/pl/forward.h
PKIND_HUMAN = 0
PKIND_CPU = 1
PKIND_DEMO = 2
PKIND_NA = 3
PKIND_BOSS = 4
PKIND_NAMES = {
    PKIND_HUMAN: 'Human',
    PKIND_CPU: 'CPU',
    PKIND_DEMO: 'Demo',
    PKIND_NA: 'N/A',
    PKIND_BOSS: 'Boss',
}

# CharacterKind sentinel used by event mode for "choose/random" handling.
CHKIND_NONE = 0x21


@dataclass
class EventRules:
    offset: int
    match_kind: int
    x0_3: int
    timer_enabled: bool
    timer_counts_up: bool
    x1_0: bool
    friendly_fire: bool
    x1_2: bool
    x1_3: bool
    x1_4: bool
    x1_5: int
    is_teams: int
    item_freq: int
    sd_penalty: int
    unk5: int
    stage_kind: int
    time_limit: int
    game_speed: float
    unk24: float


@dataclass
class EventPlayer:
    pointer_index: int
    offset: int
    character_kind: int
    slot_type: int
    stocks: int
    color: int
    spawn_pos: int
    sub_color: int
    team: int
    xB: int
    flags: int
    cpu_kind: int
    cpu_level: int
    damage1: int
    hp: int
    attack_ratio: float
    defense_ratio: float
    model_scale: float

    @property
    def slot_type_name(self) -> str:
        return PKIND_NAMES.get(self.slot_type, f'Unknown {self.slot_type}')


@dataclass
class EventMatch:
    index: int
    offset: int
    kind: int
    flags: int
    player_count_field: int
    rules: EventRules
    players: list[EventPlayer]
    x4_pointer: int
    bonus_pointer: int
    stage_table_pointer: int

    @property
    def display_number(self) -> int:
        return self.index + 1


class EventMatchArchive:
    """Source-grounded GmEvent.dat editor for retail GALE01 event matches.

    The archive is data-driven: sqEventInitDataLevelTbl is a table of 51 event
    pointers.  This editor mutates only fields whose meaning is established by
    the decomp's gm_evinit / gm_801BAB40_src layouts.  Opaque pointers and
    event-specific payloads are preserved exactly.

    A useful side effect is that ordinary Event Match entries can be converted
    into two-human local co-op experiments without executable code injection:
    player slot 0 and slot 1 are both Gm_PKind_Human, while remaining active
    slots can stay CPU.  Vanilla event CSS only selects the first player's
    variable fighter, so P2 should use a fixed CharacterKind until a true
    two-human CSS bridge is implemented.
    """

    def __init__(self, path_or_bytes: str | Path | bytes | bytearray):
        if isinstance(path_or_bytes, (bytes, bytearray)):
            self.path: Path | None = None
            self.archive = HSDArchive(path_or_bytes)
            self.filename = 'GmEvent.dat'
        else:
            self.path = Path(path_or_bytes)
            self.archive = HSDArchive.from_file(self.path)
            self.filename = self.path.name
        self.root = self._require_public(EVENT_PUBLIC)
        self._validate_root()

    def _require_public(self, name: str) -> int:
        p = next((p for p in self.archive.publics if p.name == name), None)
        if p is None:
            raise ValueError(f'{self.filename}: required public symbol {name!r} was not found')
        return p.offset

    def _check_range(self, off: int, size: int, label: str) -> None:
        if off < 0 or size < 0 or off + size > self.archive.header.data_size:
            raise ValueError(f'{self.filename}: {label} 0x{off:X}+0x{size:X} is outside HSD data')

    def _validate_root(self) -> None:
        self._check_range(self.root, EVENT_COUNT * 4, EVENT_PUBLIC)
        for i in range(EVENT_COUNT):
            p = self.archive.data_u32(self.root + i * 4)
            self._check_range(p, 0x2C, f'event[{i}]')
            evinit = self.archive.data_u32(p + 0x08)
            if not evinit:
                raise ValueError(f'event[{i}] has no gm_evinit pointer')
            self._check_range(evinit, EVINIT_SIZE, f'event[{i}].evinit')
            for j in range(MAX_EVENT_PLAYER_POINTERS):
                q = self.archive.data_u32(p + 0x14 + j * 4)
                if q:
                    self._check_range(q, PLAYER_RECORD_SIZE, f'event[{i}].player[{j}]')

    def _read_u8(self, off: int) -> int:
        return self.archive.data_bytes(off, 1)[0]

    def _read_i8(self, off: int) -> int:
        return struct.unpack('>b', self.archive.data_bytes(off, 1))[0]

    def _read_u16(self, off: int) -> int:
        return struct.unpack('>H', self.archive.data_bytes(off, 2))[0]

    def _read_u32(self, off: int) -> int:
        return self.archive.data_u32(off)

    def _read_f32(self, off: int) -> float:
        return self.archive.data_f32(off)

    def _write_bytes(self, off: int, data: bytes) -> None:
        self._check_range(off, len(data), 'write')
        a = self.archive.data_start + off
        self.archive.raw[a:a+len(data)] = data

    def _write_u8(self, off: int, value: int) -> None:
        if not 0 <= int(value) <= 0xFF:
            raise ValueError('u8 value out of range')
        self._write_bytes(off, bytes([int(value)]))

    def _write_i8(self, off: int, value: int) -> None:
        if not -128 <= int(value) <= 127:
            raise ValueError('s8 value out of range')
        self._write_bytes(off, struct.pack('>b', int(value)))

    def _write_u16(self, off: int, value: int) -> None:
        if not 0 <= int(value) <= 0xFFFF:
            raise ValueError('u16 value out of range')
        self._write_bytes(off, struct.pack('>H', int(value)))

    def _write_u32(self, off: int, value: int) -> None:
        if not 0 <= int(value) <= 0xFFFFFFFF:
            raise ValueError('u32 value out of range')
        self.archive.write_data_u32(off, int(value))

    def _write_f32(self, off: int, value: float) -> None:
        self.archive.write_data_f32(off, float(value))

    def _event_offset(self, index: int) -> int:
        index = int(index)
        if not 0 <= index < EVENT_COUNT:
            raise IndexError(f'event index must be 0..{EVENT_COUNT-1}')
        return self.archive.data_u32(self.root + index * 4)

    def _parse_rules(self, off: int) -> EventRules:
        b0 = self._read_u8(off)
        b1 = self._read_u8(off + 1)
        return EventRules(
            offset=off,
            match_kind=(b0 >> 5) & 0x7,
            x0_3=(b0 >> 2) & 0x7,
            timer_enabled=bool((b0 >> 1) & 1),
            timer_counts_up=bool(b0 & 1),
            x1_0=bool((b1 >> 7) & 1),
            friendly_fire=bool((b1 >> 6) & 1),
            x1_2=bool((b1 >> 5) & 1),
            x1_3=bool((b1 >> 4) & 1),
            x1_4=bool((b1 >> 3) & 1),
            x1_5=b1 & 0x7,
            is_teams=self._read_u8(off + 2),
            item_freq=self._read_i8(off + 3),
            sd_penalty=self._read_i8(off + 4),
            unk5=self._read_u8(off + 5),
            stage_kind=self._read_u16(off + 6),
            time_limit=self._read_u32(off + 8),
            game_speed=self._read_f32(off + 0x20),
            unk24=self._read_f32(off + 0x24),
        )

    def _parse_player(self, pointer_index: int, off: int) -> EventPlayer:
        return EventPlayer(
            pointer_index=pointer_index,
            offset=off,
            character_kind=self._read_i8(off),
            slot_type=self._read_u8(off + 1),
            stocks=self._read_u8(off + 2),
            color=self._read_u8(off + 3),
            spawn_pos=self._read_u8(off + 4),
            sub_color=self._read_u8(off + 5),
            team=self._read_u8(off + 6),
            xB=self._read_u8(off + 7),
            flags=self._read_u8(off + 8),
            cpu_kind=self._read_u8(off + 9),
            cpu_level=self._read_u8(off + 0xA),
            damage1=self._read_u16(off + 0xC),
            hp=self._read_u16(off + 0xE),
            attack_ratio=self._read_f32(off + 0x10),
            defense_ratio=self._read_f32(off + 0x14),
            model_scale=self._read_f32(off + 0x18),
        )

    def event(self, index: int) -> EventMatch:
        off = self._event_offset(index)
        flags = self._read_u8(off + 1)
        evinit = self._read_u32(off + 0x08)
        players: list[EventPlayer] = []
        for j in range(MAX_EVENT_PLAYER_POINTERS):
            p = self._read_u32(off + 0x14 + 4*j)
            if p:
                players.append(self._parse_player(j, p))
        return EventMatch(
            index=int(index), offset=off, kind=self._read_u8(off), flags=flags,
            player_count_field=(flags >> 5) & 0x7,
            rules=self._parse_rules(evinit), players=players,
            x4_pointer=self._read_u32(off + 4), bonus_pointer=self._read_u32(off + 0x0C),
            stage_table_pointer=self._read_u32(off + 0x10),
        )

    def events(self) -> list[EventMatch]:
        return [self.event(i) for i in range(EVENT_COUNT)]

    def set_rules(self, index: int, *, stage_kind: int | None = None,
                  time_limit: int | None = None, game_speed: float | None = None,
                  is_teams: int | bool | None = None,
                  friendly_fire: bool | None = None,
                  timer_enabled: bool | None = None,
                  timer_counts_up: bool | None = None,
                  item_freq: int | None = None) -> dict[str, Any]:
        e = self.event(index); off=e.rules.offset
        before = self.archive.data_bytes(off, EVINIT_SIZE)
        if stage_kind is not None: self._write_u16(off + 6, int(stage_kind))
        if time_limit is not None: self._write_u32(off + 8, int(time_limit))
        if game_speed is not None:
            if not (0.05 <= float(game_speed) <= 10.0): raise ValueError('game_speed must be 0.05..10.0')
            self._write_f32(off + 0x20, float(game_speed))
        if is_teams is not None: self._write_u8(off + 2, 1 if bool(is_teams) else 0)
        if item_freq is not None: self._write_i8(off + 3, int(item_freq))
        if timer_enabled is not None or timer_counts_up is not None:
            b0=self._read_u8(off)
            if timer_enabled is not None: b0=(b0 & ~0x02) | (0x02 if timer_enabled else 0)
            if timer_counts_up is not None: b0=(b0 & ~0x01) | (0x01 if timer_counts_up else 0)
            self._write_u8(off,b0)
        if friendly_fire is not None:
            b1=self._read_u8(off+1); b1=(b1 & ~0x40) | (0x40 if friendly_fire else 0); self._write_u8(off+1,b1)
        after=self.archive.data_bytes(off,EVINIT_SIZE)
        return {'event_index':int(index),'offset':off,'before':before.hex(),'after':after.hex()}

    def set_player(self, index: int, pointer_index: int, *, character_kind: int | None = None,
                   slot_type: int | None = None, stocks: int | None = None,
                   color: int | None = None, team: int | None = None,
                   cpu_level: int | None = None, hp: int | None = None,
                   attack_ratio: float | None = None,
                   defense_ratio: float | None = None,
                   model_scale: float | None = None) -> dict[str, Any]:
        e=self.event(index)
        p=next((x for x in e.players if x.pointer_index==int(pointer_index)),None)
        if p is None: raise ValueError(f'Event {index+1} has no player record at pointer slot {pointer_index}')
        off=p.offset; before=self.archive.data_bytes(off,PLAYER_RECORD_SIZE)
        if character_kind is not None:
            if not -1 <= int(character_kind) <= 0x7F: raise ValueError('character_kind must fit signed byte')
            self._write_i8(off,int(character_kind))
        if slot_type is not None:
            if int(slot_type) not in PKIND_NAMES: raise ValueError('slot_type must be Human/CPU/Demo/N/A/Boss (0..4)')
            self._write_u8(off+1,int(slot_type))
        if stocks is not None: self._write_u8(off+2,int(stocks))
        if color is not None: self._write_u8(off+3,int(color))
        if team is not None: self._write_u8(off+6,int(team))
        if cpu_level is not None:
            if not 0 <= int(cpu_level) <= 9: raise ValueError('cpu_level must be 0..9')
            self._write_u8(off+0xA,int(cpu_level))
        if hp is not None: self._write_u16(off+0xE,int(hp))
        if attack_ratio is not None: self._write_f32(off+0x10,float(attack_ratio))
        if defense_ratio is not None: self._write_f32(off+0x14,float(defense_ratio))
        if model_scale is not None: self._write_f32(off+0x18,float(model_scale))
        after=self.archive.data_bytes(off,PLAYER_RECORD_SIZE)
        return {'event_index':int(index),'pointer_index':int(pointer_index),'offset':off,'before':before.hex(),'after':after.hex()}

    def set_player_count_field(self, index: int, count: int) -> None:
        if not 0 <= int(count) <= 7: raise ValueError('event player count field must be 0..7')
        off=self._event_offset(index); b=self._read_u8(off+1)
        self._write_u8(off+1,(b & 0x1F) | ((int(count)&7)<<5))

    def make_duo_coop(self, index: int, *, p2_character_kind: int,
                       cpu_level: int = 7, stocks: int | None = None,
                       p1_character_kind: int = CHKIND_NONE,
                       friendly_fire: bool = False) -> dict[str, Any]:
        """Convert a normal 3/4-player event into a two-human co-op battle.

        This intentionally requires pre-existing player records; it does not
        fabricate event-specific opaque data.  P1 may remain ChKind_None so the
        vanilla event CSS can choose P1. P2 is fixed because vanilla event CSS
        does not provide a second fighter-selection cursor.
        """
        e=self.event(index)
        if e.kind != 0:
            raise ValueError('Duo conversion currently supports ordinary event kind 0 only; bonus/multi-round events have special runtime logic.')
        active=sorted(e.players,key=lambda x:x.pointer_index)
        if len(active) < 3:
            raise ValueError('Duo conversion needs an event with at least 3 existing player records (P1, P2, and at least one opponent).')
        if active[0].pointer_index != 0 or active[1].pointer_index != 1:
            raise ValueError('Duo conversion requires player pointer slots 0 and 1 to exist.')
        if not 0 <= int(p2_character_kind) <= 0x20:
            raise ValueError('P2 CharacterKind must be 0..0x20 (fixed fighter identity).')
        self.set_player(index,0,character_kind=int(p1_character_kind),slot_type=PKIND_HUMAN,team=0,
                        **({'stocks':int(stocks)} if stocks is not None else {}))
        self.set_player(index,1,character_kind=int(p2_character_kind),slot_type=PKIND_HUMAN,team=0,
                        **({'stocks':int(stocks)} if stocks is not None else {}))
        for p in active[2:4]:
            self.set_player(index,p.pointer_index,slot_type=PKIND_CPU,team=1,cpu_level=int(cpu_level),
                            **({'stocks':int(stocks)} if stocks is not None else {}))
        # Player count is the contiguous runtime count consumed by onEnterVs.
        used=[p for p in active if p.pointer_index < 4]
        count=max(p.pointer_index for p in used)+1
        self.set_player_count_field(index,count)
        self.set_rules(index,is_teams=True,friendly_fire=friendly_fire)
        return {
            'event_index':int(index),'event_number':int(index)+1,
            'runtime_player_count':count,'p1':'Human / vanilla event CSS selectable' if int(p1_character_kind)==CHKIND_NONE else 'Human / fixed',
            'p2':'Human / fixed','p2_character_kind':int(p2_character_kind),
            'cpu_level':int(cpu_level),'friendly_fire':bool(friendly_fire),
            'note':'Runtime-data conversion complete. In-game controller/CSS behavior should be tested on hardware/emulator before treating this as production-safe.'
        }

    def report(self) -> dict[str, Any]:
        evs=self.events()
        return {
            'format':'melee-sdk-event-report-v1','filename':self.filename,
            'event_count':len(evs),'public_root':EVENT_PUBLIC,'public_offset':self.root,
            'ordinary_events':sum(e.kind==0 for e in evs),
            'bonus_events':sum(e.kind==1 for e in evs),
            'multiround_events':sum(e.kind==2 for e in evs),
            'events':[{
                'index':e.index,'number':e.display_number,'kind':e.kind,'flags':e.flags,
                'player_count_field':e.player_count_field,'stage_kind':e.rules.stage_kind,
                'time_limit':e.rules.time_limit,'game_speed':e.rules.game_speed,
                'is_teams':e.rules.is_teams,'friendly_fire':e.rules.friendly_fire,
                'players':[asdict(p) | {'slot_type_name':p.slot_type_name} for p in e.players],
            } for e in evs]
        }

    def export_json(self, path: str | Path) -> Path:
        p=Path(path); p.write_text(json.dumps(self.report(),indent=2),encoding='utf-8'); return p

    def save(self, path: str | Path | None = None) -> Path:
        out=Path(path) if path is not None else self.path
        if out is None: raise ValueError('save path is required for an in-memory GmEvent archive')
        self.archive.write_file(out); return out
