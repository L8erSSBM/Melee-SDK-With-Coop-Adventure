"""Keep SDK-authored SSS archives outside Slippi's stock filename diff path."""
from pathlib import Path

from .gamecube_iso import GameCubeISO
from .sss_visual_qol import patch_mnslmap_bytes

MENU_ALIASES = {'MnSlMap.usd': 'MnCoMap.usd', 'MnSlMap.dat': 'MnCoMap.dat'}


def stage_isolated_menus(iso: GameCubeISO, build: Path, icon: Path, *, standalone_stages=False) -> dict:
    sources = {name: iso.read_file(iso.find_file(name)) for name in MENU_ALIASES}
    first = {name: patch_mnslmap_bytes(raw, icon, standalone_stages=standalone_stages)[1] for name, raw in sources.items()}
    # One compact runtime works for both language archives; row contents remain
    # language-specific and retail captions are restored byte-for-byte.
    table = (max(r['runtime_visual_table_offset'] for r in first.values())+31)&~31
    reports = {}
    for name, raw in sources.items():
        patched, report = patch_mnslmap_bytes(raw, icon, runtime_table_offset=table, standalone_stages=standalone_stages)
        dest = build / MENU_ALIASES[name]
        dest.write_bytes(patched)
        report.update(source_path=name, output=str(dest), size=len(patched))
        reports[name] = report
    primary = dict(reports['MnSlMap.usd'])
    contract = ('runtime_visual_models_offset', 'runtime_visual_table_offset', 'runtime_visual_record_count')
    for report in reports.values():
        if any(report[k] != primary[k] for k in contract):
            raise ValueError('Language archives disagree on the SSS runtime contract')
    primary.update(archives=reports, archive_aliases=MENU_ALIASES,
                   archive_isolation='SDK filenames bypass Slippi stock-menu diffs')
    return primary


def isolate_menu_load_names(dol_bytes: bytes) -> tuple[bytes, list[dict]]:
    data = bytearray(dol_bytes)
    changes = []
    for original, alias in MENU_ALIASES.items():
        before, after = original.encode()+b'\0', alias.encode()+b'\0'
        if len(before) != len(after) or data.count(before) != 1:
            raise ValueError(f'Expected exactly one retail menu filename: {original}')
        offset = data.index(before)
        data[offset:offset+len(before)] = after
        changes.append({'original': original, 'alias': alias, 'file_offset': offset})
    return bytes(data), changes
