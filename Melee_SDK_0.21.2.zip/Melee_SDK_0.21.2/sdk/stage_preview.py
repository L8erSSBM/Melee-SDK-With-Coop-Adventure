from __future__ import annotations

from pathlib import Path
from typing import Any
import math
import struct
import zlib

from .stage import StageDAT
from .stage_architecture import collision_surface_inventory


def _bounds(stage: StageDAT):
    pts = stage.vertices() if stage.has_public('coll_data') else []
    if not pts:
        return (-100, -75, 100, 75)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    pad = max(10.0, (max(xs)-min(xs))*0.08, (max(ys)-min(ys))*0.08)
    return (min(xs)-pad, min(ys)-pad, max(xs)+pad, max(ys)+pad)


class _Raster:
    """Tiny dependency-free RGB raster used when Pillow is unavailable.

    Draft Preview is core SDK functionality and therefore must not require an
    optional third-party image package.  This intentionally implements only the
    primitives the orthographic collision preview needs.
    """
    def __init__(self, width: int, height: int, bg=(232, 234, 236)):
        self.width = int(width)
        self.height = int(height)
        self.pixels = bytearray(bytes(bg) * (self.width * self.height))

    def pixel(self, x: int, y: int, color):
        if 0 <= x < self.width and 0 <= y < self.height:
            i = (y * self.width + x) * 3
            self.pixels[i:i+3] = bytes(color)

    def rect(self, x0, y0, x1, y1, color):
        x0, x1 = sorted((max(0, int(x0)), min(self.width-1, int(x1))))
        y0, y1 = sorted((max(0, int(y0)), min(self.height-1, int(y1))))
        row = bytes(color) * (x1-x0+1)
        for y in range(y0, y1+1):
            i = (y*self.width + x0)*3
            self.pixels[i:i+len(row)] = row

    def line(self, x0, y0, x1, y1, color, width=1):
        x0, y0, x1, y1 = map(lambda v: int(round(v)), (x0, y0, x1, y1))
        dx = abs(x1-x0); sx = 1 if x0 < x1 else -1
        dy = -abs(y1-y0); sy = 1 if y0 < y1 else -1
        err = dx + dy
        r = max(0, int(width)//2)
        while True:
            for yy in range(y0-r, y0+r+1):
                for xx in range(x0-r, x0+r+1):
                    self.pixel(xx, yy, color)
            if x0 == x1 and y0 == y1:
                break
            e2 = 2*err
            if e2 >= dy:
                err += dy; x0 += sx
            if e2 <= dx:
                err += dx; y0 += sy

    def disc(self, cx, cy, r, color):
        cx, cy, r = int(round(cx)), int(round(cy)), max(1, int(round(r)))
        rr = r*r
        for y in range(cy-r, cy+r+1):
            for x in range(cx-r, cx+r+1):
                if (x-cx)*(x-cx) + (y-cy)*(y-cy) <= rr:
                    self.pixel(x, y, color)

    @staticmethod
    def _chunk(kind: bytes, data: bytes) -> bytes:
        return struct.pack('>I', len(data)) + kind + data + struct.pack('>I', zlib.crc32(kind+data) & 0xFFFFFFFF)

    def save_png(self, path: str | Path):
        raw = bytearray()
        stride = self.width * 3
        for y in range(self.height):
            raw.append(0)  # PNG filter: None
            i = y*stride
            raw.extend(self.pixels[i:i+stride])
        png = bytearray(b'\x89PNG\r\n\x1a\n')
        png += self._chunk(b'IHDR', struct.pack('>IIBBBBB', self.width, self.height, 8, 2, 0, 0, 0))
        png += self._chunk(b'IDAT', zlib.compress(bytes(raw), 6))
        png += self._chunk(b'IEND', b'')
        Path(path).write_bytes(png)


def _render_dependency_free(stage: StageDAT, output: Path, width: int, height: int, grid_step: float) -> Path:
    r = _Raster(width, height)
    x0, y0, x1, y1 = _bounds(stage)
    sx = (width-80)/(x1-x0 or 1); sy = (height-80)/(y1-y0 or 1); s = min(sx, sy)
    cx = width/2-(x0+x1)/2*s; cy = height/2+(y0+y1)/2*s
    def cv(p): return (cx+p[0]*s, cy-p[1]*s)

    gx = math.floor(x0/grid_step)*grid_step
    while gx <= x1:
        X = cv((gx, 0))[0]; r.line(X, 0, X, height-1, (198, 202, 206)); gx += grid_step
    gy = math.floor(y0/grid_step)*grid_step
    while gy <= y1:
        Y = cv((0, gy))[1]; r.line(0, Y, width-1, Y, (198, 202, 206)); gy += grid_step
    X = cv((0,0))[0]; Y = cv((0,0))[1]
    r.line(X, 0, X, height-1, (135,139,144), 2)
    r.line(0, Y, width-1, Y, (135,139,144), 2)

    colors = {'Floor':(40,40,40), 'Ceiling':(185,70,70), 'Left Wall':(70,90,180),
              'Right Wall':(70,90,180), 'Dynamic':(120,70,160)}
    vertices = stage.vertices() if stage.has_public('coll_data') else []
    for i, line in enumerate(stage.lines() if stage.has_public('coll_data') else []):
        surf = stage.line_surface(i)
        col = colors.get(surf['category'], (70,70,70))
        p0 = cv(vertices[line['v0']]); p1 = cv(vertices[line['v1']])
        r.line(*p0, *p1, col, 5 if surf['platform'] else 3)
        if surf['ledge']:
            r.disc(*p0, 5, (30,170,80)); r.disc(*p1, 5, (30,170,80))

    if stage.has_public('map_head'):
        for m in stage.markers():
            if m.marker_id > 7 and not (0x94 <= m.marker_id <= 0x98):
                continue
            p = cv((m.world_x, m.world_y))
            fill = (25,130,200) if m.marker_id <= 7 else (210,130,20)
            r.disc(*p, 5, fill)

    # Simple header strip.  Text labels are supplied by the GUI itself when PIL
    # is absent; geometry remains identical to the richer Pillow path.
    r.rect(0, 0, width-1, 33, (245,246,247))
    r.save_png(output)
    return output


def render_stage_draft_png(stage: StageDAT, output: str|Path, *, width:int=1280, height:int=720, grid_step:float=20.0) -> Path:
    """Render an orthographic builder preview of collision + known markers.

    No third-party dependency is required. If Pillow is installed the preview
    includes text labels; otherwise the SDK uses its built-in PNG rasterizer.
    """
    out = Path(output)
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return _render_dependency_free(stage, out, width, height, grid_step)

    im=Image.new('RGB',(width,height),(232,234,236)); d=ImageDraw.Draw(im)
    x0,y0,x1,y1=_bounds(stage); sx=(width-80)/(x1-x0 or 1); sy=(height-80)/(y1-y0 or 1); s=min(sx,sy)
    cx=width/2-(x0+x1)/2*s; cy=height/2+(y0+y1)/2*s
    def cv(p): return (cx+p[0]*s, cy-p[1]*s)

    gx=math.floor(x0/grid_step)*grid_step
    while gx<=x1:
        X=cv((gx,0))[0]; d.line((X,0,X,height),fill=(198,202,206),width=1); gx+=grid_step
    gy=math.floor(y0/grid_step)*grid_step
    while gy<=y1:
        Y=cv((0,gy))[1]; d.line((0,Y,width,Y),fill=(198,202,206),width=1); gy+=grid_step
    X=cv((0,0))[0]; Y=cv((0,0))[1]
    d.line((X,0,X,height),fill=(135,139,144),width=2); d.line((0,Y,width,Y),fill=(135,139,144),width=2)

    colors={'Floor':(40,40,40),'Ceiling':(185,70,70),'Left Wall':(70,90,180),'Right Wall':(70,90,180),'Dynamic':(120,70,160)}
    vertices=stage.vertices() if stage.has_public('coll_data') else []
    for i,l in enumerate(stage.lines() if stage.has_public('coll_data') else []):
        surf=stage.line_surface(i); col=colors.get(surf['category'],(70,70,70)); p0=cv(vertices[l['v0']]); p1=cv(vertices[l['v1']])
        d.line((*p0,*p1),fill=col,width=5 if surf['platform'] else 3)
        if surf['ledge']:
            for p in (p0,p1): d.ellipse((p[0]-5,p[1]-5,p[0]+5,p[1]+5),fill=(30,170,80))
    if stage.has_public('map_head'):
        for m in stage.markers():
            if m.marker_id > 7 and not (0x94<=m.marker_id<=0x98): continue
            p=cv((m.world_x,m.world_y)); rr=5
            fill=(25,130,200) if m.marker_id<=7 else (210,130,20)
            d.ellipse((p[0]-rr,p[1]-rr,p[0]+rr,p[1]+rr),fill=fill)
            d.text((p[0]+7,p[1]-8),m.name,fill=(20,20,20))
    title=stage.catalog.name if stage.catalog else stage.filename
    d.rectangle((0,0,width,34),fill=(245,246,247)); d.text((12,9),f'{title} — Draft Collision Preview',fill=(20,20,20))
    d.text((width-370,9),'Gray grid = builder reference, not in-game geometry',fill=(80,80,80))
    im.save(out)
    return out


def create_training_grid_asset(output: str|Path, *, width:int=1024, height:int=1024, minor:int=32, major_every:int=4) -> Path:
    """Create the neutral training/grid background without requiring Pillow."""
    out=Path(output)
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        r=_Raster(width,height,(225,227,229))
        for x in range(0,width+1,minor):
            major=(x//minor)%major_every==0; v=177 if major else 204
            r.line(x,0,x,height-1,(v,v,v),2 if major else 1)
        for y in range(0,height+1,minor):
            major=(y//minor)%major_every==0; v=177 if major else 204
            r.line(0,y,width-1,y,(v,v,v),2 if major else 1)
        r.line(width//2,0,width//2,height-1,(130,133,136),3)
        r.line(0,height//2,width-1,height//2,(130,133,136),3)
        r.save_png(out); return out
    im=Image.new('RGB',(width,height),(225,227,229)); d=ImageDraw.Draw(im)
    for x in range(0,width+1,minor):
        major=(x//minor)%major_every==0; v=177 if major else 204; d.line((x,0,x,height),fill=(v,v,v),width=2 if major else 1)
    for y in range(0,height+1,minor):
        major=(y//minor)%major_every==0; v=177 if major else 204; d.line((0,y,width,y),fill=(v,v,v),width=2 if major else 1)
    d.line((width//2,0,width//2,height),fill=(130,133,136),width=3)
    d.line((0,height//2,width,height//2),fill=(130,133,136),width=3)
    im.save(out); return out
