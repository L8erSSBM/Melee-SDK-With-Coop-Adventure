"""HF24: fail-safe for the Adventure clear-screen snapshot under extreme heap pressure.

HF22 reduced the results/clear-screen capture from 640x480 RGB5A3 to 320x240,
but a forced Team-Kirby clear while all fighters are still resident can leave no
contiguous block large enough even for that smaller 153,600-byte image.

This patch wraps only the already-HF22-patched allocation call.  On the proven
Icies Team-Kirby terminal path it verifies that the current OS heap contains a
contiguous block large enough for the HF22 image plus allocator overhead.  If
not, it skips only the captured-background setup block (allocation, textured
quad creation, and its callback) and resumes the score-clear initializer at the
next retail instruction.  The score tally/UI/audio continue; lbl_80472D28.x2C
remains NULL from the function's earlier memzero and is not referenced elsewhere
unless that background GObj was created.

Outside that exact path, or when headroom is sufficient, behavior tail-enters
HF22 unchanged.
"""
from __future__ import annotations

import struct

from .ppc import addi, cmpwi, encode_bc, encode_branch, lbz, li, lis, lwz, stw, stwu

ALLOC_SITE = 0x80180A08
BACKGROUND_CONTINUE = 0x80180A50
ADVENTURE_MODE = 0x80479D30
ADVENTURE_STATE = 0x80479D33
CURRENT_HEAP = 0x804D5E00
HEAP_ARRAY = 0x804D7360
NUM_HEAPS = 0x804D7364

# HF22 allocates 320*240*2 = 153,600 bytes.  Captured allocator accounting
# showed 153,632 bytes required including alignment/cell overhead.
HF22_BUFFER_BYTES = 320 * 240 * 2
MIN_CLEAR_BLOCK = HF22_BUFFER_BYTES + 0x20
MAX_FREE_NODES = 160
MEM1_LOW = 0x80000000
MEM1_LAST_CELL = 0x817FFFF4


def word(value: int) -> bytes:
    return struct.pack('>I', value & 0xFFFFFFFF)


class Asm:
    def __init__(self, base: int):
        self.base = int(base)
        self.data = bytearray()
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str, int, int]] = []

    def emit(self, *chunks: bytes) -> None:
        for chunk in chunks:
            self.data.extend(chunk)

    def constant(self, r: int, value: int) -> None:
        value &= 0xFFFFFFFF
        self.emit(lis(r, (value + 0x8000) >> 16), addi(r, r, value & 0xFFFF))

    def absolute(self, r: int, address: int, *, byte: bool = False) -> None:
        self.constant(12, address)
        self.emit((lbz if byte else lwz)(r, 0, 12))

    def compare(self, a: int, b: int) -> None:
        # cmplw cr7,rA,rB
        self.emit(word((31 << 26) | (7 << 23) | (a << 16) | (b << 11) | (32 << 1)))

    def label(self, name: str) -> None:
        self.labels[name] = len(self.data)

    def branch(self, label: str, bo: int = 20, bi: int = 0) -> None:
        self.fixups.append((len(self.data), label, bo, bi))
        self.emit(bytes(4))

    def finish(self) -> bytes:
        for off, label, bo, bi in self.fixups:
            self.data[off:off+4] = encode_bc(
                self.base + off, self.base + self.labels[label], bo=bo, bi=bi)
        return bytes(self.data)


def wrapper(base: int, hf22_alloc_stub: int, terminal_guard: int, counter: int) -> bytes:
    a = Asm(base)

    # Preserve HF22/retail for every path except the exact verified terminal
    # Team-Kirby clear-screen allocation.
    a.absolute(11, ADVENTURE_MODE, byte=True)
    a.emit(cmpwi(11, 4, crf=7)); a.branch('hf22', 4, 30)
    a.absolute(11, terminal_guard, byte=True)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('hf22', 4, 30)
    a.absolute(11, ADVENTURE_STATE, byte=True)
    a.emit(cmpwi(11, 0x23, crf=7)); a.branch('hf22', 4, 30)
    for reg, value in ((4, 640), (5, 480), (6, 5), (7, 0)):
        a.emit(cmpwi(reg, value, crf=7)); a.branch('hf22', 4, 30)

    # From here on we need scratch registers that overlap the original args.
    # Save r3-r7 so the sufficient-headroom path can enter HF22 byte-for-byte.
    a.emit(stwu(1, -0x30, 1))
    for reg, off in ((3, 8), (4, 12), (5, 16), (6, 20), (7, 24)):
        a.emit(stw(reg, off, 1))

    a.absolute(4, CURRENT_HEAP)
    a.absolute(5, NUM_HEAPS)
    a.compare(4, 5); a.branch('skip', 4, 28)  # heap >= NumHeaps, includes -1
    a.absolute(5, HEAP_ARRAY)
    a.emit(cmpwi(5, 0, crf=7)); a.branch('skip', 12, 30)

    # OSHeapInfo[heap] (12 bytes), free-list head at +4.
    a.emit(word((7 << 26) | (4 << 21) | (4 << 16) | 12))  # mulli r4,r4,12
    a.emit(word((31 << 26) | (5 << 21) | (5 << 16) | (4 << 11) | (266 << 1)))  # add r5,r5,r4
    a.emit(lwz(6, 4, 5))
    a.constant(7, MIN_CLEAR_BLOCK)
    a.emit(li(8, MAX_FREE_NODES))
    a.constant(9, MEM1_LOW)
    a.constant(10, MEM1_LAST_CELL)

    a.label('scan')
    a.emit(cmpwi(6, 0, crf=7)); a.branch('skip', 12, 30)
    a.compare(6, 9); a.branch('skip', 12, 28)   # ptr < MEM1_LOW
    a.compare(6, 10); a.branch('skip', 12, 29)  # ptr > MEM1_LAST_CELL
    a.emit(lwz(11, 8, 6))
    a.compare(11, 7); a.branch('restore_hf22', 4, 28)  # size >= threshold
    a.emit(addi(8, 8, -1), cmpwi(8, 0, crf=7)); a.branch('skip', 12, 30)
    a.emit(lwz(6, 4, 6)); a.branch('scan')

    a.label('restore_hf22')
    for reg, off in ((3, 8), (4, 12), (5, 16), (6, 20), (7, 24)):
        a.emit(lwz(reg, off, 1))
    a.emit(addi(1, 1, 0x30))
    a.emit(encode_branch(base + len(a.data), hf22_alloc_stub))

    a.label('skip')
    # Diagnostic proof that the captured background was deliberately omitted.
    a.constant(12, counter)
    a.emit(lwz(11, 0, 12), cmpwi(11, -1, crf=7))
    a.branch('skip_jump', 12, 30)
    a.emit(addi(11, 11, 1), stw(11, 0, 12))
    a.label('skip_jump')
    a.emit(addi(1, 1, 0x30))
    # Resume inside fn_80180630 after allocation + background GObj/callback
    # setup.  state->x2C stays NULL from the initializer's memzero.
    a.emit(encode_branch(base + len(a.data), BACKGROUND_CONTINUE))

    a.label('hf22')
    a.emit(encode_branch(base + len(a.data), hf22_alloc_stub))
    return a.finish()


def install(dol, index: int, terminal_guard: int, hf22_alloc_stub: int) -> dict:
    expected = encode_branch(ALLOC_SITE, hf22_alloc_stub, link=True)
    if dol.read_at_address(ALLOC_SITE, 4) != expected:
        raise ValueError('HF24 clear-screen fail-safe expected HF22 allocation hook mismatch')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)
    payload = bytearray(b'HF24CLSK' + bytes(24))
    counter = base + 0x10
    stub = base + len(payload)
    blob = wrapper(stub, hf22_alloc_stub, terminal_guard, counter)
    payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base

    replacement = encode_branch(ALLOC_SITE, stub, link=True)
    dol.patch_at_address(ALLOC_SITE, replacement, expected=expected)
    return dict(
        marker='HF24CLSK', section=added, site_address=ALLOC_SITE,
        stub_address=stub, skip_counter=counter,
        hf22_allocation_stub=hf22_alloc_stub,
        background_continue=BACKGROUND_CONTINUE,
        min_clear_block=MIN_CLEAR_BLOCK,
        scan_limit=MAX_FREE_NODES,
        behavior='skip captured clear-screen background only when HF22 image cannot fit',
        runtime_validation='pending Dolphin reproduction',
    )
