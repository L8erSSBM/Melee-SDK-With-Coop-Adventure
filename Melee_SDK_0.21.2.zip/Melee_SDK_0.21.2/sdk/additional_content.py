from __future__ import annotations

import json
from dataclasses import dataclass, asdict
from pathlib import Path


@dataclass(frozen=True)
class ContentFeature:
    key: str
    label: str
    category: str
    description: str
    dependencies: tuple[str, ...] = ()
    experimental: bool = False


FEATURES: tuple[ContentFeature, ...] = (
    ContentFeature('stage_hub', 'Expanded Stage Select', 'Stages',
                   'Paged Stage Select runtime and mode/stage dispatch hub.'),
    ContentFeature('custom_stages', 'Custom / Imported Stages', 'Stages',
                   'Additional first-class Gr*.dat stages and dormant-stage bridge.', ('stage_hub',)),
    ContentFeature('coop_adventure', '2-Player Adventure', 'Game Modes',
                   'Two-human continuous retail Adventure campaign.', ('stage_hub',)),
    ContentFeature('coop_friendly_fire', 'Co-op Adventure Friendly Fire', 'Gameplay Extensions',
                   'Allow P1/P2 to damage each other while remaining on the co-op Adventure team.', ('coop_adventure',)),
    ContentFeature('coop_team_survival', 'Co-op Team Survival', 'Gameplay Extensions',
                   'Use independent P1/P2 stocks; Adventure fails only when both humans are eliminated.', ('coop_adventure',)),
    ContentFeature('coop_camera_control', 'Co-op Camera Control', 'Gameplay Extensions',
                   'Pass Adventure route/camera authority to the surviving human when the current owner dies.', ('coop_adventure',)),
    ContentFeature('one_player_cstick', 'C-stick in 1-Player Modes', 'Gameplay Extensions',
                   'Enable C-stick attacks in retail 1-player modes without changing their mode semantics.'),
    ContentFeature('coop_either_player_pause', 'Either Player Can Pause', 'Gameplay Extensions',
                   'Allow either active human to pause during Co-op Adventure using retail multiplayer pauser validation.', ('coop_adventure',)),
    ContentFeature('coop_dual_credits', 'Two-Player Credits Shooting', 'Gameplay Extensions',
                   'Give P1 and P2 separate Staff Roll shooting lenses with independent movement and firing while the shared credits timeline advances once per frame.', ('coop_adventure',)),
    ContentFeature('coop_either_human_events', 'Either Human Triggers Adventure Events', 'Gameplay Extensions',
                   'Evaluate shared Adventure ground-event volumes for either instantiated campaign human without transferring Control.', ('coop_adventure',)),
    ContentFeature('coop_scene_revive', 'Revive Eliminated Players Next Scene', 'Gameplay Extensions',
                   'At the next Adventure scene, revive an eliminated partner using the run\'s originally selected starting stock count.', ('coop_adventure',)),
    ContentFeature('duo_challenges', 'Duo Challenges', 'Game Modes',
                   'SDK authored two-human challenge recipes.', ('stage_hub',), True),
    ContentFeature('stock_run', 'Stock Run', 'Game Modes',
                   'Isolated deterministic roguelike mode runtime.', ('stage_hub',), True),
    ContentFeature('custom_thumbnails', 'Custom Stage Thumbnails', 'Frontend',
                   'Custom artwork for authored Stage Select entries.', ('stage_hub',), True),
    ContentFeature('slippi_extensions', 'Slippi-Compatible Extensions', 'Compatibility',
                   'Deterministic custom-mode contracts intended for matched peer builds.', (), True),
)
FEATURE_BY_KEY = {x.key: x for x in FEATURES}


@dataclass
class AdditionalContentProfile:
    name: str = 'Vanilla + Character Edits'
    enabled: list[str] = None

    def __post_init__(self):
        self.enabled = list(self.enabled or [])

    def validate(self) -> None:
        unknown = sorted(set(self.enabled) - set(FEATURE_BY_KEY))
        if unknown:
            raise ValueError(f'Unknown Additional Content feature(s): {", ".join(unknown)}')
        enabled = set(self.enabled)
        missing = []
        for key in enabled:
            for dep in FEATURE_BY_KEY[key].dependencies:
                if dep not in enabled:
                    missing.append((key, dep))
        if missing:
            text = ', '.join(f'{a} requires {b}' for a,b in missing)
            raise ValueError(f'Additional Content dependency error: {text}')

    def with_dependencies(self) -> 'AdditionalContentProfile':
        enabled = set(self.enabled)
        changed = True
        while changed:
            changed = False
            for key in tuple(enabled):
                for dep in FEATURE_BY_KEY[key].dependencies:
                    if dep not in enabled:
                        enabled.add(dep); changed = True
        out = AdditionalContentProfile(self.name, sorted(enabled))
        out.validate()
        return out

    def is_enabled(self, key: str) -> bool:
        return key in set(self.enabled)

    def build_plan(self) -> dict:
        self.validate()
        return {
            'format': 'melee-sdk-additional-content-plan-v1',
            'profile': self.name,
            'enabled': list(self.enabled),
            'features': [asdict(FEATURE_BY_KEY[k]) for k in self.enabled],
            'vanilla_isolation': {
                'fighter_edits_require_additional_content': False,
                'normal_vs_modified_by_default': False,
                'classic_modified_by_default': False,
                'all_star_modified_by_default': False,
            },
        }

    def save(self, path: str | Path) -> Path:
        self.validate()
        p = Path(path)
        p.write_text(json.dumps({'format':'melee-sdk-additional-content-profile-v1',
                                 'name':self.name,'enabled':self.enabled}, indent=2), encoding='utf-8')
        return p

    @classmethod
    def load(cls, path: str | Path) -> 'AdditionalContentProfile':
        data=json.loads(Path(path).read_text(encoding='utf-8'))
        if data.get('format') != 'melee-sdk-additional-content-profile-v1':
            raise ValueError('Unsupported Additional Content profile format')
        obj=cls(data.get('name','Additional Content'), list(data.get('enabled',[])))
        obj.validate(); return obj


def vanilla_character_only_profile() -> AdditionalContentProfile:
    return AdditionalContentProfile('Vanilla + Character Edits', [])


def full_dlc_profile() -> AdditionalContentProfile:
    return AdditionalContentProfile('Melee DLC', [
        'stage_hub','custom_stages','coop_adventure','coop_friendly_fire','coop_team_survival','coop_camera_control','one_player_cstick','coop_either_player_pause','coop_dual_credits','coop_either_human_events','coop_scene_revive','duo_challenges',
        'stock_run','custom_thumbnails','slippi_extensions'])
