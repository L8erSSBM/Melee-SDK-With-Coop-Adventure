from __future__ import annotations

import math
import struct
import zlib
from collections import defaultdict
from pathlib import Path
from typing import Any

from .melee_dat import HSDArchive
from .stage_assets import GX_TEX_FORMATS, SUPPORTED_PNG_FORMATS, texture_level_size, encode_gx_texture

COOP_TILE_SLOT = 27
EXPECTED_FAMILY_MIN = 29
_ASSET_DIR = Path(__file__).resolve().parents[1] / 'assets' / 'sss_qol'


class _PixelAccess:
    def __init__(self, image: '_RGBAImage'):
        self.image = image
    def __getitem__(self, key):
        x, y = key
        return self.image.pixels[y * self.image.width + x]
    def __setitem__(self, key, value):
        x, y = key
        self.image.pixels[y * self.image.width + x] = tuple(value)


class _RGBAImage:
    """Tiny Pillow-free RGBA surface implementing the API encode_gx_texture needs."""
    def __init__(self, width: int, height: int, pixels=None):
        self.width = int(width)
        self.height = int(height)
        if self.width <= 0 or self.height <= 0:
            raise ValueError('invalid image dimensions')
        if pixels is None:
            self.pixels = [(0, 0, 0, 0)] * (self.width * self.height)
        else:
            self.pixels = list(pixels)
            if len(self.pixels) != self.width * self.height:
                raise ValueError('RGBA pixel count mismatch')
    @property
    def size(self):
        return self.width, self.height
    def convert(self, mode: str):
        if mode != 'RGBA':
            raise ValueError(f'only RGBA conversion is supported, got {mode!r}')
        return self
    def load(self):
        return _PixelAccess(self)
    def getdata(self):
        return list(self.pixels)
    def crop(self, box):
        x0, y0, x1, y1 = map(int, box)
        x0 = max(0, min(self.width, x0)); x1 = max(x0, min(self.width, x1))
        y0 = max(0, min(self.height, y0)); y1 = max(y0, min(self.height, y1))
        out = []
        for y in range(y0, y1):
            row = y * self.width
            out.extend(self.pixels[row + x0: row + x1])
        return _RGBAImage(x1 - x0, y1 - y0, out)
    def resize(self, size):
        """Deterministic bilinear resize; no external imaging package required."""
        nw, nh = map(int, size)
        if nw <= 0 or nh <= 0:
            raise ValueError('invalid resize dimensions')
        if (nw, nh) == self.size:
            return _RGBAImage(self.width, self.height, self.pixels)
        sw, sh = self.size
        src = self.pixels
        out = []
        for y in range(nh):
            sy = ((y + 0.5) * sh / nh) - 0.5
            y0 = max(0, min(sh - 1, int(math.floor(sy))))
            y1 = min(sh - 1, y0 + 1)
            fy = max(0.0, min(1.0, sy - y0))
            for x in range(nw):
                sx = ((x + 0.5) * sw / nw) - 0.5
                x0 = max(0, min(sw - 1, int(math.floor(sx))))
                x1 = min(sw - 1, x0 + 1)
                fx = max(0.0, min(1.0, sx - x0))
                p00 = src[y0 * sw + x0]; p10 = src[y0 * sw + x1]
                p01 = src[y1 * sw + x0]; p11 = src[y1 * sw + x1]
                q = []
                for c in range(4):
                    a = p00[c] * (1.0 - fx) + p10[c] * fx
                    b = p01[c] * (1.0 - fx) + p11[c] * fx
                    q.append(max(0, min(255, int(round(a * (1.0 - fy) + b * fy)))))
                out.append(tuple(q))
        return _RGBAImage(nw, nh, out)
    def composite(self, overlay: '_RGBAImage', x0: int, y0: int):
        """Alpha-composite overlay in-place."""
        for oy in range(overlay.height):
            dy = y0 + oy
            if not (0 <= dy < self.height):
                continue
            for ox in range(overlay.width):
                dx = x0 + ox
                if not (0 <= dx < self.width):
                    continue
                sr, sg, sb, sa = overlay.pixels[oy * overlay.width + ox]
                if sa <= 0:
                    continue
                dr, dg, db, da = self.pixels[dy * self.width + dx]
                af = sa / 255.0; daf = da / 255.0
                oa = af + daf * (1.0 - af)
                if oa <= 1e-9:
                    self.pixels[dy * self.width + dx] = (0, 0, 0, 0)
                    continue
                r = int(round((sr * af + dr * daf * (1.0 - af)) / oa))
                g = int(round((sg * af + dg * daf * (1.0 - af)) / oa))
                b = int(round((sb * af + db * daf * (1.0 - af)) / oa))
                self.pixels[dy * self.width + dx] = (max(0,min(255,r)), max(0,min(255,g)), max(0,min(255,b)), max(0,min(255,int(round(oa*255)))))
        return self


def _paeth(a, b, c):
    p = a + b - c
    pa = abs(p - a); pb = abs(p - b); pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    return b if pb <= pc else c


def _load_png_rgba(path: str | Path) -> _RGBAImage:
    """Decode ordinary 8-bit non-interlaced PNGs using only Python stdlib.

    K20C accidentally made every ISO build depend on Pillow. K20E intentionally
    keeps the visual patch fully offline/stdlib-only so the normal SDK builder
    works on the same clean Windows Python install as the rest of the SDK.
    """
    raw = Path(path).read_bytes()
    if raw[:8] != b'\x89PNG\r\n\x1a\n':
        raise ValueError(f'not a PNG file: {path}')
    pos = 8; ihdr = None; idat = bytearray()
    while pos + 12 <= len(raw):
        ln = struct.unpack_from('>I', raw, pos)[0]
        typ = raw[pos+4:pos+8]
        data = raw[pos+8:pos+8+ln]
        pos += 12 + ln
        if typ == b'IHDR': ihdr = data
        elif typ == b'IDAT': idat += data
        elif typ == b'IEND': break
    if ihdr is None or len(ihdr) != 13:
        raise ValueError(f'PNG missing IHDR: {path}')
    w, h, bit_depth, color_type, comp, flt, interlace = struct.unpack('>IIBBBBB', ihdr)
    if bit_depth != 8 or comp != 0 or flt != 0 or interlace != 0:
        raise ValueError(f'PNG must be 8-bit, non-interlaced: {path}')
    channels = {0:1, 2:3, 4:2, 6:4}.get(color_type)
    if channels is None:
        raise ValueError(f'PNG color type {color_type} is unsupported for SDK visual assets')
    data = zlib.decompress(bytes(idat))
    stride = w * channels
    expected = h * (stride + 1)
    if len(data) != expected:
        raise ValueError(f'PNG scanline size mismatch: {len(data)} != {expected}')
    prev = bytearray(stride); p = 0; pixels = []
    for _y in range(h):
        filt = data[p]; p += 1
        cur = bytearray(data[p:p+stride]); p += stride
        for i in range(stride):
            a = cur[i-channels] if i >= channels else 0
            b = prev[i]
            c = prev[i-channels] if i >= channels else 0
            if filt == 1: cur[i] = (cur[i] + a) & 0xFF
            elif filt == 2: cur[i] = (cur[i] + b) & 0xFF
            elif filt == 3: cur[i] = (cur[i] + ((a+b)//2)) & 0xFF
            elif filt == 4: cur[i] = (cur[i] + _paeth(a,b,c)) & 0xFF
            elif filt != 0: raise ValueError(f'unsupported PNG filter {filt}')
        if color_type == 6:
            pixels.extend(tuple(cur[i:i+4]) for i in range(0, stride, 4))
        elif color_type == 2:
            pixels.extend((cur[i],cur[i+1],cur[i+2],255) for i in range(0,stride,3))
        elif color_type == 0:
            pixels.extend((q,q,q,255) for q in cur)
        else:  # grayscale + alpha
            pixels.extend((cur[i],cur[i],cur[i],cur[i+1]) for i in range(0,stride,2))
        prev = cur
    return _RGBAImage(w, h, pixels)


def _texture_records(raw: bytes):
    arc = HSDArchive(raw)
    incoming = defaultdict(list)
    for loc in arc.relocations:
        try: incoming[arc.data_u32(loc)].append(loc)
        except Exception: pass
    rows=[]; seen=set()
    for desc in arc.relocations:
        if desc in seen or desc < 0 or desc + 0x18 > arc.header.data_size: continue
        try:
            image=arc.data_u32(desc)
            width=struct.unpack_from('>H',arc.raw,arc.data_start+desc+4)[0]
            height=struct.unpack_from('>H',arc.raw,arc.data_start+desc+6)[0]
            fmt=arc.data_u32(desc+8); mip=arc.data_u32(desc+0xC)
            min_lod=arc.data_f32(desc+0x10); max_lod=arc.data_f32(desc+0x14)
            if not incoming.get(desc): continue
            if not (4<=width<=2048 and 4<=height<=2048): continue
            if fmt not in GX_TEX_FORMATS or GX_TEX_FORMATS[fmt] not in SUPPORTED_PNG_FORMATS: continue
            if mip not in (0,1): continue
            if not (math.isfinite(min_lod) and math.isfinite(max_lod) and -64<=min_lod<=64 and -64<=max_lod<=64): continue
            size=texture_level_size(width,height,fmt)
            if image<=0 or image+size>arc.header.data_size: continue
            seen.add(desc)
            rows.append({'name':f'ImageDesc@{desc:08X}','image':image,'desc':desc,'w':width,'h':height,'fmt':fmt,'mip':mip,'size':size,'incoming_refs':len(incoming.get(desc,()))})
        except Exception: continue
    return arc,rows


def _decode_gx_texture(data: bytes, w: int, h: int, fmt: int) -> _RGBAImage:
    px=[(0,0,0,0)]*(w*h); pos=0
    def put(x,y,c):
        if x<w and y<h: px[y*w+x]=tuple(c)
    def rgb565(v): return (((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255)
    def rgb5a3(v):
        if v&0x8000: return (((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255)
        return (((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7)
    if fmt==0:
        for by in range(0,(h+7)//8*8,8):
            for bx in range(0,(w+7)//8*8,8):
                for y in range(8):
                    for x in range(0,8,2):
                        b=data[pos]; pos+=1
                        for dx,n in ((0,b>>4),(1,b&15)):
                            v=n*17; put(bx+x+dx,by+y,(v,v,v,255))
    elif fmt in (1,2):
        for by in range(0,(h+3)//4*4,4):
            for bx in range(0,(w+7)//8*8,8):
                for y in range(4):
                    for x in range(8):
                        b=data[pos]; pos+=1
                        c=(b,b,b,255) if fmt==1 else ((b&15)*17,(b&15)*17,(b&15)*17,(b>>4)*17)
                        put(bx+x,by+y,c)
    elif fmt in (3,4,5):
        for by in range(0,(h+3)//4*4,4):
            for bx in range(0,(w+3)//4*4,4):
                for y in range(4):
                    for x in range(4):
                        v=struct.unpack_from('>H',data,pos)[0]; pos+=2
                        if fmt==3: c=(v&255,v&255,v&255,v>>8)
                        elif fmt==4: c=rgb565(v)
                        else: c=rgb5a3(v)
                        put(bx+x,by+y,c)
    elif fmt==6:
        for by in range(0,(h+3)//4*4,4):
            for bx in range(0,(w+3)//4*4,4):
                ar=data[pos:pos+32]; gb=data[pos+32:pos+64]; pos+=64
                for i in range(16):
                    a,r=ar[i*2:i*2+2]; g,b=gb[i*2:i*2+2]
                    put(bx+i%4,by+i//4,(r,g,b,a))
    elif fmt==14:
        for by in range(0,(h+7)//8*8,8):
            for bx in range(0,(w+7)//8*8,8):
                for oy,ox in ((0,0),(0,4),(4,0),(4,4)):
                    c0,c1,bits=struct.unpack_from('>HHI',data,pos); pos+=8
                    p0=rgb565(c0); p1=rgb565(c1)
                    if c0>c1:
                        pal=[p0,p1,tuple((2*p0[i]+p1[i])//3 for i in range(4)),tuple((p0[i]+2*p1[i])//3 for i in range(4))]
                    else:
                        pal=[p0,p1,tuple((p0[i]+p1[i])//2 for i in range(4)),(0,0,0,0)]
                    for i in range(16):
                        idx=(bits>>(30-2*i))&3; put(bx+ox+i%4,by+oy+i//4,pal[idx])
    else: raise ValueError(f'unsupported texture format {fmt}')
    return _RGBAImage(w,h,px)


def _text_likeness(arc:HSDArchive,r:dict[str,Any])->float:
    try:
        start=arc.data_start+r['image']; raw=bytes(arc.raw[start:start+r['size']])
        im=_decode_gx_texture(raw,r['w'],r['h'],r['fmt']).resize((64,max(8,round(64*r['h']/r['w']))))
        pix=im.getdata()
        if not pix:return 0.0
        alpha=sum(1 for q in pix if q[3]>=32)/len(pix)
        bright=sum(1 for q in pix if q[3]>=32 and max(q[:3])>=96)/len(pix)
        return max(0.0,1.0-alpha)*2.0+min(0.8,bright)
    except Exception:return 0.0


def _fit_asset(asset: _RGBAImage, w:int, h:int, *, contain:bool=False) -> _RGBAImage:
    if contain:
        scale=min(w/asset.width,h/asset.height)
        nw=max(1,round(asset.width*scale)); nh=max(1,round(asset.height*scale))
        resized=asset.resize((nw,nh)); canvas=_RGBAImage(w,h)
        canvas.composite(resized,(w-nw)//2,(h-nh)//2); return canvas
    target=w/h; sw,sh=asset.size
    if sw/sh>target:
        nw=max(1,int(sh*target)); x=(sw-nw)//2; asset=asset.crop((x,0,x+nw,sh))
    else:
        nh=max(1,int(sw/target)); y=(sh-nh)//2; asset=asset.crop((0,y,sw,y+nh))
    return asset.resize((w,h))


def _render_icon(source:Path,w:int,h:int):
    return _fit_asset(_load_png_rgba(source),w,h)


def _render_label(w:int,h:int,text:str,*,nav_up:bool=False):
    if text=='SPECIAL MODE': asset=_load_png_rgba(_ASSET_DIR/'special_mode_label.png')
    elif text=='COOP ADVENTURE' and nav_up: asset=_load_png_rgba(_ASSET_DIR/'coop_adventure_nav_up.png')
    else: raise ValueError(f'no packaged label asset for {text!r}')
    return _fit_asset(asset,w,h,contain=True)


def _render_combined_coop_label(w:int,h:int):
    """Render only the selected-stage title. Navigation has its own SSS object."""
    return _fit_asset(_load_png_rgba(_ASSET_DIR/'coop_adventure_title_only.png'),w,h,contain=True)


def _rgb565_word(r:int,g:int,b:int)->int:
    return ((r*31//255)<<11)|((g*63//255)<<5)|(b*31//255)


def _encode_c8_rgb332(image:_RGBAImage,w:int,h:int)->tuple[bytes,bytes]:
    """Encode opaque artwork as tiled C8 plus a deterministic 256-entry RGB565 TLUT.

    K20K fixed the palette problem but still letterboxed the stage tile by fitting
    the wide source image *inside* the square preview.  K20K deliberately crops to
    fill the 48x48 tile so the Adventure thumbnail uses the full stage-select box
    with no top/bottom black bars.  RGB332 still gives a stable 256-colour mapping
    without Pillow on end-user builds.
    """
    image=_fit_asset(image,w,h,contain=False)
    pal=bytearray()
    for idx in range(256):
        ri=(idx>>5)&7; gi=(idx>>2)&7; bi=idx&3
        r=round(ri*255/7); g=round(gi*255/7); b=round(bi*255/3)
        pal+=struct.pack('>H',_rgb565_word(r,g,b))
    out=bytearray()
    for by in range(0,(h+3)//4*4,4):
        for bx in range(0,(w+7)//8*8,8):
            for y in range(4):
                for x in range(8):
                    sx,sy=bx+x,by+y
                    if sx>=w or sy>=h:
                        out.append(0); continue
                    r,g,b,a=image.pixels[sy*w+sx]
                    # Artwork is intentionally opaque; transparent pixels map black.
                    if a<32: out.append(0)
                    else: out.append(((r>>5)<<5)|((g>>5)<<2)|(b>>6))
    return bytes(out),bytes(pal)


def _write_c8_art_and_palette(arc:HSDArchive,r:dict[str,Any],image:_RGBAImage)->None:
    if r.get('fmt')!=9 or not r.get('palette_desc'):
        enc=_encode_for_record(image,r,arc)
        st=arc.data_start+r['image'];arc.raw[st:st+r['size']]=enc
        return
    pd=int(r['palette_desc']); lut=arc.data_u32(pd); pf=arc.data_u32(pd+4)
    n=struct.unpack_from('>H',arc.raw,arc.data_start+pd+0x0C)[0]
    if pf!=1 or n<256:
        # Fall back to the original palette path for an unexpected retail variant.
        enc=_encode_for_record(image,r,arc)
        st=arc.data_start+r['image'];arc.raw[st:st+r['size']]=enc
        return
    enc,pal=_encode_c8_rgb332(image,r['w'],r['h'])
    if len(enc)!=r['size'] or len(pal)!=512: raise AssertionError('C8 icon encode size mismatch')
    st=arc.data_start+r['image'];arc.raw[st:st+r['size']]=enc
    ps=arc.data_start+lut;arc.raw[ps:ps+512]=pal


def _embed_default_down_nav(arc:HSDArchive,r:dict[str,Any]):
    start=arc.data_start+r['image']; raw=bytes(arc.raw[start:start+r['size']])
    base=_decode_gx_texture(raw,r['w'],r['h'],r['fmt'])
    nav=_load_png_rgba(_ASSET_DIR/'default_nav_down.png')
    maxw=max(16,int(r['w']*0.34)); maxh=max(8,int(r['h']*0.88))
    scale=min(maxw/nav.width,maxh/nav.height)
    nw=max(1,round(nav.width*scale)); nh=max(1,round(nav.height*scale))
    nav=nav.resize((nw,nh))
    base.composite(nav,max(0,r['w']-nw-1),max(0,(r['h']-nh)//2))
    return base



def _read_image_desc(arc: HSDArchive, desc: int) -> dict[str, Any]:
    desc=int(desc)
    if desc <= 0 or desc + 0x18 > arc.header.data_size:
        raise ValueError(f'ImageDesc 0x{desc:X} is outside MnSlMap data')
    image=arc.data_u32(desc)
    width=struct.unpack_from('>H',arc.raw,arc.data_start+desc+4)[0]
    height=struct.unpack_from('>H',arc.raw,arc.data_start+desc+6)[0]
    fmt=arc.data_u32(desc+8); mip=arc.data_u32(desc+0xC)
    size=texture_level_size(width,height,fmt)
    if image <= 0 or image + size > arc.header.data_size:
        raise ValueError(f'ImageDesc 0x{desc:X} has invalid pixel range 0x{image:X}+0x{size:X}')
    return {'desc':desc,'image':image,'w':width,'h':height,'fmt':fmt,'mip':mip,'size':size}


def _public_root(arc:HSDArchive,name:str)->int:
    for p in arc.publics:
        if p.name==name:return int(p.offset)
    raise ValueError(f'MnSlMap is missing required public root {name!r}')


def _iter_matanim_tables(arc:HSDArchive, root:int):
    """Yield source-known HSD_TexAnim image tables below a MatAnimJoint tree."""
    out=[]; stack=[int(root)] if root else []; seen_j=set(); seen_ma=set(); seen_ta=set()
    while stack:
        j=stack.pop()
        if not j or j in seen_j:continue
        seen_j.add(j)
        if j+0x0C>arc.header.data_size:continue
        child=arc.data_u32(j); nxt=arc.data_u32(j+4); ma=arc.data_u32(j+8)
        if child:stack.append(child)
        if nxt:stack.append(nxt)
        while ma and ma not in seen_ma and ma+0x10<=arc.header.data_size:
            seen_ma.add(ma)
            ma_next=arc.data_u32(ma); ta=arc.data_u32(ma+8)
            while ta and ta not in seen_ta and ta+0x18<=arc.header.data_size:
                seen_ta.add(ta)
                ta_next=arc.data_u32(ta); table=arc.data_u32(ta+0x0C)
                n=struct.unpack_from('>H',arc.raw,arc.data_start+ta+0x14)[0]
                entries=[]; tluts=[]
                if table and n and table+4*n<=arc.header.data_size:
                    entries=[arc.data_u32(table+i*4) for i in range(n)]
                tlut_table=arc.data_u32(ta+0x10); nt=struct.unpack_from('>H',arc.raw,arc.data_start+ta+0x16)[0]
                if tlut_table and nt and tlut_table+4*nt<=arc.header.data_size:
                    tluts=[arc.data_u32(tlut_table+i*4) for i in range(nt)]
                out.append({'matanim_joint':j,'matanim':ma,'texanim':ta,'table':table,'count':n,'entries':entries,'tluts':tluts})
                ta=ta_next
            ma=ma_next
    return out


def _iter_joint_static_images(arc:HSDArchive, root:int):
    """Collect default TObj ImageDesc pointers from a source HSD_Joint tree."""
    found=[]; stack=[int(root)] if root else []; seen_j=set(); seen_d=set(); seen_t=set()
    while stack:
        j=stack.pop()
        if not j or j in seen_j or j+0x14>arc.header.data_size:continue
        seen_j.add(j)
        child=arc.data_u32(j+8); nxt=arc.data_u32(j+0x0C); dobj=arc.data_u32(j+0x10)
        if child:stack.append(child)
        if nxt:stack.append(nxt)
        while dobj and dobj not in seen_d and dobj+0x10<=arc.header.data_size:
            seen_d.add(dobj); dn=arc.data_u32(dobj+4); mobj=arc.data_u32(dobj+8)
            if mobj and mobj+0x0C<=arc.header.data_size:
                td=arc.data_u32(mobj+8)
                while td and td not in seen_t and td+0x5C<=arc.header.data_size:
                    seen_t.add(td)
                    tn=arc.data_u32(td+4); desc=arc.data_u32(td+0x4C)
                    if desc:
                        try: found.append(_read_image_desc(arc,desc))
                        except Exception: pass
                    td=tn
            dobj=dn
    uniq={r['desc']:r for r in found}
    return list(uniq.values())




def _decode_tlut_rgba(arc:HSDArchive, desc:int):
    lut=arc.data_u32(desc); fmt=arc.data_u32(desc+4)
    n=struct.unpack_from('>H',arc.raw,arc.data_start+desc+0x0C)[0]
    if not lut or not n: return []
    out=[]
    for i in range(n):
        v=struct.unpack_from('>H',arc.raw,arc.data_start+lut+i*2)[0]
        if fmt==0:  # IA8
            a=((v>>8)&0xFF); q=v&0xFF; out.append((q,q,q,a))
        elif fmt==1:  # RGB565
            out.append((((v>>11)&31)*255//31,((v>>5)&63)*255//63,(v&31)*255//31,255))
        elif fmt==2:  # RGB5A3
            if v&0x8000: out.append((((v>>10)&31)*255//31,((v>>5)&31)*255//31,(v&31)*255//31,255))
            else: out.append((((v>>8)&15)*17,((v>>4)&15)*17,(v&15)*17,((v>>12)&7)*255//7))
        else: raise ValueError(f'unsupported TLUT format {fmt}')
    return out

def _encode_c8_with_palette(image:_RGBAImage, palette:list[tuple[int,int,int,int]], w:int,h:int)->bytes:
    image=_fit_asset(image,w,h,contain=True)
    if not palette: raise ValueError('C8 target has no palette')
    cache={}; out=bytearray()
    for by in range(0,(h+3)//4*4,4):
        for bx in range(0,(w+7)//8*8,8):
            for y in range(4):
                for x in range(8):
                    sx,sy=bx+x,by+y
                    if sx>=w or sy>=h: out.append(0); continue
                    q=image.pixels[sy*w+sx]
                    key=(q[0]>>3,q[1]>>3,q[2]>>3,q[3]>>4)
                    idx=cache.get(key)
                    if idx is None:
                        r,g,b,a=q
                        idx=min(range(len(palette)), key=lambda i:(palette[i][0]-r)**2+(palette[i][1]-g)**2+(palette[i][2]-b)**2+2*(palette[i][3]-a)**2)
                        cache[key]=idx
                    out.append(idx&0xFF)
    return bytes(out)

def _encode_for_record(image:_RGBAImage,r:dict[str,Any],arc:HSDArchive|None=None)->bytes:
    fitted=_fit_asset(image,r['w'],r['h'],contain=True)
    if r['fmt'] in (0,1):
        fitted=_intensity_art(fitted)
    if r['fmt']==9:
        if arc is None or not r.get('palette_desc'): raise ValueError('C8 record requires palette descriptor')
        enc=_encode_c8_with_palette(fitted,_decode_tlut_rgba(arc,int(r['palette_desc'])),r['w'],r['h'])
    else:
        enc=encode_gx_texture(fitted,r['fmt'])
    if len(enc)!=r['size']:raise AssertionError((len(enc),r['size']))
    return enc


def _intensity_art(image:_RGBAImage)->_RGBAImage:
    """Bake alpha into luminance for native I4/I8 menu masks."""
    return _RGBAImage(image.width,image.height,
                      [(r*a//255,g*a//255,b*a//255,255) for r,g,b,a in image.pixels])


def _overlay_variant(arc:HSDArchive,r:dict[str,Any],asset_path:Path)->bytes:
    raw=bytes(arc.raw[arc.data_start+r['image']:arc.data_start+r['image']+r['size']])
    base=_decode_gx_texture(raw,r['w'],r['h'],r['fmt'])
    nav=_load_png_rgba(asset_path)
    # Lower-right, intentionally restrained so it sits above the retail STAGE SELECT
    # treatment rather than obscuring the stage grid.
    maxw=max(24,int(r['w']*0.46)); maxh=max(16,int(r['h']*0.28))
    scale=min(maxw/nav.width,maxh/nav.height)
    nw=max(1,round(nav.width*scale)); nh=max(1,round(nav.height*scale))
    nav=nav.resize((nw,nh))
    base.composite(nav,max(0,r['w']-nw-2),max(0,r['h']-nh-2))
    return encode_gx_texture(base,r['fmt'])


def _append_runtime_visual_blob(arc:HSDArchive, records:list[dict[str,Any]])->tuple[int,int]:
    """Append custom texture bytes + a tiny relocation-free runtime swap table.

    Each record is {desc, original_image, custom_bytes}. The DOL page renderer
    computes the loaded MnSlMap data base from sss_models, then swaps only the
    ImageDesc.image_ptr word. Live TObjs already point at these ImageDesc objects,
    so no fragile GObj/JObj animation discovery is required at runtime.
    """
    base=arc.header.data_size; blob=bytearray(); rows=[]
    for rec in records:
        while len(blob)&0x1F:blob.append(0)
        custom_off=base+len(blob); data=bytes(rec['custom_bytes']); blob+=data
        rows.append((int(rec['desc']),int(rec['original_image']),custom_off,int(rec.get('kind',0))))
    while len(blob)&0x1F:blob.append(0)
    table_off=base+len(blob)
    blob+=b'SSQF'+struct.pack('>II',1,len(rows))
    for desc,orig,custom,kind in rows:
        blob+=struct.pack('>IIII',desc,orig,custom,kind)
    arc.replace_data_ranges([(base,0,bytes(blob))],align_to=0x20)
    return table_off,len(rows)


def patch_mnslmap_bytes(raw:bytes,icon_source:str|Path,*,strict:bool=True,
                        runtime_table_offset:int|None=None, standalone_stages:bool=False)->tuple[bytes,dict[str,Any]]:
    """K20Q page-local Co-op presentation with zero retail-stage replacement.

    Default/retail keeps every stage icon and selected-stage title byte exactly
    as supplied by MnSlMap.  The only intentional default-page art change is the
    requested right-side shaded D-Pad Down / PAGE 2 footer.

    Page 2 reuses slot 27's *geometry only*.  The Co-op Adventure thumbnail,
    selected-stage title artwork, and left-side shaded D-Pad Up / DEFAULT footer
    are stored as appended payloads and copied into the already-live texture
    buffers only while Page 2 is active.  Returning to Default copies the exact
    original icon/title bytes back.  No retail animation frame is permanently
    repurposed, so Yoshi's Island (N64) remains retail on Page 1.
    """
    arc=HSDArchive(raw); root=_public_root(arc,'MnSelectStageDataTable'); models=root+0x10
    if models+0xC0>arc.header.data_size:raise ValueError('MnSelectStageDataTable model table is truncated')
    icon_special_mat=arc.data_u32(models+0x20+8)
    stage_name_mat=arc.data_u32(models+0x30+8)
    menu_border_joint=arc.data_u32(models+0x50)

    # Slot 27 is the fourth x20 bottom-row button.  Its retail visual animation
    # resolves through special-icon frame 5; capture every descriptor referenced
    # by that frame rather than assuming one table/descriptor owns the tile.
    icon_targets=[]
    for ta in _iter_matanim_tables(arc,icon_special_mat):
        if ta['count']>5 and len(ta['entries'])>5 and ta['entries'][5]:
            try:
                r=_read_image_desc(arc,ta['entries'][5])
                if len(ta.get('tluts',[]))>5 and ta['tluts'][5]:r['palette_desc']=ta['tluts'][5]
                if 16<=r['w']<=512 and 16<=r['h']<=512 and .45<=r['w']/r['h']<=2.2:icon_targets.append(r)
            except Exception:pass
    icon_targets=list({r['desc']:r for r in icon_targets}.values())

    # The selected-stage caption is composed from more than one MatAnim table in
    # retail.  Patch *all* frame-27 descriptors so both the small heading and the
    # large stage name change together on Page 2 instead of leaving Past Stages /
    # Yoshi's Island behind.
    title_targets=[]
    for ta in _iter_matanim_tables(arc,stage_name_mat):
        if ta['count']>0x1B and len(ta['entries'])>0x1B and ta['entries'][0x1B]:
            try:
                r=_read_image_desc(arc,ta['entries'][0x1B])
                if r['w']>=32 and r['h']>=8:title_targets.append(r)
            except Exception:pass
    title_targets=list({r['desc']:r for r in title_targets}.values())

    nav_candidates=[r for r in _iter_joint_static_images(arc,menu_border_joint)
                    if r['w']==232 and r['h']==16 and r['fmt']==0]
    nav_target=(dict(nav_candidates[0],source='x50_stage_select_footer') if nav_candidates else None)

    rows=[]; blob=bytearray(); data_base=arc.header.data_size
    def append_blob(data:bytes,align:int=0x20)->int:
        nonlocal blob
        while len(blob)%align:blob.append(0)
        off=data_base+len(blob);blob+=bytes(data);return off
    def add_row(target:int,default:bytes,coop:bytes,kind:str):
        if len(default)!=len(coop):raise ValueError(f'{kind} page visual sizes differ')
        d=append_blob(default);c=append_blob(coop)
        rows.append({'target_data':int(target),'default_data':int(d),'coop_data':int(c),'size':len(default),'kind':kind})

    icon_asset=_load_png_rgba(icon_source)
    for r in icon_targets:
        original=bytes(arc.raw[arc.data_start+r['image']:arc.data_start+r['image']+r['size']])
        if r.get('fmt')==9 and r.get('palette_desc'):
            pd=int(r['palette_desc']);lut=arc.data_u32(pd);pf=arc.data_u32(pd+4)
            n=struct.unpack_from('>H',arc.raw,arc.data_start+pd+0x0C)[0]
            if pf==1 and n>=256:
                enc,pal=_encode_c8_rgb332(icon_asset,r['w'],r['h'])
                add_row(r['image'],original,enc,'icon_pixels')
                porig=bytes(arc.raw[arc.data_start+lut:arc.data_start+lut+512])
                add_row(lut,porig,pal,'icon_palette')
            else:
                enc=_encode_for_record(icon_asset,r,arc);add_row(r['image'],original,enc,'icon_pixels')
        else:
            enc=_encode_for_record(icon_asset,r,arc);add_row(r['image'],original,enc,'icon_pixels')

    # Use one authored two-line composition on every frame-27 caption surface.
    # This guarantees the visible heading and stage name both stop showing retail
    # text even when MnSlMap uses multiple MatAnim tables for the caption.
    title_art=_fit_asset(_load_png_rgba(_ASSET_DIR/'coop_adventure_title_only.png'),224,56,contain=True)
    for r in title_targets:
        original=bytes(arc.raw[arc.data_start+r['image']:arc.data_start+r['image']+r['size']])
        enc=_encode_for_record(title_art,r,arc);add_row(r['image'],original,enc,'stage_title')

    if standalone_stages:
        from .standalone_stage_catalog import STAGES
        # Native rows are not in caption/animation order. Keep their original
        # x9 values so retail animation ownership and cursor handling stay valid.
        frames=(0,1,2,3,4,5,8,9,10,11,12,13,6)
        icon_tables=_iter_matanim_tables(arc,arc.data_u32(models+0x40+8))
        caption_tables=_iter_matanim_tables(arc,stage_name_mat)
        if len(icon_tables)!=2:raise ValueError('Expected two alternating native icon tables')
        for slot,(stage,frame) in enumerate(zip(STAGES,frames)):
            # First MatAnimJoint is child (odd row), next sibling is even row.
            ta=icon_tables[1 if slot%2==0 else 0];n=frame//2+2
            r=_read_image_desc(arc,ta['entries'][n]);r['palette_desc']=ta['tluts'][n]
            art=_load_png_rgba(_ASSET_DIR/'standalone'/f'{stage.key}_icon.png')
            pd=r['palette_desc'];lut=arc.data_u32(pd)
            if r['fmt']!=9 or arc.data_u32(pd+4)!=1:raise ValueError('Unexpected native icon format')
            enc,pal=_encode_c8_rgb332(art,r['w'],r['h'])
            original=bytes(arc.raw[arc.data_start+r['image']:arc.data_start+r['image']+r['size']])
            add_row(r['image'],original,enc,f'{stage.key}_icon')
            original=bytes(arc.raw[arc.data_start+lut:arc.data_start+lut+512])
            add_row(lut,original,pal,f'{stage.key}_palette')
            art=_load_png_rgba(_ASSET_DIR/'standalone'/f'{stage.key}_title.png')
            for ta in caption_tables:
                r=_read_image_desc(arc,ta['entries'][frame])
                original=bytes(arc.raw[arc.data_start+r['image']:arc.data_start+r['image']+r['size']])
                add_row(r['image'],original,_encode_for_record(art,r,arc),f'{stage.key}_title')

    if nav_target is not None:
        down=_fit_asset(_load_png_rgba(_ASSET_DIR/'sss_nav_default_down.png'),232,16,contain=True)
        up=_fit_asset(_load_png_rgba(_ASSET_DIR/'sss_nav_page2_up.png'),232,16,contain=True)
        down_enc=encode_gx_texture(_intensity_art(down),nav_target['fmt']);up_enc=encode_gx_texture(_intensity_art(up),nav_target['fmt'])
        # Default page begins with the requested Down/PAGE 2 legend resident.
        ns=arc.data_start+nav_target['image'];arc.raw[ns:ns+nav_target['size']]=down_enc
        add_row(nav_target['image'],down_enc,up_enc,'footer')

    table_off=0
    if rows:
        while len(blob)&0x1F:blob.append(0)
        if runtime_table_offset is not None:
            if runtime_table_offset < data_base+len(blob):
                raise ValueError('Shared visual table offset overlaps texture payloads')
            blob.extend(bytes(runtime_table_offset-data_base-len(blob)))
        table_off=data_base+len(blob)
        blob+=b'SSVQ'+struct.pack('>I',len(rows))
        for rec in rows:
            blob+=struct.pack('>IIII',int(rec['target_data'])-models,
                              int(rec['default_data'])-models,
                              int(rec['coop_data'])-models,int(rec['size']))
    if blob:arc.replace_data_ranges([(arc.header.data_size,0,bytes(blob))],align_to=0x20)

    report={'format':'melee-sdk-sss-qol-v16-page-local-live-copy','tile_slot':COOP_TILE_SLOT,
            'source_public_root':root,'models_offset':models,'icon_patched':bool(icon_targets),
            'special_mode_patched':bool(title_targets),'coop_adventure_patched':bool(title_targets),
            'dpad_up_figure_embedded':bool(nav_target),'dpad_down_figures_embedded':(1 if nav_target else 0),
            'canned_page3_removed':True,'third_party_image_dependency':False,
            'navigation':'Page 1: right-aligned shaded D-Pad Down / PAGE 2; Page 2: left-aligned shaded D-Pad Up / DEFAULT',
            'runtime_visual_table_offset':table_off,'runtime_visual_record_count':len(rows),
            'runtime_visual_models_offset':models,'runtime_visual_records':rows,
            'patch_mode':'page-local live texture copy + cache flush; no retail icon/title frame is permanently overwritten',
            'icon_special_targets':[{k:r[k] for k in ('desc','image','w','h','fmt')} for r in icon_targets],
            'stage_name_targets':[{k:r[k] for k in ('desc','image','w','h','fmt')} for r in title_targets],
            'nav_target':({k:nav_target[k] for k in ('source','desc','image','w','h','fmt')} if nav_target else None),
            'selection_contract':{'retail_slot':27,'retail_x9':27,'coop_x9':27,'visual_swap':'page-local-bytes-only',
                                  'retail_yoshi_island_n64_preserved':True}}
    report['standalone_stage_count']=13 if standalone_stages else 0
    missing=[]
    if not icon_targets:missing.append('x20 slot-27/special-icon frame 5')
    if not title_targets:missing.append('x30 selected-stage caption frame 27')
    if nav_target is None:missing.append('x50 232x16 STAGE SELECT footer')
    if strict and missing:raise ValueError('MnSlMap Page-2 visual patch could not verify: '+', '.join(missing))
    return bytes(arc.raw),report

def patch_mnslmap_from_iso(clean_iso:str|Path,output_path:str|Path,icon_source:str|Path,*,strict:bool=True)->dict[str,Any]:
    from .gamecube_iso import GameCubeISO
    iso=GameCubeISO(clean_iso);entry=None
    for name in ('MnSlMap.usd','MnSlMap.dat'):
        try:entry=iso.find_file(name);break
        except KeyError:pass
    if entry is None:raise KeyError('MnSlMap.usd/dat not found in clean ISO')
    patched,rep=patch_mnslmap_bytes(iso.read_file(entry),icon_source,strict=strict)
    out=Path(output_path);out.write_bytes(patched);rep.update({'source_path':entry.path,'output':str(out),'size':len(patched)})
    return rep
