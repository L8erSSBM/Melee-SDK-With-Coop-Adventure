"""HF23: low-memory protection for optional particle effects in Adventure.

HF22 proved the Team-Kirby/Icies failure is broader heap starvation: once the
OS heap is exhausted, HSD_ObjAlloc's attempt to grow the particle/generator
object pools reaches HSD_MemAlloc, whose retail assertion panics instead of
letting HSD_ObjAlloc return NULL.  The two effect constructors already handle
NULL correctly.

This patch wraps only the HSD_ObjAlloc calls in generator and particle
creation.  Existing free pool objects are always allowed.  A pool refill is
allowed only when the current OS heap has a contiguous free block large enough
for the small refill while preserving a 320-KiB emergency reserve.  Otherwise
the optional effect creation returns NULL.  Fighters, stage objects, items,
and all other allocation paths remain untouched.
"""
from __future__ import annotations

import struct

from .ppc import addi, blr, cmpwi, encode_bc, encode_branch, lbz, li, lis, lwz, stw

# Retail GALE01 1.02 HSD object allocator and the two nullable effect callers.
OBJ_ALLOC = 0x8037ABC8
SITES = (
    (0x8039D9E0, 'generator', 0x804D0F90),
    (0x80398C90, 'particle',  0x804D0F60),
)

# HSD / Dolphin OS heap globals.
CURRENT_HEAP = 0x804D5E00
HEAP_ARRAY = 0x804D7360
NUM_HEAPS = 0x804D7364
ADVENTURE_MODE = 0x80479D30

# Keep enough contiguous headroom for HF22's 320x240 clear image (153,632
# bytes including allocator overhead/alignment in the captured runs) plus its
# observed clear-screen/UI tail.  The refill itself is at most ~0x98 bytes;
# 0xA0 is a conservative aligned allowance.
RESERVE_BYTES = 0x50000
REFILL_ALLOWANCE = 0xA0
MIN_FREE_BLOCK = RESERVE_BYTES + REFILL_ALLOWANCE
MAX_FREE_NODES = 160
MEM1_LOW = 0x80000000
MEM1_LAST_CELL = 0x817FFFF4


def word(value: int) -> bytes:
    return struct.pack('>I', value & 0xFFFFFFFF)


class Asm:
    def __init__(self, base: int):
        self.base = int(base)
        self.data = bytearray()
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str, int, int]] = []

    def emit(self, *chunks: bytes) -> None:
        for chunk in chunks:
            self.data.extend(chunk)

    def constant(self, r: int, value: int) -> None:
        value &= 0xFFFFFFFF
        self.emit(lis(r, (value + 0x8000) >> 16), addi(r, r, value & 0xFFFF))

    def absolute(self, r: int, address: int, *, byte: bool = False) -> None:
        self.constant(12, address)
        self.emit((lbz if byte else lwz)(r, 0, 12))

    def compare(self, a: int, b: int) -> None:
        # cmplw cr7,rA,rB -- unsigned compare.  This is intentional for MEM1
        # addresses and also causes current-heap -1 to fail the heap-index gate.
        self.emit(word((31 << 26) | (7 << 23) | (a << 16) | (b << 11) | (32 << 1)))

    def label(self, name: str) -> None:
        self.labels[name] = len(self.data)

    def branch(self, label: str, bo: int = 20, bi: int = 0) -> None:
        self.fixups.append((len(self.data), label, bo, bi))
        self.emit(bytes(4))

    def finish(self) -> bytes:
        for off, label, bo, bi in self.fixups:
            self.data[off:off+4] = encode_bc(
                self.base + off, self.base + self.labels[label], bo=bo, bi=bi)
        return bytes(self.data)


def wrapper(base: int, pool: int, counter: int) -> bytes:
    a = Asm(base)

    # Outside Adventure, preserve retail behavior exactly.
    a.absolute(11, ADVENTURE_MODE, byte=True)
    a.emit(cmpwi(11, 4, crf=7))
    a.branch('retail', 4, 30)  # bne cr7

    # Guard only the expected particle/generator object pool call site.
    a.constant(11, pool)
    a.compare(3, 11)
    a.branch('retail', 4, 30)  # bne cr7

    # If the pool already has a reusable object, no heap allocation is needed.
    # HSD_ObjAllocData.free is at +0x0C.
    a.emit(lwz(11, 0x0C, 3), cmpwi(11, 0, crf=7))
    a.branch('retail', 4, 30)  # nonzero -> retail

    # Validate current OS heap index using the same globals as HSD_GetHeap /
    # OSAllocFromHeap.  Only volatile GPRs and CR7 are touched.
    a.absolute(4, CURRENT_HEAP)
    a.absolute(5, NUM_HEAPS)
    a.compare(4, 5)
    a.branch('drop', 4, 28)  # heap >= NumHeaps, also rejects 0xFFFFFFFF

    a.absolute(5, HEAP_ARRAY)
    a.emit(cmpwi(5, 0, crf=7))
    a.branch('drop', 12, 30)

    # OSHeapInfo is 12 bytes; its free-list head is the second word.
    a.emit(word((7 << 26) | (4 << 21) | (4 << 16) | 12))  # mulli r4,r4,12
    a.emit(word((31 << 26) | (5 << 21) | (5 << 16) | (4 << 11) | (266 << 1)))  # add r5,r5,r4
    a.emit(lwz(6, 4, 5))

    a.constant(7, MIN_FREE_BLOCK)
    a.emit(li(8, MAX_FREE_NODES))
    a.constant(9, MEM1_LOW)
    a.constant(10, MEM1_LAST_CELL)

    # OSHeapCell layout: prev @+0, next @+4, size @+8.  Walk a bounded
    # free-list looking for one contiguous block that can preserve the reserve.
    a.label('scan')
    a.emit(cmpwi(6, 0, crf=7))
    a.branch('drop', 12, 30)
    a.compare(6, 9)
    a.branch('drop', 12, 28)  # ptr < MEM1_LOW
    a.compare(6, 10)
    a.branch('drop', 12, 29)  # ptr > MEM1_LAST_CELL
    a.emit(lwz(11, 8, 6))
    a.compare(11, 7)
    a.branch('retail', 4, 28)  # size >= threshold (not unsigned-less-than)
    a.emit(addi(8, 8, -1), cmpwi(8, 0, crf=7))
    a.branch('drop', 12, 30)
    a.emit(lwz(6, 4, 6))
    a.branch('scan')

    # Low headroom: suppress only this optional effect.  Saturating counters
    # give us runtime proof without creating any additional allocations.
    a.label('drop')
    a.constant(12, counter)
    a.emit(lwz(11, 0, 12), cmpwi(11, -1, crf=7))
    a.branch('null', 12, 30)
    a.emit(addi(11, 11, 1), stw(11, 0, 12))
    a.label('null')
    a.emit(li(3, 0), blr())

    # Tail-enter retail HSD_ObjAlloc so the original caller's LR is retained.
    a.label('retail')
    a.emit(encode_branch(base + len(a.data), OBJ_ALLOC))
    return a.finish()


def install(dol, index: int) -> dict:
    # Validate both retail BL call sites before mutating anything.
    for site, _, _ in SITES:
        expected = encode_branch(site, OBJ_ALLOC, link=True)
        if dol.read_at_address(site, 4) != expected:
            raise ValueError(f'HF23 effect allocation call mismatch at {site:#x}')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)

    # Header is 32 bytes: marker + two u32 drop counters + reserved telemetry.
    payload = bytearray(b'HF23FXMG' + bytes(24))
    hooks = []
    for number, (site, name, pool) in enumerate(SITES):
        address = base + len(payload)
        counter = base + 0x10 + number * 4
        blob = wrapper(address, pool, counter)
        payload.extend(blob)
        payload.extend(bytes((-len(payload)) % 32))
        hooks.append(dict(
            name='hf23_' + name + '_memory_guard',
            site_address=site,
            stub_address=address,
            size=len(blob),
            pool=pool,
            drop_counter=counter,
            expected=encode_branch(site, OBJ_ALLOC, link=True).hex(),
            site_branch=encode_branch(site, address, link=True).hex(),
        ))

    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base
    for hook in hooks:
        dol.patch_at_address(
            hook['site_address'], bytes.fromhex(hook['site_branch']),
            expected=bytes.fromhex(hook['expected']))

    return dict(
        marker='HF23FXMG', section=added, hooks=hooks,
        reserve_bytes=RESERVE_BYTES, refill_allowance=REFILL_ALLOWANCE,
        min_free_block=MIN_FREE_BLOCK, scan_limit=MAX_FREE_NODES,
        existing_pool_objects_bypass_guard=True,
        scope='Adventure optional generator/particle pool refills only',
        runtime_validation='pending Dolphin reproduction',
    )
