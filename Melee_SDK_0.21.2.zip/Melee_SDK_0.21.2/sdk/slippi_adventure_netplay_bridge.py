"""SDK 0.20.21K16: Direct session lifetime and rollback repair.

Paired regular-vs-Adventure saves proved the legal Yoshi carrier reordered both
visible fighter slots and Slippi local/remote logical indices before Adventure
was constructed. K10 treats the carrier as transport only: pre-carrier Direct
SSS roles are restored into the relocated ODB while each peer's physical input
source remains Slippi-owned.

K10 also removes K9's global scene-word spoof (which disabled the Adventure
presentation barrier) and enables the four Slippi rollback-sound scene guards
directly alongside the 13 core input/rollback guards. Adventure therefore stays
true GM_ADVENTURE while Slippi's scoped online helpers remain active.
"""
from __future__ import annotations

import struct
from dataclasses import dataclass

from .early_clear_failsafe import Asm
from .ppc import (addi, blr, cmpw, cmpwi, encode_bc, encode_branch, lbz, li,
                  lis, lwz, mflr, mtlr, stb, stw, stwu)

HSD_MEM_FREE = 0x8037F1B0
HSD_MEM_FREE_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0

SLIPPI_EXI_VENEER = 0x800055F0
SLIPPI_EXI_VENEER_EXPECTED = bytes.fromhex('4bffd570')
SLIPPI_EXI_TRANSFER = 0x80002B60
GAME_END = 0x39
ONLINE_INPUTS = 0xB0
CAPTURE_SAVESTATE = 0xB1
LOAD_SAVESTATE = 0xB2
CLEANUP_CONNECTIONS = 0xBA

# Melee scene-routing state. gm_801A4B60 is only a store of 1 to this flag.
# 0.20.21H performs that store from the first live B0 exchange after
# the Direct Adventure bridge has armed, avoiding the too-early HUD-init write
# and avoiding LRA+Start (which terminates Slippi netplay).
GM_SCENE_EXIT_FLAG_ADDR = 0x80479D64
# Slippi's getMinorMajor macro reads the 32-bit scene-controller word at
# 0x80479D30 and rotates it so byte 3 becomes the minor id and byte 0 the
# major id. Native online gameplay therefore requires major=0x08/minor=0x02.
GM_SCENE_WORD_ADDR = 0x80479D30
GLOBAL_FRAME_ADDR = 0x80479D60
RNG_SEED_ADDR = 0x804D5F90
GM_ONLINE_MAJOR = 0x08
GM_ONLINE_INGAME_MINOR = 0x02

# Current project-slippi/slippi-ssbm-asm Online/Online.s contract, validated
# against the supplied working Direct PC/ROG savestates.
OFST_R13_ODB_ADDR = -0x49E4
ODB_LOCAL_PLAYER_INDEX = 0x000
ODB_ONLINE_PLAYER_INDEX = 0x001
ODB_INPUT_SOURCE_INDEX = 0x002
# Native Slippi ODB frame/RNG fields are intentionally unaligned.  Adventure
# scene creation resets Melee's global frame counter, while the preserved ODB
# continues the carrier frame domain. K13 bridges those domains once at the
# Adventure handoff and recreates Slippi's per-frame RNG seed in B0.
ODB_FRAME = 0x003
ODB_RNG_OFFSET = 0x007
ODB_DELAY_FRAMES = 0x021
ODB_TXB_ADDR = 0x0D7
ODB_RXB_ADDR = 0x0DB
ODB_SSRB_ADDR = 0x3A0
ODB_SSCB_ADDR = 0x3A4
OFST_R13_ARENA_HI = -0x4330

# SlippiSavestate freezes its dynamic main-heap backup range when Dolphin sees
# B0 frame 1. Direct's carrier heap is much smaller than Adventure's later heap,
# so K4 temporarily reports the future safe ceiling during that synchronous EXI
# call, then restores the real carrier value immediately afterward.
MAIN_HEAP_END_ADDR = 0x804D76BC
FULL_ROLLBACK_HEAP_END = 0x817E0000
FULL_ROLLBACK_HEAP_START = 0x8071B000
SDK_SNAPSHOT_BASE = 0x817E0000
SDK_RUNTIME_BASE = 0x804F0C00
SDK_RUNTIME_SIZE = 0x4000
S_BATCH_FRAME = 0x14
S_SIM_FRAME = 0x18

MARKER = b'SLNP'
STATE_SIZE = 0x70
STATE_VERSION = 18
TRACE_IDLE = 0xE0
TRACE_ARM_ENTER = 0xE1
TRACE_ODB_CAPTURED = 0xE2
TRACE_RUNTIME_VALIDATED = 0xE3
TRACE_ARENA_RESERVED = 0xE4
TRACE_SESSION_RELOCATED = 0xE5
TRACE_ARMED = 0xE6

PHASE_OFF = 0
PHASE_TRANSITION = 1
PHASE_WARMUP = 2  # legacy diagnostic value; K8 does not use fake warmup gating
PHASE_FULL = 3
WARMUP_B0_FRAMES = 0

S_VERSION = 0x04
S_TRACE = 0x05
S_LOCAL_INDEX = 0x06
S_FAILURE = 0x07
S_ARM_COUNT = 0x08
S_FREE_SKIP_COUNT = 0x0C
S_CLEANUP_BLOCK_COUNT = 0x10
S_ODB = 0x14
S_TXB = 0x18
S_RXB = 0x1C
S_SSRB = 0x20
S_SSCB = 0x24
S_PATCH_COUNT = 0x28
# This byte is now an explicit bridge phase. Guard shims only need non-zero
# scope, so retain the historical alias for compatibility with diagnostics.
S_PHASE = 0x2C
S_SESSION_SCOPE = S_PHASE
S_ORIG_ODB = 0x30
S_ORIG_TXB = 0x34
S_ORIG_RXB = 0x38
S_ORIG_SSRB = 0x3C
S_ORIG_SSCB = 0x40
S_RELOCATE_COUNT = 0x44
S_ORIG_ARENA_HI = 0x48
S_ARENA_RESERVE_COUNT = 0x4C
S_WARMUP_B0_COUNT = 0x50
S_SNAPSHOT_PATCHED = 0x54
S_ARENA_RESERVED = 0x55
S_ARM_ONLINE_INDEX = 0x56
S_ARM_INPUT_SOURCE_INDEX = 0x57
S_B0_COUNT = 0x58
S_B1_COUNT = 0x5C
S_B2_COUNT = 0x60
S_LAST_B1_FRAME = 0x64
S_LAST_B2_FRAME = 0x68
S_TRANSITION_RESET_COUNT = 0x6C
# K9 compatibility aliases only. K10 never spoofs the global Adventure
# scene-controller word; these offsets remain exported for old diagnostics/tests.
S_ORIG_SCENE_WORD = S_WARMUP_B0_COUNT
S_SCENE_SHADOW_ACTIVE = S_FREE_SKIP_COUNT + 2
# K4 reuses the retired diagnostic bytes. These are intentionally outside
# Slippi's rollback regions, so B2 cannot undo the host-range priming evidence.
S_ROLLBACK_HEAP_PRIMED = S_FREE_SKIP_COUNT      # byte at 0x0C
S_ADVENTURE_HEAP_CLAMPED = S_FREE_SKIP_COUNT + 1 # byte at 0x0D
S_ADVENTURE_HEAP_CARVED = S_ADVENTURE_HEAP_CLAMPED  # compatibility alias

# Historical K2 heap globals are intentionally absent from the live bridge.
# Paired K2 saves prove the active HSD heap ends well below SESSION_HIGH_BASE;
# K4 excludes the island from the rollback/gameplay heap ceiling at B0 frame 1.

# Stable high-MEM1 session island reserved by slippi_memory_layout.  Keep the
# same relative child layout observed on both working Direct peers so Slippi's
# own assumptions continue to hold while Adventure is free to recycle the old
# scene heap allocation.
SESSION_HIGH_BASE = 0x817FE000
SESSION_HIGH_LIMIT = 0x81800000
# K6: bridge-control state lives in the ArenaHi-reserved island, not the low SDK
# runtime. The K5 paired crash saves showed the low SLNP state block corrupted
# while DRCT remained intact; hot rollback code must not dereference that block.
HIGH_CTRL = 0x817FFF80
HC_MAGIC = 0x00
HC_PHASE = 0x04
HC_WARMUP = 0x08
HC_LOCAL = 0x0C
HC_ONLINE = 0x0D
HC_INPUT = 0x0E
HC_SNAPSHOT = 0x0F
HC_ORIG_ARENA_HI = 0x10
HC_MAGIC_VALUE = 0x4B36434C  # 'K6CL'

STABLE_ODB = SESSION_HIGH_BASE + 0x000
STABLE_TXB = SESSION_HIGH_BASE + 0xD20
STABLE_RXB = SESSION_HIGH_BASE + 0xD60
STABLE_SSRB = SESSION_HIGH_BASE + 0xEC0
STABLE_SSCB = SESSION_HIGH_BASE + 0xF20
ODB_SIZE = 0xCEF
TXB_SIZE = 0x1A
RXB_SIZE = 0x129
SSRB_SIZE = 0x21
SSCB_SIZE = 0x9E
SSCB_SSDB_COUNT = 0x01
ROLLBACK_MAX_FRAME_COUNT = 7
MIN_DELAY_FRAMES = 1


@dataclass(frozen=True)
class GuardSpec:
    site: int
    expected: bytes
    target: int
    name: str


def _bc_target(site: int, raw: bytes) -> int:
    word = struct.unpack('>I', raw)[0]
    if (word >> 26) != 16 or (word & 2):
        raise ValueError(f'expected relative bc at {site:#x}: {raw.hex()}')
    bd = word & 0xFFFC
    if bd & 0x8000:
        bd -= 0x10000
    return (site + bd) & 0xFFFFFFFF


_RAW_GUARDS = (
    (0x80665540, '4082005c', 'customize_lras_message'),
    (0x806655C0, '408200a4', 'force_engine_on_rollback'),
    (0x806656A8, '40820038', 'force_input_refetch_on_advance'),
    (0x80665704, '4082005c', 'handle_local_rumble'),
    (0x80665D10, '40820250', 'init_client_pause'),
    (0x80666000, '408200f0', 'lgl_game_end_message'),
    (0x80666144, '408202b8', 'loop_engine_for_rollback'),
    (0x80666438, '40820038', 'prevent_pause_stranding'),
    (0x806664B8, '40820028', 'report_no_contest_lras'),
    (0x80666500, '40820044', 'skip_new_input_fetch_on_rollback'),
    (0x806667A8, '40820470', 'start_engine_loop'),
    (0x80666C58, '40820754', 'trigger_send_input'),
    (0x8066780C, '40820058', 'prevent_pad_alarm_during_rollback'),
    (0x80667D9C, '408200b4', 'sound_assign_instance_id'),
    (0x80667E70, '408200c8', 'sound_no_destroy_voice'),
    (0x80667F58, '408200c8', 'sound_no_destroy_voice2'),
    (0x80668040, '40820144', 'sound_prevent_duplicate_sounds'),
    (0x806681B0, '4082002c', 'teams_prevent_dead_stranding'),
)
GUARDS = tuple(
    GuardSpec(site, bytes.fromhex(raw), _bc_target(site, bytes.fromhex(raw)), name)
    for site, raw, name in _RAW_GUARDS
)

# K16: these names are mapped to C2 headers in the actual supplied RAM.
# Presentation/pause/match-lifecycle hooks were incorrectly classified as core
# rollback gates in earlier builds. Do not globally activate those in Adventure.
CONTROL_GUARD_NAMES = {
    'force_engine_on_rollback', 'force_input_refetch_on_advance',
    'handle_local_rumble', 'loop_engine_for_rollback',
    'skip_new_input_fetch_on_rollback', 'start_engine_loop',
    'trigger_send_input', 'prevent_pad_alarm_during_rollback',
    'sound_assign_instance_id', 'sound_no_destroy_voice',
    'sound_no_destroy_voice2', 'sound_prevent_duplicate_sounds',
    # K19: Slippi's client-pause pair must remain live while Adventure owns the
    # Direct session.  K16 left these scene-gated, which works during continuous
    # play but lets one peer run beyond the rollback window when the other host
    # is suspended by focus loss / tab-out.  Keep the pair together: the init
    # hook owns the pause bookkeeping consumed by prevent_pause_stranding.
    'init_client_pause', 'prevent_pause_stranding',
}
ACTIVE_GUARDS = tuple(g for g in GUARDS if g.name in CONTROL_GUARD_NAMES)
AUX_SCENE_GUARDS = tuple(g for g in GUARDS if g.name not in CONTROL_GUARD_NAMES)
SNAPSHOT_GUARDS = AUX_SCENE_GUARDS  # historical public alias
assert len(ACTIVE_GUARDS) == 14
assert len(AUX_SCENE_GUARDS) == 4

from . import slippi_engine_repair as er
GUARDS = GUARDS + er.extra_specs(__import__(__name__, fromlist=["GuardSpec"]))


def _word(value: int) -> bytes:
    return struct.pack('>I', value & 0xFFFFFFFF)


def _rlwinm(ra: int, rs: int, sh: int, mb: int, me: int) -> bytes:
    return _word((21 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) |
                 ((sh & 31) << 11) | ((mb & 31) << 6) | ((me & 31) << 1))


def _or(ra: int, rs: int, rb: int) -> bytes:
    return _word((31 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) |
                 ((rb & 31) << 11) | (444 << 1))


def _mulli(rt: int, ra: int, imm: int) -> bytes:
    return _word((7 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) | (imm & 0xFFFF))


def _add(rt: int, ra: int, rb: int) -> bytes:
    return _word((31 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) |
                 ((rb & 31) << 11) | (266 << 1))


def _subf(rt: int, ra: int, rb: int) -> bytes:
    # rt = rb - ra
    return _word((31 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) |
                 ((rb & 31) << 11) | (40 << 1))


def _mtctr(rs: int) -> bytes:
    # mtspr CTR,rS (SPR 9; halves reversed in instruction encoding).
    return _word(0x7C0903A6 | ((rs & 31) << 21))


def _cmplw(ra: int, rb: int, *, crf: int = 0) -> bytes:
    return _word((31 << 26) | ((crf & 7) << 23) | ((ra & 31) << 16) |
                 ((rb & 31) << 11) | (32 << 1))


def _emit_copy(a: Asm, *, src_reg: int, dst: int, size: int, label: str) -> None:
    """Emit an aligned word-copy loop plus a short byte tail.

    HSD_MemAlloc and the reserved high-session destinations are word aligned.
    The earlier byte loop was correct but needlessly expensive (~4k interpreter
    iterations for one ODB). 0.20.21 copies words so the bootstrap completes
    comfortably before the Online-In-Game handoff.
    """
    words, tail = divmod(size, 4)
    a.constant(4, dst)
    if words <= 2 and tail == 0:
        for i in range(words): a.emit(lwz(6, i*4, src_reg), stw(6, i*4, 4))
        return
    if words:
        a.emit(li(5, words), _mtctr(5))
        a.label(label + '_words')
        a.emit(lwz(6, 0, src_reg), stw(6, 0, 4), addi(src_reg, src_reg, 4),
               addi(4, 4, 4))
        a.emit(encode_bc(a.base + len(a.data), a.base + a.labels[label + '_words'], bo=16, bi=0))
    for i in range(tail):
        a.emit(lbz(6, i, src_reg), stb(6, i, 4))


def _load_be_u32_unaligned(a: Asm, dst: int, base_reg: int, offset: int,
                           scratch: int = 8) -> None:
    """Load a big-endian u32 from an address that need not be word aligned."""
    a.emit(lwz(dst, offset, base_reg))


def _store_be_u32_unaligned(a: Asm, src: int, base_reg: int, offset: int,
                            scratch: int = 8) -> None:
    """Store a big-endian u32 using the same unaligned ABI as native Slippi."""
    a.emit(stw(src, offset, base_reg))


def _dcbst(ra: int, rb: int) -> bytes:
    return _word(0x7C00006C | ((ra & 31) << 16) | ((rb & 31) << 11))


def _icbi(ra: int, rb: int) -> bytes:
    return _word(0x7C0007AC | ((ra & 31) << 16) | ((rb & 31) << 11))


def _sync() -> bytes:
    return _word(0x7C0004AC)


def _isync() -> bytes:
    return _word(0x4C00012C)


def _short_base_and_disp(addr: int) -> tuple[int, int]:
    """Return lis high-half + signed D-form displacement for an absolute addr."""
    addr &= 0xFFFFFFFF
    hi = ((addr + 0x8000) >> 16) & 0xFFFF
    return hi, addr & 0xFFFF


def _short_abs_byte(a: Asm, dst: int, addr: int, base_reg: int = 12) -> None:
    hi, disp = _short_base_and_disp(addr)
    a.emit(lis(base_reg, hi), lbz(dst, disp, base_reg))


def _short_abs_word(a: Asm, dst: int, addr: int, base_reg: int = 12) -> None:
    hi, disp = _short_base_and_disp(addr)
    a.emit(lis(base_reg, hi), lwz(dst, disp, base_reg))


def _inc_abs_word(a: Asm, addr: int) -> None:
    hi, disp = _short_base_and_disp(addr)
    a.emit(lis(12, hi), lwz(11, disp, 12), addi(11, 11, 1), stw(11, disp, 12))


def build_free_wrapper(base: int, *, pending_addr: int, active_addr: int,
                       state_addr: int) -> bytes:
    """Protect the authoritative session objects only while the bridge owns them.

    K2's permanent heap-carve policy is retired: the supplied PC/ROG saves prove
    the live HSD heap ends far below 0x817FE000. ArenaHi reservation now owns the
    high island, while this hook simply prevents accidental HSD_MemFree calls on
    the active relocated session.
    """
    del pending_addr, active_addr
    a = Asm(base)
    _short_abs_byte(a, 11, state_addr + S_PHASE)
    a.emit(cmpwi(11, PHASE_OFF, crf=7)); a.branch('retail', 12, 30)

    # Defensive range protection for the relocated ODB + child buffers. This
    # should never be reached by retail HSD heap frees because the island is not
    # part of that heap, but suppressing it while scoped is safer than freeing
    # an ArenaHi-reserved session object.
    a.constant(11, SESSION_HIGH_BASE)
    a.emit(_cmplw(3, 11, crf=7)); a.branch('retail', 12, 28)
    a.constant(11, SESSION_HIGH_LIMIT)
    a.emit(_cmplw(3, 11, crf=7)); a.branch('protected', 12, 28)

    a.label('retail')
    a.emit(mflr(0), encode_branch(base + len(a.data) + 4, HSD_MEM_FREE + 4))

    a.label('protected')
    # Keep this hot path code-size neutral: do not increment the old
    # diagnostic-only free-skip counter here.
    a.emit(blr())
    return a.finish()


def build_exi_wrapper(base: int, *, pending_addr: int, active_addr: int,
                      state_addr: int, snapshot_table_addr: int | None = None,
                      patch_table_addr: int | None = None,
                      prime_addr: int | None = None, snapshot_addr: int | None = None,
                      restore_addr: int | None = None,
                      return_pending_addr: int | None = None) -> bytes:
    """Keep Slippi input/rollback state alive while Adventure stays Adventure.

    K10 never rewrites Melee's global scene-controller word. The scoped 17 guard
    NOPs keep core input/rollback plus rollback-audio helpers alive, while native
    B0/B1/B2 bookkeeping and SSCB remain entirely Slippi-owned.
    """
    del snapshot_table_addr
    if patch_table_addr is None:
        patch_table_addr = (base + 0x1100) & ~3
    a = Asm(base)

    if return_pending_addr is not None:
        a.emit(lbz(11,0,3),cmpwi(11,CLEANUP_CONNECTIONS,crf=7))
        a.branch('phase_check',4,30)
        for address,value in ((return_pending_addr,1),(GM_SCENE_WORD_ADDR,GM_ONLINE_MAJOR),
                              (pending_addr,0),(active_addr,0)):
            _short_abs_byte(a,11,address);a.emit(cmpwi(11,value,crf=7))
            a.branch('phase_check',4,30)
        hi,disp=_short_base_and_disp(return_pending_addr)
        a.emit(lis(12,hi),li(11,0),stb(11,disp,12));a.branch('blocked')
        a.label('phase_check')
    _short_abs_byte(a, 11, state_addr + S_PHASE)
    a.emit(cmpwi(11, PHASE_OFF, crf=7)); a.branch('original', 12, 30)

    a.emit(lbz(11, 0, 3))
    a.emit(cmpwi(11, ONLINE_INPUTS, crf=7)); a.branch('b0', 12, 30)
    a.emit(cmpwi(11, CAPTURE_SAVESTATE, crf=7)); a.branch('b1', 12, 30)
    a.emit(cmpwi(11, LOAD_SAVESTATE, crf=7)); a.branch('b2', 12, 30)
    a.emit(cmpwi(11, CLEANUP_CONNECTIONS, crf=7)); a.branch('cleanup', 12, 30)
    a.branch('original')

    a.label('b1')
    _inc_abs_word(a, state_addr + S_B1_COUNT)
    _load_be_u32_unaligned(a, 10, 3, 1, scratch=8)
    hi, disp = _short_base_and_disp(state_addr + S_LAST_B1_FRAME)
    a.emit(lis(12, hi), stw(10, disp, 12))
    a.emit(encode_branch(base + len(a.data), snapshot_addr)) if snapshot_addr else a.branch('original')

    a.label('b2')
    _inc_abs_word(a, state_addr + S_B2_COUNT)
    _load_be_u32_unaligned(a, 10, 3, 1, scratch=8)
    hi, disp = _short_base_and_disp(state_addr + S_LAST_B2_FRAME)
    a.emit(lis(12, hi), stw(10, disp, 12))
    a.emit(encode_branch(base + len(a.data), snapshot_addr)) if snapshot_addr else a.branch('original')

    a.label('b0')
    _inc_abs_word(a, state_addr + S_B0_COUNT)

    _short_abs_byte(a, 11, pending_addr)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('active', 12, 30)
    a.constant(12, GM_SCENE_EXIT_FLAG_ADDR)
    a.emit(li(11, 1), stw(11, 0, 12)); a.branch('original')
    a.label('active')
    _short_abs_byte(a, 11, active_addr)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('original', 12, 30)
    hi, disp = _short_base_and_disp(state_addr + S_PHASE)
    phase_hi, phase_disp = hi, disp
    a.emit(lis(12, hi), li(11, PHASE_FULL), stb(11, disp, 12))
    a.branch('original')

    a.label('cleanup')
    # CleanupConnections is forbidden until both gateway ownership flags clear.
    _short_abs_byte(a, 11, pending_addr)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('blocked', 4, 30)
    _short_abs_byte(a, 11, active_addr)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('blocked', 4, 30)

    # K19 transition fence: Adventure can transiently clear the gateway flags
    # while score/credits/Coming Soon teardown is still using campaign objects.
    # CleanupConnections destroys the persistent Slippi session and restores the
    # scene-scoped hooks, so only permit it after the scene controller has truly
    # returned to the Direct/Online major scene.  This also prevents a delayed
    # cleanup packet (for example after a host focus stall) from tearing down the
    # transport in the middle of a chapter transition.
    a.constant(12, GM_SCENE_WORD_ADDR)
    a.emit(lbz(11, 0, 12), cmpwi(11, GM_ONLINE_MAJOR, crf=7))
    a.branch('blocked', 4, 30)

    if restore_addr is not None:
        a.emit(stwu(1,-0x10,1),mflr(0),stw(0,0x14,1))
        a.emit(encode_branch(base+len(a.data),restore_addr,link=True))
        a.emit(lwz(0,0x14,1),mtlr(0),addi(1,1,0x10))
        a.branch('original')
    else:
        _emit_restore(a, state_addr, patch_table_addr)
        a.branch('original')

    a.label('blocked')
    _inc_abs_word(a, state_addr + S_CLEANUP_BLOCK_COUNT)
    a.emit(li(3, 0), blr())

    a.label('original')
    a.emit(encode_branch(base + len(a.data), prime_addr or SLIPPI_EXI_TRANSFER))
    return a.finish()


def _emit_restore(a, state_addr, patch_table_addr):
    # Shared by native CleanupConnections and the completed return to Online.
    # Does not issue a host disconnect or modify the connection's player data.
    # Restore every exact Slippi scene branch. The auxiliary rows were never
    # changed, but restoring them is idempotent and keeps cleanup version-scoped.
    a.constant(8, patch_table_addr)
    a.emit(li(7, len(GUARDS)), _mtctr(7))
    a.label('restore_guards_write')
    a.emit(lwz(6, 0, 8), lwz(11, 4, 8), stw(11, 0, 6), _dcbst(0, 6), _sync(), _icbi(0, 6), addi(8, 8, 12))
    a.emit(encode_bc(a.base + len(a.data), a.base + a.labels['restore_guards_write'], bo=16, bi=0), _sync(), _isync())

    # K10 never shadows the global scene word, so cleanup only restores the
    # allocator boundary and scoped Slippi branches.
    _short_abs_word(a, 10, state_addr + S_ORIG_ARENA_HI)
    a.emit(cmpwi(10, 0, crf=7)); a.branch('cleanup_phase_off', 12, 30)
    a.emit(stw(10, OFST_R13_ARENA_HI, 13))
    a.label('cleanup_phase_off')
    hi, disp = _short_base_and_disp(state_addr + S_PHASE)
    a.emit(lis(12, hi), li(11, PHASE_OFF), stb(11, disp, 12))


def build_restore(base, state_addr, patch_table_addr):
    a=Asm(base);_emit_restore(a,state_addr,patch_table_addr);a.emit(blr())
    return a.finish()


def build_menu_return(base, *, pending_addr, active_addr, state_addr, restore_addr,
                      canonical_local_addr=None):
    """Restore native engine guards before the first returned Online scene."""
    a=Asm(base)
    for address,value in ((GM_SCENE_WORD_ADDR,GM_ONLINE_MAJOR),(pending_addr,0),(active_addr,0)):
        _short_abs_byte(a,11,address);a.emit(cmpwi(11,value,crf=7));a.branch('retail',4,30)
    _short_abs_byte(a,11,state_addr+S_PHASE)
    a.emit(cmpwi(11,PHASE_OFF,crf=7));a.branch('retail',12,30)
    if canonical_local_addr is not None:
        # SDK campaigns/challenges bypass native VS winner selection. Give the
        # canonical P1 the next selection, including first-match/draw returns.
        _short_abs_byte(a,11,canonical_local_addr)
        a.emit(stb(11,-0x5037,13),li(11,0),stb(11,-0x5036,13))
    a.emit(stwu(1,-0x10,1),mflr(0),stw(0,0x14,1))
    a.emit(encode_branch(base+len(a.data),restore_addr,link=True))
    a.emit(lwz(0,0x14,1),mtlr(0),addi(1,1,0x10))
    a.label('retail');a.emit(mflr(0),encode_branch(base+len(a.data)+4,0x801A4018))
    return a.finish()

def build_guard_shim(base: int, spec: GuardSpec, *, pending_addr: int,
                     active_addr: int, state_addr: int | None = None) -> bytes:
    """Compact scoped replacement for one Slippi ``bne 0x0208`` guard.

    The original cmpwi immediately before every patched branch has already set
    CR0.  We compare the SDK scope byte in CR7, preserving CR0.  With no scope,
    we recreate the original bne result; with scope, we always continue.
    """
    del pending_addr, active_addr
    if state_addr is None:
        # Backwards-compatible unit use: STATE was historically supplied only
        # indirectly. New installer/tests pass it explicitly.
        raise ValueError('state_addr is required for compact Slippi guard shim')
    a = Asm(base)
    # This is an arbitrary mid-function Slippi branch site, so preserve the two
    # scratch GPRs used by the scope probe. None of these instructions touch
    # CR0, which still contains the original cmpwi 0x0208 result.
    # 0.20.21J compact scope probe: preserve only r11 and use it as both
    # absolute-address base and byte destination. r12 is untouched. This saves
    # 8 bytes per shim so the two rollback-engine gates fit under the E boot-safe
    # low-runtime ceiling.
    a.emit(stwu(1, -0x10, 1), stw(11, 0x08, 1))
    hi, disp = _short_base_and_disp(state_addr + S_SESSION_SCOPE)
    a.emit(lis(11, hi), lbz(11, disp, 11), cmpwi(11, 0, crf=7),
           lwz(11, 0x08, 1), addi(1, 1, 0x10))
    a.branch('allow', 4, 30)     # scope != 0
    a.branch('reject', 4, 2)     # original bne CR0
    a.label('allow')
    a.emit(encode_branch(base + len(a.data), spec.site + 4))
    a.label('reject')
    a.emit(encode_branch(base + len(a.data), spec.target))
    return a.finish()


def build_patch_table(*, guard_shims: dict[int, int] | None = None,
                      exi_wrapper_addr: int) -> bytes:
    """Validation/install rows: (site, expected-word, installed-word).

    The 17 core-input/rollback + rollback-sound branches are installed as NOP
    while the bridge owns the Direct session. The Teams helper remains native.
    All 18 originals remain in the table so cleanup is exact and version-scoped.
    """
    overrides = guard_shims or {}
    rows: list[tuple[int, int, int]] = []
    for spec in GUARDS:
        expected = struct.unpack('>I', spec.expected)[0]
        installed = int.from_bytes(overrides[spec.site], "big") if isinstance(overrides.get(spec.site), bytes) else (0x60000000 if spec in ACTIVE_GUARDS else expected)
        rows.append((spec.site, expected, installed))
    rows.append((
        SLIPPI_EXI_VENEER,
        struct.unpack('>I', SLIPPI_EXI_VENEER_EXPECTED)[0],
        struct.unpack('>I', encode_branch(SLIPPI_EXI_VENEER, exi_wrapper_addr))[0],
    ))
    return b''.join(struct.pack('>III', *row) for row in rows)


def build_snapshot_table() -> bytes:
    """Legacy compatibility export of the five auxiliary sound/team sites.

    K8 does not install or toggle this table. It remains callable so external
    tooling that imported the old helper does not break abruptly.
    """
    return b''.join(struct.pack('>I', spec.site) for spec in AUX_SCENE_GUARDS)


def build_arm_stub(base: int, *, state_addr: int, guard_shims: dict[int, int],
                   exi_wrapper_addr: int, patch_table_addr: int | None = None,
                   txrx_blob_addr: int | None = None, ss_blob_addr: int | None = None,
                   ssrb_meta_blob_addr: int | None = None,
                   canonical_valid_addr: int | None = None,
                   canonical_local_addr: int | None = None,
                   canonical_remote_addr: int | None = None) -> bytes:
    """Capture/validate Slippi, relocate the session island, then arm.

    K4 leaves ArenaHi untouched. The frame-1 B0 path controls the heap boundary
    that Dolphin samples when constructing its rollback savestate maps.
    """
    if patch_table_addr is None:
        patch_table_addr = (base + 0x500) & ~3
    if txrx_blob_addr is None: txrx_blob_addr = (base + 0x700) & ~3
    if ss_blob_addr is None: ss_blob_addr = txrx_blob_addr + 8
    if ssrb_meta_blob_addr is None: ssrb_meta_blob_addr = ss_blob_addr + 8
    patch_count = len(GUARDS) + 1
    a = Asm(base)
    a.emit(li(11, TRACE_ARM_ENTER)); _short_store = _short_base_and_disp(state_addr + S_TRACE)
    a.emit(lis(12, _short_store[0]), stb(11, _short_store[1], 12))
    fail_hi, fail_disp = _short_base_and_disp(state_addr + S_FAILURE)
    assert fail_hi == _short_store[0]
    a.emit(li(11, 0), stb(11, fail_disp, 12))

    # Capture Slippi's three ownership bytes independently. InitOnlinePlay writes
    # MSRB_LOCAL_PLAYER_INDEX -> ODB_LOCAL_PLAYER_INDEX and
    # MSRB_REMOTE_PLAYER_INDEX -> ODB_ONLINE_PLAYER_INDEX. K4 mistakenly treated
    # the opponent byte as the local fighter index and copied it into both fields.
    a.emit(lwz(9, OFST_R13_ODB_ADDR, 13), cmpwi(9, 0, crf=7)); a.branch('fail_odb', 12, 30)
    a.emit(lbz(10, ODB_LOCAL_PLAYER_INDEX, 9), cmpwi(10, 0, crf=7)); a.branch('local_ok', 12, 30)
    a.emit(cmpwi(10, 1, crf=7)); a.branch('local_ok', 12, 30); a.branch('fail_local')
    a.label('local_ok')

    state_hi, _ = _short_base_and_disp(state_addr)
    # Only the original source pointers remain in low diagnostics. K6 hot code
    # never reads ownership/phase/session pointers from this block after arm.
    a.emit(lis(12, state_hi), stw(9, (state_addr + S_ORIG_ODB) & 0xFFFF, 12))
    for odb_off, state_off, orig_off in (
        (ODB_TXB_ADDR, S_TXB, S_ORIG_TXB), (ODB_RXB_ADDR, S_RXB, S_ORIG_RXB),
        (ODB_SSRB_ADDR, S_SSRB, S_ORIG_SSRB), (ODB_SSCB_ADDR, S_SSCB, S_ORIG_SSCB),
    ):
        if odb_off & 3:
            _load_be_u32_unaligned(a, 10, 9, odb_off)
        else:
            a.emit(lwz(10, odb_off, 9))
        a.emit(cmpwi(10, 0, crf=7)); a.branch('fail_child', 12, 30)
        a.emit(stw(10, (state_addr + orig_off) & 0xFFFF, 12))

    # Validate every one of the 18 scene guards plus the EXI veneer before any
    # live code is changed. Snapshot rows currently install their original word.
    a.constant(8, patch_table_addr); a.emit(li(7, patch_count), _mtctr(7))
    a.label('validate_loop')
    a.emit(lwz(6, 0, 8), lwz(10, 0, 6), lwz(11, 4, 8), cmpw(10, 11, crf=7))
    a.branch('validate_ok', 12, 30)
    a.emit(lwz(11, 8, 8), cmpw(10, 11, crf=7)); a.branch('fail_patch', 4, 30)
    a.label('validate_ok')
    a.emit(addi(8, 8, 12))
    a.emit(encode_bc(base + len(a.data), base + a.labels['validate_loop'], bo=16, bi=0))

    # Reserve the high session island from future Adventure allocations. This is
    # allocator protection only; unlike K6 it is NOT used as the rollback backup
    # ceiling. ArenaHi keeps HSD allocations below the relocated session island;
    # K8 uses that same in-MEM1 boundary as the maximum dynamic rollback range.
    a.emit(lwz(10, OFST_R13_ARENA_HI, 13))
    a.constant(11, SESSION_HIGH_BASE)
    a.emit(_cmplw(10, 11, crf=7)); a.branch('fail_arena', 12, 28)
    a.emit(lis(12, state_hi), stw(10, (state_addr + S_ORIG_ARENA_HI) & 0xFFFF, 12),
           stw(11, OFST_R13_ARENA_HI, 13))

    # Relocate ODB and children while Online-In-Game still owns valid copies.
    for src_off, dst, size, label in (
        (S_ORIG_ODB, STABLE_ODB, ODB_SIZE, 'copy_odb'),
        (S_ORIG_TXB, STABLE_TXB, TXB_SIZE, 'copy_txb'),
        (S_ORIG_RXB, STABLE_RXB, RXB_SIZE, 'copy_rxb'),
        (S_ORIG_SSRB, STABLE_SSRB, SSRB_SIZE, 'copy_ssrb'),
        (S_ORIG_SSCB, STABLE_SSCB, SSCB_SIZE, 'copy_sscb'),
    ):
        # r12 retains state_hi across the inline copy loops (only r3-r6 change).
        a.emit(lwz(3, (state_addr + src_off) & 0xFFFF, 12))
        _emit_copy(a, src_reg=3, dst=dst, size=size, label=label)

    # Rebase the unaligned child pointers and savestate preservation metadata in
    # the relocated objects. These preservation blocks keep network bookkeeping
    # outside gameplay rewinds even though the high island lies in main heap RAM.
    a.constant(3, txrx_blob_addr); _emit_copy(a, src_reg=3, dst=STABLE_ODB + ODB_TXB_ADDR, size=8, label='copy_txrx_ptrs')
    a.constant(3, ss_blob_addr); _emit_copy(a, src_reg=3, dst=STABLE_ODB + ODB_SSRB_ADDR, size=8, label='copy_ss_ptrs')
    a.constant(3, ssrb_meta_blob_addr); _emit_copy(a, src_reg=3, dst=STABLE_SSRB + 5, size=24, label='copy_ssrb_meta')

    # K10 canonical ownership override. The carrier ODB may have reversed the
    # logical player order (proved by paired K9 regular-vs-Adventure saves). If
    # SSS captured canonical roles, restore those two logical indices now. The
    # physical input-source byte is deliberately left exactly as Slippi created
    # it on this machine (typically local physical Port 1 / index 0).
    if canonical_valid_addr is not None:
        if canonical_local_addr is None or canonical_remote_addr is None:
            raise ValueError('canonical local/remote addresses required with canonical_valid_addr')
        _short_abs_byte(a,10,canonical_valid_addr,base_reg=8)
        a.emit( cmpwi(10, 1, crf=7)); a.branch('canonical_roles_done', 4, 30)
        _short_abs_byte(a,10,canonical_local_addr,base_reg=8)
        a.constant(9, STABLE_ODB); a.emit(stb(10, ODB_LOCAL_PLAYER_INDEX, 9))
        _short_abs_byte(a,10,canonical_remote_addr,base_reg=8); a.emit(stb(10, ODB_ONLINE_PLAYER_INDEX, 9))
        a.label('canonical_roles_done')

    # Preserve Slippi's three ownership roles independently in the low SDK
    # control block. The physical input source stays carrier/native; only the
    # logical local/remote indices can be canonicalized above.
    a.constant(11, STABLE_ODB)
    a.emit(stw(11, OFST_R13_ODB_ADDR, 13))
    a.constant(12, state_addr)
    a.emit(_or(9,11,11))
    a.emit(lbz(10, ODB_LOCAL_PLAYER_INDEX, 9), stb(10, S_LOCAL_INDEX, 12),
           lbz(10, ODB_ONLINE_PLAYER_INDEX, 9), stb(10, S_ARM_ONLINE_INDEX, 12),
           lbz(10, ODB_INPUT_SOURCE_INDEX, 9), stb(10, S_ARM_INPUT_SOURCE_INDEX, 12),
           li(10, 0), stw(10, S_WARMUP_B0_COUNT, 12), stb(10, S_SNAPSHOT_PATCHED, 12),
           stw(10, S_B0_COUNT, 12), stw(10, S_B1_COUNT, 12), stw(10, S_B2_COUNT, 12),
           stw(10, S_LAST_B1_FRAME, 12), stw(10, S_LAST_B2_FRAME, 12),
           stw(10, S_TRANSITION_RESET_COUNT, 12))
    # Install the 17 scoped core/sound fall-through NOPs + EXI wrapper; the
    # Teams row stays native. Cache maintenance covers all 19 table rows.
    a.constant(8, patch_table_addr); a.emit(li(7, patch_count), _mtctr(7))
    a.label('patch_loop')
    a.emit(lwz(6, 0, 8), lwz(11, 8, 8), stw(11, 0, 6), _dcbst(0, 6), _sync(), _icbi(0, 6), addi(8, 8, 12))
    a.emit(encode_bc(base + len(a.data), base + a.labels['patch_loop'], bo=16, bi=0), _sync(), _isync())

    a.constant(12, state_addr); a.emit(li(11, PHASE_TRANSITION), stb(11, S_PHASE, 12))
    a.emit(li(11, TRACE_ARMED), stb(11, S_TRACE, 12), li(3, 1), blr())

    a.label('fail_odb'); a.emit(li(11, 0x01)); a.branch('fail_common')
    a.label('fail_local'); a.emit(li(11, 0x02)); a.branch('fail_common')
    a.label('fail_child'); a.emit(li(11, 0x03)); a.branch('fail_common')
    a.label('fail_patch'); a.emit(li(11, 0x20)); a.branch('fail_common')
    a.label('fail_arena'); a.emit(li(11, 0x31))
    a.label('fail_common')
    hi, disp = _short_base_and_disp(state_addr + S_FAILURE)
    a.emit(lis(12, hi), stb(11, disp, 12), li(3, 0), blr())
    return a.finish()


def install(dol, runtime_index: int, *, gateway_pending_addr: int,
            gateway_active_addr: int, gateway_return_pending_addr: int | None = None,
            canonical_valid_addr: int | None = None,
            canonical_local_addr: int | None = None,
            canonical_remote_addr: int | None = None) -> dict:
    got = dol.read_at_address(HSD_MEM_FREE, 4)
    if got != HSD_MEM_FREE_EXPECTED:
        raise ValueError(
            f'Slippi Adventure netplay bridge expected HSD_MemFree 0x{HSD_MEM_FREE:08X}='
            f'{HSD_MEM_FREE_EXPECTED.hex()}, got {got.hex()}')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == runtime_index)
    base = section.address + ((section.size + 31) & ~31)
    state_addr = base
    cursor = base + STATE_SIZE
    blobs: list[tuple[int, bytes, str]] = []

    def add_blob(name: str, builder, alignment: int = 4) -> int:
        nonlocal cursor
        cursor = (cursor + alignment - 1) & ~(alignment - 1)
        addr = cursor
        blob = builder(addr)
        blobs.append((addr, blob, name))
        cursor = addr + len(blob)
        return addr

    free_wrapper = add_blob(
        'slippi_session_memfree_guard',
        lambda addr: build_free_wrapper(
            addr, pending_addr=gateway_pending_addr,
            active_addr=gateway_active_addr, state_addr=state_addr))
    import sys
    nb = sys.modules[__name__]
    batch_addr = add_blob('k15_batch_clock', lambda addr: er.batch(addr,state_addr,nb))
    start_addr = add_blob('k15_engine_clock', lambda addr: er.start(addr,state_addr,nb))
    end_addr = add_blob('k15_engine_clock_advance', lambda addr: er.end(addr,state_addr,nb))
    rng_addr = add_blob('k15_simulation_rng', lambda addr: er.rng(addr,state_addr,nb))
    heap_addr = add_blob('k15_heap_reservation', lambda addr: er.heap(addr,nb))
    prime_addr = add_blob('k15_first_map_prime', lambda addr: er.prime(addr,nb))
    snapshot_addr = add_blob('k15_sdk_snapshot', lambda addr: er.snapshot(addr,state_addr,nb))
    file_scope_addr = add_blob('k18_file_scope', er.file_scope)
    live_overrides = er.patches(state_addr,batch_addr,start_addr,end_addr,nb,file_scope_addr)
    # Put the validation/restore table immediately before EXI. Its row count is
    # fixed, so the EXI address is known before the table's branch word is built.
    restore_base=(cursor+3)&~3
    patch_table_addr=restore_base+len(build_restore(restore_base,state_addr,0))
    restore_addr=add_blob('k20t_restore_native_engine',lambda addr:build_restore(addr,state_addr,patch_table_addr))
    predicted_exi_wrapper = patch_table_addr + (len(GUARDS) + 1) * 12
    patch_table = build_patch_table(guard_shims=live_overrides, exi_wrapper_addr=predicted_exi_wrapper)
    actual_patch_table = add_blob('slippi_live_patch_table', lambda _addr: patch_table)
    if actual_patch_table != patch_table_addr:
        raise ValueError('Slippi patch-table layout mismatch')
    exi_wrapper = add_blob(
        'slippi_cleanupconnections_filter',
        lambda addr: build_exi_wrapper(
            addr, pending_addr=gateway_pending_addr,
            active_addr=gateway_active_addr, state_addr=state_addr,
            patch_table_addr=patch_table_addr, prime_addr=prime_addr, snapshot_addr=snapshot_addr,
            restore_addr=restore_addr,return_pending_addr=gateway_return_pending_addr))
    if exi_wrapper != predicted_exi_wrapper:
        raise ValueError('Slippi EXI wrapper layout mismatch')
    menu_return_addr=add_blob('k20t_online_return',lambda addr:build_menu_return(
        addr,pending_addr=gateway_pending_addr,active_addr=gateway_active_addr,
        state_addr=state_addr,restore_addr=restore_addr,canonical_local_addr=canonical_local_addr))

    # 0.20.21K4 does not need per-site low-memory shims. The 13 engine/control
    # branches are NOP while armed and all 18 exact originals restore on cleanup.
    guard_shims: dict[int, int] = {}
    txrx_blob = struct.pack('>II', STABLE_TXB, STABLE_RXB)
    ss_blob = struct.pack('>II', STABLE_SSRB, STABLE_SSCB)
    ssrb_meta_blob = struct.pack('>IIIIII', STABLE_ODB, ODB_SIZE, STABLE_RXB, RXB_SIZE, STABLE_SSCB, SSCB_SIZE)
    txrx_blob_addr = add_blob('slippi_stable_txrx_pointer_blob', lambda _addr: txrx_blob)
    ss_blob_addr = add_blob('slippi_stable_savestate_pointer_blob', lambda _addr: ss_blob)
    ssrb_meta_blob_addr = add_blob('slippi_stable_ssrb_metadata_blob', lambda _addr: ssrb_meta_blob)
    arm_stub = add_blob(
        'slippi_adventure_runtime_arm',
        lambda addr: build_arm_stub(
            addr, state_addr=state_addr, guard_shims=guard_shims,
            exi_wrapper_addr=exi_wrapper, patch_table_addr=patch_table_addr,
            txrx_blob_addr=txrx_blob_addr, ss_blob_addr=ss_blob_addr,
            ssrb_meta_blob_addr=ssrb_meta_blob_addr,
            canonical_valid_addr=canonical_valid_addr,
            canonical_local_addr=canonical_local_addr,
            canonical_remote_addr=canonical_remote_addr))

    payload = bytearray(cursor - base)
    payload[0:4] = MARKER
    payload[S_VERSION] = STATE_VERSION
    payload[S_TRACE] = TRACE_IDLE
    payload[S_LOCAL_INDEX] = 0xFF
    payload[S_FAILURE] = 0
    payload[S_PHASE] = PHASE_OFF
    for addr, blob, _name in blobs:
        off = addr - base
        payload[off:off+len(blob)] = blob
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(runtime_index, payload, alignment=0x20)
    if added['address'] != base:
        raise ValueError('Slippi Adventure netplay bridge append address mismatch')

    dol.patch_at_address(0x80390CFC, encode_branch(0x80390CFC,rng_addr), expected=mflr(0))
    dol.patch_at_address(0x801A4014,encode_branch(0x801A4014,menu_return_addr),expected=mflr(0))
    dol.patch_at_address(0x80375414, encode_branch(0x80375414,heap_addr), expected=lwz(0,-0x3FE8,13))

    free_branch = encode_branch(HSD_MEM_FREE, free_wrapper)
    dol.patch_at_address(HSD_MEM_FREE, free_branch, expected=HSD_MEM_FREE_EXPECTED)

    return {
        'native_restore':restore_addr,'menu_return':menu_return_addr,
        'early_exi_wrapper': exi_wrapper,
        'k15': {'batch_clock': batch_addr, 'engine_clock':start_addr,'engine_end':end_addr,'rng':rng_addr,'heap':heap_addr,'prime':prime_addr,'snapshot':snapshot_addr,'simulation_frame':state_addr+S_SIM_FRAME,'snapshot_base':SDK_SNAPSHOT_BASE},
        'marker': MARKER.decode('ascii'),
        'state_version': STATE_VERSION,
        'section': added,
        'state_address': state_addr,
        'trace_address': state_addr + S_TRACE,
        'local_player_index_address': state_addr + S_LOCAL_INDEX,
        'failure_address': state_addr + S_FAILURE,
        'session_scope_address': state_addr + S_SESSION_SCOPE,
        'arm_count_address': state_addr + S_ARM_COUNT,
        'free_skip_count_address': state_addr + S_FREE_SKIP_COUNT,
        'cleanup_block_count_address': state_addr + S_CLEANUP_BLOCK_COUNT,
        'batch_frame_address': state_addr + S_BATCH_FRAME,
        'simulation_frame_address': state_addr + S_SIM_FRAME,
        'arm_stub': arm_stub,
        'free_wrapper': free_wrapper,
        'exi_wrapper': exi_wrapper,
        'patch_table': patch_table_addr,
        'patch_table_size': len(patch_table),
        'hmemfree_hook': HSD_MEM_FREE,
        'hmemfree_branch': free_branch.hex(),
        'live_exi_site': SLIPPI_EXI_VENEER,
        'live_exi_expected': SLIPPI_EXI_VENEER_EXPECTED.hex(),
        'live_exi_original_target': SLIPPI_EXI_TRANSFER,
        'guard_count': len(ACTIVE_GUARDS),
        'all_guard_count': len(GUARDS),
        'live_patch_count': len(GUARDS) + 1,
        'active_control_patch_count': len(ACTIVE_GUARDS) + 1,
        'aux_scene_guard_count': len(AUX_SCENE_GUARDS),
        'snapshot_gate_count': 0,
        'snapshot_table': None,
        'guard_sites': [
            {'name': g.name, 'site': g.site, 'expected': g.expected.hex(),
             'original_target': g.target, 'installed': '60000000'}
            for g in ACTIVE_GUARDS
        ],
        'retail_gated_guard_sites': [
            {'name': g.name, 'site': g.site, 'expected': g.expected.hex(),
             'original_target': g.target}
            for g in AUX_SCENE_GUARDS if g.site not in live_overrides
        ],
        'engine_patch_sites': [{'site': site, 'installed': code.hex()} for site, code in live_overrides.items()],
        'protected_allocations': ['HSD_GetNextArena clamps heap end to 0x817E0000; SDK snapshot ring and high session remain outside game heap'],
        'stable_session': {'base': SESSION_HIGH_BASE, 'limit': SESSION_HIGH_LIMIT, 'odb': STABLE_ODB, 'txb': STABLE_TXB, 'rxb': STABLE_RXB, 'ssrb': STABLE_SSRB, 'sscb': STABLE_SSCB},
        'original_odb_diagnostic_address': state_addr + S_ORIG_ODB,
        'relocate_count_address': state_addr + S_RELOCATE_COUNT,
        'scope': 'Direct A5 marker arms session relocation and scoped engine/sound patches; Adventure retains its real scene identity',
        'slippi_runtime': 'boot-retail ArenaHi + layout-preserving 16 KiB SDK ArenaLo; version-scoped Slippi Online-In-Game guard words validated from paired Direct saves',
        'failure_policy': 'arm fails closed before any live code modification; Direct sentinel remains a normal Slippi match if validation fails',
        'rollback_status': 'K16 prevents carrier/chapter exit from marking the campaign transport game over; retains K15 engine clock, RNG and snapshot repairs. Two-peer gameplay validation required',
        'rollback_heap_primed_address': state_addr + S_ROLLBACK_HEAP_PRIMED,
        'adventure_heap_clamped_address': state_addr + S_ADVENTURE_HEAP_CLAMPED,
        'phase_address': state_addr + S_PHASE,
        'arena_reserved_address': state_addr + S_ARENA_RESERVED,
        'original_arena_hi_address': state_addr + S_ORIG_ARENA_HI,
        'snapshot_patched_address': state_addr + S_SNAPSHOT_PATCHED,
        'arm_online_index_address': state_addr + S_ARM_ONLINE_INDEX,
        'arm_input_source_index_address': state_addr + S_ARM_INPUT_SOURCE_INDEX,
        'b0_count_address': state_addr + S_B0_COUNT,
        'b1_count_address': state_addr + S_B1_COUNT,
        'b2_count_address': state_addr + S_B2_COUNT,
        'last_b1_frame_address': state_addr + S_LAST_B1_FRAME,
        'last_b2_frame_address': state_addr + S_LAST_B2_FRAME,
        'transition_reset_count_address': state_addr + S_TRANSITION_RESET_COUNT,
        'scene_shadow_active_address': state_addr + S_SCENE_SHADOW_ACTIVE,
        'original_scene_word_address': state_addr + S_ORIG_SCENE_WORD,
    }
