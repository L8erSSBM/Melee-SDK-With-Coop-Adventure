"""HF28: paced developer fast-forward through the small Team-Kirby wave.

HF26's developer L+D-Pad Down shortcut continuously moved every live event
fighter below the blast zone on every helper invocation.  Dolphin reproduction
showed why that was too aggressive: a fighter can retain stock/entity state
while already inside its normal KO/retirement lifecycle, so the wrapper could
reposition the same final-wave fighters repeatedly instead of leaving retail to
finish retiring their player slots.

HF28 supersedes *only* that Team-Kirby developer shortcut.  L+D-Pad Down now
latches a fast-forward request.  Each active event slot is driven below the
blast zone exactly once, then a per-slot latch prevents any further touch until
``Player_GetPlayerState(slot) == 0`` proves retail has fully recycled/retired
that slot.  A replacement Kirby may be handled on a later helper frame.

Most importantly, HF28 never writes the match result or terminate byte.  Once
retail reports the event ``complete != 0 && active == 0``, HF28 simply stops.
Retail owns the Team-Kirby match completion and normal Adventure transition to
Giant Kirby (subject to the game's ordinary <=30 second Giant-Kirby condition).

L+D-Pad Left remains HF27's direct Team-Kirby test warp.  Other shortcuts still
delegate unchanged through HF27/HF26.
"""
from __future__ import annotations

from .ppc import andi_dot, blr, cmpwi, encode_branch, li, lis, lwz
from .team_kirby_force_clear import Asm, _addr_parts

ADVENTURE_MODE_ADDR = 0x80479D30
ADVENTURE_STATE_ADDR = 0x80479D33
GM_ADVENTURE = 4
TEAM_KIRBY_FIGHT_STATE = 0x23

HSD_PAD_COPY_STATUS = 0x804C20BC
PAD_STATUS_STRIDE = 0x44
PAD_BUTTON_OFF = 0x00
PAD_TRIGGER_OFF = 0x08
PAD_BUTTON_DDOWN = 0x0004
PAD_BUTTON_L = 0x0040

PLAYER_GET_PLAYER_STATE = 0x800322C0
PLAYER_GET_STOCKS = 0x80033BD8
PLAYER_GET_ENTITY = 0x80034110
PLAYER_GET_FLAGS_BIT1 = 0x8003565C
PLAYER_SET_POSITION = 0x80032A04
EVENT_ENEMY_IS_COMPLETE = 0x8016A1E4
EVENT_ENEMY_IS_ACTIVE = 0x8016A1F8

EVENT_SLOTS = (2, 3, 4, 5)


def wrapper(base: int, *, hf27_stub: int, request_state_addr: int,
            latch_addrs: tuple[int, int, int, int], request_counter_addr: int,
            drive_counter_addr: int, recycle_counter_addr: int,
            complete_counter_addr: int, offscreen_vec_addr: int) -> bytes:
    """Build the HF28 shortcut-front wrapper.

    request_state: 0 idle, 1 paced fast-forward active.
    Each latch byte corresponds to event slots 2..5 and means that particular
    fighter generation has already received its one offscreen KO request.
    """
    a = Asm(base)

    # Strict Adventure + Team-Kirby gate. Outside it, clear stale HF28 test
    # state and delegate to HF27, which owns Left warp and the legacy shortcuts.
    a.load_abs(11, ADVENTURE_MODE_ADDR, byte=True)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7)); a.branch('clear_delegate', bo=4, bi=30)
    a.load_abs(11, ADVENTURE_STATE_ADDR, byte=True)
    a.emit(cmpwi(11, TEAM_KIRBY_FIGHT_STATE, crf=7)); a.branch('clear_delegate', bo=4, bi=30)

    a.load_abs(11, request_state_addr, byte=True)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('drive', bo=12, bi=30)

    # Idle in Team Kirby: intercept only a newly-triggered L+DDown chord.
    for pad_index in (0, 1):
        pad = HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE * pad_index
        hi, lo = _addr_parts(pad)
        a.emit(lis(12, hi), lwz(11, lo + PAD_BUTTON_OFF, 12),
               andi_dot(10, 11, PAD_BUTTON_L))
        a.branch(f'pad{pad_index}_next', bo=12, bi=2)
        a.emit(lwz(11, lo + PAD_TRIGGER_OFF, 12),
               andi_dot(10, 11, PAD_BUTTON_DDOWN))
        a.branch('latch_request', bo=4, bi=2)
        a.label(f'pad{pad_index}_next')
    a.branch('delegate')

    a.label('clear_delegate')
    a.emit(li(11, 0)); a.store_abs(11, request_state_addr, byte=True)
    for addr in latch_addrs:
        a.store_abs(11, addr, byte=True)
    a.label('delegate')
    a.emit(encode_branch(base + len(a.data), hf27_stub))

    a.label('latch_request')
    a.emit(li(11, 1)); a.store_abs(11, request_state_addr, byte=True)
    a.emit(li(11, 0))
    for addr in latch_addrs:
        a.store_abs(11, addr, byte=True)
    a.inc_counter(request_counter_addr, 'drive')

    a.label('drive')
    # We return directly on this path, so preserve the caller LR around retail
    # query/API calls.
    from .ppc import mflr, mtlr, stw, stwu, addi
    a.emit(stwu(1, -0x30, 1), mflr(0), stw(0, 0x14, 1))

    # If retail already completed the event, STOP.  Do not force match end;
    # its completion callback and normal Adventure state machine own the route.
    a.emit(encode_branch(base + len(a.data), EVENT_ENEMY_IS_COMPLETE, link=True))
    a.emit(stw(3, 0x18, 1))
    a.emit(encode_branch(base + len(a.data), EVENT_ENEMY_IS_ACTIVE, link=True))
    a.emit(cmpwi(3, 0, crf=7)); a.branch('scan_slots', bo=4, bi=30)
    a.emit(lwz(11, 0x18, 1), cmpwi(11, 0, crf=7)); a.branch('scan_slots', bo=12, bi=30)

    a.emit(li(11, 0)); a.store_abs(11, request_state_addr, byte=True)
    for addr in latch_addrs:
        a.store_abs(11, addr, byte=True)
    a.inc_counter(complete_counter_addr, 'return_special')
    a.branch('return_special')

    a.label('scan_slots')
    for idx, slot in enumerate(EVENT_SLOTS):
        latch = latch_addrs[idx]
        label_prefix = f'slot{slot}'

        # Already sent this generation to the blast zone?  Leave it entirely
        # alone until retail reports the player slot empty (state 0).
        a.load_abs(11, latch, byte=True)
        a.emit(cmpwi(11, 0, crf=7)); a.branch(f'{label_prefix}_candidate', bo=12, bi=30)
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_PLAYER_STATE, link=True))
        a.emit(cmpwi(3, 0, crf=7)); a.branch(f'{label_prefix}_next', bo=4, bi=30)
        a.emit(li(11, 0)); a.store_abs(11, latch, byte=True)
        a.inc_counter(recycle_counter_addr, f'{label_prefix}_next')
        a.branch(f'{label_prefix}_next')

        a.label(f'{label_prefix}_candidate')
        # Only touch a genuine active event fighter.  Retail itself uses state
        # 2 to count active event fighters (gm_801694A0).
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_FLAGS_BIT1, link=True))
        a.emit(cmpwi(3, 0, crf=7)); a.branch(f'{label_prefix}_next', bo=12, bi=30)
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_PLAYER_STATE, link=True))
        a.emit(cmpwi(3, 2, crf=7)); a.branch(f'{label_prefix}_next', bo=4, bi=30)
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_STOCKS, link=True))
        a.emit(cmpwi(3, 0, crf=7)); a.branch(f'{label_prefix}_next', bo=12, bi=30)
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_ENTITY, link=True))
        a.emit(cmpwi(3, 0, crf=7)); a.branch(f'{label_prefix}_next', bo=12, bi=30)

        a.emit(li(3, slot))
        hi, lo = _addr_parts(offscreen_vec_addr)
        a.emit(lis(4, hi), addi(4, 4, lo))
        a.emit(encode_branch(base + len(a.data), PLAYER_SET_POSITION, link=True))
        a.emit(li(11, 1)); a.store_abs(11, latch, byte=True)
        a.inc_counter(drive_counter_addr, f'{label_prefix}_next')
        a.label(f'{label_prefix}_next')

    a.label('return_special')
    a.emit(lwz(0, 0x14, 1), mtlr(0), addi(1, 1, 0x30), blr())
    return a.finish()


def install(dol, index: int, *, old_shortcut_addr: int, hf27_stub: int,
            offscreen_vec_addr: int) -> dict:
    """Append HF28 to an HF27 DOL and front the developer shortcut entry."""
    expected = encode_branch(old_shortcut_addr, hf27_stub)
    got = dol.read_at_address(old_shortcut_addr, 4)
    if got != expected:
        raise ValueError(
            'HF28 expected HF27 shortcut redirect at '
            f'0x{old_shortcut_addr:08X}: expected {expected.hex()}, got {got.hex()}')

    import struct
    expected_vec = struct.pack('>fff', 0.0, -10000.0, 0.0)
    if dol.read_at_address(offscreen_vec_addr, len(expected_vec)) != expected_vec:
        raise ValueError('HF28 offscreen vector mismatch')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)
    # 00 marker; 10 state; 11..14 slot latches; 18 request count;
    # 1C one-shot drive count; 20 slot-recycle count; 24 retail-complete count;
    # 40 code.
    payload = bytearray(b'HF28TKFF' + bytes(56))
    request_state = base + 0x10
    latch_addrs = tuple(base + 0x11 + i for i in range(4))
    request_counter = base + 0x18
    drive_counter = base + 0x1C
    recycle_counter = base + 0x20
    complete_counter = base + 0x24
    stub = base + 0x40
    blob = wrapper(
        stub, hf27_stub=hf27_stub, request_state_addr=request_state,
        latch_addrs=latch_addrs, request_counter_addr=request_counter,
        drive_counter_addr=drive_counter, recycle_counter_addr=recycle_counter,
        complete_counter_addr=complete_counter, offscreen_vec_addr=offscreen_vec_addr)
    payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base

    replacement = encode_branch(old_shortcut_addr, stub)
    dol.patch_at_address(old_shortcut_addr, replacement, expected=expected)
    return {
        'marker': 'HF28TKFF',
        'section': added,
        'shortcut_entry': old_shortcut_addr,
        'stub_address': stub,
        'hf27_delegate_stub': hf27_stub,
        'request_state': request_state,
        'slot_latches': list(latch_addrs),
        'request_counter': request_counter,
        'one_shot_drive_counter': drive_counter,
        'slot_recycle_counter': recycle_counter,
        'retail_complete_counter': complete_counter,
        'offscreen_vec_addr': offscreen_vec_addr,
        'event_slots': list(EVENT_SLOTS),
        'scope': 'developer test shortcut only; Adventure Team-Kirby state 0x23',
        'behavior': (
            'L+DDown fast-forwards small Team Kirby with one blast-zone request per '
            'fighter generation; waits for retail slot retirement before touching a '
            'replacement; never forces match termination'),
        'giant_kirby_policy': 'retail transition only; no result/terminate write',
        'runtime_validation': 'pending Dolphin reproduction',
    }
