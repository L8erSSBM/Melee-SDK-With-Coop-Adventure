from __future__ import annotations

import struct
from dataclasses import dataclass, asdict
from typing import Any

from .dol_patch import DOLImage, SymbolMap

BE_U32 = struct.Struct('>I')
FT_KIND_COUNT = 0x21
FT_KIND_BOY = 0x1D
FT_KIND_GIRL = 0x1E

# Source-backed per-FighterKind tables whose entries are useful when cloning a
# donor behavior profile into a prototype slot.  The prototype operation is
# intentionally separate from CSS/menu work and custom asset naming.
KNOWN_FTKIND_TABLES_4 = (
    'ftData_OnLoad', 'ftData_OnDeath', 'ftData_OnUserDataRemove',
    'ftData_CharacterStateTables', 'ftData_UnkMotionStates0',
    'ftData_SpecialS', 'ftData_SpecialAirHi', 'ftData_SpecialAirLw',
    'ftData_SpecialAirS', 'ftData_SpecialAirN', 'ftData_SpecialN',
    'ftData_SpecialLw', 'ftData_SpecialHi', 'ftData_OnAbsorb',
    'ftData_OnItemInvisible', 'ftData_OnItemVisible',
)


@dataclass(frozen=True)
class FighterSlotStatus:
    kind: int
    name: str
    dat_filename_symbol: str
    anim_filename_symbol: str
    has_existing_asset_identity: bool
    motion_state_pointer: int


class CharacterSlotAuthor:
    """Foundation for eventually adding a new playable character.

    Melee already reserves FighterKind 0x1D/0x1E for Male/Female Wireframes.
    Phase 16 treats these as prototype identities rather than expanding every
    Ft_Kind_Max-sized table immediately.  They already have DAT/AJ filename
    strings, costume lists, and many callbacks, which makes them much safer
    experimental slots than inventing FtKind 0x21+.
    """

    def __init__(self, dol: DOLImage, symbols: SymbolMap):
        self.dol = dol
        self.symbols = symbols

    def _table_entry(self, symbol: str, kind: int, entry_size: int = 4) -> bytes:
        s = self.symbols.require(symbol)
        if s.size is not None and s.size < FT_KIND_COUNT * entry_size:
            raise ValueError(f'{symbol} is smaller than expected FtKind table')
        return self.dol.read_at_address(s.address + kind * entry_size, entry_size)

    def _cstring_symbol(self, name: str) -> str | None:
        s = self.symbols.require(name)
        # Read conservatively until NUL or 64 bytes.
        data = bytearray()
        for i in range(64):
            b = self.dol.read_at_address(s.address + i, 1)
            if b == b'\0':
                break
            data += b
        return data.decode('ascii', errors='replace')

    def slot_status(self, kind: int) -> FighterSlotStatus:
        if kind == FT_KIND_BOY:
            name, ds, ars = 'Male Wireframe / Boy', 'ftBo_Init_DatFilename', 'ftBo_Init_AnimDatFilename'
        elif kind == FT_KIND_GIRL:
            name, ds, ars = 'Female Wireframe / Girl', 'ftGl_Init_DatFilename', 'ftGl_Init_AnimDatFilename'
        else:
            raise ValueError('Phase 16 prototype slots are Boy (0x1D) and Girl (0x1E).')
        motion = BE_U32.unpack(self._table_entry('ftData_CharacterStateTables', kind))[0]
        return FighterSlotStatus(kind, name, ds, ars, True, motion)

    def clone_ftkind_callback_tables(self, donor_kind: int, target_kind: int,
                                     *, include_motion_states: bool = True) -> list[dict[str, Any]]:
        if not 0 <= donor_kind < FT_KIND_COUNT:
            raise IndexError(donor_kind)
        if target_kind not in (FT_KIND_BOY, FT_KIND_GIRL):
            raise ValueError('Target must be one of the two reserved wireframe prototype FighterKinds.')
        patches=[]
        for name in KNOWN_FTKIND_TABLES_4:
            if not include_motion_states and name in ('ftData_CharacterStateTables','ftData_UnkMotionStates0'):
                continue
            if name not in self.symbols.by_name:
                continue
            s=self.symbols.require(name)
            if s.size is not None and s.size != FT_KIND_COUNT*4:
                continue
            donor=self._table_entry(name, donor_kind)
            addr=s.address+target_kind*4
            expected=self.dol.read_at_address(addr,4)
            if donor == expected:
                continue
            row=self.dol.patch_at_address(addr, donor, expected=expected)
            row.update({'table':name,'donor_kind':donor_kind,'target_kind':target_kind})
            patches.append(row)
        return patches

    def report(self) -> dict[str, Any]:
        slots=[]
        for k in (FT_KIND_BOY,FT_KIND_GIRL):
            st=self.slot_status(k)
            row=asdict(st)
            row['dat_filename']=self._cstring_symbol(st.dat_filename_symbol)
            row['anim_filename']=self._cstring_symbol(st.anim_filename_symbol)
            slots.append(row)
        return {
            'fighter_kind_count':FT_KIND_COUNT,
            'prototype_slots':slots,
            'recommended_strategy':'prototype on Boy/Girl identity first; expand Ft_Kind_Max only after full table audit',
            'remaining_for_new_playable_slot':[
                'CSS icon/name/portrait and CharacterKind mapping',
                'independent DAT/AJ/costume filename strings',
                'costume/model resources',
                'per-FighterKind callback/load tables beyond the cloned prototype set',
                'Kirby-copy/announcer/results/stock/UI integrations',
                'event/classic/all-star/random-selection tables',
                'animation/model authoring for a genuinely new body',
            ],
        }
