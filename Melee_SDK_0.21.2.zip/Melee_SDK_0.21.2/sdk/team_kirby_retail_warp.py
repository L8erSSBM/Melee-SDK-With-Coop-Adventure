"""Developer Adventure fast-forward helper with retail exit bookkeeping.

This module intentionally has no dependency on HF22-HF28.  It is the only
post-HF21 test helper retained in the Team-Kirby rollback build.

L+D-Pad Left, from either controller while in Adventure, requests the ordinary
1P stage-end scene exit for the current playable state and latches a one-shot
warp. A second hook runs after the current Adventure state's retail ``on_exit``
handler and replaces only the pending next-state route with the configured target.

The historical default remains Team Kirby (0x23) for archival tests. Current SDK
builds select Bowser Fight (0x59). Once the target is active, L+D-Pad Left is a
no-op. All other test shortcuts
fall through to the original Phase-39 helper byte-for-byte by replaying its
single displaced prologue instruction and tail-branching back to +4.
"""
from __future__ import annotations

from .ppc import (
    addi, andi_dot, blr, cmpwi, encode_bc, encode_branch, lbz, li, lis, lwz,
    stb, stw, stwu,
)

ADVENTURE_MODE_ADDR = 0x80479D30
ADVENTURE_STATE_ADDR = 0x80479D33
ADVENTURE_NEXT_STATE_ADDR = 0x80479D35
GM_ADVENTURE = 4
TEAM_KIRBY_FIGHT_STATE = 0x23
BOWSER_FIGHT_STATE = 0x59
# Adventure's routing engine stores target+1 before consuming it.
TEAM_KIRBY_NEXT_ROUTE_BYTE = TEAM_KIRBY_FIGHT_STATE + 1

HSD_PAD_COPY_STATUS = 0x804C20BC
PAD_STATUS_STRIDE = 0x44
PAD_BUTTON_OFF = 0x00
PAD_TRIGGER_OFF = 0x08
PAD_BUTTON_DLEFT = 0x0001
PAD_BUTTON_L = 0x0040

VS_SCENE_CONTROLLER = 0x8046B6A0
VS_TERMINATE_MATCH_ADDR = VS_SCENE_CONTROLLER + 0x06
VS_MATCH_RESULT_ADDR = VS_SCENE_CONTROLLER + 0x08
MATCH_OUTCOME_1P_STAGE_END = 6

# gm_801A4014: immediately after state->on_exit(state), before routing consumes
# the pending next-state byte.
ROUTING_HOOK = 0x801A4148
ROUTING_RETURN = ROUTING_HOOK + 4
ROUTING_EXPECTED = lbz(0, 3, 31)

# Original Phase-39 developer helper prologue at its runtime entry.
SHORTCUT_ENTRY_EXPECTED = stwu(1, -0x20, 1)


def _addr_parts(addr: int) -> tuple[int, int]:
    addr &= 0xFFFFFFFF
    hi = (addr + 0x8000) >> 16
    lo = addr & 0xFFFF
    return hi & 0xFFFF, lo


def _load_abs(out: bytearray, reg: int, addr: int, *, byte: bool = False) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(12, hi)
    out += (lbz if byte else lwz)(reg, lo, 12)


def _store_abs(out: bytearray, reg: int, addr: int, *, byte: bool = False) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(12, hi)
    out += (stb if byte else stw)(reg, lo, 12)


class Asm:
    def __init__(self, base: int):
        self.base = int(base)
        self.data = bytearray()
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str, int, int]] = []

    def emit(self, *chunks: bytes) -> None:
        for chunk in chunks:
            self.data.extend(chunk)

    def label(self, name: str) -> None:
        self.labels[name] = len(self.data)

    def branch(self, label: str, *, bo: int = 20, bi: int = 0) -> None:
        self.fixups.append((len(self.data), label, bo, bi))
        self.emit(bytes(4))

    def load_abs(self, reg: int, addr: int, *, byte: bool = False) -> None:
        _load_abs(self.data, reg, addr, byte=byte)

    def store_abs(self, reg: int, addr: int, *, byte: bool = False) -> None:
        _store_abs(self.data, reg, addr, byte=byte)

    def inc_counter(self, addr: int, done_label: str) -> None:
        hi, lo = _addr_parts(addr)
        self.emit(lis(12, hi), lwz(11, lo, 12), cmpwi(11, -1, crf=7))
        self.branch(done_label, bo=12, bi=30)
        self.emit(addi(11, 11, 1), stw(11, lo, 12))

    def finish(self) -> bytes:
        for off, label, bo, bi in self.fixups:
            self.data[off:off + 4] = encode_bc(
                self.base + off, self.base + self.labels[label], bo=bo, bi=bi)
        return bytes(self.data)


def shortcut_wrapper(base: int, *, old_shortcut_addr: int,
                     warp_flag_addr: int, request_counter_addr: int,
                     target_state: int = TEAM_KIRBY_FIGHT_STATE) -> bytes:
    """Intercept only L+Left; otherwise execute the original helper unchanged."""
    a = Asm(base)

    a.load_abs(11, ADVENTURE_MODE_ADDR, byte=True)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7))
    a.branch('delegate', bo=4, bi=30)

    for pad_index in (0, 1):
        pad = HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE * pad_index
        hi, lo = _addr_parts(pad)
        a.emit(lis(12, hi), lwz(11, lo + PAD_BUTTON_OFF, 12),
               andi_dot(10, 11, PAD_BUTTON_L))
        a.branch(f'pad{pad_index}_next', bo=12, bi=2)
        a.emit(lwz(11, lo + PAD_TRIGGER_OFF, 12),
               andi_dot(10, 11, PAD_BUTTON_DLEFT))
        a.branch('warp', bo=4, bi=2)
        a.label(f'pad{pad_index}_next')

    a.label('delegate')
    # Replay the displaced Phase-39 helper prologue and continue at +4.  This
    # preserves Down/Right/Up behavior exactly as it existed before HF26.
    a.emit(SHORTCUT_ENTRY_EXPECTED)
    a.emit(encode_branch(base + len(a.data), old_shortcut_addr + 4))

    a.label('warp')
    a.load_abs(11, ADVENTURE_STATE_ADDR, byte=True)
    a.emit(cmpwi(11, target_state, crf=7))
    a.branch('return', bo=12, bi=30)

    a.emit(li(11, 1))
    a.store_abs(11, warp_flag_addr, byte=True)
    a.inc_counter(request_counter_addr, 'terminate')

    a.label('terminate')
    a.emit(li(11, MATCH_OUTCOME_1P_STAGE_END))
    a.store_abs(11, VS_MATCH_RESULT_ADDR, byte=True)
    a.emit(li(11, 1))
    a.store_abs(11, VS_TERMINATE_MATCH_ADDR, byte=True)

    a.label('return')
    a.emit(blr())
    return a.finish()


def routing_wrapper(base: int, *, warp_flag_addr: int,
                    applied_counter_addr: int,
                    target_state: int = TEAM_KIRBY_FIGHT_STATE) -> bytes:
    """Apply the test route after the current state's retail on_exit completes."""
    a = Asm(base)
    a.load_abs(11, warp_flag_addr, byte=True)
    a.emit(cmpwi(11, 0, crf=7))
    a.branch('replay', bo=12, bi=30)

    a.emit(li(11, 0))
    a.store_abs(11, warp_flag_addr, byte=True)
    a.emit(li(11, target_state + 1))
    a.store_abs(11, ADVENTURE_NEXT_STATE_ADDR, byte=True)
    a.inc_counter(applied_counter_addr, 'replay')

    a.label('replay')
    a.emit(ROUTING_EXPECTED)
    a.emit(encode_branch(base + len(a.data), ROUTING_RETURN))
    return a.finish()


def install(dol, index: int, *, old_shortcut_addr: int,
            target_state: int = TEAM_KIRBY_FIGHT_STATE) -> dict:
    """Append the standalone warp to an HF21-equivalent runtime image."""
    got_shortcut = dol.read_at_address(old_shortcut_addr, 4)
    if got_shortcut != SHORTCUT_ENTRY_EXPECTED:
        raise ValueError(
            'HF29 retail-isolation warp expected the original test-shortcut '
            f'prologue at 0x{old_shortcut_addr:08X}: expected '
            f'{SHORTCUT_ENTRY_EXPECTED.hex()}, got {got_shortcut.hex()}')

    got_route = dol.read_at_address(ROUTING_HOOK, 4)
    if got_route != ROUTING_EXPECTED:
        raise ValueError(
            f'HF29 routing hook expected {ROUTING_EXPECTED.hex()} at '
            f'0x{ROUTING_HOOK:08X}, got {got_route.hex()}')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)

    payload = bytearray(b'HF29TKRW' + bytes(24))
    warp_flag = base + 0x10
    request_counter = base + 0x14
    applied_counter = base + 0x18
    shortcut_stub = base + 0x20

    sw = shortcut_wrapper(
        shortcut_stub,
        old_shortcut_addr=old_shortcut_addr,
        warp_flag_addr=warp_flag,
        request_counter_addr=request_counter,
        target_state=target_state,
    )
    payload.extend(sw)
    payload.extend(bytes((-len(payload)) % 32))

    routing_stub = base + len(payload)
    rw = routing_wrapper(
        routing_stub,
        warp_flag_addr=warp_flag,
        applied_counter_addr=applied_counter,
        target_state=target_state,
    )
    payload.extend(rw)
    payload.extend(bytes((-len(payload)) % 32))

    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base

    shortcut_branch = encode_branch(old_shortcut_addr, shortcut_stub)
    route_branch = encode_branch(ROUTING_HOOK, routing_stub)
    dol.patch_at_address(
        old_shortcut_addr, shortcut_branch, expected=SHORTCUT_ENTRY_EXPECTED)
    dol.patch_at_address(
        ROUTING_HOOK, route_branch, expected=ROUTING_EXPECTED)

    return {
        'marker': 'HF29TKRW',
        'section': added,
        'shortcut_entry': old_shortcut_addr,
        'shortcut_stub': shortcut_stub,
        'original_shortcut_body': old_shortcut_addr + 4,
        'routing_hook': ROUTING_HOOK,
        'routing_stub': routing_stub,
        'warp_flag': warp_flag,
        'request_counter': request_counter,
        'applied_counter': applied_counter,
        'target_state': target_state,
        'scope': 'developer test shortcut only; Adventure',
        'behavior': (
            f'L+DLeft exits the current playable Adventure match normally, then '
            f'overrides post-on_exit routing to Adventure state 0x{target_state:02X}; all other '
            'shortcuts fall through to the original pre-HF26 helper'),
        'team_kirby_runtime_changes': 'none; this helper changes only the post-on_exit target route',
    }
