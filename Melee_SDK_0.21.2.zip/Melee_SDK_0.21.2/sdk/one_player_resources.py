from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
import zipfile
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Iterable, Iterator

# Source-grounded Adventure StKind -> GrKind/file mapping from
# gr/stage.c::stage_id_map and each StageData filename in gr/*.c.
# These are the retail resources the existing Adventure mode already uses.
ADVENTURE_STAGE_RESOURCES = [
    (59, 1, 'Mushroom Kingdom route', 'GrNKr.dat', 'KinokoRoute', 'route'),
    (60, 1, "Princess Peach's Castle", 'GrCs.dat', 'Castle', 'battle'),
    (61, 2, 'Kongo Jungle', 'GrKg.dat', 'Kongo', 'battle'),
    (62, 2, 'Jungle Japes', 'GrGd.dat', 'Garden', 'battle'),
    (63, 3, 'Underground Maze route', 'GrNSr.dat', 'ShrineRoute', 'route'),
    (64, 3, 'Temple', 'GrSh.dat', 'Shrine', 'battle'),
    (65, 4, 'Brinstar', 'GrZe.dat', 'Zebes', 'battle'),
    (66, 4, 'Brinstar Escape route', 'GrNZr.dat', 'ZebesRoute', 'route'),
    (67, 5, 'Green Greens encounter A', 'GrGr.dat', 'Greens', 'battle'),
    (68, 5, 'Green Greens encounter B', 'GrGr.dat', 'Greens', 'wave'),
    (69, 5, 'Green Greens encounter C', 'GrGr.dat', 'Greens', 'battle'),
    (70, 6, 'Corneria encounter A', 'GrCn.dat', 'Corneria', 'battle'),
    (71, 6, 'Corneria encounter B', 'GrCn.dat', 'Corneria', 'battle'),
    (72, 7, 'Pokemon Stadium', 'GrPs.dat', 'PStadium', 'wave'),
    (73, 8, 'F-Zero Grand Prix route', 'GrNBr.dat', 'BigBlueRoute', 'route'),
    (74, 8, 'Mute City', 'GrMc.dat', 'MuteCity', 'battle'),
    (75, 9, 'Onett', 'GrOt.dat', 'Onett', 'battle'),
    (76, 10, 'Icicle Mountain encounter A', 'GrIm.dat', 'Icemt', 'battle'),
    (77, 10, 'Icicle Mountain encounter B', 'GrIm.dat', 'Icemt', 'battle'),
    (78, 11, 'Battlefield wireframe encounter', 'GrNBa.dat', 'Battle', 'wave'),
    (79, 11, 'Battlefield metal encounter', 'GrNBa.dat', 'Battle', 'battle'),
    (80, 12, 'Final Destination encounter A', 'GrNLa.dat', 'Last', 'boss'),
    (81, 12, 'Final Destination encounter B', 'GrNLa.dat', 'Last', 'boss'),
]

# Pokemon Stadium has transformation archives loaded by the stage code.  Keep
# these alongside GrPs.dat when auditing/copying the retail Adventure resource set.
ADVENTURE_AUXILIARY_STAGE_FILES = ('GrPs1.dat', 'GrPs2.dat', 'GrPs3.dat', 'GrPs4.dat')

@dataclass(frozen=True)
class OnePlayerResourceEntry:
    filename: str
    size: int
    category: str
    source_name: str

@dataclass
class OnePlayerResourceReport:
    source: str
    file_count: int
    total_bytes: int
    movie_count: int
    categories: dict[str, int]
    entries: list[OnePlayerResourceEntry]

    def to_dict(self) -> dict:
        d = asdict(self)
        return d


def _category_for_name(name: str) -> str:
    low = name.lower()
    if low.endswith('.mth'):
        return 'movie'
    if low.startswith('ir') and low.endswith(('.dat', '.usd')):
        return '1p_visual_interface'
    if low.startswith('tymn') and low.endswith(('.dat', '.usd')):
        return 'trophy_menu'
    if low.startswith('ty') and low.endswith(('.dat', '.usd')):
        return 'trophy_resource'
    if low.startswith('tm') and low.endswith(('.dat', '.usd')):
        return 'mode_resource'
    if low.startswith('gr') and low.endswith('.dat'):
        return 'stage'
    if low.startswith('gm') and low.endswith(('.dat', '.usd')):
        return 'game_mode'
    return 'other'


def _iter_zip(path: Path) -> Iterator[tuple[str, int, bytes | None]]:
    with zipfile.ZipFile(path) as zf:
        for info in zf.infolist():
            if info.is_dir():
                continue
            name = Path(info.filename).name
            if not name:
                continue
            yield name, info.file_size, None


def _iter_folder(path: Path) -> Iterator[tuple[str, int, Path]]:
    for p in sorted(path.rglob('*')):
        if p.is_file():
            yield p.name, p.stat().st_size, p


def inspect_one_player_resources(source: str | Path) -> OnePlayerResourceReport:
    p = Path(source)
    if not p.exists():
        raise FileNotFoundError(p)
    rows: list[OnePlayerResourceEntry] = []
    cats: dict[str, int] = {}
    total = 0
    movies = 0
    iterable = _iter_zip(p) if p.is_file() and zipfile.is_zipfile(p) else _iter_folder(p) if p.is_dir() else None
    if iterable is None:
        raise ValueError('1P resources must be a folder or ZIP archive')
    seen: set[str] = set()
    for name, size, _ in iterable:
        key = name.lower()
        if key in seen:
            raise ValueError(f'Duplicate resource basename in 1P package: {name}')
        seen.add(key)
        cat = _category_for_name(name)
        rows.append(OnePlayerResourceEntry(name, size, cat, name))
        cats[cat] = cats.get(cat, 0) + 1
        total += size
        movies += int(cat == 'movie')
    return OnePlayerResourceReport(str(p), len(rows), total, movies, dict(sorted(cats.items())), rows)


def _read_member(source: Path, filename: str) -> bytes:
    if source.is_dir():
        matches = [p for p in source.rglob('*') if p.is_file() and p.name.lower() == filename.lower()]
        if len(matches) != 1:
            raise FileNotFoundError(filename)
        return matches[0].read_bytes()
    with zipfile.ZipFile(source) as zf:
        matches = [n for n in zf.namelist() if Path(n).name.lower() == filename.lower()]
        if len(matches) != 1:
            raise FileNotFoundError(filename)
        return zf.read(matches[0])


def import_one_player_resources(project, source: str | Path, *, include_movies: bool = False) -> dict:
    """Snapshot a 1P resource package into an existing project.

    Movies are optional because a normal ISO rebuild can leave the retail MTH
    files untouched.  This keeps huge ending movies out of the SDK workspace.
    """
    src = Path(source)
    report = inspect_one_player_resources(src)
    imported: list[str] = []
    skipped_movies: list[str] = []
    existing = {r['filename'].lower(): r for r in project.manifest.setdefault('resources', [])}
    for row in report.entries:
        if row.category == 'movie' and not include_movies:
            skipped_movies.append(row.filename)
            continue
        # Never overwrite an existing immutable baseline with a package import.
        orig = project.original_dir / row.filename
        work = project.working_dir / row.filename
        data = _read_member(src, row.filename)
        if orig.exists():
            if orig.read_bytes() != data:
                raise ValueError(f'{row.filename} already exists in the project with different baseline data')
            if not work.exists():
                work.write_bytes(data)
        else:
            orig.write_bytes(data)
            work.write_bytes(data)
        digest = hashlib.sha256(orig.read_bytes()).hexdigest()
        existing[row.filename.lower()] = {
            'filename': row.filename,
            'source_relative': f'<1p package:{src.name}>',
            'sha256': digest,
            'size': len(data),
        }
        imported.append(row.filename)
    project.manifest['resources'] = sorted(existing.values(), key=lambda x: x['filename'].lower())
    project.manifest['one_player_resources'] = {
        'source': str(src),
        'imported_count': len(imported),
        'movie_files_imported': bool(include_movies),
        'movie_count_in_package': report.movie_count,
        'categories': report.categories,
    }
    project.save_manifest()
    return {
        'imported': imported,
        'skipped_movies': skipped_movies,
        'report': report.to_dict(),
    }


def adventure_resource_audit(project=None, extra_filenames: Iterable[str] = ()) -> dict:
    available: set[str] = {str(x).lower() for x in extra_filenames}
    if project is not None:
        available.update(p.name.lower() for p in project.working_dir.iterdir() if p.is_file())
    rows = []
    for stkind, chapter, name, filename, grkind, encounter_type in ADVENTURE_STAGE_RESOURCES:
        rows.append({
            'stkind': stkind,
            'chapter': chapter,
            'name': name,
            'filename': filename,
            'grkind': grkind,
            'encounter_type': encounter_type,
            'available': filename.lower() in available,
        })
    aux = [{'filename': fn, 'available': fn.lower() in available, 'purpose': 'Pokemon Stadium transformation archive'}
           for fn in ADVENTURE_AUXILIARY_STAGE_FILES]
    unique_required = sorted({x[3] for x in ADVENTURE_STAGE_RESOURCES}, key=str.lower)
    missing = [fn for fn in unique_required if fn.lower() not in available]
    missing_aux = [x['filename'] for x in aux if not x['available']]
    return {
        'segments': rows,
        'required_stage_files': unique_required,
        'required_stage_file_count': len(unique_required),
        'available_required_stage_files': len(unique_required) - len(missing),
        'missing_stage_files': missing,
        'auxiliary_stage_files': aux,
        'missing_auxiliary_stage_files': missing_aux,
        'ready_for_retail_adventure_stage_assets': not missing,
    }


def write_resource_report(source: str | Path, output: str | Path) -> Path:
    report = inspect_one_player_resources(source)
    p = Path(output)
    p.write_text(json.dumps(report.to_dict(), indent=2), encoding='utf-8')
    return p
