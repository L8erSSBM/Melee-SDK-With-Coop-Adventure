from __future__ import annotations

import struct
from dataclasses import dataclass, asdict
from typing import Any

from .dol_patch import DOLImage, SymbolMap

BE_U32 = struct.Struct('>I')
STAGE_DATA_SIZE = 0x34
STAGE_DATAS_ENTRY_SIZE = 4
STAGE_ID_MAP_ENTRY_SIZE = 0x0C

# Source-validated dormant pairing in GALE01 1.02:
# St_Kind_Akaneia (0x15) -> Gr_Kind_Unk26 (0x1A), whose stage_datas slot is NULL.
AKANEIA_STKIND = 0x15
AKANEIA_GRKIND = 0x1A


@dataclass(frozen=True)
class StageSlotCandidate:
    stkind: int
    grkind: int
    stage_data_pointer: int
    stage_data_is_null: bool
    label: str


@dataclass(frozen=True)
class InjectedStageSlot:
    stkind: int
    grkind: int
    stage_data_address: int
    filename_address: int
    filename: str
    template_symbol: str
    patches: list[dict[str, Any]]


class StageSlotAuthor:
    """DOL-side stage-slot authoring for GALE01 1.02.

    Phase 16 intentionally targets the already-existing dormant Akaneia StKind/
    GrKind pair instead of expanding the global stage tables.  That gives us a
    real extra runtime stage identity while keeping the first implementation
    bounded and reversible.  Stage-select-screen icon authoring remains a
    separate MnSlMap archive operation.
    """

    def __init__(self, dol: DOLImage, symbols: SymbolMap):
        self.dol = dol
        self.symbols = symbols

    def stage_datas_capacity(self) -> int:
        s = self.symbols.require('stage_datas')
        if s.size is None or s.size % 4:
            raise ValueError('stage_datas has no usable declared size')
        return s.size // 4

    def stage_id_map_capacity(self) -> int:
        s = self.symbols.require('stage_id_map')
        if s.size is None or s.size % STAGE_ID_MAP_ENTRY_SIZE:
            raise ValueError('stage_id_map has no usable declared size')
        return s.size // STAGE_ID_MAP_ENTRY_SIZE

    def stage_data_pointer(self, grkind: int) -> int:
        cap = self.stage_datas_capacity()
        if not 0 <= grkind < cap:
            raise IndexError(grkind)
        s = self.symbols.require('stage_datas')
        return BE_U32.unpack(self.dol.read_at_address(s.address + grkind * 4, 4))[0]

    def mapped_grkind(self, stkind: int) -> int:
        cap = self.stage_id_map_capacity()
        if not 0 <= stkind < cap:
            raise IndexError(stkind)
        s = self.symbols.require('stage_id_map')
        return BE_U32.unpack(self.dol.read_at_address(s.address + stkind * STAGE_ID_MAP_ENTRY_SIZE, 4))[0]

    def hidden_slot_status(self) -> StageSlotCandidate:
        gr = self.mapped_grkind(AKANEIA_STKIND)
        ptr = self.stage_data_pointer(AKANEIA_GRKIND)
        return StageSlotCandidate(
            stkind=AKANEIA_STKIND,
            grkind=gr,
            stage_data_pointer=ptr,
            stage_data_is_null=(ptr == 0),
            label='Akaneia dormant stage identity',
        )

    def _candidate_data_caves(self, minimum_size: int, alignment: int = 4) -> list[tuple[int, int]]:
        """Return zero-filled ranges in DOL data sections, largest first.

        This does not claim every zero run is semantically unused.  The caller
        must explicitly choose a cave address; automatic writing is avoided.
        """
        out: list[tuple[int, int]] = []
        for sec in self.dol.sections:
            if sec.kind != 'data':
                continue
            raw = self.dol.raw[sec.file_offset:sec.file_offset + sec.size]
            i = 0
            while i < len(raw):
                if raw[i] != 0:
                    i += 1
                    continue
                j = i + 1
                while j < len(raw) and raw[j] == 0:
                    j += 1
                start_addr = sec.address + i
                aligned = (start_addr + alignment - 1) & ~(alignment - 1)
                usable = (sec.address + j) - aligned
                if usable >= minimum_size:
                    out.append((aligned, usable))
                i = j
        out.sort(key=lambda x: (-x[1], x[0]))
        return out

    def candidate_data_caves(self, filename: str = '/GrMy.dat') -> list[dict[str, int]]:
        need = STAGE_DATA_SIZE + len(filename.encode('ascii')) + 1
        return [{'address': a, 'size': n} for a, n in self._candidate_data_caves(need)]

    def inject_hidden_stage_slot(self, template_symbol: str, filename: str,
                                 cave_address: int) -> InjectedStageSlot:
        """Clone one existing StageData into the dormant Akaneia runtime slot.

        The injected record reuses the donor stage callbacks/joint table but
        changes grkind and DAT filename.  This is ideal for template-derived
        stages: e.g. clone Battlefield behavior while loading /GrMy.dat.
        """
        if not filename.startswith('/'):
            filename = '/' + filename
        if not filename.lower().endswith('.dat'):
            raise ValueError('Stage filename must end in .dat')
        try:
            name_bytes = filename.encode('ascii') + b'\0'
        except UnicodeEncodeError as exc:
            raise ValueError('Stage filename must be ASCII') from exc

        status = self.hidden_slot_status()
        if status.grkind != AKANEIA_GRKIND:
            raise ValueError(f'Expected StKind 0x15 to map to GrKind 0x1A; got 0x{status.grkind:X}')
        if not status.stage_data_is_null:
            raise ValueError('Dormant GrKind 0x1A is already occupied; refusing to overwrite it.')

        template = self.symbols.require(template_symbol)
        if template.size is not None and template.size < STAGE_DATA_SIZE:
            raise ValueError(f'{template_symbol} is smaller than StageData')
        raw = bytearray(self.dol.read_at_address(template.address, STAGE_DATA_SIZE))

        filename_addr = cave_address + STAGE_DATA_SIZE
        # StageData +0x00 = grkind, +0x08 = data1 filename pointer.
        struct.pack_into('>I', raw, 0x00, AKANEIA_GRKIND)
        struct.pack_into('>I', raw, 0x08, filename_addr)

        total = bytes(raw) + name_bytes
        before = self.dol.read_at_address(cave_address, len(total))
        if any(before):
            raise ValueError('Selected data cave is not entirely zero-filled.')

        patches: list[dict[str, Any]] = []
        p = self.dol.patch_at_address(cave_address, total, expected=before)
        p['purpose'] = 'injected StageData + filename'
        patches.append(p)

        table = self.symbols.require('stage_datas')
        slot_addr = table.address + AKANEIA_GRKIND * 4
        expected = self.dol.read_at_address(slot_addr, 4)
        if expected != b'\0\0\0\0':
            raise ValueError('stage_datas dormant entry changed before patch application')
        p = self.dol.patch_at_address(slot_addr, BE_U32.pack(cave_address), expected=expected)
        p['purpose'] = 'stage_datas[Gr_Kind_Unk26] -> injected StageData'
        patches.append(p)

        return InjectedStageSlot(
            stkind=AKANEIA_STKIND,
            grkind=AKANEIA_GRKIND,
            stage_data_address=cave_address,
            filename_address=filename_addr,
            filename=filename,
            template_symbol=template_symbol,
            patches=patches,
        )


    def inject_hidden_stage_slot_expanded(self, template_symbol: str, filename: str) -> InjectedStageSlot:
        """Install the dormant Akaneia stage using a real appended DOL data section.

        Unlike the Phase 16 cave path, this does not rely on a guessed zero run.
        It allocates a loader-backed data section for the cloned StageData and
        filename, then patches stage_datas[0x1A] to the new virtual address.
        """
        if not filename.startswith('/'):
            filename = '/' + filename
        if not filename.lower().endswith('.dat'):
            raise ValueError('Stage filename must end in .dat')
        try:
            name_bytes = filename.encode('ascii') + b'\0'
        except UnicodeEncodeError as exc:
            raise ValueError('Stage filename must be ASCII') from exc
        status = self.hidden_slot_status()
        if status.grkind != AKANEIA_GRKIND:
            raise ValueError(f'Expected StKind 0x15 to map to GrKind 0x1A; got 0x{status.grkind:X}')
        if not status.stage_data_is_null:
            raise ValueError('Dormant GrKind 0x1A is already occupied; refusing to overwrite it.')
        template = self.symbols.require(template_symbol)
        raw = bytearray(self.dol.read_at_address(template.address, STAGE_DATA_SIZE))
        # Placeholder filename pointer is fixed after the section allocator chooses VA.
        struct.pack_into('>I', raw, 0x00, AKANEIA_GRKIND)
        payload = bytes(raw) + name_bytes
        # If the shared SDK runtime arena is already present, append stage
        # metadata there rather than consuming another DOL section header slot.
        shared = self.dol.find_data_section_prefix(b'MSDKRT29')
        if shared is not None:
            sec = self.dol.append_to_data_section(shared.index, payload, alignment=0x20)
        else:
            sec = self.dol.add_data_section(payload)
        filename_addr = sec['address'] + STAGE_DATA_SIZE
        self.dol.patch_at_address(sec['address'] + 0x08, BE_U32.pack(filename_addr))
        table = self.symbols.require('stage_datas')
        slot_addr = table.address + AKANEIA_GRKIND * 4
        expected = self.dol.read_at_address(slot_addr, 4)
        if expected != b'\0\0\0\0':
            raise ValueError('stage_datas dormant entry changed before patch application')
        patch = self.dol.patch_at_address(slot_addr, BE_U32.pack(sec['address']), expected=expected)
        patch['purpose'] = 'stage_datas[Gr_Kind_Unk26] -> appended StageData section'
        return InjectedStageSlot(
            stkind=AKANEIA_STKIND, grkind=AKANEIA_GRKIND,
            stage_data_address=sec['address'], filename_address=filename_addr,
            filename=filename, template_symbol=template_symbol,
            patches=[{'purpose':'new DOL data section','address':sec['address'],
                      'file_offset':sec['file_offset'],'size':sec['size']}, patch],
        )

    def report(self) -> dict[str, Any]:
        hidden = self.hidden_slot_status()
        return {
            'stage_datas_capacity': self.stage_datas_capacity(),
            'stage_id_map_capacity': self.stage_id_map_capacity(),
            'hidden_slot': asdict(hidden),
            'strategy': 'reuse dormant St_Kind_Akaneia 0x15 -> Gr_Kind_Unk26 0x1A; prefer appended DOL data section over guessed caves',
            'sss_requirement': 'MnSlMap icon/list authoring still required for normal Stage Select Screen visibility',
        }
