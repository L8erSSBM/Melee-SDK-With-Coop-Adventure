from __future__ import annotations

import math
import struct
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any

from .stage import StageDAT, JOBJ_INSTANCE

GX_TEX_FORMATS = {
    0: 'I4', 1: 'I8', 2: 'IA4', 3: 'IA8', 4: 'RGB565', 5: 'RGB5A3',
    6: 'RGBA8', 8: 'C4', 9: 'C8', 10: 'C14X2', 14: 'CMPR',
}
SUPPORTED_PNG_FORMATS = {'I4','I8','IA4','IA8','RGB565','RGB5A3','RGBA8','CMPR'}

@dataclass(frozen=True)
class TextureRecord:
    symbol: str
    image_offset: int
    descriptor_offset: int
    width: int
    height: int
    format_id: int
    format_name: str
    mipmap: int
    min_lod: float
    max_lod: float
    encoded_size: int
    png_replace_supported: bool


def _align(v: int, a: int) -> int:
    return (v + a - 1) // a * a


def texture_level_size(width: int, height: int, format_id: int) -> int:
    w,h=int(width),int(height)
    if format_id in (0,8): return _align(w,8)*_align(h,8)//2
    if format_id in (1,2,9): return _align(w,8)*_align(h,4)
    if format_id in (3,4,5,10): return _align(w,4)*_align(h,4)*2
    if format_id == 6: return _align(w,4)*_align(h,4)*4
    if format_id == 14: return _align(w,8)*_align(h,8)//2
    raise ValueError(f'Unsupported GX texture format {format_id}')


def _rgb565(r,g,b):
    return ((r>>3)<<11)|((g>>2)<<5)|(b>>3)

def _rgb565_unpack(v):
    return (((v>>11)&31)*255//31, ((v>>5)&63)*255//63, (v&31)*255//31, 255)

def _rgb5a3(r,g,b,a):
    if a >= 224:
        return 0x8000 | ((r>>3)<<10) | ((g>>3)<<5) | (b>>3)
    return ((a>>5)<<12) | ((r>>4)<<8) | ((g>>4)<<4) | (b>>4)

def _intensity(r,g,b):
    return max(0,min(255,round(0.299*r+0.587*g+0.114*b)))


def _encode_cmpr_block(px):
    # GameCube CMPR is DXT1 endpoint/index coding inside tiled 8x8 groups.
    opaque = [p for p in px if p[3] >= 128]
    has_alpha = len(opaque) != len(px)
    if not opaque:
        c0=c1=0
    else:
        lo=min(opaque,key=lambda p:_intensity(*p[:3])); hi=max(opaque,key=lambda p:_intensity(*p[:3]))
        a=_rgb565(*hi[:3]); b=_rgb565(*lo[:3])
        if has_alpha:
            c0,c1=(min(a,b),max(a,b))
        else:
            c0,c1=(max(a,b),min(a,b))
            if c0 == c1:
                c0 = min(0xFFFF,c0+1)
    p0=_rgb565_unpack(c0); p1=_rgb565_unpack(c1)
    if c0 > c1:
        pal=[p0,p1,
             tuple((2*p0[i]+p1[i])//3 for i in range(4)),
             tuple((p0[i]+2*p1[i])//3 for i in range(4))]
    else:
        pal=[p0,p1,tuple((p0[i]+p1[i])//2 for i in range(4)),(0,0,0,0)]
    bits=0
    for p in px:
        if has_alpha and p[3] < 128:
            idx=3
        else:
            limit=3 if c0 <= c1 else 4
            idx=min(range(limit), key=lambda j: sum((p[k]-pal[j][k])**2 for k in range(3)))
        bits=(bits<<2)|idx
    return struct.pack('>HHI',c0,c1,bits)


def encode_gx_texture(image, format_id: int) -> bytes:
    im=image.convert('RGBA'); w,h=im.size; get=im.load(); out=bytearray()
    def p(x,y): return get[x,y] if x<w and y<h else (0,0,0,0)
    if format_id == 0: # I4 8x8
        for by in range(0,_align(h,8),8):
            for bx in range(0,_align(w,8),8):
                for y in range(8):
                    for x in range(0,8,2):
                        i0=_intensity(*p(bx+x,by+y)[:3])>>4; i1=_intensity(*p(bx+x+1,by+y)[:3])>>4
                        out.append((i0<<4)|i1)
    elif format_id in (1,2): # I8 / IA4, 8x4
        for by in range(0,_align(h,4),4):
            for bx in range(0,_align(w,8),8):
                for y in range(4):
                    for x in range(8):
                        q=p(bx+x,by+y); inten=_intensity(*q[:3])
                        out.append(inten if format_id==1 else ((q[3]>>4)<<4)|(inten>>4))
    elif format_id in (3,4,5): # 4x4, 16-bit
        for by in range(0,_align(h,4),4):
            for bx in range(0,_align(w,4),4):
                for y in range(4):
                    for x in range(4):
                        r,g,b,a=p(bx+x,by+y)
                        if format_id==3: v=(a<<8)|_intensity(r,g,b)
                        elif format_id==4: v=_rgb565(r,g,b)
                        else: v=_rgb5a3(r,g,b,a)
                        out += struct.pack('>H',v)
    elif format_id == 6: # RGBA8, AR plane then GB plane per 4x4 block
        for by in range(0,_align(h,4),4):
            for bx in range(0,_align(w,4),4):
                block=[p(bx+x,by+y) for y in range(4) for x in range(4)]
                for r,g,b,a in block: out += bytes((a,r))
                for r,g,b,a in block: out += bytes((g,b))
    elif format_id == 14: # CMPR, 8x8 tile with four 4x4 DXT1 sub-blocks
        for by in range(0,_align(h,8),8):
            for bx in range(0,_align(w,8),8):
                for oy,ox in ((0,0),(0,4),(4,0),(4,4)):
                    block=[p(bx+ox+x,by+oy+y) for y in range(4) for x in range(4)]
                    out += _encode_cmpr_block(block)
    else:
        raise ValueError(f'PNG import does not support GX format {GX_TEX_FORMATS.get(format_id,format_id)} yet')
    expected=texture_level_size(w,h,format_id)
    if len(out)!=expected: raise AssertionError((len(out),expected,format_id,w,h))
    return bytes(out)


class StageAssetEditor:
    """Model/JObj and texture authoring against source-known HSD descriptors."""
    def __init__(self, stage: StageDAT):
        self.stage=stage
        self.arc=stage.archive

    def joint_inventory(self) -> list[dict[str,Any]]:
        roots=[]; seen_roots=set(); out=[]
        for b in self.stage.marker_bindings():
            r=b['map_joint_offset']
            if r in seen_roots: continue
            seen_roots.add(r); roots.append(r)
        for root_i,root in enumerate(roots):
            for idx,j in enumerate(self.stage.flatten_joint_tree(root)):
                out.append({'root_index':root_i,'root_offset':root,'preorder_index':idx,'offset':j['offset'],
                            'parent_index':j['parent_index'],'flags':j['flags'],'position':j['position'],
                            'rotation':j['rotation'],'scale':j['scale'],'world_position':j['world_position'],
                            'has_dobj':bool(j.get('flags',0)&((1<<5)|(1<<14))==0 and self.arc.data_u32(j['offset']+0x10))})
        return out

    def set_joint_transform(self, joint_offset: int, *, position=None, rotation=None, scale=None) -> None:
        off=int(joint_offset); self.stage._bounds(off,0x40,'HSD_Joint')
        for rel,vals,name in ((0x14,rotation,'rotation'),(0x20,scale,'scale'),(0x2C,position,'position')):
            if vals is None: continue
            vals=tuple(float(v) for v in vals)
            if len(vals)!=3 or not all(math.isfinite(v) for v in vals): raise ValueError(f'{name} must contain three finite values')
            if name=='scale' and any(abs(v)<1e-8 for v in vals): raise ValueError('Joint scale components cannot be zero')
            for i,v in enumerate(vals): self.arc.write_data_f32(off+rel+i*4,v)

    def textures(self) -> list[TextureRecord]:
        pubs=[p for p in self.arc.publics if p.name.endswith('_image')]
        backrefs={}
        for loc in self.arc.relocations:
            try: target=self.arc.data_u32(loc)
            except Exception: continue
            backrefs.setdefault(target,[]).append(loc)
        out=[]; seen=set()
        for pub in pubs:
            for desc in backrefs.get(pub.offset,[]):
                if desc in seen: continue
                try:
                    self.stage._bounds(desc,0x18,'HSD_ImageDesc')
                    width=struct.unpack_from('>H',self.arc.raw,self.arc.data_start+desc+4)[0]
                    height=struct.unpack_from('>H',self.arc.raw,self.arc.data_start+desc+6)[0]
                    fmt=self.arc.data_u32(desc+8); mip=self.arc.data_u32(desc+0xC)
                    minlod=self.arc.data_f32(desc+0x10); maxlod=self.arc.data_f32(desc+0x14)
                    if not (0<width<=4096 and 0<height<=4096 and fmt in GX_TEX_FORMATS): continue
                    size=texture_level_size(width,height,fmt)
                except Exception: continue
                seen.add(desc)
                out.append(TextureRecord(pub.name,pub.offset,desc,width,height,fmt,GX_TEX_FORMATS[fmt],mip,minlod,maxlod,size,
                                         GX_TEX_FORMATS[fmt] in SUPPORTED_PNG_FORMATS and mip==0))
        return sorted(out,key=lambda x:x.symbol.lower())

    def replace_texture_png(self, symbol: str, png_path: str|Path) -> TextureRecord:
        records=[x for x in self.textures() if x.symbol==symbol]
        if not records: raise KeyError(symbol)
        if len(records)>1: raise ValueError(f'{symbol} is referenced by multiple image descriptors; choose a descriptor-specific replacement')
        rec=records[0]
        if not rec.png_replace_supported:
            why='mipmapped texture' if rec.mipmap else f'GX format {rec.format_name}'
            raise ValueError(f'PNG replacement is not yet enabled for {why}')
        try:
            from PIL import Image
        except ImportError as e:
            raise RuntimeError('PNG texture import requires Pillow (PIL). The rest of the SDK does not require Pillow. Install Pillow only if your environment allows it, or use the other stage-authoring tools without PNG import.') from e
        im=Image.open(png_path)
        if im.size != (rec.width,rec.height):
            raise ValueError(f'PNG must be exactly {rec.width}x{rec.height}; got {im.width}x{im.height}')
        enc=encode_gx_texture(im,rec.format_id)
        self.stage._bounds(rec.image_offset,len(enc),'texture image data')
        start=self.arc.data_start+rec.image_offset
        self.arc.raw[start:start+len(enc)]=enc
        return rec


def stage_asset_report(stage: StageDAT) -> dict[str,Any]:
    ed=StageAssetEditor(stage); tex=ed.textures(); joints=ed.joint_inventory()
    return {'filename':stage.filename,'joints':len(joints),'textures':len(tex),
            'png_replaceable_textures':sum(t.png_replace_supported for t in tex),
            'texture_formats':{f:sum(t.format_name==f for t in tex) for f in sorted({t.format_name for t in tex})}}
