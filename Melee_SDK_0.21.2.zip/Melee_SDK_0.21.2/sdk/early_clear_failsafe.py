"""HF25: cover the pre-terminal Team-Kirby clear-screen OOM path.

HF24 guarded the clear-screen snapshot only after the verified Team-Kirby
active->terminal edge (C1).  A test/forced clear can enter gmregclear while the
wave is still active (C0/lifecycle 01), so both HF24 and HF22 intentionally
fell back to retail.  Retail then asks for the original 640x480x2 background
image (614,400 bytes), which panics when the Icies + Kirby working set has
already exhausted the heap.

This wrapper handles only that missing pre-terminal case:
  * Adventure mode
  * Team-Kirby state 0x23
  * terminal guard still 0
  * one human campaign slot is Ice Climbers
  * the exact retail clear-screen allocation signature (640,480,RGB5A3,0)

For that case the captured gameplay background is omitted entirely and
execution resumes after the optional background GObj/callback setup.  The
score tally/UI/audio and scene progression remain retail.  Once the normal C1
terminal edge exists, HF24 remains the authority and is entered unchanged.
"""
from __future__ import annotations

import struct

from .ppc import addi, cmpwi, encode_bc, encode_branch, lbz, lis, lwz, stw

ALLOC_SITE = 0x80180A08
BACKGROUND_CONTINUE = 0x80180A50
ADVENTURE_MODE = 0x80479D30
ADVENTURE_STATE = 0x80479D33
CKIND_POPO_NANA = 0x0E


def word(value: int) -> bytes:
    return struct.pack('>I', value & 0xFFFFFFFF)


class Asm:
    def __init__(self, base: int):
        self.base = int(base)
        self.data = bytearray()
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str, int, int]] = []

    def emit(self, *chunks: bytes) -> None:
        for chunk in chunks:
            self.data.extend(chunk)

    def constant(self, r: int, value: int) -> None:
        value &= 0xFFFFFFFF
        self.emit(lis(r, (value + 0x8000) >> 16), addi(r, r, value & 0xFFFF))

    def absolute(self, r: int, address: int, *, byte: bool = False) -> None:
        self.constant(12, address)
        self.emit((lbz if byte else lwz)(r, 0, 12))

    def label(self, name: str) -> None:
        self.labels[name] = len(self.data)

    def branch(self, label: str, bo: int = 20, bi: int = 0) -> None:
        self.fixups.append((len(self.data), label, bo, bi))
        self.emit(bytes(4))

    def finish(self) -> bytes:
        for off, label, bo, bi in self.fixups:
            self.data[off:off+4] = encode_bc(
                self.base + off, self.base + self.labels[label], bo=bo, bi=bi)
        return bytes(self.data)


def wrapper(base: int, hf24_stub: int, terminal_guard: int,
            p1_ckind_addr: int, p2_ckind_addr: int, skip_counter: int) -> bytes:
    a = Asm(base)

    # Everything except the proven missing pre-terminal Icies/Team-Kirby path
    # tail-enters HF24 byte-for-byte with the original argument registers.
    a.absolute(11, ADVENTURE_MODE, byte=True)
    a.emit(cmpwi(11, 4, crf=7)); a.branch('hf24', 4, 30)       # != Adventure
    a.absolute(11, ADVENTURE_STATE, byte=True)
    a.emit(cmpwi(11, 0x23, crf=7)); a.branch('hf24', 4, 30)    # != Team Kirby
    a.absolute(11, terminal_guard, byte=True)
    a.emit(cmpwi(11, 0, crf=7)); a.branch('hf24', 4, 30)       # normal C1 path

    # Require a human Ice Climbers campaign slot.  The CharacterKind bytes are
    # persistent campaign identity saved by the existing Phase-43 runtime.
    a.absolute(11, p1_ckind_addr, byte=True)
    a.emit(cmpwi(11, CKIND_POPO_NANA, crf=7)); a.branch('icies', 12, 30)
    a.absolute(11, p2_ckind_addr, byte=True)
    a.emit(cmpwi(11, CKIND_POPO_NANA, crf=7)); a.branch('hf24', 4, 30)
    a.label('icies')

    # Only intercept the exact gmregclear full-screen image request.  Any other
    # allocation at this site is forwarded to HF24 unchanged.
    for reg, value in ((4, 640), (5, 480), (6, 5), (7, 0)):
        a.emit(cmpwi(reg, value, crf=7)); a.branch('hf24', 4, 30)

    # This path is necessarily an early/forced clear while the wave is still
    # active.  The background capture is cosmetic, so do not allocate it at all.
    # Count the bypass without allocating memory; saturate at 0xffffffff.
    a.constant(12, skip_counter)
    a.emit(lwz(11, 0, 12), cmpwi(11, -1, crf=7))
    a.branch('continue_clear', 12, 30)
    a.emit(addi(11, 11, 1), stw(11, 0, 12))
    a.label('continue_clear')
    a.emit(encode_branch(base + len(a.data), BACKGROUND_CONTINUE))

    a.label('hf24')
    a.emit(encode_branch(base + len(a.data), hf24_stub))
    return a.finish()


def install(dol, index: int, *, terminal_guard: int, p1_ckind_addr: int,
            p2_ckind_addr: int, hf24_stub: int) -> dict:
    expected = encode_branch(ALLOC_SITE, hf24_stub, link=True)
    if dol.read_at_address(ALLOC_SITE, 4) != expected:
        raise ValueError('HF25 early-clear fail-safe expected HF24 allocation hook mismatch')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)
    payload = bytearray(b'HF25ECLR' + bytes(24))
    skip_counter = base + 0x10
    stub = base + len(payload)
    blob = wrapper(stub, hf24_stub, terminal_guard, p1_ckind_addr,
                   p2_ckind_addr, skip_counter)
    payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base

    replacement = encode_branch(ALLOC_SITE, stub, link=True)
    dol.patch_at_address(ALLOC_SITE, replacement, expected=expected)
    return dict(
        marker='HF25ECLR', section=added, site_address=ALLOC_SITE,
        stub_address=stub, skip_counter=skip_counter,
        hf24_stub=hf24_stub, terminal_guard=terminal_guard,
        p1_ckind_addr=p1_ckind_addr, p2_ckind_addr=p2_ckind_addr,
        background_continue=BACKGROUND_CONTINUE,
        scope='Adventure Icies Team-Kirby pre-terminal/forced clear only',
        behavior='omit optional captured gameplay background and continue score clear',
        runtime_validation='pending Dolphin reproduction',
    )
