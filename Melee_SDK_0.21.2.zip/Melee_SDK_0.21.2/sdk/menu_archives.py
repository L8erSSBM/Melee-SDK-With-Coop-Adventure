from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any

from .melee_dat import HSDArchive

MENU_ARCHIVES = {
    'MnSlMap.usd': 'MnSelectStageDataTable',
    'MnSlMap.dat': 'MnSelectStageDataTable',
    'MnSlChr.usd': 'MnSelectChrDataTable',
    'MnSlChr.dat': 'MnSelectChrDataTable',
}


@dataclass(frozen=True)
class MenuArchiveReport:
    filename: str
    expected_public: str
    public_found: bool
    public_offset: int | None
    public_count: int
    relocation_count: int
    file_size: int
    data_size: int


class MenuArchiveInspector:
    """Conservative HSD menu-archive inspector.

    Phase 17 intentionally stops before mutating the stage/CSS visual trees: the
    retail MnSlMap/MnSlChr archives are needed to validate their exact root and
    JObj topology.  This class makes those resources first-class project inputs
    and verifies the source-known public roots before any future writer runs.
    """

    def __init__(self, path_or_bytes: str | Path | bytes | bytearray):
        if isinstance(path_or_bytes, (bytes, bytearray)):
            self.path = None
            raw = bytes(path_or_bytes)
            self.filename = '<bytes>'
        else:
            self.path = Path(path_or_bytes)
            raw = self.path.read_bytes()
            self.filename = self.path.name
        self.archive = HSDArchive(raw)

    def report(self, expected_public: str | None = None) -> MenuArchiveReport:
        if expected_public is None:
            expected_public = MENU_ARCHIVES.get(self.filename, '')
        match = next((p for p in self.archive.publics if p.name == expected_public), None) if expected_public else None
        return MenuArchiveReport(
            filename=self.filename,
            expected_public=expected_public or '',
            public_found=match is not None,
            public_offset=match.offset if match else None,
            public_count=len(self.archive.publics),
            relocation_count=len(self.archive.relocations),
            file_size=len(self.archive.raw),
            data_size=self.archive.header.data_size,
        )

    def require_public(self, expected_public: str) -> int:
        match = next((p for p in self.archive.publics if p.name == expected_public), None)
        if match is None:
            raise ValueError(f'{self.filename}: required HSD public symbol {expected_public!r} was not found')
        return match.offset


def inspect_menu_archives(folder: str | Path) -> list[dict[str, Any]]:
    folder = Path(folder)
    out: list[dict[str, Any]] = []
    for filename, root in MENU_ARCHIVES.items():
        path = folder / filename
        if not path.exists():
            continue
        r = MenuArchiveInspector(path).report(root)
        out.append(r.__dict__.copy())
    return out

# --- Phase 18: source-layout menu model tables -------------------------------
def _ptr_ok(arc, value: int) -> bool:
    return value == 0 or 0 <= value < arc.header.data_size


def _static_model_desc(arc, off: int) -> dict[str, int]:
    vals=[arc.data_u32(off+i*4) for i in range(4)]
    if not all(_ptr_ok(arc,v) for v in vals):
        raise ValueError(f'StaticModelDesc at 0x{off:X} has out-of-range HSD pointer')
    return {'offset':off,'joint':vals[0],'animjoint':vals[1],'matanim_joint':vals[2],'shapeanim_joint':vals[3]}


def _model_table_report(self: MenuArchiveInspector) -> dict[str, Any]:
    if self.filename.lower().startswith('mnslmap'):
        root=self.require_public('MnSelectStageDataTable')
        if root+0xD0>self.archive.header.data_size: raise ValueError('MnSelectStageDataTable is truncated')
        models=[]
        # x10..xA0 are eleven StaticModelDesc rows. xB0..xBC is a final model quartet.
        for i in range(11): models.append(_static_model_desc(self.archive,root+0x10+i*0x10))
        final={'joint':self.archive.data_u32(root+0xC0),'animjoint':self.archive.data_u32(root+0xC4),
               'matanim_joint':self.archive.data_u32(root+0xC8),'shapeanim_joint':self.archive.data_u32(root+0xCC)}
        return {'kind':'sss','root_offset':root,'camera':self.archive.data_u32(root),'lights':[self.archive.data_u32(root+4),self.archive.data_u32(root+8)],
                'fog':self.archive.data_u32(root+0xC),'static_models':models,'final_model':final,
                'model_count':12,'source_layout':'mnstagesel.c temp_r3 + mnStageSel_804D6C98_t'}
    if self.filename.lower().startswith('mnslchr'):
        root=self.require_public('MnSelectChrDataTable')
        if root+0xA0>self.archive.header.data_size: raise ValueError('MnSelectChrDataTable is truncated')
        models=[_static_model_desc(self.archive,root+0x10+i*0x10) for i in range(9)]
        return {'kind':'css','root_offset':root,'camera':self.archive.data_u32(root),'lights':[self.archive.data_u32(root+4),self.archive.data_u32(root+8)],
                'fog':self.archive.data_u32(root+0xC),'static_models':models,'model_count':9,
                'source_layout':'MnSelectChrDataTable'}
    raise ValueError('Model table layout is only defined for MnSlMap/MnSlChr archives')

MenuArchiveInspector.model_table_report=_model_table_report
