from __future__ import annotations

import hashlib
import itertools
import json
import struct
import tempfile
from pathlib import Path

from .additional_content import FEATURES, AdditionalContentProfile, vanilla_character_only_profile, full_dlc_profile
from .adventure_probe import install_phase30_coop_spawn_probe
from .character_slot import CharacterSlotAuthor, FT_KIND_BOY
from .dol_patch import DOLImage, SymbolMap
from .gamecube_iso import GALE01_102_DOL_SHA1
from .ppc import decode_branch
from .stage_slot import StageSlotAuthor, AKANEIA_GRKIND

MEM1_END = 0x81800000
SDK_MAGIC = b'MSDKRT29'


def _free_data_slots(dol: DOLImage) -> list[int]:
    return [i for i in range(11) if struct.unpack_from('>I', dol.raw, 0xAC + i * 4)[0] == 0]


def _section_row(sec) -> dict:
    return {
        'kind': sec.kind, 'index': sec.index, 'file_offset': sec.file_offset,
        'address': sec.address, 'size': sec.size, 'end_address': sec.end_address,
    }


def audit_architecture(clean_dol_path: str | Path, symbols_path: str | Path) -> dict:
    clean_path = Path(clean_dol_path)
    symbols_path = Path(symbols_path)
    source = clean_path.read_bytes()
    source_sha1 = hashlib.sha1(source).hexdigest()
    if source_sha1.lower() != GALE01_102_DOL_SHA1:
        raise ValueError(f'Architecture audit requires canonical GALE01 1.02 main.dol; got {source_sha1}')
    symbols = SymbolMap.from_file(symbols_path)
    clean = DOLImage(source)
    clean_free = _free_data_slots(clean)

    with tempfile.TemporaryDirectory(prefix='melee_sdk_arch_audit_') as td:
        probe_path = Path(td) / 'probe.dol'
        probe_manifest = install_phase30_coop_spawn_probe(clean_path, symbols_path, probe_path)
        probe = DOLImage(probe_path)
        probe_free = _free_data_slots(probe)
        shared = probe.find_data_section_prefix(SDK_MAGIC)
        if shared is None:
            raise AssertionError('Shared SDK runtime section missing after co-op install')

        # Verify every emitted direct hook actually targets the shared runtime section.
        branch_checks = []
        hook_rows = list(probe_manifest['framework']['hooks']) + list(probe_manifest['hooks'])
        for h in hook_rows:
            site = int(h.get('site_address'))
            raw = probe.read_at_address(site, 4)
            # Most runtime hooks are direct b/bl branches into the shared SDK
            # section. Phase 35 also has guarded in-place instruction patches
            # (currently the historical 1P C-stick NOP), which should survive
            # composition but do not have a runtime branch target.
            if (int.from_bytes(raw, 'big') >> 26) == 18:
                decoded = decode_branch(site, raw)
                target = decoded['target']
                inside = shared.address <= target < shared.end_address
                branch_checks.append({'name': h['name'], 'site': site, 'target': target, 'inside_shared_runtime': inside, 'kind':'runtime_branch'})
                if not inside:
                    raise AssertionError(f'{h["name"]} does not target the shared runtime section')
            else:
                expected_replacement = h.get('replacement')
                if expected_replacement is not None and raw.hex() != expected_replacement:
                    raise AssertionError(f'{h["name"]} static patch does not match its declared replacement')
                branch_checks.append({'name': h['name'], 'site': site, 'target': None, 'inside_shared_runtime': None, 'kind':'static_patch', 'bytes':raw.hex()})

        # Compose the authored-stage runtime on top of Co-op Adventure. It must
        # reuse the same section and preserve section-slot count.
        stage = StageSlotAuthor(probe, symbols).inject_hidden_stage_slot_expanded('grNBa_StageData', '/GrAudit.dat')
        after_stage_free = _free_data_slots(probe)
        if after_stage_free != probe_free:
            raise AssertionError('Stage runtime consumed a new DOL section despite shared SDK runtime availability')
        ptr = struct.unpack('>I', probe.read_at_address(symbols.require('stage_datas').address + AKANEIA_GRKIND * 4, 4))[0]
        if ptr != stage.stage_data_address:
            raise AssertionError('Dormant stage slot pointer does not reference composed stage data')

        # Compose a fighter prototype table patch after both runtime features.
        fighter_patches = CharacterSlotAuthor(probe, symbols).clone_ftkind_callback_tables(0x00, FT_KIND_BOY)
        shared_after = probe.find_data_section_prefix(SDK_MAGIC)
        if shared_after is None:
            raise AssertionError('Fighter authoring destroyed the shared runtime section')
        if _free_data_slots(probe) != probe_free:
            raise AssertionError('Fighter prototype unexpectedly consumed DOL section slots')

        # Re-check hook branches after subsequent architectures mutate the DOL.
        for row in branch_checks:
            raw_now = probe.read_at_address(row['site'], 4)
            if row['kind'] == 'runtime_branch':
                decoded = decode_branch(row['site'], raw_now)
                if decoded['target'] != row['target']:
                    raise AssertionError(f'Later authoring changed runtime hook {row["name"]}')
            elif raw_now.hex() != row['bytes']:
                raise AssertionError(f'Later authoring changed static patch {row["name"]}')

        combined_path = Path(td) / 'combined.dol'
        probe.save_as(combined_path)
        combined_size = combined_path.stat().st_size
        combined_shared = probe.find_data_section_prefix(SDK_MAGIC)
        assert combined_shared is not None

    # Exercise every raw Additional Content subset through dependency closure.
    keys = [f.key for f in FEATURES]
    profile_count = 0
    unique_closed = set()
    for mask in range(1 << len(keys)):
        raw = [keys[i] for i in range(len(keys)) if mask & (1 << i)]
        closed = AdditionalContentProfile('audit', raw).with_dependencies()
        plan = closed.build_plan()
        unique_closed.add(tuple(sorted(plan['enabled'])))
        profile_count += 1
    vanilla = vanilla_character_only_profile(); vanilla.validate()
    full = full_dlc_profile(); full.validate()

    bss_addr, bss_size = clean.bss_range()
    return {
        'format': 'melee-sdk-architecture-audit-v1',
        'target': 'GALE01 1.02',
        'source_sha1': source_sha1,
        'status': 'PASS',
        'dol': {
            'clean_size': len(source),
            'combined_size': combined_size,
            'combined_growth_bytes': combined_size - len(source),
            'clean_data_section_slots_free': clean_free,
            'after_coop_data_section_slots_free': probe_free,
            'after_stage_and_fighter_data_section_slots_free': after_stage_free,
            'shared_runtime_section': _section_row(combined_shared),
            'shared_runtime_consumes_one_header_slot': len(clean_free) - len(probe_free) == 1,
            'bss_start': bss_addr,
            'bss_size': bss_size,
            'mem1_end': MEM1_END,
            'static_address_headroom_bytes': MEM1_END - combined_shared.end_address,
            'note': 'Static DOL/MEM1 overlap audit only; runtime heap/Arena behavior still requires Dolphin testing.',
        },
        'composition': {
            'coop_adventure_installed': True,
            'custom_stage_runtime_composed_after_coop': True,
            'custom_stage_reused_shared_runtime_section': True,
            'fighter_prototype_composed_after_stage_and_coop': True,
            'fighter_patch_count': len(fighter_patches),
            'stage_data_address': stage.stage_data_address,
            'stage_filename_address': stage.filename_address,
            'runtime_hooks_survived_later_authoring': True,
        },
        'branches': {
            'all_runtime_hooks_target_shared_section': all(x['inside_shared_runtime'] for x in branch_checks if x['kind']=='runtime_branch'),
            'static_patches_survived_later_authoring': all(x['kind']!='static_patch' or x.get('bytes') for x in branch_checks),
            'checks': branch_checks,
        },
        'additional_content': {
            'feature_count': len(keys),
            'raw_profile_combinations_checked': profile_count,
            'unique_dependency_closed_profiles': len(unique_closed),
            'character_only_profile_valid': vanilla.enabled == [],
            'full_dlc_profile_valid': set(full.enabled) == set(keys),
        },
        'limits': {
            'dol_data_section_header_slots_total': 11,
            'clean_unused_data_section_slots': len(clean_free),
            'unused_slots_after_composed_runtime': len(probe_free),
            'policy': 'All SDK runtime payloads should share one loader-backed runtime section whenever it is present.',
        },
    }


def write_architecture_audit(clean_dol_path: str | Path, symbols_path: str | Path, output_path: str | Path) -> Path:
    result = audit_architecture(clean_dol_path, symbols_path)
    p = Path(output_path)
    p.write_text(json.dumps(result, indent=2), encoding='utf-8')
    return p
