"""K15 engine-clock and rollback helpers. Supported Slippi signatures fail closed."""
import struct
from .early_clear_failsafe import Asm
from .ppc import *

# These sound readers all already hold ODB in r31. Use reserved padding for
# a mirror of the simulation clock without growing the low-code reservation.
ODB_SIM_MIRROR=0xCF0
SOUND_READS=(0x80667DE4,0x80667DF8,0x80667E94,0x80667EA8,
             0x80667F7C,0x80667F90,0x80668094,0x806680A8)
BATCH_SITE=0x80665624
# Verified C2 ReportNoContestLRAS hook and StartEngineLoop match-end block.
# Install only while the Adventure bridge owns the Direct session; cleanup
# restores exact original instructions. A chapter is not a Slippi match end.
REPORT_EXIT_GATE=0x806664B8
REPORT_EXIT_CONTINUE=0x806664E0
GAME_END_CHECK=0x80666BA4
GAME_END_CONTINUE=0x80666C04

def extra_specs(nb):
 rows=[nb.GuardSpec(BATCH_SITE,stw(4,0xAC5,5),0,'k15_batch_clock'),
       nb.GuardSpec(0x8066618C,lis(24,0x8048),0,'k15_end_clock'),
       nb.GuardSpec(0x806667C4,lis(31,0x8048),0,'k15_start_clock'),
       nb.GuardSpec(0x806668B4,lwz(31,-0x62A0,31),0,'k15_restored_clock')]
 rows += [nb.GuardSpec(site,lwz(3,-0x62A0,3),0,'k15_sound_clock') for site in SOUND_READS]
 rows += [nb.GuardSpec(0x806673E8,cmpwi(31,0),0,'k18_file_size_scope'),
          nb.GuardSpec(0x806674C8,cmpwi(31,0),0,'k18_file_load_scope')]
 rows.append(nb.GuardSpec(GAME_END_CHECK,lbz(3,0x0F,30),GAME_END_CONTINUE,'k16_campaign_transport_lifetime'))
 return tuple(rows)

def batch(base,state,nb):
 a=Asm(base)
 a.emit(stw(4,0xAC5,5),lwz(10,3,5))
 # Read the live queue depth under ForceEngine's interrupt lock: r27 was read
 # before that lock and may exclude an input alarm that just arrived.
 a.constant(11,0x804C1F7B);a.emit(lbz(11,0,11),nb._subf(10,11,10))
 a.constant(12,state);a.emit(stw(10,nb.S_BATCH_FRAME,12))
 a.emit(encode_branch(base+len(a.data),BATCH_SITE+4));return a.finish()

def start(base,state,nb):
 a=Asm(base);a.constant(12,state)
 a.emit(lbz(10,0xABF,30),cmpwi(10,0,crf=7));a.branch('load',4,30)
 a.emit(lwz(10,nb.S_BATCH_FRAME,12),nb._add(10,10,26),stw(10,nb.S_SIM_FRAME,12))
 a.label('load');a.emit(lwz(31,nb.S_SIM_FRAME,12),stw(31,ODB_SIM_MIRROR,30))
 a.emit(encode_branch(base+len(a.data),0x806667CC));return a.finish()

def end(base,state,nb):
 a=Asm(base);a.constant(12,state)
 a.emit(lwz(24,nb.S_SIM_FRAME,12),addi(24,24,1),stw(24,nb.S_SIM_FRAME,12),stw(24,ODB_SIM_MIRROR,31))
 a.emit(encode_branch(base+len(a.data),0x80666194));return a.finish()

def file_scope(base):
 # Both native loaders branch to their disc fallback when CR0 is equal.
 # LR is already saved by the native injection prologue; r12 is volatile.
 a=Asm(base)
 a.emit(lis(12,0x8048),lbz(12,-0x62D0,12),cmpwi(12,4))
 a.branch('done',12,2)
 a.emit(cmpwi(31,0))
 a.label('done');a.emit(blr());return a.finish()

def patches(state,batch_addr,start_addr,end_addr,nb,file_scope_addr=None):
 out={BATCH_SITE:encode_branch(BATCH_SITE,batch_addr),
      REPORT_EXIT_GATE:encode_branch(REPORT_EXIT_GATE,REPORT_EXIT_CONTINUE),
      GAME_END_CHECK:encode_branch(GAME_END_CHECK,GAME_END_CONTINUE)}
 # The original native conditional branch executes after this comparison.
 # Online menu assets must remain eligible for host replacement.
 if file_scope_addr is None: file_scope_addr=end_addr+0x100
 for site in (0x806673E8,0x806674C8):
  out[site]=encode_branch(site,file_scope_addr,link=True)
 for site in SOUND_READS: out[site]=lwz(3,ODB_SIM_MIRROR,31)
 out[0x806668B4]=lwz(31,ODB_SIM_MIRROR,30)
 for site,target in [(0x806667C4,start_addr),(0x8066618C,end_addr)]:
  out[site]=encode_branch(site,target)
 return out

def rng(base,state,nb):
 a=Asm(base);a.constant(12,state)
 a.emit(lbz(10,nb.S_PHASE,12),cmpwi(10,0,crf=7));a.branch('retail',12,30)
 a.emit(lwz(10,nb.S_SIM_FRAME,12),nb._rlwinm(10,10,16,0,31))
 a.constant(12,nb.STABLE_ODB);a.emit(lwz(11,7,12),nb._add(10,10,11))
 a.constant(12,nb.RNG_SEED_ADDR);a.emit(stw(10,0,12))
 a.label('retail');a.emit(mflr(0),encode_branch(base+len(a.data)+4,0x80390D00))
 return a.finish()

def heap(base,nb):
 # HSD_GetNextArena returns the authoritative bounds used to initialize lbHeap.
 a=Asm(base);a.emit(lwz(0,-0x3FE8,13),stw(0,0,3),lwz(0,-0x3FE4,13))
 a.constant(12,nb.FULL_ROLLBACK_HEAP_END)
 a.emit(nb._cmplw(0,12,crf=7));a.branch('store',12,28)
 a.emit(nb._or(0,12,12))
 a.label('store');a.emit(stw(0,0,4),blr());return a.finish()

def prime(base,nb):
 a=Asm(base)
 a.emit(lbz(10,0,3),cmpwi(10,nb.ONLINE_INPUTS,crf=7));a.branch('retail',4,30)
 a.emit(lwz(10,1,3),cmpwi(10,1,crf=7));a.branch('retail',4,30)
 a.emit(stwu(1,-0x20,1),mflr(0),stw(0,0x24,1))
 a.constant(12,nb.MAIN_HEAP_END_ADDR-4)
 a.emit(lwz(10,0,12),stw(10,8,1),lwz(10,4,12),stw(10,12,1))
 a.constant(10,nb.FULL_ROLLBACK_HEAP_START);a.emit(stw(10,0,12))
 a.constant(10,nb.FULL_ROLLBACK_HEAP_END);a.emit(stw(10,4,12))
 a.emit(encode_branch(base+len(a.data),nb.SLIPPI_EXI_TRANSFER,link=True))
 a.constant(12,nb.MAIN_HEAP_END_ADDR-4)
 a.emit(lwz(10,8,1),stw(10,0,12),lwz(10,12,1),stw(10,4,12),
        lwz(0,0x24,1),mtlr(0),addi(1,1,0x20),blr())
 a.label('retail');a.emit(encode_branch(base+len(a.data),nb.SLIPPI_EXI_TRANSFER));return a.finish()

def snapshot(base,state,nb):
 """B1 saves SDK state alongside the native slot; B2 restores after host RAM.

 Transport state/diagnostics in SLNP stay live. Only its simulation clock rewinds.
 Native SSCB and its frame tags remain authoritative, including slot reuse.
 """
 a=Asm(base)
 a.emit(stwu(1,-0x20,1),mflr(0),stw(0,0x24,1),stw(3,8,1),stw(4,12,1),stw(5,16,1))
 a.emit(lbz(10,0,3),stw(10,20,1),cmpwi(10,nb.LOAD_SAVESTATE,crf=7));a.branch('select',4,30)
 a.emit(encode_branch(base+len(a.data),nb.SLIPPI_EXI_TRANSFER,link=True),lwz(3,8,1))
 a.label('select');a.emit(lwz(10,1,3))
 # Match native LoadState: search newest-to-oldest, including duplicate tags.
 a.constant(12,nb.STABLE_SSCB);a.emit(lbz(11,0,12),li(9,7),nb._mtctr(9))
 a.label('find');a.emit(addi(11,11,-1),cmpwi(11,0,crf=7));a.branch('index_ok',4,28)
 a.emit(addi(11,11,7))
 a.label('index_ok');a.emit(nb._rlwinm(9,11,2,0,29),nb._add(9,12,9),lwz(9,2,9),cmpw(9,10,crf=7));a.branch('found',12,30)
 a.emit(encode_bc(base+len(a.data),base+a.labels['find'],bo=16,bi=0))
 # Do not copy an unrelated slot if native state is inconsistent.
 a.branch('finish')
 a.label('found');a.emit(nb._rlwinm(11,11,14,0,17))
 a.constant(7,nb.SDK_SNAPSHOT_BASE);a.emit(nb._add(7,7,11))
 a.constant(6,nb.SDK_RUNTIME_BASE);a.emit(nb._or(8,6,6))
 a.emit(lwz(10,20,1),cmpwi(10,nb.LOAD_SAVESTATE,crf=7));a.branch('direction_ready',4,30)
 a.emit(nb._or(6,7,7),nb._or(7,8,8))
 a.label('direction_ready');a.constant(10,state);a.constant(9,nb.SDK_RUNTIME_BASE+nb.SDK_RUNTIME_SIZE)
 a.label('copy');a.emit(cmpw(8,10,crf=7));a.branch('word',4,30)
 a.emit(lwz(11,nb.S_SIM_FRAME,6),stw(11,nb.S_SIM_FRAME,7),
        addi(6,6,nb.STATE_SIZE),addi(7,7,nb.STATE_SIZE),addi(8,8,nb.STATE_SIZE));a.branch('check')
 a.label('word');a.emit(lwz(11,0,6),stw(11,0,7),addi(6,6,4),addi(7,7,4),addi(8,8,4))
 a.label('check');a.emit(cmpw(8,9,crf=7));a.branch('copy',12,28)
 a.label('finish');a.emit(lwz(3,8,1),lwz(4,12,1),lwz(5,16,1),lwz(10,20,1),
                         lwz(0,0x24,1),mtlr(0),addi(1,1,0x20),cmpwi(10,nb.LOAD_SAVESTATE,crf=7))
 a.branch('loaded',12,30);a.emit(encode_branch(base+len(a.data),nb.SLIPPI_EXI_TRANSFER))
 a.label('loaded');a.constant(12,state);a.emit(lwz(11,nb.S_SIM_FRAME,12));a.constant(12,nb.STABLE_ODB);a.emit(stw(11,ODB_SIM_MIRROR,12),blr());return a.finish()
