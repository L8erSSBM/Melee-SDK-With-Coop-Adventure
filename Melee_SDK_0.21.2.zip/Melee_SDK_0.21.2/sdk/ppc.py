from __future__ import annotations

import struct


def _word(value: int) -> bytes:
    return struct.pack('>I', int(value) & 0xFFFFFFFF)


def encode_branch(source: int, target: int, *, link: bool = False, absolute: bool = False) -> bytes:
    """Encode a PowerPC b/bl instruction."""
    source = int(source) & 0xFFFFFFFF
    target = int(target) & 0xFFFFFFFF
    if target & 3:
        raise ValueError('PowerPC branch target must be 4-byte aligned')
    if source & 3:
        raise ValueError('PowerPC branch source must be 4-byte aligned')
    if absolute:
        if target >= 0x02000000:
            raise ValueError('Absolute b/bl target does not fit the 26-bit LI field')
        li = target & 0x03FFFFFC
    else:
        delta = (target - source + (1 << 31)) % (1 << 32) - (1 << 31)
        if delta < -0x02000000 or delta > 0x01FFFFFC:
            raise ValueError('Relative PowerPC branch target is outside +/-32 MiB reach')
        li = delta & 0x03FFFFFC
    return _word(0x48000000 | li | (2 if absolute else 0) | (1 if link else 0))


def encode_bc(source: int, target: int, *, bo: int, bi: int, link: bool = False, absolute: bool = False) -> bytes:
    """Encode a PowerPC bc-form conditional branch.

    This is intended for short branches *inside* SDK stubs. Long returns to
    retail code use :func:`encode_branch` after a local conditional branch.
    """
    source=int(source); target=int(target); bo=int(bo); bi=int(bi)
    if source & 3 or target & 3:
        raise ValueError('PowerPC branch addresses must be 4-byte aligned')
    if not 0 <= bo <= 31 or not 0 <= bi <= 31:
        raise ValueError('BO and BI must be 5-bit values')
    if absolute:
        delta=target
        if delta < 0 or delta > 0x7FFC:
            raise ValueError('Absolute bc target does not fit the BD field')
    else:
        delta=target-source
        if delta < -0x8000 or delta > 0x7FFC:
            raise ValueError('Conditional branch target is outside +/-32 KiB reach')
    return _word((16 << 26) | (bo << 21) | (bi << 16) | (delta & 0xFFFC) |
                 (2 if absolute else 0) | (1 if link else 0))


def decode_branch(source: int, raw: bytes) -> dict:
    if len(raw) != 4:
        raise ValueError('PowerPC branch instruction must be exactly four bytes')
    word = struct.unpack('>I', raw)[0]
    if (word >> 26) != 18:
        raise ValueError('Instruction is not a PowerPC b/bl form')
    aa = bool(word & 2); lk = bool(word & 1)
    li = word & 0x03FFFFFC
    if li & 0x02000000: li -= 0x04000000
    target = (li if aa else int(source) + li) & 0xFFFFFFFF
    return {'source': int(source), 'target': target, 'absolute': aa, 'link': lk, 'word': word}


def addi(rt: int, ra: int, imm: int) -> bytes:
    return _word((14 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) | (imm & 0xFFFF))


def li(rt: int, imm: int) -> bytes:
    return addi(rt, 0, imm)


def lis(rt: int, imm: int) -> bytes:
    return _word((15 << 26) | ((rt & 31) << 21) | (imm & 0xFFFF))


def lbz(rt: int, disp: int, ra: int) -> bytes:
    return _word((34 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) | (disp & 0xFFFF))


def lwz(rt: int, disp: int, ra: int) -> bytes:
    return _word((32 << 26) | ((rt & 31) << 21) | ((ra & 31) << 16) | (disp & 0xFFFF))


def stb(rs: int, disp: int, ra: int) -> bytes:
    return _word((38 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) | (disp & 0xFFFF))


def stw(rs: int, disp: int, ra: int) -> bytes:
    return _word((36 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) | (disp & 0xFFFF))


def stwu(rs: int, disp: int, ra: int) -> bytes:
    return _word((37 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) | (disp & 0xFFFF))


def cmpwi(ra: int, imm: int, *, crf: int = 0) -> bytes:
    if not 0 <= crf <= 7:
        raise ValueError('CR field must be 0..7')
    return _word((11 << 26) | ((crf & 7) << 23) | ((ra & 31) << 16) | (imm & 0xFFFF))


def cmpw(ra: int, rb: int, *, crf: int = 0) -> bytes:
    """Encode cmpw crf,rA,rB (signed 32-bit compare)."""
    if not 0 <= crf <= 7:
        raise ValueError('CR field must be 0..7')
    return _word((31 << 26) | ((crf & 7) << 23) | ((ra & 31) << 16) | ((rb & 31) << 11))


def mflr(rt: int) -> bytes:
    # mfspr rt, LR (SPR 8; SPR halves are reversed in instruction encoding)
    return _word(0x7C0802A6 | ((rt & 31) << 21))


def mtlr(rs: int) -> bytes:
    # mtspr LR, rs
    return _word(0x7C0803A6 | ((rs & 31) << 21))



def andi_dot(ra: int, rs: int, imm: int) -> bytes:
    """Encode andi. rA,rS,UIMM (updates CR0)."""
    return _word((28 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) | (imm & 0xFFFF))


def ori(ra: int, rs: int, imm: int) -> bytes:
    """Encode ori rA,rS,UIMM."""
    return _word((24 << 26) | ((rs & 31) << 21) | ((ra & 31) << 16) | (imm & 0xFFFF))


def blr() -> bytes:
    return _word(0x4E800020)


def nop() -> bytes:
    return b'\x60\x00\x00\x00'
