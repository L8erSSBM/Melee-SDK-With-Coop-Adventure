"""K20S standalone scene adapters, loaded only after Direct reserves its heap.

The seven 16-KiB rollback slots end at 0x817FC000. This immutable 8-KiB
module occupies the gap before the relocated session at 0x817FE000. It is
never a loader-backed DOL section and contains no simulation state.
"""
import struct
from pathlib import Path
from .early_clear_failsafe import Asm
from .ppc import (addi, blr, cmpw, cmpwi, decode_branch, encode_branch,
                  lbz, li, lwz, mflr, mtlr, stb, stw, stwu)
from .standalone_stage_catalog import STAGES
ADVENTURE_STATES=0x803DE1B8

BASE=0x817FC000
LIMIT=0x817FE000
MAGIC=0x53534F4C  # SSOL
ENTRY=BASE+0x20
FILENAME=b'/StSolo.dat\0'
NO_ENEMIES=BASE+0x10
MAZE=0x803E5988
YOSHI=0x803E584C

def word(v): return struct.pack('>I',v&0xFFFFFFFF)
def add(rd,ra,rb): return word((31<<26)|(rd<<21)|(ra<<16)|(rb<<11)|(266<<1))
def mulli(rd,ra,n): return word((7<<26)|(rd<<21)|(ra<<16)|(n&65535))
def mtctr(r): return word(0x7C0903A6|(r<<21))
def call(a,target): a.emit(encode_branch(a.base+len(a.data),target,link=True))
def tail(a,target): a.emit(encode_branch(a.base+len(a.data),target))
def save(a):
    a.emit(stwu(1,-0x40,1),mflr(0),stw(0,0x44,1),stw(29,0x30,1),stw(30,0x34,1),stw(31,0x38,1))
def restore(a):
    a.emit(lwz(29,0x30,1),lwz(30,0x34,1),lwz(31,0x38,1),lwz(0,0x44,1),mtlr(0),addi(1,1,0x40),blr())
def arena_guard(a,marker,retail):
    a.absolute(11,marker,byte=True);a.emit(cmpwi(11,0xAC,crf=7));a.branch('retail',12,28)
def finish_retail(a,retail):
    a.label('retail');tail(a,retail);return a.finish()

def entry(base,marker):
    a=Asm(base);a.absolute(11,marker,byte=True)
    for i,s in enumerate(STAGES):
        a.emit(cmpwi(11,0xA6+i,crf=7));a.branch(f'n{i}',4,30)
        a.emit(li(3,s.entry_state),blr());a.label(f'n{i}')
    a.emit(li(3,0),blr());return a.finish()

OFST_R13_ISWINNER=-0x5037
OFST_R13_CHOSESTAGE=-0x5036
SELECTOR_ROLE_OFFSET=0x05

def exit_scene(base,marker,retail,selector_state=0,*,origin_addr=None,active_addr=None,return_pending_addr=None,canonical_local_addr=None):
    a=Asm(base);a.absolute(10,marker,byte=True)
    for i,s in enumerate(STAGES):
        a.emit(cmpwi(10,0xA6+i,crf=7));a.branch(f'n{i}',4,30)
        a.emit(lbz(11,0,3),cmpwi(11,s.play_state,crf=7));a.branch('retail',4,30)
        a.branch('selected');a.label(f'n{i}')
    a.branch('retail')
    a.label('selected')
    if origin_addr is not None:
        a.absolute(11,origin_addr,byte=True);a.emit(cmpwi(11,8,crf=7));a.branch('retail',4,30)
        # Recreate Slippi Direct's normal post-match stage-picker state. The
        # carrier never runs Slippi's VSSceneDecide, so without this both peers
        # can retain/receive loser status and both are sent to SSS. Preserve the
        # local pre-carrier winner/loser role and reset CHOSESTAGE exactly as
        # Slippi does after a normal Direct match.
    if canonical_local_addr is not None:
        # Challenges have no VS winner. Slippi permits both peers to pick after
        # draws, so restoring a previous role alone cannot guarantee authority.
        # Use the synchronized canonical player slots: P1 picks, P2 waits.
        a.absolute(11,canonical_local_addr,byte=True)
        a.emit(cmpwi(11,1,crf=7));a.branch('retail',12,29)
        a.emit(stb(11,OFST_R13_ISWINNER,13),li(11,0),stb(11,OFST_R13_CHOSESTAGE,13))
    elif selector_state:
        a.absolute(11,selector_state+SELECTOR_ROLE_OFFSET,byte=True)
        a.emit(stb(11,OFST_R13_ISWINNER,13),li(11,0),stb(11,OFST_R13_CHOSESTAGE,13))
    if origin_addr is not None:
        for address,value in ((active_addr,0),(origin_addr,0),(return_pending_addr,1),(marker,0xFF)):
            a.constant(12,address);a.emit(li(11,value),stb(11,0,12))
        a.emit(li(3,8));tail(a,0x801A42F8)
    else:
        tail(a,0x801B4408)
    return finish_retail(a,retail)

def exit_dispatch(base, marker):
    """Called at the actual state-exit dispatch, with native callback in r9."""
    a=Asm(base);a.absolute(10,marker,byte=True)
    for i,s in enumerate(STAGES):
        a.emit(cmpwi(10,0xA6+i,crf=7));a.branch(f'n{i}',4,30)
        a.emit(lbz(11,0,3),cmpwi(11,s.play_state,crf=7));a.branch('retail',4,30)
        tail(a,0x801B4408);a.label(f'n{i}')
    a.label('retail');a.emit(mtctr(9),word(0x4E800420));return a.finish()

def exit_gate(base, marker, active, target):
    # Replaces mtlr r12 at the common state-exit call, before blrl sets LR.
    # Keep the runtime-resolved callback, including other installed wrappers.
    a=Asm(base);a.emit(addi(9,12,0))
    for address,value in ((0x80479D30,4),(active,1)):
        a.absolute(11,address,byte=True);a.emit(cmpwi(11,value,crf=7));a.branch('retail',4,30)
    a.absolute(11,marker,byte=True)
    a.emit(cmpwi(11,0xA6,crf=7));a.branch('retail',12,28)
    a.emit(cmpwi(11,0xB2,crf=7));a.branch('retail',12,29)
    a.absolute(11,BASE);a.constant(12,MAGIC);a.emit(cmpw(11,12,crf=7));a.branch('retail',4,30)
    a.constant(12,target);a.branch('invoke')
    a.label('retail');a.emit(addi(12,9,0))
    a.label('invoke');a.emit(mtlr(12));tail(a,0x801A4140);return a.finish()

def prepare(base,marker,retail):
    a=Asm(base);a.absolute(11,marker,byte=True)
    a.emit(cmpwi(11,0xAB,crf=7));a.branch('retail',12,28)
    save(a);a.emit(addi(29,11,0));call(a,0x801A427C);a.emit(addi(30,3,0))
    call(a,0x8017E424);a.emit(addi(31,3,0),li(11,0),stb(11,8,31),stb(11,9,31),stb(11,10,31),li(11,4),stb(11,11,31))
    a.emit(cmpwi(29,0xAB,crf=7));a.branch('versus_stage',4,30)
    a.emit(li(11,0x80),stb(11,8,31),li(11,2),stb(11,9,31),li(9,180),li(10,0x52));a.branch('setup')
    a.label('versus_stage');a.emit(li(9,480),li(10,0x3F),cmpwi(29,0xB2,crf=7));a.branch('setup',4,30)
    a.emit(li(10,0x3B))
    a.label('setup');a.emit(addi(3,30,0),addi(4,31,0));a.constant(5,NO_ENEMIES)
    a.emit(li(6,0),li(7,1),li(8,0),li(11,0),stw(11,8,1),stw(11,12,1))
    call(a,0x8017CE34)
    # The Adventure item-frequency callback is not Classic's bonus callback.
    # Race and the versus variants both require no random item spawns.
    a.emit(li(11,-1),stb(11,0xB,30),li(11,0),stw(11,0x20,30),stw(11,0x24,30))
    a.emit(cmpwi(29,0xAB,crf=7));a.branch('rumble',12,30)
    # Stock, timer, normal VS victory; no objective or event-manager callback.
    for off,val in ((0,0x22),(1,0),(2,0x80),(3,0),(4,0xC0),(5,0),
                    (8,0),(9,0),(0xB,0xFF),(0x61,0),(0x85,0),(0x62,4),(0x86,4),
                    (0x65,0),(0x89,1),(0x66,1),(0x8A,0xFF),(0x69,0),(0x8D,1)):
        a.emit(li(11,val),stb(11,off,30))
    a.emit(li(11,0))
    for off in (0x20,0x24,0x38,0x3C,0x40,0x44,0x48,0x4C,0x50,0x54):a.emit(stw(11,off,30))
    for slot in range(2,6):a.emit(li(11,3),stb(11,0x60+slot*0x24+1,30))
    a.label('rumble');a.emit(addi(3,30,0));call(a,0x8016F088);restore(a)
    # Race to the Finish deliberately borrows Adventure state 0x12 only as a
    # scene shell. Calling that state's retail enter callback here overwrites
    # the 0x52 / bonus-subtype-2 setup above with Hyrule/Zelda. For marker AB,
    # our complete StartMeleeData is the enter callback, so return directly.
    a.absolute(11,marker,byte=True);a.emit(cmpwi(11,0xAB,crf=7));a.branch('retail',4,30)
    a.emit(blr())
    return finish_retail(a,retail)

def no_arena(base,marker,retail):
    a=Asm(base);arena_guard(a,marker,retail);a.emit(blr());return finish_retail(a,retail)

def stock(base,marker,retail,vs_target):
    a=Asm(base);arena_guard(a,marker,retail);tail(a,vs_target);return finish_retail(a,retail)

def retail_prologue(base,marker,retail,site):
    a=Asm(base);arena_guard(a,marker,retail);a.emit(mflr(0));tail(a,site+4)
    return finish_retail(a,retail)

def controller_init(base,marker,retail,yoshi=False):
    a=Asm(base);arena_guard(a,marker,retail);save(a)
    a.emit(addi(30,3,0),lwz(31,0x2C,3))
    if yoshi:
        a.emit(lwz(3,0x28,30),lwz(4,0x14,31));call(a,0x801C2ED0)
    else:call(a,0x80058560)
    a.emit(addi(3,30,0),lwz(4,0x14,31),li(5,0));call(a,0x801C8138)
    a.emit(li(11,0),stw(11,8,31),stw(11,12,31))
    # Do not register the native deferred fighter/event callback.
    restore(a);return finish_retail(a,retail)

def hide(a,gobj,node):
    a.emit(addi(3,gobj,0),li(4,node));call(a,0x801C3FA4)
    a.emit(cmpwi(3,0,crf=7));name=f'hide_{len(a.data)}';a.branch(name,12,30)
    a.emit(li(4,0x10));call(a,0x80371D9C);a.label(name)

def stage_init(base,marker,retail,yoshi=False):
    a=Asm(base);arena_guard(a,marker,retail);save(a);call(a,retail)
    a.emit(li(3,3 if yoshi else 4));call(a,0x801C2BA4);a.emit(addi(30,3,0))
    if yoshi:
        # The native multi-Yoshi arena retains collision section 58. The route
        # bridges and all other sections are excluded from this VS variant.
        for i in range(61):
            if i!=58:a.emit(li(3,i));call(a,0x80057BC0)
        a.emit(addi(3,30,0),li(4,0));call(a,0x8020836C)
    else:
        a.absolute(29,marker,byte=True);a.emit(addi(29,29,-0xAC))
        for i in range(14):
            if i>=8:
                a.emit(cmpwi(29,i-8,crf=7));a.branch(f'keep{i}',12,30)
            a.emit(li(3,i));call(a,0x80057BC0)
            if i>=8:
                hide(a,30,(0x13,0x14,0x12,0x11,0x10,0x0F)[i-8]);a.label(f'keep{i}')
        hide(a,30,1)
        a.emit(li(3,2));call(a,0x801C2BA4);a.emit(addi(30,3,0));hide(a,30,0)
    a.emit(li(3,0));call(a,0x80030AE0)
    restore(a);return finish_retail(a,retail)

def filename_adapter(base,marker,retail,arg_reg,maze_ptr,yoshi_ptr,alias_addrs):
    a=Asm(base);arena_guard(a,marker,retail)
    a.emit(cmpwi(11,0xB2,crf=7));a.branch('yoshi',12,30)
    a.constant(12,maze_ptr);a.emit(cmpw(arg_reg,12,crf=7));a.branch('retail',4,30)
    for i,addr in enumerate(alias_addrs[:6]):
        a.emit(cmpwi(11,0xAC+i,crf=7));a.branch(f'n{i}',4,30)
        a.constant(arg_reg,addr);tail(a,retail);a.label(f'n{i}')
    a.branch('retail');a.label('yoshi');a.constant(12,yoshi_ptr)
    a.emit(cmpw(arg_reg,12,crf=7));a.branch('retail',4,30)
    a.constant(arg_reg,alias_addrs[6]);return finish_retail(a,retail)

def install(dol,index,*,marker_addr,active_addr,onload_addr,onload_blob,output_dir,selector_state_addr=0,origin_addr=None,return_pending_addr=None,canonical_local_addr=None):
    section=next(s for s in dol.sections if s.kind=='data' and s.index==index)
    low=(section.end_address+31)&~31
    high=bytearray(0x20);high[:4]=word(MAGIC);high[0x10:0x13]=b'\x21'*3
    def emit_high(blob):
        pos=BASE+len(high);high.extend(blob);high.extend(bytes((-len(high))%4));return pos
    emit_high(entry(ENTRY,marker_addr))
    aliases=[]
    for name in [f'/GrSL{i+1}.dat' for i in range(6)]+['/GrSYs.dat']:
        aliases.append(emit_high(name.encode()+b'\0'))
    routes=[];patches=[]
    def route(retail,builder):
        target=emit_high(builder(BASE+len(high),retail));routes.append((retail,target));return len(routes)-1
    def ptr_hook(address,builder):
        original=int.from_bytes(dol.read_at_address(address,4),'big')
        patches.append((address,route(original,builder),False,dol.read_at_address(address,4)))
    # Group identical scene callbacks to save permanent low code.
    groups={}
    for off in range(0,0x498,24):
        addr=ADVENTURE_STATES+off;sid=dol.read_at_address(addr,1)[0]
        if sid in {s.play_state for s in STAGES}:
            fields=[]
            if sid in (1,0x11,0x12):
                fields.append((4,prepare))
            # Patch only the standalone states' own on_exit table entries.
            # Full Co-op Adventure marker A5 never passes the low dispatcher
            # scope gate, and the common gm_801A413C state-exit instruction is
            # left completely retail.
            fields.append((8,exit_scene))
            for field,builder in fields:
                original=int.from_bytes(dol.read_at_address(addr+field,4),'big');key=(original,builder)
                if key not in groups:
                    if builder is exit_scene:
                        groups[key]=route(original,lambda b,r:exit_scene(b,marker_addr,r,selector_state_addr,
                            origin_addr=origin_addr,active_addr=active_addr,return_pending_addr=return_pending_addr,
                            canonical_local_addr=canonical_local_addr))
                    else:
                        groups[key]=route(original,lambda b,r,fn=builder:fn(b,marker_addr,r))
                patches.append((addr+field,groups[key],False,word(original)))
    for data,yoshi in ((MAZE,False),(YOSHI,True)):
        callbacks=int.from_bytes(dol.read_at_address(data+4,4),'big');ci=3 if yoshi else 4
        ptr_hook(data+12,lambda b,r,y=yoshi:stage_init(b,marker_addr,r,y))
        ptr_hook(data+24,lambda b,r:no_arena(b,marker_addr,r))
        if yoshi:ptr_hook(data+20,lambda b,r:no_arena(b,marker_addr,r))
        ptr_hook(callbacks+ci*20,lambda b,r,y=yoshi:controller_init(b,marker_addr,r,y))
        ptr_hook(callbacks+ci*20+8,lambda b,r:no_arena(b,marker_addr,r))
        if yoshi:ptr_hook(callbacks+8,lambda b,r:no_arena(b,marker_addr,r))
    # Substitute archive names at both preload and actual map-load call sites.
    maze_ptr=int.from_bytes(dol.read_at_address(MAZE+8,4),'big')
    yoshi_ptr=int.from_bytes(dol.read_at_address(YOSHI+8,4),'big')
    for start,end,target,reg in ((0x801C06B8,0x801C0754,0x800178E8,4),(0x801C0754,0x801C0800,0x801C6038,3)):
        sites=[addr for addr in range(start,end,4) if dol.read_at_address(addr,4)==encode_branch(addr,target,link=True)]
        if len(sites)!=1:raise ValueError('Stage archive call site mismatch')
        rid=route(target,lambda b,r:filename_adapter(b,marker_addr,r,reg,maze_ptr,yoshi_ptr,aliases))
        patches.append((sites[0],rid,True,dol.read_at_address(sites[0],4)))
    for addr,expected in ((0x8016BFA0,'4bec7cad'),(0x8016C0F4,'4bec7b59'),
                          (0x80167248,'4becbb39'),(0x8002B23C,'48008ed5')):
        current=dol.read_at_address(addr,4);retail=decode_branch(addr,current)['target'];vs=decode_branch(addr,bytes.fromhex(expected))['target']
        rid=route(retail,lambda b,r:stock(b,marker_addr,r,vs));patches.append((addr,rid,True,current))
    for addr in (0x8016719C,0x801C57A4):
        current=dol.read_at_address(addr,4);retail=decode_branch(addr,current)['target']
        rid=route(retail,lambda b,r:retail_prologue(b,marker_addr,r,addr))
        patches.append((addr,rid,'jump',current))
    if len(high)>LIMIT-BASE:raise ValueError(f'Standalone module exceeds gap: {len(high)}')
    high.extend(bytes((LIMIT-BASE)-len(high)))
    Path(output_dir).mkdir(parents=True,exist_ok=True)
    Path(output_dir,'StSolo.dat').write_bytes(high)
    # Permanent low dispatcher has no dependency on high code outside scoped
    # standalone Adventure. Table rows contain exact original callback targets.
    table=low;stub_base=table+8*len(routes);dispatch=stub_base+8*len(routes)
    a=Asm(dispatch);a.constant(12,table);a.emit(add(12,12,10),lwz(10,0,12),lwz(11,4,12),mtctr(10))
    # Save selected high address in r10; only volatile registers are changed.
    a.emit(addi(10,11,0));a.absolute(11,0x80479D30,byte=True)
    a.emit(cmpwi(11,4,crf=7));a.branch('retail',4,30)
    a.absolute(11,active_addr,byte=True);a.emit(cmpwi(11,1,crf=7));a.branch('retail',4,30)
    a.absolute(11,marker_addr,byte=True);a.emit(cmpwi(11,0xA6,crf=7));a.branch('retail',12,28)
    a.emit(cmpwi(11,0xB2,crf=7));a.branch('retail',12,29)
    a.absolute(11,BASE);a.constant(12,MAGIC);a.emit(cmpw(11,12,crf=7));a.branch('retail',4,30)
    a.emit(mtctr(10));a.label('retail');a.emit(word(0x4E800420));dispatcher=a.finish()
    loader_addr=dispatch+len(dispatcher)
    # File name follows the fixed-size loader (computed in two passes).
    def loader(filename):
        a=Asm(loader_addr);a.absolute(11,marker_addr,byte=True)
        a.emit(li(3,0),cmpwi(11,0xA6,crf=7));a.branch('done',12,28)
        a.emit(cmpwi(11,0xB2,crf=7));a.branch('done',12,29)
        save(a);a.constant(3,filename);call(a,0x800163D8)
        a.emit(cmpwi(3,LIMIT-BASE,crf=7));a.branch('failed',4,30)
        a.constant(3,filename);a.constant(4,BASE);a.emit(addi(5,1,0x20));call(a,0x8001668C)
        a.absolute(11,BASE);a.constant(12,MAGIC);a.emit(cmpw(11,12,crf=7));a.branch('failed',4,30)
        a.constant(3,BASE);a.constant(4,LIMIT-BASE);call(a,0x8034480C)
        a.constant(3,BASE);a.constant(4,LIMIT-BASE);call(a,0x803448D4)
        call(a,ENTRY);restore(a)
        a.label('failed');a.constant(12,marker_addr);a.emit(li(11,0xA5),stb(11,0,12),li(3,0));restore(a)
        a.label('done');a.emit(blr());return a.finish()
    dummy=loader(0);code=loader(loader_addr+len(dummy));assert len(code)==len(dummy)
    payload=bytearray().join(word(r)+word(t) for r,t in routes)
    for i in range(len(routes)):
        addr=stub_base+i*8;payload+=li(10,i*8)+encode_branch(addr+4,dispatch)
    payload+=dispatcher+code+FILENAME;payload+=bytes((-len(payload))%32)
    added=dol.append_to_data_section(index,payload)
    assert added['address']==low
    # 0.21.1: never interpose the global common state-exit call. The former
    # 0x801A413C hook ran during every full Co-op Adventure score/cutscene
    # transition even for marker A5. Standalone exits are now table-local only.
    if dol.read_at_address(0x801A413C,4) != mtlr(12):
        raise ValueError('Standalone install requires retail common state-exit instruction at 0x801A413C')
    for addr,rid,linked,expected in patches:
        stub=stub_base+rid*8
        replacement=(encode_branch(addr,stub,link=linked is True) if linked else word(stub))
        dol.patch_at_address(addr,replacement,expected=expected)
    # Locate the final li r3,0 by its exact following retail state setter.
    from .adventure_probe import GM_SET_GAME_MODE_STATE_ID
    candidates=[i for i in range(0,len(onload_blob)-4,4) if onload_blob[i:i+4]==li(3,0) and onload_blob[i+4:i+8]==encode_branch(onload_addr+i+4,GM_SET_GAME_MODE_STATE_ID,link=True)]
    if len(candidates)!=1:raise ValueError('Gateway entry-state call signature mismatch')
    addr=onload_addr+candidates[0];dol.patch_at_address(addr,encode_branch(addr,loader_addr,link=True),expected=li(3,0))
    return {'module':'StSolo.dat','module_base':BASE,'module_limit':LIMIT,'low_section':added,
            'exit_strategy':'state_table_on_exit_only','global_exit_hook':None,
            'retail_common_exit_instruction':'0x801A413C mtlr r12 preserved',
            'selector_state_address':selector_state_addr,
            'entry':ENTRY,'loader':loader_addr,'dispatcher':dispatch,'routes':routes,
            'patches':[{'address':a,'stub':stub_base+i*8,'linked':l} for a,i,l,_ in patches],
            'stage_count':len(STAGES),'live_gameplay_validated':False}
