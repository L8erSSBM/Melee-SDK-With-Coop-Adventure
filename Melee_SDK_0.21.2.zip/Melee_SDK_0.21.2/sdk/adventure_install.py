from __future__ import annotations

import hashlib
import json
from pathlib import Path

from .adventure_runtime import RUNTIME_TOUCHPOINTS
from .dol_patch import DOLImage, SymbolMap
from .gamecube_iso import GALE01_102_DOL_SHA1
from .runtime_hook import HookSite, RuntimeHookInstaller


def coop_hook_sites(dol: DOLImage, symbols: SymbolMap) -> list[HookSite]:
    """Resolve the six source-grounded Adventure touchpoints to guarded hook sites."""
    out=[]
    for tp in RUNTIME_TOUCHPOINTS:
        sym=symbols.require(tp.symbol)
        out.append(HookSite(tp.symbol, sym.address, dol.read_at_address(sym.address,4)))
    return out


def install_phase29_runtime_framework(dol_path: str | Path, symbols_path: str | Path,
                                      output_path: str | Path, *, flags: int = 0,
                                      require_clean: bool = True) -> dict:
    src=Path(dol_path)
    raw=src.read_bytes()
    source_sha1=hashlib.sha1(raw).hexdigest()
    if require_clean and source_sha1.lower()!=GALE01_102_DOL_SHA1.lower():
        raise ValueError(f'Expected clean GALE01 1.02 main.dol SHA-1 {GALE01_102_DOL_SHA1}, got {source_sha1}')
    dol=DOLImage(raw)
    symbols=SymbolMap.from_file(symbols_path)
    sites=coop_hook_sites(dol,symbols)
    manifest=RuntimeHookInstaller(dol).install_transparent_hooks(sites,flags=flags)
    out=Path(output_path)
    dol.save_as(out)
    manifest.update({
        'target':'GALE01 1.02',
        'source_sha1':source_sha1,
        'source_was_canonical_clean': source_sha1.lower()==GALE01_102_DOL_SHA1.lower(),
        'output_path':str(out),
        'output_size':out.stat().st_size,
        'scope':'Phase 29 executable transport only; co-op behavior payload not yet enabled',
    })
    return manifest


def write_install_manifest(path: str | Path, manifest: dict) -> Path:
    p=Path(path)
    p.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return p
