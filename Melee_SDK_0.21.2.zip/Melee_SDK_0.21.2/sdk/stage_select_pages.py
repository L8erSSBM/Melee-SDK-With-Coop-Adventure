from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any

from .dol_patch import DOLImage, SymbolMap
from .gamecube_iso import GALE01_102_DOL_SHA1
from .menu_archives import MenuArchiveInspector

FORMAT = 'melee-sdk-stage-pages-v2'
LEGACY_FORMAT = 'melee-sdk-stage-pages-v1'
MAX_VISIBLE_SLOTS = 29
RANDOM_SLOT = 29
VIRTUAL_STAGE_STKIND = 0x15  # dormant Akaneia identity used by the SDK custom-stage bridge
PAD_DPAD_UP = 0x0008
PAD_DPAD_DOWN = 0x0004

# Source-backed retail SSS slot facts from mnstagesel.static.h.  The five final
# stage buttons are special: mnstagesel.c creates them from the x20 StaticModelDesc
# rather than the x40 model used by the first 24 stage buttons.  This makes the
# bottom row an ideal conservative landing area for a small custom page.
RETAIL_SLOT_SKINS: dict[int, dict[str, Any]] = {
    24: {'name': 'Battlefield', 'stkind': 0x1F, 'anim_index': 0x18, 'model_group': 'x20'},
    25: {'name': 'Final Destination', 'stkind': 0x20, 'anim_index': 0x19, 'model_group': 'x20'},
    26: {'name': 'Dream Land', 'stkind': 0x1C, 'anim_index': 0x1A, 'model_group': 'x20'},
    27: {'name': "Yoshi's Island (N64)", 'stkind': 0x1D, 'anim_index': 0x1B, 'model_group': 'x20'},
    28: {'name': 'Kongo Jungle (N64)', 'stkind': 0x1E, 'anim_index': 0x1C, 'model_group': 'x20'},
}

# The requested sparse first page: custom stages first appear in the three
# familiar bottom-row locations Battlefield / Dream Land / Final Destination.
# Co-op launchers occupy the remaining two bottom-row buttons.  Only when the
# page outgrows those five tiles do we populate the regular grid above.
PRIMARY_STAGE_SLOTS = (24, 26, 25)
MODE_SLOTS = (27, 28)
OVERFLOW_STAGE_SLOTS = tuple(range(24))
FIRST_CUSTOM_STAGE_SLOTS = PRIMARY_STAGE_SLOTS + OVERFLOW_STAGE_SLOTS
LATER_PAGE_SLOT_ORDER = PRIMARY_STAGE_SLOTS + MODE_SLOTS + OVERFLOW_STAGE_SLOTS


@dataclass
class StagePageEntry:
    entry_id: str
    title: str
    kind: str  # stage | mode
    stage_filename: str | None = None
    stkind: int | None = None
    mode_id: str | None = None
    preview_slot: int = 0  # retail visual/animation skin slot
    enabled: bool = True
    notes: str = ''
    grid_slot: int | None = None  # physical retail SSS button slot on this page
    thumbnail_path: str | None = None
    subtitle: str = ''
    launch_action: str | None = None

    def validate(self) -> None:
        if self.kind not in ('stage', 'mode'):
            raise ValueError(f'{self.entry_id}: kind must be stage or mode')
        if not 0 <= int(self.preview_slot) < MAX_VISIBLE_SLOTS:
            raise ValueError(f'{self.entry_id}: preview_slot must be 0..28')
        if self.grid_slot is not None and not 0 <= int(self.grid_slot) < MAX_VISIBLE_SLOTS:
            raise ValueError(f'{self.entry_id}: grid_slot must be 0..28')
        if self.kind == 'stage' and not self.stage_filename:
            raise ValueError(f'{self.entry_id}: stage entry requires stage_filename')
        if self.kind == 'mode' and not self.mode_id:
            raise ValueError(f'{self.entry_id}: mode entry requires mode_id')
        if self.stkind is not None and not 0 <= int(self.stkind) <= 0xFF:
            raise ValueError(f'{self.entry_id}: invalid StKind')

    @property
    def effective_grid_slot(self) -> int:
        return int(self.preview_slot if self.grid_slot is None else self.grid_slot)


@dataclass
class StagePage:
    page_id: str
    title: str
    entries: list[StagePageEntry] = field(default_factory=list)
    builtin_retail: bool = False
    random_enabled: bool = True
    layout: str = 'retail-grid'

    def validate(self) -> None:
        if len(self.entries) > MAX_VISIBLE_SLOTS:
            raise ValueError(f'{self.page_id}: {len(self.entries)} entries exceeds the 29 visible SSS slots')
        ids=set(); slots=set()
        for e in self.entries:
            e.validate()
            if e.entry_id in ids:
                raise ValueError(f'{self.page_id}: duplicate entry id {e.entry_id}')
            ids.add(e.entry_id)
            if e.grid_slot is not None:
                slot=int(e.grid_slot)
                if slot in slots:
                    raise ValueError(f'{self.page_id}: duplicate physical grid slot {slot}')
                slots.add(slot)


@dataclass
class StagePageSet:
    pages: list[StagePage]
    wrap_pages: bool = True
    page_up_mask: int = PAD_DPAD_UP
    page_down_mask: int = PAD_DPAD_DOWN
    page_indicator: bool = True
    transition_style: str = 'retail-icon-pulse'

    def force_navigation_contract(self) -> 'StagePageSet':
        """Force the SDK-wide paging controls.

        Custom stage metadata is never allowed to remap the reserved SSS page
        controls. D-Pad Down always advances and D-Pad Up always returns.
        """
        self.page_up_mask = PAD_DPAD_UP
        self.page_down_mask = PAD_DPAD_DOWN
        return self

    def validate(self) -> None:
        self.force_navigation_contract()
        if not self.pages:
            raise ValueError('At least one SSS page is required')
        ids=set()
        for p in self.pages:
            p.validate()
            if p.page_id in ids:
                raise ValueError(f'Duplicate page id {p.page_id}')
            ids.add(p.page_id)
        if self.transition_style not in ('instant', 'retail-icon-pulse', 'fade-swap'):
            raise ValueError('Unsupported page transition style')

    def to_dict(self) -> dict[str, Any]:
        self.validate()
        return {
            'format': FORMAT,
            'wrap_pages': self.wrap_pages,
            'page_up_mask': self.page_up_mask,
            'page_down_mask': self.page_down_mask,
            'page_indicator': self.page_indicator,
            'transition_style': self.transition_style,
            'navigation_contract': {
                'policy': 'sdk-forced',
                'up': 'D-Pad Up / previous page',
                'down': 'D-Pad Down / next page',
            },
            'pages': [asdict(p) for p in self.pages],
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> 'StagePageSet':
        fmt=data.get('format')
        if fmt not in (FORMAT, LEGACY_FORMAT):
            raise ValueError(f'Unsupported stage page format: {fmt!r}')
        pages=[]
        for p in data.get('pages', []):
            entries=[]
            for idx,e in enumerate(p.get('entries', [])):
                d=dict(e)
                # Phase 25 files did not distinguish visual skin from physical slot.
                if fmt == LEGACY_FORMAT and 'grid_slot' not in d:
                    d['grid_slot']=int(d.get('preview_slot', idx))
                entries.append(StagePageEntry(**d))
            pages.append(StagePage(page_id=p['page_id'], title=p['title'], entries=entries,
                                   builtin_retail=bool(p.get('builtin_retail', False)),
                                   random_enabled=bool(p.get('random_enabled', True)),
                                   layout=str(p.get('layout','retail-grid'))))
        # Navigation masks are an SDK ABI, not importable content. Ignore any
        # stale/custom values from stage packs or older project JSON.
        obj=cls(pages, bool(data.get('wrap_pages', True)), PAD_DPAD_UP,
                PAD_DPAD_DOWN, bool(data.get('page_indicator', True)),
                str(data.get('transition_style','retail-icon-pulse')))
        obj.validate(); return obj

    def save(self, path: str | Path) -> Path:
        p=Path(path); p.write_text(json.dumps(self.to_dict(), indent=2), encoding='utf-8'); return p


def _resource_meta(project, filename: str) -> dict[str, Any]:
    for r in project.manifest.get('resources', []):
        if str(r.get('filename','')).lower() == filename.lower():
            return r
    return {}


def _stage_entry(project, st, slot: int, active_runtime_file: str) -> StagePageEntry:
    meta=_resource_meta(project, st.filename)
    direct = VIRTUAL_STAGE_STKIND if active_runtime_file.lower() == st.filename.lower() else None
    skin=RETAIL_SLOT_SKINS.get(slot)
    skin_note=(f"Reuses {skin['name']} bottom-row MnSlMap model/animation skin" if skin else
               'Reuses the retail regular-stage MnSlMap icon button at this physical slot')
    return StagePageEntry(
        entry_id='stage:'+st.filename.lower(), title=st.display_name or Path(st.filename).stem,
        kind='stage', stage_filename=st.filename, stkind=direct,
        preview_slot=slot, grid_slot=slot,
        subtitle=st.filename,
        launch_action='launch_virtual_stage',
        notes=(('Direct hidden-slot mapping; ' if direct is not None else 'Uses dynamic custom-stage filename bridge; ')+skin_note),
    )


def build_project_page_set(project, *, include_coop_modes: bool = True) -> StagePageSet:
    """Build a scalable SSS hub with a sparse, polished first custom page.

    Page 0 remains the original retail grid.  Page 1 intentionally starts in
    the bottom row: custom stages use the Battlefield, Dream Land, and Final
    Destination positions; Co-op Adventure / Duo use the final two buttons.
    Additional custom stages fill the regular grid only as the collection grows.
    """
    custom=[]
    runtime_stage=(project.manifest.get('runtime_authoring', {}) or {}).get('stage_slot', {}) or {}
    active_runtime_file=str(runtime_stage.get('filename',''))
    for st in project.stages:
        meta=_resource_meta(project, st.filename)
        src=str(meta.get('source_relative',''))
        is_custom=bool(meta.get('authored_new')) or src.startswith('<authored') or src.startswith('<imported stage package')
        if is_custom:
            custom.append(st)

    pages=[StagePage('retail','Retail Stages',[],builtin_retail=True,random_enabled=True,layout='retail-grid')]
    launchers=[]
    if include_coop_modes:
        launchers=[
            StagePageEntry('mode:coop-adventure','Co-op Adventure','mode',mode_id='coop_adventure',
                           preview_slot=MODE_SLOTS[0],grid_slot=MODE_SLOTS[0],subtitle='2P continuous 1P Adventure',
                           launch_action='launch_coop_adventure',
                           notes=f"Direct launcher; reuses {RETAIL_SLOT_SKINS[MODE_SLOTS[0]]['name']} bottom-row MnSlMap button geometry/animation."),
            StagePageEntry('mode:duo-challenges','Duo Challenges','mode',mode_id='duo_challenges',
                           preview_slot=MODE_SLOTS[1],grid_slot=MODE_SLOTS[1],subtitle='2P Event / custom challenges',
                           launch_action='launch_duo_challenges',
                           notes=f"Direct launcher; reuses {RETAIL_SLOT_SKINS[MODE_SLOTS[1]]['name']} bottom-row MnSlMap button geometry/animation."),
        ]

    first_capacity=len(FIRST_CUSTOM_STAGE_SLOTS)
    first_stages=custom[:first_capacity]
    first_entries=[_stage_entry(project, st, FIRST_CUSTOM_STAGE_SLOTS[i], active_runtime_file) for i,st in enumerate(first_stages)]
    first_entries += launchers
    # Sort by physical slot for deterministic rendering/runtime mapping.
    first_entries.sort(key=lambda e:e.effective_grid_slot)
    pages.append(StagePage('custom-1','Custom + Co-op',first_entries,builtin_retail=False,random_enabled=True,layout='bottom-row-first'))

    remaining=custom[first_capacity:]
    page_no=2
    while remaining:
        chunk=remaining[:MAX_VISIBLE_SLOTS]; remaining=remaining[MAX_VISIBLE_SLOTS:]
        entries=[_stage_entry(project, st, LATER_PAGE_SLOT_ORDER[i], active_runtime_file) for i,st in enumerate(chunk)]
        entries.sort(key=lambda e:e.effective_grid_slot)
        pages.append(StagePage(f'custom-{page_no}',f'Custom Stages {page_no}',entries,builtin_retail=False,random_enabled=True,layout='bottom-row-first'))
        page_no += 1
    result=StagePageSet(pages,page_indicator=True,transition_style='retail-icon-pulse'); result.validate(); return result


def save_project_page_set(project, page_set: StagePageSet) -> None:
    page_set.validate()
    project.manifest['stage_select_pages']=page_set.to_dict()
    project.manifest_path.write_text(json.dumps(project.manifest, indent=2), encoding='utf-8')


def load_project_page_set(project) -> StagePageSet:
    raw=project.manifest.get('stage_select_pages')
    return StagePageSet.from_dict(raw) if raw else build_project_page_set(project)




def enforce_project_page_navigation(project, *, rebuild: bool = False) -> StagePageSet:
    """Reassert the reserved Up/Down SSS contract in a project manifest.

    ``rebuild=True`` is used after creating/importing a new stage so the new
    entry is added to the canonical page set. Normal builds use ``False`` to
    preserve hand-authored page layouts while still overriding any attempted
    controller remap.
    """
    raw = project.manifest.get('stage_select_pages')
    if rebuild or not raw:
        page_set = build_project_page_set(project)
    else:
        try:
            page_set = StagePageSet.from_dict(raw)
        except Exception:
            page_set = build_project_page_set(project)
    page_set.force_navigation_contract()
    save_project_page_set(project, page_set)
    return page_set


def inspect_sss_menu(path: str | Path) -> dict[str, Any]:
    insp=MenuArchiveInspector(path)
    report=insp.report('MnSelectStageDataTable')
    models=insp.model_table_report()
    if not report.public_found:
        raise ValueError('MnSelectStageDataTable public root not found')
    if models.get('kind') != 'sss' or models.get('model_count') != 12:
        raise ValueError('Unexpected MnSlMap source layout')
    return {
        'filename': report.filename,
        'file_size': report.file_size,
        'relocation_count': report.relocation_count,
        'root_offset': report.public_offset,
        'model_count': models['model_count'],
        'visible_stage_slots': MAX_VISIBLE_SLOTS,
        'random_slot': RANDOM_SLOT,
        'regular_icon_model_group':'x40',
        'bottom_row_icon_model_group':'x20',
        'random_model_group':'x10',
        'icon_root_model_group':'x90',
        'menu_model_group':'xA0',
        'background_model_group':'x50',
        'strategy': 'reuse-retail-grid-bottom-row-first',
        'note': ('mnstagesel.c builds stage slots 0..23 from x40, the final five stage slots 24..28 from x20, '
                 'and Random from x10. Phase 26 intentionally puts the first custom/co-op tiles in x20-backed bottom-row slots.'),
    }


def visual_manifest(page_set: StagePageSet) -> dict[str, Any]:
    """Describe visual reuse without pretending MnSlMap has been structurally expanded."""
    page_set.validate()
    pages=[]
    for pi,p in enumerate(page_set.pages):
        rows=[]
        if p.builtin_retail:
            pages.append({'page':pi,'page_id':p.page_id,'title':p.title,'builtin_retail':True,'tiles':'retail-unchanged'})
            continue
        for idx,e in enumerate(p.entries):
            slot=int(e.grid_slot) if e.grid_slot is not None else idx
            skin=RETAIL_SLOT_SKINS.get(e.preview_slot)
            rows.append({
                'grid_slot':slot,
                'entry_id':e.entry_id,
                'title':e.title,
                'subtitle':e.subtitle,
                'kind':e.kind,
                'thumbnail_path':e.thumbnail_path,
                'visual_source': ('custom-thumbnail' if e.thumbnail_path else 'retail-slot-skin'),
                'retail_skin_slot':e.preview_slot,
                'retail_skin_name':skin['name'] if skin else f'Retail slot {e.preview_slot}',
                'model_group':skin['model_group'] if skin else 'x40',
                'animation_index':skin['anim_index'] if skin else None,
            })
        pages.append({'page':pi,'page_id':p.page_id,'title':p.title,'builtin_retail':False,'layout':p.layout,'tiles':rows})
    return {
        'format':'melee-sdk-sss-visual-manifest-v1',
        'page_indicator':{'enabled':page_set.page_indicator,'format':'{current}/{total}','placement':'upper-right safe overlay'},
        'transition':transition_plan(page_set.transition_style),
        'pages':pages,
    }


def transition_plan(style: str='retail-icon-pulse') -> dict[str, Any]:
    if style=='instant':
        return {'style':'instant','total_frames':0,'steps':['swap descriptors immediately']}
    if style=='fade-swap':
        return {'style':'fade-swap','total_frames':12,'swap_frame':6,
                'steps':['frames 0-5 fade current tile set','frame 6 remap stage/mode descriptors and labels','frames 7-12 fade new tile set']}
    return {'style':'retail-icon-pulse','total_frames':14,'swap_frame':7,
            'steps':['frames 0-6 request existing icon deselect/pulse animation','frame 7 hide/remap inactive slots and swap labels/thumbnails','frames 8-14 request existing icon reveal/select animation'],
            'asset_policy':'reuse MnSlMap JObjs/AnimJoint/MatAnimJoint; no new icon hierarchy required'}


def mode_dispatch_contract() -> dict[str, Any]:
    return {
        'coop_adventure':{
            'type':'mode','label':'Co-op Adventure','launch_action':'launch_coop_adventure',
            'entry_scene':'retail Adventure CSS / Adventure scene chain',
            'activation':'set SDK co-op Adventure runtime flag before entering retail Adventure',
            'campaign':'retail 12-chapter Adventure sequence',
            'runtime_touchpoints':['gm_801B42E8','gm_801B4350','gm_801B4064','gm_8017CE34','gm_8017D7AC','gm_8017E7A0'],
            'resource_policy':'use retail Adventure resources in-place; do not convert the tile into a fake stage launch',
        },
        'duo_challenges':{
            'type':'mode','label':'Duo Challenges','launch_action':'launch_duo_challenges',
            'entry_scene':'SDK duo/event challenge dispatcher',
            'activation':'route selected recipe/Event Match through two-human match initialization',
        },
    }


def runtime_plan(page_set: StagePageSet) -> dict[str, Any]:
    page_set.validate()
    virtual_files=[]; modes=[]; slots=[]
    for pi,p in enumerate(page_set.pages):
        for idx,e in enumerate(p.entries):
            si=int(e.grid_slot) if e.grid_slot is not None else idx
            slots.append({'page':pi,'grid_slot':si,'entry_id':e.entry_id,'kind':e.kind,'skin_slot':e.preview_slot})
            if e.kind=='stage' and e.stage_filename and e.stkind is None:
                virtual_files.append({'page':pi,'slot':si,'filename':e.stage_filename,'stkind':VIRTUAL_STAGE_STKIND})
            elif e.kind=='mode':
                modes.append({'page':pi,'slot':si,'mode_id':e.mode_id,'launch_action':e.launch_action})
    return {
        'format':'melee-sdk-paged-sss-runtime-plan-v2',
        'target':'GALE01 1.02',
        'source_facts':{
            'stage_table_symbol':'mnStageSel_803F06D0','stage_table_rows':30,'visible_stage_rows':29,'random_row':29,
            'onframe_symbol':'mnStageSel_Scene_OnFrame','dpad_up_mask':PAD_DPAD_UP,'dpad_down_mask':PAD_DPAD_DOWN,
            'regular_icon_model_group':'x40','bottom_row_icon_model_group':'x20','random_model_group':'x10',
            'bottom_row_slots':[24,25,26,27,28],
        },
        'page_count':len(page_set.pages),
        'page_switch':{
            'up':'previous page','down':'next page','wrap':page_set.wrap_pages,
            'behavior':'cancel hover selection, run transition-out, swap slot descriptors/labels/thumbnail bindings, refresh visibility, run transition-in, keep Random as final tile',
            'transition':transition_plan(page_set.transition_style),
        },
        'page_indicator':{'enabled':page_set.page_indicator,'format':'{current}/{total}','example':f'1/{len(page_set.pages)}'},
        'slot_map':slots,
        'visual_manifest':visual_manifest(page_set),
        'virtual_stage_bridge':{
            'stkind':VIRTUAL_STAGE_STKIND,'entries':virtual_files,
            'behavior':'before scene exit, point the SDK dormant StageData slot at selected Gr*.dat filename, then launch StKind 0x15',
        },
        'mode_launchers':modes,
        'mode_dispatch':mode_dispatch_contract(),
        'random_policy':'random chooses enabled stage entries on active page; mode launcher tiles are excluded',
        'menu_asset_strategy':'reuse retail MnSlMap x20 bottom-row icon model first, then x40 regular icon grid; labels/page indicator are runtime overlays; optional thumbnail bindings do not require hierarchy expansion',
        'status':'VISUAL_AND_DISPATCH_AUTHORING_READY_RUNTIME_HOOK_PENDING_DOL',
    }


def write_hub_bundle(directory: str|Path, page_set: StagePageSet, *, campaign=None,
                     route_atlas: dict[str,Any]|None=None, dol_preflight: dict[str,Any]|None=None) -> Path:
    """Create one portable package tying the SSS hub to Co-op Adventure runtime authoring."""
    root=Path(directory); root.mkdir(parents=True,exist_ok=True)
    page_set.save(root/'stage_pages.json')
    (root/'sss_visual_manifest.json').write_text(json.dumps(visual_manifest(page_set),indent=2),encoding='utf-8')
    (root/'sss_runtime_plan.json').write_text(json.dumps(runtime_plan(page_set),indent=2),encoding='utf-8')
    (root/'mode_dispatch.json').write_text(json.dumps(mode_dispatch_contract(),indent=2),encoding='utf-8')
    if campaign is not None:
        campaign.save(root/'coop_adventure.json')
        (root/'coop_adventure_runtime_plan.json').write_text(json.dumps(campaign.runtime_plan(),indent=2),encoding='utf-8')
    if route_atlas is not None:
        (root/'route_partner_atlas.json').write_text(json.dumps(route_atlas,indent=2),encoding='utf-8')
    if dol_preflight is not None:
        (root/'dol_preflight.json').write_text(json.dumps(dol_preflight,indent=2),encoding='utf-8')
    (root/'README.txt').write_text(
        'Phase 26 Stage Select Hub bundle\n\n'
        'This bundle ties the paged retail MnSlMap grid to custom stage dispatch and the Co-op Adventure runtime contract.\n'
        'It is an authoring/runtime-preflight bundle; final PowerPC hook installation still requires a project start.dol.\n',encoding='utf-8')
    return root


def preflight_sss_dol(dol_path: str | Path, symbols_path: str | Path, *, require_clean: bool=False) -> dict[str, Any]:
    raw=Path(dol_path).read_bytes(); sha1=hashlib.sha1(raw).hexdigest()
    if require_clean and sha1.lower()!=GALE01_102_DOL_SHA1.lower():
        raise ValueError(f'Expected canonical GALE01 1.02 main.dol {GALE01_102_DOL_SHA1}, got {sha1}')
    dol=DOLImage(raw); syms=SymbolMap.from_file(symbols_path)
    hooks=[]
    for name in ('mnStageSel_Scene_OnFrame','mnStageSel_803F06D0'):
        s=syms.require(name)
        capture=min(0x40, s.size or 0x40)
        data=dol.read_at_address(s.address,capture)
        hooks.append({'symbol':name,'address':s.address,'section':s.section,'declared_size':s.size,
                      'capture_size':capture,'sha256':hashlib.sha256(data).hexdigest(),'bytes':data.hex()})
    return {'format':'melee-sdk-paged-sss-preflight-v2','target':'GALE01 1.02','dol_sha1':sha1,
            'canonical_clean':sha1.lower()==GALE01_102_DOL_SHA1.lower(),'hooks':hooks,
            'required_behavior':['D-pad page switching','slot descriptor remap','page indicator overlay','custom-stage bridge','mode dispatch interception'],
            'status':'PASS'}
