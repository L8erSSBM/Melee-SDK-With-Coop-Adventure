"""Shared GUI build route: project resources plus reproducible co-op runtime."""
from pathlib import Path
import hashlib
from .gamecube_iso import GALE01_102_DOL_SHA1, fresh_rebuild, quick_update
from .iso_builder import build_test_iso, ADVENTURE_DIFFICULTIES


def validate_options(options):
    result = dict(options)
    if result['adventure_difficulty'] not in ADVENTURE_DIFFICULTIES:
        raise ValueError('Choose a supported Adventure difficulty.')
    result['adventure_stocks'] = int(result['adventure_stocks'])
    if not 1 <= result['adventure_stocks'] <= 9:
        raise ValueError('Adventure stocks must be 1–9.')
    return result


def build_project_iso(clean, output, content_dir, options, *, fresh=False):
    options = validate_options(options)
    content_dir = Path(content_dir)
    if options['coop_direct']:
        # The co-op installer must own the executable; never silently discard
        # a separately authored runtime. Ordinary DAT/AJ edits are merged.
        for item in content_dir.iterdir():
            if item.name.lower() == 'start.dol':
                if hashlib.sha1(item.read_bytes()).hexdigest() != GALE01_102_DOL_SHA1:
                    raise ValueError('Build/start.dol contains separate runtime patches. Use a project with a clean main.dol (or no start.dol) for Co-op Direct; DAT/AJ resource edits are supported.')
        manifest = build_test_iso(clean, output, variant='coop_showcase',
            symbols_path=Path(__file__).resolve().parents[1]/'data/runtime_symbols_GALE01.txt',
            content_dir=content_dir, vs_p2_identity_bridge=True, adventure_sss_gateway=True,
            **{key: options[key] for key in ('friendly_fire', 'scene_revive', 'test_shortcuts',
                'unlock_all', 'adventure_difficulty', 'adventure_stocks')})
        return {**manifest['rebuild'], 'mode': 'coop_direct_rebuild',
                'output_iso': str(output), 'manifest_path': manifest['manifest_path']}
    # Always rebuild for this dialog, including when disabling co-op, so a
    # prior generated runtime cannot survive in the output image.
    return fresh_rebuild(clean, output, content_dir, verify_hash=True)
