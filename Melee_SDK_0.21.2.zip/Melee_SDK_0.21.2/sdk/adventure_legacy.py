from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class LegacyAdventureWrite:
    line: int
    gecko_type: str
    address: int
    value_template: str
    size: int
    target: str
    meaning: str
    confidence: str = 'high'
    warning: str = ''

    def value(self, character_id: int) -> int:
        text = self.value_template.replace('XX', f'{character_id & 0xFF:02X}')
        return int(text, 16)

    def gecko_line(self, character_id: int) -> str:
        value = self.value(character_id)
        if self.gecko_type == '00':
            code_addr = self.address - 0x80000000
            return f'{code_addr:08X} {value:08X}'
        if self.gecko_type == '04':
            code_addr = 0x04000000 | (self.address - 0x80000000)
            return f'{code_addr:08X} {value:08X}'
        raise ValueError(self.gecko_type)


# Nick Reynolds' historical 2-Player Adventure patch, decoded against the
# current GALE01 source/layout.  The list deliberately preserves the historical
# writes exactly for research/export, including the slot_type write that does
# not agree with the modern StaticPlayer type model.
LEGACY_WRITES: tuple[LegacyAdventureWrite, ...] = (
    LegacyAdventureWrite(1, '04', 0x80456AC4, '000000XX', 4,
        'player_slots[4].player_character',
        'Seeds the extra StaticPlayer record with the selected external CharacterKind.'),
    LegacyAdventureWrite(2, '04', 0x80456AC8, '000000XX', 4,
        'player_slots[4].slot_type',
        'Historical code writes the same XX value into Gm_PKind slot_type.',
        confidence='low',
        warning='Current source defines this field as Gm_PKind, so copying a CharacterKind here is structurally unsafe.'),
    LegacyAdventureWrite(3, '04', 0x80432094, '000000XX', 4,
        'fighter preload/cache BSS region',
        'Seeds a fighter/resource preload identity used by the old hack.',
        confidence='medium',
        warning='The exact modern symbol for this BSS word is not present in the bundled minimal runtime symbol map.'),
    LegacyAdventureWrite(4, '04', 0x8016E2F8, '4800015C', 4,
        'fn_8016E2BC + 0x3C',
        'Branches to 0x8016E454, skipping the P1-only single-player spawn block and entering the multi-slot spawn path.'),
    LegacyAdventureWrite(5, '04', 0x80456B08, '01000400', 4,
        'player_slots[4] + 0x48',
        'Sets player_id=1, cpu_level=0, cpu_type=4, handicap=0 for the historical extra slot.',
        confidence='medium'),
    LegacyAdventureWrite(6, '04', 0x80456B4C, '00000500', 4,
        'player_slots[4] + 0x8C',
        'Clears suicide count and seeds stocks=5 in the historical extra slot.'),
    LegacyAdventureWrite(7, '04', 0x80456B04, '00000000', 4,
        'player_slots[4] + 0x44',
        'Clears costume/unk45/controller/team bytes for the historical extra slot.'),
    LegacyAdventureWrite(8, '04', 0x802F653C, '60000000', 4,
        'ifStatus_802F6508 + 0x34',
        'NOPs one HUD/status initialization instruction in the single-player HUD path.',
        confidence='medium'),
    LegacyAdventureWrite(9, '00', 0x80456B6C, '00000000', 1,
        'player_slots[4].flags',
        'Clears the first StaticPlayer flags byte.'),
    LegacyAdventureWrite(10, '04', 0x80032720, '48800000', 4,
        'Player_LoadPlayerCoords + 0x10',
        'Branches to the custom trampoline at 0x80832720.'),
    LegacyAdventureWrite(11, '04', 0x80832720, '3C608045', 4,
        'legacy trampoline', 'lis r3, 0x8045; begins reconstruction of player_slots base.'),
    LegacyAdventureWrite(12, '04', 0x80832724, '38033080', 4,
        'legacy trampoline', 'addi r0, r3, 0x3080; r0 = 0x80453080 (player_slots base).'),
    LegacyAdventureWrite(13, '04', 0x80832728, '2C1900XX', 4,
        'legacy trampoline', 'cmpwi r25, XX; detects the selected extra-player CharacterKind.'),
    LegacyAdventureWrite(14, '04', 0x8083272C, '4182000C', 4,
        'legacy trampoline', 'beq 0x80832738; selects alternate slot-offset register when r25 matches XX.'),
    LegacyAdventureWrite(15, '04', 0x80832730, '7C602214', 4,
        'legacy trampoline', 'add r3, r0, r4; normal player_slots base+offset calculation.'),
    LegacyAdventureWrite(16, '04', 0x80832734, '4B7FFFF8', 4,
        'legacy trampoline', 'Branches back to 0x8003272C.'),
    LegacyAdventureWrite(17, '04', 0x80832738, '7C605A14', 4,
        'legacy trampoline', 'add r3, r0, r11; alternate base+offset calculation for the selected character.'),
    LegacyAdventureWrite(18, '04', 0x8083273C, '4B7FFFF0', 4,
        'legacy trampoline', 'Branches back to 0x8003272C.'),
)


def legacy_gecko_code(character_id: int, *, include_header: bool = True) -> str:
    """Render the historical code exactly, parameterized by XX.

    This is a research/compatibility export.  It is intentionally not the SDK's
    recommended Phase 28 runtime implementation because several writes mutate
    global BSS and one field is type-inconsistent with current source.
    """
    if not 0 <= int(character_id) <= 0xFF:
        raise ValueError('character_id must fit in one byte')
    lines=[]
    if include_header:
        lines.append('$2-Player Adventure Mode [Nick Reynolds]')
    lines.extend(w.gecko_line(int(character_id)) for w in LEGACY_WRITES)
    return '\n'.join(lines) + '\n'


def legacy_analysis() -> dict:
    return {
        'format': 'melee-sdk-phase28-legacy-2p-adventure-v1',
        'target': 'GALE01 1.02',
        'title': '2-Player Adventure Mode [Nick Reynolds]',
        'write_count': len(LEGACY_WRITES),
        'branch_targets': {
            '0x8016E2F8': '0x8016E454',
            '0x80032720': '0x80832720',
            '0x80832734': '0x8003272C',
            '0x8083273C': '0x8003272C',
        },
        'player_slots_base': '0x80453080',
        'static_player_size': '0xE90',
        'historical_extra_record': 'player_slots[4]',
        'findings': [
            'The 0x8016E2F8 branch skips the P1-only branch in fn_8016E2BC and resumes inside the multi-slot spawn path.',
            'The 0x80032720 hook replaces part of Player_LoadPlayerCoords with a character-sensitive base+offset trampoline.',
            'The HUD NOP lands inside ifStatus_802F6508, which initializes per-player damage/stock HUD state.',
            'The BSS writes seed a fifth StaticPlayer record even though normal match fighter records are distinct from controller ports.',
            'The historical slot_type write is inconsistent with the modern typed layout and is therefore treated as evidence, not a safe SDK patch.',
        ],
        'safe_phase28_policy': [
            'Do not globally patch fn_8016E2BC or ifStatus_802F6508.',
            'Gate co-op behavior on the SDK Co-op Adventure activation state.',
            'Build P2 through StartMeleeData/PlayerInitData and the normal player initialization path.',
            'Reserve human slots before CPU/wave allocation rather than manufacturing player_slots[4] by raw BSS writes.',
            'Use route-stage partner coordinates from the Phase 24 atlas and normal Player coordinate setters.',
            'Evaluate stocks/progression as the human team, not player_standings[0] only.',
        ],
        'writes': [asdict(w) for w in LEGACY_WRITES],
    }


def write_legacy_analysis(path: str | Path) -> Path:
    p=Path(path)
    p.write_text(json.dumps(legacy_analysis(), indent=2), encoding='utf-8')
    return p
