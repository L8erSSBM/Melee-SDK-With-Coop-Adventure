"""HF26: make the *test-only* Team-Kirby force-clear follow retail cleanup.

HF25 proved the remaining forced-clear crash happened *before* the clear-screen
background hook: results initialization tried to load ``GmRegClr`` while the
live Team-Kirby event working set was still resident.  The allocator is not the
right boundary to patch.

This module changes only the developer L+D-Pad Down shortcut.  Outside Team
Kirby it delegates to the existing shortcut byte-for-byte.  In Team Kirby a
single chord latches a request, then the wrapper drives only live dynamic event
fighters (reserved co-op slots 2..5) below the blast zone through the existing
``Player_SetPosition`` API.  Retail therefore owns every KO, wave refill and
final event retirement.  The wrapper waits for the same source-grounded
``complete != 0 && active == 0`` boundary used by the HF20 terminal detector,
gives retail one additional frame, and only then writes the ordinary 1P
stage-end result/terminate bytes.

No fighter is freed directly, no event-manager counters are fabricated, Nana
and human slots 0/1 are untouched, and HF22-HF25 production paths are unchanged.
The patch is installed only when developer test shortcuts are enabled.
"""
from __future__ import annotations

import struct

from .ppc import (
    addi, andi_dot, blr, cmpwi, encode_bc, encode_branch, lbz, li, lis, lwz,
    mflr, mtlr, stb, stw, stwu,
)

ADVENTURE_MODE_ADDR = 0x80479D30
ADVENTURE_STATE_ADDR = 0x80479D33
GM_ADVENTURE = 4
TEAM_KIRBY_FIGHT_STATE = 0x23

HSD_PAD_COPY_STATUS = 0x804C20BC
PAD_STATUS_STRIDE = 0x44
PAD_BUTTON_OFF = 0x00
PAD_TRIGGER_OFF = 0x08
PAD_BUTTON_DDOWN = 0x0004
PAD_BUTTON_L = 0x0040

PLAYER_GET_ENTITY = 0x80034110
PLAYER_GET_STOCKS = 0x80033BD8
PLAYER_SET_POSITION = 0x80032A04
EVENT_ENEMY_IS_COMPLETE = 0x8016A1E4
EVENT_ENEMY_IS_ACTIVE = 0x8016A1F8

VS_SCENE_CONTROLLER = 0x8046B6A0
VS_TERMINATE_MATCH_ADDR = VS_SCENE_CONTROLLER + 0x06
VS_MATCH_RESULT_ADDR = VS_SCENE_CONTROLLER + 0x08
MATCH_OUTCOME_1P_STAGE_END = 6

# Original helper's first instruction, displaced by our entry branch.
SHORTCUT_ENTRY_EXPECTED = stwu(1, -0x20, 1)
EVENT_SLOTS = (2, 3, 4, 5)


def _addr_parts(addr: int) -> tuple[int, int]:
    addr &= 0xFFFFFFFF
    hi = (addr + 0x8000) >> 16
    lo = addr & 0xFFFF
    return hi & 0xFFFF, lo


def _load_abs(out: bytearray, reg: int, addr: int, *, byte: bool = False) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(12, hi)
    out += (lbz if byte else lwz)(reg, lo, 12)


def _store_abs(out: bytearray, reg: int, addr: int, *, byte: bool = False) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(12, hi)
    out += (stb if byte else stw)(reg, lo, 12)


def _inc_counter(out: bytearray, addr: int) -> None:
    """Saturating u32 counter, using CR7 so pad-test CR0 is irrelevant."""
    hi, lo = _addr_parts(addr)
    out += lis(12, hi)
    out += lwz(11, lo, 12)
    out += cmpwi(11, -1, crf=7)
    # Branch over add/store if already 0xffffffff; fixed locally by caller.


class Asm:
    def __init__(self, base: int):
        self.base = int(base)
        self.data = bytearray()
        self.labels: dict[str, int] = {}
        self.fixups: list[tuple[int, str, int, int]] = []

    def emit(self, *chunks: bytes) -> None:
        for c in chunks:
            self.data.extend(c)

    def label(self, name: str) -> None:
        self.labels[name] = len(self.data)

    def branch(self, label: str, *, bo: int = 20, bi: int = 0) -> None:
        self.fixups.append((len(self.data), label, bo, bi))
        self.emit(bytes(4))

    def load_abs(self, reg: int, addr: int, *, byte: bool = False) -> None:
        _load_abs(self.data, reg, addr, byte=byte)

    def store_abs(self, reg: int, addr: int, *, byte: bool = False) -> None:
        _store_abs(self.data, reg, addr, byte=byte)

    def inc_counter(self, addr: int, done_label: str) -> None:
        hi, lo = _addr_parts(addr)
        self.emit(lis(12, hi), lwz(11, lo, 12), cmpwi(11, -1, crf=7))
        self.branch(done_label, bo=12, bi=30)  # beq CR7
        self.emit(addi(11, 11, 1), stw(11, lo, 12))

    def finish(self) -> bytes:
        for off, label, bo, bi in self.fixups:
            self.data[off:off+4] = encode_bc(
                self.base + off, self.base + self.labels[label], bo=bo, bi=bi)
        return bytes(self.data)


def wrapper(base: int, *, old_shortcut_addr: int, request_state_addr: int,
            request_counter_addr: int, terminal_counter_addr: int,
            ko_counter_addr: int, offscreen_vec_addr: int) -> bytes:
    """Build the HF26 entry wrapper.

    request_state values:
      0 = idle
      1 = driving event fighters through retail KO/wave lifecycle
      2 = terminal complete/inactive observed; wait one helper frame, then clear
    """
    a = Asm(base)

    # The helper is already called from an Adventure-only wrapper, but retain an
    # independent mode/state gate so a future caller cannot broaden HF26.
    a.load_abs(11, ADVENTURE_MODE_ADDR, byte=True)
    a.emit(cmpwi(11, GM_ADVENTURE, crf=7)); a.branch('delegate', bo=4, bi=30)
    a.load_abs(11, ADVENTURE_STATE_ADDR, byte=True)
    a.emit(cmpwi(11, TEAM_KIRBY_FIGHT_STATE, crf=7)); a.branch('not_team_kirby', bo=4, bi=30)

    # Resume an already latched request before accepting any other shortcut.
    a.load_abs(11, request_state_addr, byte=True)
    a.emit(cmpwi(11, 1, crf=7)); a.branch('drive', bo=12, bi=30)
    a.emit(cmpwi(11, 2, crf=7)); a.branch('terminate', bo=12, bi=30)

    # Idle Team-Kirby: intercept only L + *triggered* D-Pad Down from either pad.
    # Every other chord delegates to the original helper unchanged.
    for pad_index in (0, 1):
        pad = HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE * pad_index
        hi, lo = _addr_parts(pad)
        a.emit(lis(12, hi), lwz(11, lo + PAD_BUTTON_OFF, 12), andi_dot(10, 11, PAD_BUTTON_L))
        a.branch(f'pad{pad_index}_next', bo=12, bi=2)  # no L
        a.emit(lwz(11, lo + PAD_TRIGGER_OFF, 12), andi_dot(10, 11, PAD_BUTTON_DDOWN))
        a.branch('latch', bo=4, bi=2)  # DDown trigger present
        a.label(f'pad{pad_index}_next')
    a.branch('delegate')

    a.label('not_team_kirby')
    # Never carry a half-finished test request into another Adventure state.
    a.emit(li(11, 0)); a.store_abs(11, request_state_addr, byte=True)
    a.branch('delegate')

    a.label('latch')
    a.emit(li(11, 1)); a.store_abs(11, request_state_addr, byte=True)
    a.inc_counter(request_counter_addr, 'drive')

    a.label('drive')
    # We are replacing the original helper entirely on this path, so make our
    # own call-safe frame and preserve the incoming LR.
    a.emit(stwu(1, -0x30, 1), mflr(0), stw(0, 0x14, 1))

    # Do not synthesize event completion.  Ask retail whether its manager has
    # committed the normal complete/inactive terminal boundary.
    a.emit(encode_branch(base + len(a.data), EVENT_ENEMY_IS_COMPLETE, link=True))
    a.emit(stw(3, 0x18, 1))
    a.emit(encode_branch(base + len(a.data), EVENT_ENEMY_IS_ACTIVE, link=True))
    a.emit(cmpwi(3, 0, crf=7)); a.branch('drive_fighters', bo=4, bi=30)  # still active
    a.emit(lwz(11, 0x18, 1), cmpwi(11, 0, crf=7)); a.branch('drive_fighters', bo=12, bi=30)

    # Terminal edge observed.  Latch state 2 and return for one full retail
    # frame; the next helper invocation performs the ordinary match termination.
    a.emit(li(11, 2)); a.store_abs(11, request_state_addr, byte=True)
    a.inc_counter(terminal_counter_addr, 'return_special')
    a.branch('return_special')

    a.label('drive_fighters')
    for slot in EVENT_SLOTS:
        next_label = f'slot{slot}_next'
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_STOCKS, link=True))
        a.emit(cmpwi(3, 0, crf=7)); a.branch(next_label, bo=12, bi=30)
        a.emit(li(3, slot))
        a.emit(encode_branch(base + len(a.data), PLAYER_GET_ENTITY, link=True))
        a.emit(cmpwi(3, 0, crf=7)); a.branch(next_label, bo=12, bi=30)
        a.emit(li(3, slot))
        hi, lo = _addr_parts(offscreen_vec_addr)
        a.emit(lis(4, hi), addi(4, 4, lo))
        a.emit(encode_branch(base + len(a.data), PLAYER_SET_POSITION, link=True))
        # Increment only when a live instantiated event slot was actually driven.
        a.inc_counter(ko_counter_addr, next_label)
        a.label(next_label)

    a.label('return_special')
    a.emit(lwz(0, 0x14, 1), mtlr(0), addi(1, 1, 0x30), blr())

    a.label('terminate')
    # This executes only on a frame *after* retail complete/inactive was seen.
    a.emit(li(11, 0)); a.store_abs(11, request_state_addr, byte=True)
    a.emit(li(11, MATCH_OUTCOME_1P_STAGE_END)); a.store_abs(11, VS_MATCH_RESULT_ADDR, byte=True)
    a.emit(li(11, 1)); a.store_abs(11, VS_TERMINATE_MATCH_ADDR, byte=True)
    a.emit(blr())

    a.label('delegate')
    # Reproduce the displaced original prologue, then enter the old helper at +4.
    a.emit(SHORTCUT_ENTRY_EXPECTED)
    a.emit(encode_branch(base + len(a.data), old_shortcut_addr + 4))
    return a.finish()


def install(dol, index: int, *, old_shortcut_addr: int, offscreen_vec_addr: int) -> dict:
    """Append HF26 to the existing shared runtime section and redirect only the
    developer shortcut helper entry.  The operation is expected-byte guarded so
    it can be safely applied directly to an HF25 DOL.
    """
    got = dol.read_at_address(old_shortcut_addr, 4)
    if got != SHORTCUT_ENTRY_EXPECTED:
        raise ValueError(
            'HF26 Team-Kirby force-clear expected original test-shortcut entry '
            f'{SHORTCUT_ENTRY_EXPECTED.hex()}, got {got.hex()}')
    expected_vec = struct.pack('>fff', 0.0, -10000.0, 0.0)
    if dol.read_at_address(offscreen_vec_addr, len(expected_vec)) != expected_vec:
        raise ValueError('HF26 Team-Kirby force-clear offscreen vector mismatch')

    section = next(s for s in dol.sections if s.kind == 'data' and s.index == index)
    base = section.address + ((section.size + 31) & ~31)
    # 0x00 marker, 0x10 request state byte, 0x14 request count,
    # 0x18 terminal-edge count, 0x1C event-slot KO-drive count, 0x20 code.
    payload = bytearray(b'HF26TKFC' + bytes(24))
    request_state = base + 0x10
    request_counter = base + 0x14
    terminal_counter = base + 0x18
    ko_counter = base + 0x1C
    stub = base + 0x20
    blob = wrapper(
        stub, old_shortcut_addr=old_shortcut_addr,
        request_state_addr=request_state, request_counter_addr=request_counter,
        terminal_counter_addr=terminal_counter, ko_counter_addr=ko_counter,
        offscreen_vec_addr=offscreen_vec_addr)
    payload.extend(blob)
    payload.extend(bytes((-len(payload)) % 32))
    added = dol.append_to_data_section(index, payload)
    assert added['address'] == base

    replacement = encode_branch(old_shortcut_addr, stub)
    dol.patch_at_address(old_shortcut_addr, replacement, expected=SHORTCUT_ENTRY_EXPECTED)
    return {
        'marker': 'HF26TKFC',
        'section': added,
        'shortcut_entry': old_shortcut_addr,
        'stub_address': stub,
        'request_state': request_state,
        'request_counter': request_counter,
        'terminal_counter': terminal_counter,
        'event_ko_counter': ko_counter,
        'offscreen_vec_addr': offscreen_vec_addr,
        'event_slots': list(EVENT_SLOTS),
        'terminal_condition': 'retail event complete != 0 and active == 0, then one-frame grace',
        'scope': 'developer test shortcut only; Adventure Team-Kirby state 0x23',
        'behavior': 'L+DDown drains event fighters through normal KO/wave lifecycle before normal match termination',
    }
