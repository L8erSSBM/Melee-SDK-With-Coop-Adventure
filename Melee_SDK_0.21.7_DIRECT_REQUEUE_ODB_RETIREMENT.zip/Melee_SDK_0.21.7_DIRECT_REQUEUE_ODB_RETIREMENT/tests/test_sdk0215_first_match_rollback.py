"""Instruction tests and a cached-host-range allocator regression.

The host model implements SlippiSavestate's first-construction range cache;
it is not an emulator or a claim of a live two-peer reproduction.
"""
import pytest
from sdk import slippi_first_match_rollback as fix
from sdk import slippi_adventure_netplay_bridge as nb
from sdk import slippi_engine_repair as er
from sdk.ppc import encode_branch
from tests.hf29d_ppc import execute, put, get

BASE = 0x804F4800
RETAIL = 0x804F3900
EXI = 0x804F3C00
PRIME = 0x804F4000
STATE = 0x804F3500
PENDING = 0x804F0C8E
ACTIVE = 0x804F22D0
COMMAND = 0x817FED20
POOL = 0x804C2580
NODE_A = 0x812806C0
NODE_B = 0x812906A0


@pytest.mark.parametrize('mode,veneer,installs', [
    (8, int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'), True),
    (4, int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'), False),
    (2, int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'), False),
    (8, 0x48000100, False),
    (8, int.from_bytes(encode_branch(nb.SLIPPI_EXI_VENEER, EXI), 'big'), False),
])
def test_online_entry_installs_only_exact_native_veneer(mode, veneer, installs):
    mem = {}; put(mem, nb.GM_SCENE_WORD_ADDR, mode, 1)
    put(mem, nb.SLIPPI_EXI_VENEER, veneer)
    result = execute(fix.wrapper(BASE, RETAIL, EXI), BASE, mem=mem,
                     initial_regs={3:0x12345678, 4:0x87654321}, stop_targets={RETAIL})
    expected = int.from_bytes(encode_branch(nb.SLIPPI_EXI_VENEER, EXI), 'big') if installs else veneer
    assert get(mem, nb.SLIPPI_EXI_VENEER) == expected
    assert result['regs'][3:5] == [0x12345678, 0x87654321]


def test_first_regular_match_primes_cached_host_map_and_preserves_arguments():
    mem = {}; put(mem, nb.GM_SCENE_WORD_ADDR, 8, 1)
    put(mem, nb.SLIPPI_EXI_VENEER, int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'))
    execute(fix.wrapper(BASE, RETAIL, EXI), BASE, mem=mem, stop_targets={RETAIL})
    bounds = []
    def host(regs, memory):
        assert regs[3:6] == [COMMAND, 0x1A, 1]
        # Slippi caches the first map, even when a later match recreates slots.
        if not bounds:
            bounds.append((get(memory, nb.MAIN_HEAP_END_ADDR-4), get(memory, nb.MAIN_HEAP_END_ADDR)))
    code = nb.build_exi_wrapper(EXI, pending_addr=PENDING, active_addr=ACTIVE,
                               state_addr=STATE, prime_addr=PRIME)
    for scene, lo, hi in [(8, 0x80BD5C40, 0x811AD5A0), (4, 0x80BECA60, 0x817E0000)]:
        put(mem, nb.GM_SCENE_WORD_ADDR, scene, 1)
        put(mem, nb.MAIN_HEAP_END_ADDR-4, lo); put(mem, nb.MAIN_HEAP_END_ADDR, hi)
        put(mem, COMMAND, nb.ONLINE_INPUTS, 1); put(mem, COMMAND+1, 1)
        execute(code, EXI, mem=mem, initial_regs={1:0x804E0000, 3:COMMAND, 4:0x1A, 5:1},
                extra_code=[(PRIME, er.prime(PRIME, nb))], callees={nb.SLIPPI_EXI_TRANSFER:host})
        assert get(mem, nb.MAIN_HEAP_END_ADDR-4) == lo
        assert get(mem, nb.MAIN_HEAP_END_ADDR) == hi
    assert bounds == [(nb.FULL_ROLLBACK_HEAP_START, nb.FULL_ROLLBACK_HEAP_END)]
    assert bounds[0][0] <= NODE_A < NODE_B < bounds[0][1]


@pytest.mark.parametrize('heap_end,expected_second', [(0x811AD5A0, 0), (nb.FULL_ROLLBACK_HEAP_END, NODE_B)])
def test_partial_heap_rollback_reproduces_null_list_allocation(heap_end, expected_second):
    mem = {}
    # Physical address zero contains the game disc header on this machine.
    put(mem, 0, 0x47414C45)
    put(mem, POOL+4, NODE_A); put(mem, POOL+8, 1238); put(mem, POOL+12, 2)
    put(mem, NODE_A, NODE_B); put(mem, NODE_B, 0)
    saved = {a:b for a,b in mem.items() if a < 0x804DEC00 or nb.FULL_ROLLBACK_HEAP_START <= a < heap_end}
    # Render after capture consumes A and writes its live-list next pointer.
    put(mem, POOL+4, NODE_B); put(mem, POOL+8, 1239); put(mem, POOL+12, 1)
    put(mem, NODE_A, 0)
    mem.update(saved)
    def pop():
        ptr = get(mem, POOL+4)
        put(mem, POOL+4, get(mem, ptr))
        put(mem, POOL+8, get(mem, POOL+8)+1)
        put(mem, POOL+12, get(mem, POOL+12)-1)
        return ptr
    assert pop() == NODE_A
    assert pop() == expected_second
    assert get(mem, POOL+8) == 1240
    assert get(mem, POOL+4) == (0x47414C45 if expected_second == 0 else 0)
