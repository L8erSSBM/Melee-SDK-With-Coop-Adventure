import pytest
from sdk import adventure_probe as ap, slippi_adventure_entry_leaf as leaf
from sdk import standalone_stage_runtime as sr, slippi_adventure_netplay_bridge as nb
from sdk.standalone_stage_catalog import STAGES
from tests.hf29d_ppc import execute, put, get, SENTINEL

BASE=0x804F1900
MARKER=0x804F1100
ACTIVE=MARKER+1
ORIGIN=MARKER+2
LATCH=MARKER+3
LOCAL=MARKER+4
PENDING=MARKER+5
STATE=0x804F3500
SCENE=0x803DE200
R13=0x804DB6A0
RETAIL=0x801B4170


def test_presentation_install_preserves_and_executes_adjacent_encounter_setup():
    allocated=len(ap._adventure_presentation_start_wrapper(BASE,BASE-8))
    assert allocated==304
    neighbor=BASE+allocated
    luigi=ap._luigi_cpu_substitution_wrapper(neighbor)
    class Image:
        def __init__(self):self.data=bytearray(allocated)+bytearray(luigi)
        def patch_at_address(self,address,data):
            self.data[address-BASE:address-BASE+len(data)]=data
    dol=Image()
    leaf.install(dol,8,presentation_wrapper_addr=BASE,trace_stage_addr=MARKER,
                 origin_addr=ORIGIN,wrapper_capacity=allocated)
    assert bytes(dol.data[allocated:])==luigi
    for previous in (1,2):
        mem={};put(mem,ap.GM_PREVIOUS_STATE_ADDR,previous,1)
        enter=0x80472000;put(mem,SCENE+0x10,enter)
        put(mem,enter+ap.CPU_SLOT2_INIT_OFFSET,ap.CKIND_MARIO,1)
        put(mem,enter+0x84,12,1) # human P2 must survive substitution
        def setup(r,m):
            for i in range(3,13):r[i]=0xBAD00000+i
        def adventure(r,m):r[3]=0x80490000
        out=execute(bytes(dol.data[allocated:]),neighbor,mem=mem,initial_regs={3:SCENE},
                    callees={ap.ADVENTURE_COMMON_VS_SETUP:setup,ap.GM_GET_ADVENTURE_DATA:adventure})
        assert out['target']==SENTINEL and out['regs'][1]==0x817FF000
        assert get(mem,enter+0x84,1)==12
        assert get(mem,enter+ap.CPU_SLOT2_INIT_OFFSET,1)==(ap.CKIND_LUIGI if previous==2 else ap.CKIND_MARIO)


def test_undersized_leaf_slot_fails_before_writing():
    class Image:
        def patch_at_address(self,*args):pytest.fail('must reject before mutation')
    with pytest.raises(ValueError,match='allocated runtime slot'):
        leaf.install(Image(),8,presentation_wrapper_addr=BASE,trace_stage_addr=MARKER,
                     origin_addr=ORIGIN,wrapper_capacity=288)


@pytest.mark.parametrize('index',range(13))
@pytest.mark.parametrize('local',[0,1])
def test_standalone_handoff_assigns_one_picker_even_after_draw(index,local):
    mem={}
    for a,v in ((MARKER,0xA6+index),(ACTIVE,1),(ORIGIN,8),(LOCAL,local),
                (SCENE,STAGES[index].play_state),(R13-0x5037,0),(R13-0x5036,1)):put(mem,a,v,1)
    code=sr.exit_scene(BASE,MARKER,RETAIL,origin_addr=ORIGIN,active_addr=ACTIVE,
                       return_pending_addr=LATCH,canonical_local_addr=LOCAL)
    out=execute(code,BASE,mem=mem,initial_regs={3:SCENE,13:R13},stop_targets=(0x801A42F8,RETAIL))
    assert out['target']==0x801A42F8 and out['regs'][3]==8
    assert get(mem,MARKER,1)==0xFF and get(mem,LATCH,1)==1
    assert get(mem,ACTIVE,1)==get(mem,ORIGIN,1)==0
    assert get(mem,R13-0x5037,1)==local and get(mem,R13-0x5036,1)==0


@pytest.mark.parametrize('phase',[0,3])
def test_late_cleanup_latch_works_before_and_after_menu_restore(phase):
    mem={};command=0x81200000
    for a,v in ((LATCH,1),(nb.GM_SCENE_WORD_ADDR,8),(STATE+nb.S_PHASE,phase),
                (command,nb.CLEANUP_CONNECTIONS)):put(mem,a,v,1)
    code=nb.build_exi_wrapper(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,
                              return_pending_addr=LATCH,patch_table_addr=0x804FA000)
    out=execute(code,BASE,mem=mem,initial_regs={3:command},stop_targets=(nb.SLIPPI_EXI_TRANSFER,))
    assert out['target']==SENTINEL and get(mem,LATCH,1)==0
    # Once native menu restore has completed, the next real disconnect passes.
    put(mem,STATE+nb.S_PHASE,0,1)
    out=execute(code,BASE,mem=mem,initial_regs={3:command},stop_targets=(nb.SLIPPI_EXI_TRANSFER,))
    assert out['target']==nb.SLIPPI_EXI_TRANSFER


@pytest.mark.parametrize('local',[0,1])
def test_campaign_menu_return_also_assigns_one_picker(local):
    mem={};restore=BASE+0x300
    for a,v in ((LOCAL,local),(nb.GM_SCENE_WORD_ADDR,8),(STATE+nb.S_PHASE,3),
                (R13-0x5037,0),(R13-0x5036,1)):put(mem,a,v,1)
    put(mem,R13+nb.OFST_R13_ODB_ADDR,nb.STABLE_ODB)
    code=nb.build_menu_return(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,
                              restore_addr=restore,canonical_local_addr=LOCAL)
    out=execute(code,BASE,mem=mem,initial_regs={13:R13,3:0x803DAD30},
                callees={restore:lambda r,m:None},stop_targets=(0x801A4018,))
    assert get(mem,R13-0x5037,1)==local and get(mem,R13-0x5036,1)==0
    assert get(mem,R13+nb.OFST_R13_ODB_ADDR)==0
    assert out['regs'][3]==0x803DAD30 and out['lr']==SENTINEL


@pytest.mark.parametrize('major,active,pending,command',[
    (4,1,0,nb.CLEANUP_CONNECTIONS),(4,0,0,nb.CLEANUP_CONNECTIONS),
    (8,1,0,nb.CLEANUP_CONNECTIONS),(8,0,1,nb.CLEANUP_CONNECTIONS),
    (8,0,0,nb.GAME_END),(8,0,0,nb.ONLINE_INPUTS)])
def test_handoff_latch_is_not_consumed_outside_completed_online_cleanup(major,active,pending,command):
    mem={};buffer=0x81200000
    for a,v in ((LATCH,1),(nb.GM_SCENE_WORD_ADDR,major),(ACTIVE,active),
                (PENDING,pending),(buffer,command)):put(mem,a,v,1)
    code=nb.build_exi_wrapper(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,
                              return_pending_addr=LATCH,patch_table_addr=0x804FA000)
    execute(code,BASE,mem=mem,initial_regs={3:buffer},stop_targets=(nb.SLIPPI_EXI_TRANSFER,))
    assert get(mem,LATCH,1)==1
