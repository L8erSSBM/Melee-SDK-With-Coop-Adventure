import pytest
from sdk import standalone_stage_runtime as sr, slippi_coop_stage_page as sp
from sdk import slippi_direct_gateway as dg
from sdk.standalone_stage_catalog import STAGES
from tests.hf29d_ppc import execute,put,get

BASE=0x817FC400
MARKER=0x804F2220
STATE=0x804F2300
RETAIL=0x801B4064

def clobber(regs):
    for r in range(3,13):regs[r]=0xBAD00000+r

@pytest.mark.parametrize('slot',list(range(13))+[27])
def test_commit_sends_selected_row_even_if_helpers_clobber_cursor_and_registers(slot):
    mem={};put(mem,STATE+sp.S_PAGE,1,1);put(mem,sp.CURSOR_INDEX_ADDR,27,1)
    def helper(r,m):clobber(r);put(m,sp.CURSOR_INDEX_ADDR,3,1)
    code=sp.build_stage_commit_wrapper(BASE,RETAIL,state_addr=STATE,
        descriptor_restore_addr=RETAIL+4,capture_addr=RETAIL+8,standalone_count=13)
    out=execute(code,BASE,mem=mem,initial_regs={3:slot},callees={a:helper for a in (RETAIL,RETAIL+4,RETAIL+8)})
    assert out['regs'][3]==0x7000+(0xA6+slot if slot<13 else 0xA5)
    assert get(mem,sp.SLIPPI_ALT_MODE_STATIC,1)==(0xA6+slot if slot<13 else 0xA5)
    assert get(mem,STATE+sp.S_PAGE,1)==0

@pytest.mark.parametrize('index,stage',list(enumerate(STAGES)))
def test_every_selection_starts_at_its_original_scene_or_explicit_adapter(index,stage):
    mem={};put(mem,MARKER,0xA6+index,1)
    out=execute(sr.entry(BASE,MARKER),BASE,mem=mem)
    assert out['regs'][3]==stage.entry_state

@pytest.mark.parametrize('index,stage',list(enumerate(STAGES)))
def test_every_mission_returns_only_after_its_play_scene(index,stage):
    for scene in (stage.play_state,0x70):
        mem={};put(mem,MARKER,0xA6+index,1);put(mem,STATE,scene,1)
        out=execute(sr.exit_scene(BASE,MARKER,RETAIL),BASE,mem=mem,
            initial_regs={3:STATE},stop_targets=(RETAIL,0x801B4408))
        assert out['target']==(0x801B4408 if scene==stage.play_state else RETAIL)
        assert out['regs'][3]==STATE

@pytest.mark.parametrize('marker',[0xA9]+list(range(0xAB,0xB3)))
def test_race_uses_classic_bonus_setup_and_arenas_use_two_human_stock_rules(marker):
    start=0x80472000;adv=0x80490000;mem={}
    put(mem,MARKER,marker,1)
    mem.update({sr.NO_ENEMIES+i:0x21 for i in range(3)})
    seen=[]
    def enter(r,m):clobber(r);r[3]=start
    def data(r,m):clobber(r);r[3]=adv
    def setup(r,m):
        seen.append(tuple(r[3:11]));assert [get(m,r[5]+i,1) for i in range(3)]==[0x21]*3
        assert get(m,r[1]+8)==0 and get(m,r[1]+12)==0
        m.update({start+i:0x7F for i in range(0x138)})
        put(m,start+0x60,2,1);put(m,start+0x84,0x14,1)
        clobber(r)
    out=execute(sr.prepare(BASE,MARKER,RETAIL),BASE,mem=mem,
        initial_regs={3:STATE,29:29,30:30,31:31},callees={0x801A427C:enter,
        0x8017E424:data,0x8017CE34:setup,0x8016F088:lambda r,m:clobber(r)})
    assert [out['regs'][r] for r in (29,30,31)]==[29,30,31]
    assert seen[0][6:]==((180,0x52) if marker==0xAB else (480,0x47 if marker==0xA9 else 0x3B if marker==0xB2 else 0x3F))
    assert get(mem,start+0xB,1)==0xFF and get(mem,start+0x20)==get(mem,start+0x24)==0
    if marker==0xAB:
        assert get(mem,adv+8,1)==0x80 and get(mem,adv+9,1)==2
    else:
        assert get(mem,start+4,1)==0xC3
        assert get(mem,start+2,1)==0x86
        assert get(mem,start+8,1)==0
        assert get(mem,start+0x62,1)==get(mem,start+0x86,1)==4
        assert get(mem,start+0x65,1)==0 and get(mem,start+0x89,1)==1
        assert get(mem,start+0x61,1)==get(mem,start+0x85,1)==0
        assert all(get(mem,start+0x60+i*0x24+1,1)==3 for i in range(2,6))
        assert get(mem,start+0x44)==get(mem,start+0x54)==0
        assert get(mem,start+0x60,1)==2 and get(mem,start+0x84,1)==0x14

def test_snapshot_ring_and_session_do_not_overlap_lazy_module():
    from sdk import slippi_adventure_netplay_bridge as n
    assert n.SDK_SNAPSHOT_BASE+7*n.SDK_RUNTIME_SIZE==sr.BASE
    assert sr.LIMIT==n.SESSION_HIGH_BASE

@pytest.mark.parametrize('marker',[0xA5,0xA6,0xAA,0xAB,0xAC,0xB2,0,0xA4,0xB3,0xFF])
def test_peer_authority_accepts_exact_marker_range(marker):
    pending=STATE+0x40;valid=pending+1;r13=0x804D0000;mem={}
    put(mem,dg.GM_CURRENT_MODE_ADDR,dg.GM_ONLINE,1)
    put(mem,dg.GM_SCENE_BYTE3_ADDR,dg.ONLINE_INGAME_BYTE3,1)
    put(mem,r13+dg.OFST_R13_ONLINE_MODE,dg.ONLINE_MODE_DIRECT,1)
    put(mem,STATE+dg.S_BOOTSTRAP_PENDING,1,1)
    put(mem,dg.NETPLAY_READY_SITE,dg.NETPLAY_READY_WORD)
    put(mem,dg.SLIPPI_ALT_MODE_STATIC,marker,1)
    calls=[]
    def arm(r,m):calls.append('arm');r[3]=1
    code=dg.build_ingame_bootstrap_wrapper(BASE,RETAIL,state_addr=STATE,
        gateway_pending_addr=pending,p2_identity_valid_addr=valid,
        netplay_arm_addr=RETAIL+4,standalone_stages=True)
    execute(code,BASE,mem=mem,initial_regs={13:r13},callees={RETAIL:lambda r,m:None,
        RETAIL+4:arm,dg.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE:lambda r,m:calls.append('transition')})
    assert ('arm' in calls)==(0xA5<=marker<=0xB2)
