"""Regression coverage for the Pokemon Stadium Slippi SIS-text crash.

The captured 0.21.5 savestate reached HSD_SisLib_Alloc from Slippi's
"Desync Risk" text helper with HSD_Text::alloc_data == NULL.  This test
validates both sides of the repair: the helper is patched only under its exact
known signature, and the guard bypasses only invalid text objects while valid
objects tail-enter the original helper after its displaced instruction.
"""
import pytest

from sdk import slippi_first_match_rollback as fix
from sdk import slippi_adventure_netplay_bridge as nb
from sdk.ppc import encode_branch
from tests.hf29d_ppc import SENTINEL, execute, get, put

BASE = 0x804F4800
RETAIL = 0x804F3900
EXI = 0x804F3C00
GUARD = 0x804F4A00
TEXT = 0x80BECC50
ALLOC_DATA = 0x80BECF00


def _online_mem(*, corrupt_signature=False):
    mem = {}
    put(mem, nb.GM_SCENE_WORD_ADDR, nb.GM_ONLINE_MAJOR, 1)
    put(mem, nb.SLIPPI_EXI_VENEER,
        int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'))
    for off, word in fix.SLIPPI_DESYNC_TEXT_SIGNATURE:
        put(mem, fix.SLIPPI_DESYNC_TEXT_HELPER + off,
            word ^ (1 if corrupt_signature and off == 0x30 else 0))
    return mem


def test_online_entry_installs_exact_desync_text_guard():
    mem = _online_mem()
    execute(fix.wrapper(BASE, RETAIL, EXI, GUARD), BASE, mem=mem,
            stop_targets={RETAIL})
    assert get(mem, fix.SLIPPI_DESYNC_TEXT_HELPER) == int.from_bytes(
        encode_branch(fix.SLIPPI_DESYNC_TEXT_HELPER, GUARD), 'big')


def test_foreign_slippi_helper_is_left_untouched():
    mem = _online_mem(corrupt_signature=True)
    original = get(mem, fix.SLIPPI_DESYNC_TEXT_HELPER)
    execute(fix.wrapper(BASE, RETAIL, EXI, GUARD), BASE, mem=mem,
            stop_targets={RETAIL})
    assert get(mem, fix.SLIPPI_DESYNC_TEXT_HELPER) == original


@pytest.mark.parametrize('text_ptr', [0, TEXT])
def test_guard_returns_without_entering_sis_when_text_is_invalid(text_ptr):
    mem = {}
    if text_ptr:
        put(mem, TEXT + fix.HSD_TEXT_ALLOC_DATA_OFFSET, 0)
    result = execute(fix.desync_text_guard(GUARD), GUARD, mem=mem,
                     initial_regs={3: text_ptr})
    assert result['target'] == SENTINEL


def test_guard_replays_displaced_mflr_and_continues_for_valid_text():
    mem = {}
    put(mem, TEXT + fix.HSD_TEXT_ALLOC_DATA_OFFSET, ALLOC_DATA)
    result = execute(fix.desync_text_guard(GUARD), GUARD, mem=mem,
                     initial_regs={3: TEXT}, stop_targets={fix.SLIPPI_DESYNC_TEXT_CONTINUE})
    assert result['target'] == fix.SLIPPI_DESYNC_TEXT_CONTINUE
    assert result['regs'][0] == SENTINEL
    assert result['regs'][3] == TEXT
