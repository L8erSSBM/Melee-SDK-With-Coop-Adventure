import struct
import pytest
from sdk import slippi_direct_launch as dl, slippi_adventure_netplay_bridge as nb
from sdk import standalone_stage_runtime as sr
from tests.hf29d_ppc import execute,put,get,SENTINEL

BASE=0x804F1000; STATE=0x804F4000; R13=0x804DB6A0; MSRB=0x81000000
TABLE=0x804E0000; PTRS=TABLE+0x800; RETAIL=0x801B4064

def seed():
    mem={};table=nb.build_patch_table(exi_wrapper_addr=0x804F6000)
    mem.update({TABLE+i:v for i,v in enumerate(table)})
    for site,old,new in struct.iter_unpack('>III',table):put(mem,site,old)
    for addr,values in ((PTRS,[nb.STABLE_TXB,nb.STABLE_RXB]),(PTRS+8,[nb.STABLE_SSRB,nb.STABLE_SSCB]),
        (PTRS+16,[nb.STABLE_ODB,nb.ODB_SIZE,nb.STABLE_RXB,nb.RXB_SIZE,nb.STABLE_SSCB,nb.SSCB_SIZE])):
        for i,v in enumerate(values):put(mem,addr+4*i,v)
    put(mem,R13+nb.OFST_R13_ARENA_HI,0x81800000);put(mem,MSRB+3,0,1);put(mem,MSRB+4,1,1)
    put(mem,MSRB+9,2,1);put(mem,0x803DAD40,0x81020000);put(mem,0x81020088,0x81030000)
    return mem,table

def arm():return dl.build_arm(BASE,state_addr=STATE,patch_table_addr=TABLE,
    txrx_blob_addr=PTRS,ss_blob_addr=PTRS+8,ssrb_meta_blob_addr=PTRS+16)

def test_five_matches_restore_native_guards_and_rearm_retained_owned_exi_hook():
    mem,table=seed();code=arm();restore=nb.build_restore(BASE+0x1000,STATE,TABLE)
    for game in range(5):
        result=execute(code,BASE,mem=mem,initial_regs={3:MSRB,13:R13},max_steps=20000)
        assert result['regs'][3]==1 and get(mem,0x81030001,2)==game+1
        assert get(mem,STATE+nb.S_PHASE,1)==nb.PHASE_TRANSITION
        execute(restore,BASE+0x1000,mem=mem,initial_regs={13:R13})
        assert get(mem,STATE+nb.S_PHASE,1)==0
        assert get(mem,nb.SLIPPI_EXI_VENEER)==int.from_bytes(table[-4:],'big')
        for site,old,new in struct.iter_unpack('>III',table[:-12]):assert get(mem,site)==old

@pytest.mark.parametrize('index',[0,len(nb.GUARDS)//2,len(nb.GUARDS)])
def test_foreign_hooks_are_still_rejected_without_touching_session(index):
    mem,table=seed();site=int.from_bytes(table[index*12:index*12+4],'big');put(mem,site,0xDEADBEEF)
    put(mem,nb.STABLE_ODB,0x12345678)
    result=execute(arm(),BASE,mem=mem,initial_regs={3:MSRB,13:R13})
    assert result['regs'][3]==0 and get(mem,nb.STABLE_ODB)==0x12345678
    assert get(mem,R13+nb.OFST_R13_ARENA_HI)==0x81800000

@pytest.mark.parametrize('marker',list(range(0xA5,0xB3)))
def test_only_versus_arenas_bypass_checkpoint_classification(marker):
    mem={};put(mem,STATE,marker,1)
    result=execute(sr.no_checkpoint(BASE,STATE,RETAIL),BASE,mem=mem,initial_regs={3:0x3B},stop_targets=(RETAIL,))
    versus=marker==0xA9 or marker>=0xAC
    assert result['target']==(SENTINEL if versus else RETAIL)
    assert result['regs'][3]==(0 if versus else 0x3B)

@pytest.mark.parametrize('marker',[0xA9,*range(0xAC,0xB3)])
def test_arena_rules_enable_hud_recreation_and_two_slot_layout(marker):
    mem={};put(mem,STATE,marker,1);start=0x81001000;adv=0x81002000
    def enter(r,m):r[3]=start
    def adventure(r,m):r[3]=adv
    def setup(r,m):
        # Deliberately dirty template must be overridden, including event hooks.
        m.update({start+i:0xFF for i in range(0x138)})
    execute(sr.prepare(BASE,STATE,RETAIL),BASE,mem=mem,callees={0x801A427C:enter,
        0x8017E424:adventure,0x8017CE34:setup,0x8016F088:lambda r,m:None})
    assert get(mem,start+2,1)&2 # retail ifStatus_802F6508 HUD creation gate
    assert (get(mem,start,1)>>2)&7==2 # exactly two HUD slots
    assert get(mem,start+3,1)==0x4C and get(mem,start+4,1)==0xC3
    assert get(mem,start+0x54)==0 # regular multiplayer spawn/camera controller
    assert get(mem,start+0x65,1)==0 and get(mem,start+0x89,1)==1
