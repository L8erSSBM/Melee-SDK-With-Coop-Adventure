import pytest
from sdk import standalone_stage_runtime as sr
from sdk import slippi_adventure_netplay_bridge as nb
from sdk.standalone_stage_catalog import STAGES
from sdk.ppc import addi
from tests.hf29d_ppc import execute, put, get, SENTINEL

BASE=0x804F4000
MARKER=0x804F1100
ACTIVE=MARKER+1
PENDING=MARKER+2
STATE=0x804F1800
CALLBACK=0x801B4170
SCENE=0x803DE1D0
HIGH=sr.BASE+0x400


@pytest.mark.parametrize('index',range(13))
@pytest.mark.parametrize('outcome',[0,1,2,7])
def test_actual_state_exit_dispatch_stops_each_standalone(index,outcome):
    # Real scene runner uses mtlr/blrl, not a direct callback invocation.
    mem={};put(mem,0x80479D30,4,1);put(mem,ACTIVE,1,1)
    put(mem,MARKER,0xA6+index,1);put(mem,sr.BASE,sr.MAGIC)
    put(mem,SCENE,STAGES[index].play_state,1)
    put(mem,0x8046B6A8,outcome,1)
    result=execute(sr.exit_gate(BASE,MARKER,ACTIVE,HIGH),BASE,mem=mem,
        initial_regs={12:CALLBACK,27:SCENE},
        extra_code=[(0x801A4140,addi(3,27,0)+sr.word(0x4E800021)),
                    (HIGH,sr.exit_dispatch(HIGH,MARKER))],
        stop_targets=(CALLBACK,0x801B4408))
    assert result['target']==0x801B4408
    assert result['lr']==0x801A4148
    assert result['regs'][3]==SCENE


@pytest.mark.parametrize('major,active,marker,magic,scene',[
    (4,1,0xA5,sr.MAGIC,1), # Full Coop Adventure
    (4,0,0xA6,sr.MAGIC,1), # Retail Adventure
    (8,1,0xA6,sr.MAGIC,1), # Online
    (4,1,0xA6,0,1),       # Module unavailable
    (4,1,0xA6,sr.MAGIC,0),# Standalone intro still advances
    (4,1,0xAA,sr.MAGIC,0x39), # F-Zero cutscene still advances
])
def test_exit_dispatch_preserves_campaign_and_intro_callbacks(major,active,marker,magic,scene):
    mem={}
    for addr,val in ((0x80479D30,major),(ACTIVE,active),(MARKER,marker),(SCENE,scene)):put(mem,addr,val,1)
    put(mem,sr.BASE,magic)
    result=execute(sr.exit_gate(BASE,MARKER,ACTIVE,HIGH),BASE,mem=mem,
        initial_regs={12:CALLBACK,27:SCENE},
        extra_code=[(0x801A4140,addi(3,27,0)+sr.word(0x4E800021)),(HIGH,sr.exit_dispatch(HIGH,MARKER))],
        stop_targets=(CALLBACK,0x801B4408))
    assert result['target']==CALLBACK
    assert result['lr']==0x801A4148


@pytest.mark.parametrize('major,active,pending,phase,expected',[
    (8,0,0,3,True),(8,0,0,1,True),(8,0,0,0,False),
    (4,1,0,3,False),(4,0,0,3,False),(0x16,1,0,3,False),
    (8,1,0,3,False),(8,0,1,3,False),(1,0,0,3,False),
])
def test_menu_return_restores_only_after_completed_online_return(major,active,pending,phase,expected):
    mem={}
    for addr,val in ((nb.GM_SCENE_WORD_ADDR,major),(ACTIVE,active),(PENDING,pending),(STATE+nb.S_PHASE,phase)):put(mem,addr,val,1)
    table=0x804F2800;restore=BASE+0x200
    for i,g in enumerate(nb.GUARDS):
        put(mem,table+12*i,g.site);put(mem,table+12*i+4,int.from_bytes(g.expected,'big'))
        put(mem,g.site,0x60000000)
    r13=0x804DB6A0
    put(mem,STATE+nb.S_ORIG_ARENA_HI,0x81800000)
    put(mem,r13+nb.OFST_R13_ARENA_HI,0x817FE000)
    put(mem,r13+nb.OFST_R13_ODB_ADDR,nb.STABLE_ODB)
    out=execute(nb.build_menu_return(BASE,pending_addr=PENDING,active_addr=ACTIVE,state_addr=STATE,restore_addr=restore),BASE,
        mem=mem,initial_regs={3:0x803DAD30,13:r13},extra_code=[(restore,nb.build_restore(restore,STATE,table))],stop_targets=(0x801A4018,))
    assert out['regs'][3]==0x803DAD30 and out['lr']==SENTINEL
    assert out['regs'][1]==0x817FF000 and out['regs'][0]==SENTINEL
    assert get(mem,STATE+nb.S_PHASE,1)==(0 if expected else phase)
    assert get(mem,r13+nb.OFST_R13_ARENA_HI)==(0x81800000 if expected else 0x817FE000)
    # 0.21.7: only a completed Online return retires the relocated ODB.
    assert get(mem,r13+nb.OFST_R13_ODB_ADDR)==(0 if expected else nb.STABLE_ODB)
    for g in nb.GUARDS:
        assert get(mem,g.site)==(int.from_bytes(g.expected,'big') if expected else 0x60000000)
