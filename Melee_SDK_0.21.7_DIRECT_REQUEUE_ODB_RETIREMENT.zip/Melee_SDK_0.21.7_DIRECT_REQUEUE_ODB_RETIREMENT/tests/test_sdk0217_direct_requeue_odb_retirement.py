import pytest

from sdk import slippi_adventure_netplay_bridge as nb
from tests.hf29d_ppc import execute, get, put, SENTINEL

BASE = 0x804F4100
STATE = 0x804F3500
PENDING = 0x804F0C8E
ACTIVE = 0x804F22D0
LOCAL = 0x804F0C95
R13 = 0x804DB6A0
RESTORE = BASE + 0x200
TABLE = 0x804F2800


def _seed_restore(mem):
    for i, g in enumerate(nb.GUARDS):
        put(mem, TABLE + 12 * i, g.site)
        put(mem, TABLE + 12 * i + 4, int.from_bytes(g.expected, 'big'))
        put(mem, g.site, 0x60000000)
    put(mem, STATE + nb.S_ORIG_ARENA_HI, 0x81800000)
    put(mem, R13 + nb.OFST_R13_ARENA_HI, nb.SESSION_HIGH_BASE)


@pytest.mark.parametrize('local', [0, 1])
def test_completed_online_return_retires_relocated_odb_before_phase_off(local):
    mem = {}
    for addr, val in (
        (nb.GM_SCENE_WORD_ADDR, nb.GM_ONLINE_MAJOR),
        (PENDING, 0), (ACTIVE, 0), (LOCAL, local),
        (STATE + nb.S_PHASE, nb.PHASE_FULL),
        (R13 - 0x5037, 0), (R13 - 0x5036, 1),
    ):
        put(mem, addr, val, 1)
    put(mem, R13 + nb.OFST_R13_ODB_ADDR, nb.STABLE_ODB)
    _seed_restore(mem)

    code = nb.build_menu_return(
        BASE, pending_addr=PENDING, active_addr=ACTIVE, state_addr=STATE,
        restore_addr=RESTORE, canonical_local_addr=LOCAL)
    out = execute(
        code, BASE, mem=mem, initial_regs={3: 0x803DAD30, 13: R13},
        extra_code=[(RESTORE, nb.build_restore(RESTORE, STATE, TABLE))],
        stop_targets=(0x801A4018,))

    assert out['target'] == 0x801A4018
    assert out['lr'] == SENTINEL
    assert get(mem, R13 + nb.OFST_R13_ODB_ADDR) == 0
    assert get(mem, STATE + nb.S_PHASE, 1) == nb.PHASE_OFF
    assert get(mem, R13 + nb.OFST_R13_ARENA_HI) == 0x81800000
    assert get(mem, R13 - 0x5037, 1) == local
    assert get(mem, R13 - 0x5036, 1) == 0


@pytest.mark.parametrize('major,active,pending,phase', [
    (4, 1, 0, nb.PHASE_FULL),
    (8, 1, 0, nb.PHASE_FULL),
    (8, 0, 1, nb.PHASE_FULL),
    (8, 0, 0, nb.PHASE_OFF),
])
def test_noncompleted_handoff_does_not_retire_odb(major, active, pending, phase):
    mem = {}
    for addr, val in (
        (nb.GM_SCENE_WORD_ADDR, major), (ACTIVE, active), (PENDING, pending),
        (STATE + nb.S_PHASE, phase),
    ):
        put(mem, addr, val, 1)
    put(mem, R13 + nb.OFST_R13_ODB_ADDR, nb.STABLE_ODB)

    code = nb.build_menu_return(
        BASE, pending_addr=PENDING, active_addr=ACTIVE, state_addr=STATE,
        restore_addr=RESTORE, canonical_local_addr=LOCAL)
    execute(code, BASE, mem=mem, initial_regs={3: 0x803DAD30, 13: R13},
            stop_targets=(0x801A4018,))

    assert get(mem, R13 + nb.OFST_R13_ODB_ADDR) == nb.STABLE_ODB
