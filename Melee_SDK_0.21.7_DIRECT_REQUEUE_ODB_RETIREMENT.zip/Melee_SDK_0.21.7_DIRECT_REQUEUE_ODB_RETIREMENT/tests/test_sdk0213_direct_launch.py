import pytest
from sdk import slippi_direct_launch as dl, slippi_direct_gateway as dg
from sdk import slippi_adventure_netplay_bridge as nb, slippi_coop_stage_page as sp
from sdk import standalone_stage_runtime as sr
from sdk.standalone_stage_catalog import STAGES
from tests.hf29d_ppc import execute, put, get, SENTINEL

BASE=0x804F1000; STATE=0x804F4000; R13=0x804DB6A0
MSRB=0x81000000; MATCH=0x81010000; RETAIL=0x801A5000; ARM=0x804F3000
VALID=STATE+0x100; PENDING=VALID+4; P2VALID=VALID+5
IDS={f'p{p}_{field}_addr':VALID+0x10+(p-1)*4+i for p in (1,2)
     for i,field in enumerate(('ckind','color','subcolor','nametag'))}

def gateway():
    return dl.build_gateway(BASE,RETAIL,state_addr=STATE,gateway_pending_addr=PENDING,
        p2_identity_valid_addr=P2VALID,netplay_arm_addr=ARM,canonical_valid_addr=VALID,
        canonical_local_addr=VALID+1,canonical_remote_addr=VALID+2,
        canonical_players_addr=sp.CANONICAL_PLAYERS_HIGH,standalone_stages=True,**IDS)

def fixture(marker,local=0):
    mem={}
    for addr,value in ((dg.GM_CURRENT_MODE_ADDR,8),(dg.GM_SCENE_BYTE3_ADDR,4),
         (R13+dg.OFST_R13_ONLINE_MODE,2),(MSRB+1,1),(MSRB+2,1),
         (MSRB+3,local),(MSRB+4,1-local),(MSRB+dl.MSRB_ALT,marker)):
        put(mem,addr,value,1)
    put(mem,R13+dg.OFST_R13_GM_MAINLIB,MATCH)
    put(mem,MATCH+dg.DIRECT_MATCH_DATA_OFFSET+0xE,dl.SPECIAL_BASE+marker,2)
    put(mem,MSRB+dl.MSRB_MATCH+0xE,dl.SPECIAL_BASE+marker,2)
    for off,value in ((0x60,2),(0x63,1),(0x67,0),(0x6A,3),(0x84,20),(0x87,2),(0x8B,0),(0x8E,4)):
        put(mem,MSRB+dl.MSRB_MATCH+off,value,1)
    return mem

def clobber(regs):
    for r in range(3,13):regs[r]=0xBAD00000+r

@pytest.mark.parametrize('marker',range(0xA5,0xB3))
@pytest.mark.parametrize('local',[0,1])
def test_direct_launch_skips_splash_and_retail_match_and_captures_fresh_both_peers(marker,local):
    mem=fixture(marker,local);events=[]
    def load(r,m):clobber(r);r[3]=MSRB
    def arm(r,m):assert r[3]==MSRB;events.append('arm');clobber(r);r[3]=1
    def free(r,m):assert r[3]==MSRB;events.append('free');clobber(r)
    def launch(r,m):assert r[3]==4;events.append('launch');clobber(r)
    out=execute(gateway(),BASE,mem=mem,initial_regs={13:R13,30:30,31:31},
        callees={0x80005610:load,ARM:arm,nb.HSD_MEM_FREE:free,0x801A42F8:launch},stop_targets=(RETAIL,))
    assert out['target']==SENTINEL and out['regs'][1]==0x817FF000
    assert out['regs'][30:32]==[30,31] and events==['arm','free','launch']
    assert get(mem,STATE+dg.S_ALT_MODE,1)==marker
    assert get(mem,VALID,1)==get(mem,PENDING,1)==get(mem,P2VALID,1)==1
    assert get(mem,VALID+1,1)==local and get(mem,VALID+2,1)==1-local
    assert get(mem,IDS['p1_ckind_addr'],1)==2 and get(mem,IDS['p2_ckind_addr'],1)==20
    assert bytes(mem.get(sp.CANONICAL_PLAYERS_HIGH+i,0) for i in range(0x48))==bytes(mem.get(MSRB+dl.MSRB_MATCH+0x60+i,0) for i in range(0x48))

@pytest.mark.parametrize('problem',['not_ready','id_mismatch','tag_mismatch','same_roles','invalid_role','cpu','arm_rejected'])
def test_invalid_launch_returns_css_without_retail_stage_or_adventure(problem):
    mem=fixture(0xAC);events=[]
    for key,addr,value,size in [('not_ready',MSRB+2,0,1),('id_mismatch',MSRB+dl.MSRB_MATCH+0xE,8,2),
        ('tag_mismatch',MSRB+dl.MSRB_ALT,0,1),('same_roles',MSRB+4,0,1),
        ('invalid_role',MSRB+3,3,1),('cpu',MSRB+dl.MSRB_MATCH+0x85,1,1)]:
        if key==problem:put(mem,addr,value,size)
    def load(r,m):r[3]=MSRB
    def arm(r,m):assert problem=='arm_rejected';r[3]=0
    def css(r,m):assert r[3]==0;events.append('css')
    execute(gateway(),BASE,mem=mem,initial_regs={13:R13},callees={0x80005610:load,ARM:arm,
        nb.HSD_MEM_FREE:lambda r,m:events.append('free'),0x801A428C:css})
    assert events==['free','css'] and get(mem,PENDING,1)==0

@pytest.mark.parametrize('stage',[2,3,8,0x1F,0x20,0x70A4,0x70B3])
def test_ordinary_retail_selection_is_exact_tail_chain(stage):
    mem=fixture(0xAC);put(mem,MATCH+dg.DIRECT_MATCH_DATA_OFFSET+0xE,stage,2)
    out=execute(gateway(),BASE,mem=mem,initial_regs={13:R13,3:0x1234},stop_targets=(RETAIL,))
    assert out['target']==RETAIL and out['regs'][3]==0x1234 and out['regs'][1]==0x817FF000

@pytest.mark.parametrize('local,delay',[(0,0),(1,2),(0,255)])
def test_direct_arm_initializes_native_buffers_and_patches_only_after_validation(local,delay):
    mem=fixture(0xAC,local);put(mem,MSRB+9,delay,1);put(mem,MSRB+5,0x76543210)
    put(mem,R13+nb.OFST_R13_ARENA_HI,0x81800000);put(mem,R13-0x5108,2,1)
    put(mem,0x803DAD40,0x81020000);put(mem,0x81020088,0x81030000);put(mem,0x81030001,3,2)
    table=0x804E0000;txrx=table+0x800;ss=txrx+8;meta=ss+8
    raw=nb.build_patch_table(exi_wrapper_addr=0x804F6000)
    mem.update({table+i:v for i,v in enumerate(raw)})
    for i in range(0,len(raw),12):put(mem,int.from_bytes(raw[i:i+4],'big'),int.from_bytes(raw[i+4:i+8],'big'))
    for addr,values in ((txrx,[nb.STABLE_TXB,nb.STABLE_RXB]),(ss,[nb.STABLE_SSRB,nb.STABLE_SSCB]),
        (meta,[nb.STABLE_ODB,nb.ODB_SIZE,nb.STABLE_RXB,nb.RXB_SIZE,nb.STABLE_SSCB,nb.SSCB_SIZE])):
        for i,v in enumerate(values):put(mem,addr+i*4,v)
    code=dl.build_arm(BASE,state_addr=STATE,patch_table_addr=table,txrx_blob_addr=txrx,ss_blob_addr=ss,ssrb_meta_blob_addr=meta)
    out=execute(code,BASE,mem=mem,initial_regs={3:MSRB,13:R13},max_steps=20000)
    assert out['regs'][3]==1 and get(mem,R13+nb.OFST_R13_ODB_ADDR)==nb.STABLE_ODB
    assert get(mem,nb.STABLE_ODB,1)==local and get(mem,nb.STABLE_ODB+1,1)==1-local
    assert get(mem,nb.STABLE_ODB+2,1)==2 and get(mem,nb.STABLE_ODB+3)==1
    assert get(mem,nb.STABLE_ODB+7)==get(mem,0x804D5F90)==0x76543210
    assert get(mem,nb.STABLE_ODB+nb.ODB_DELAY_FRAMES,1)==min(15,max(1,delay))
    assert get(mem,nb.STABLE_ODB+nb.ODB_TXB_ADDR)==nb.STABLE_TXB
    assert get(mem,nb.STABLE_SSCB+1,1)==7 and get(mem,nb.STABLE_SSRB+5)==nb.STABLE_ODB
    assert get(mem,nb.STABLE_ODB+0xABB)==BASE+len(code)-4
    assert get(mem,0x81030001,2)==4
    assert get(mem,R13+nb.OFST_R13_ARENA_HI)==nb.SESSION_HIGH_BASE
    for i in range(0,len(raw),12):assert get(mem,int.from_bytes(raw[i:i+4],'big'))==int.from_bytes(raw[i+8:i+12],'big')
    # A fresh attempt with any unsupported guard must leave the entire island alone.
    put(mem,int.from_bytes(raw[:4],'big'),0xDEADBEEF)
    before={k:v for k,v in mem.items() if nb.SESSION_HIGH_BASE<=k<0x81800000}
    out=execute(code,BASE,mem=mem,initial_regs={3:MSRB,13:R13})
    assert out['regs'][3]==0
    assert before=={k:v for k,v in mem.items() if nb.SESSION_HIGH_BASE<=k<0x81800000}

@pytest.mark.parametrize('index',range(6))
def test_link_backdrop_created_positioned_unhidden_and_animated(index):
    mem={};put(mem,STATE,0xAC+index,1);gobj=0x81020000;jobj=gobj+0x100
    put(mem,gobj+0x28,jobj);events=[]
    def create(r,m):assert r[3]==5;events.append('create');r[3]=gobj
    def marker(r,m):
        assert r[3]==0xBD+index
        for i,v in enumerate((0x447A0000,0x43FA0000,0)):put(m,r[4]+i*4,v)
        r[3]=1
    def visible(r,m):assert (r[3],r[4])==(jobj,0x10);events.append('visible')
    def animate(r,m):assert (r[3],r[4],r[5])==(gobj,5,0);events.append('animate')
    def no_node(r,m):r[3]=0
    code=sr.stage_init(BASE,STATE,RETAIL)
    execute(code,BASE,mem=mem,callees={RETAIL:lambda r,m:None,0x801C2BA4:no_node,
        0x80057BC0:lambda r,m:None,0x801C3FA4:no_node,0x802088C0:create,
        0x801C2D24:marker,0x803732E8:lambda r,m:None,0x80371F9C:visible,
        0x801C8138:animate,0x80030AE0:lambda r,m:None,0x8002F474:lambda r,m:None})
    assert events==['create','visible','animate']
    assert [get(mem,jobj+0x38+i*4) for i in range(3)]==[0x447A0000,0x43FA0000,0]

def test_corneria_enters_versus_without_fox_intro():
    assert STAGES[3].entry_state==STAGES[3].play_state==0x2B and STAGES[3].mode=='versus'
