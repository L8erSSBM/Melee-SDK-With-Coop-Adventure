"""Direct Page 2 bootstrap: no retail match or stage preload is executed.

The negotiated positive u16 selection ID is consumed before Online Splash.
Only the supported live Slippi runtime is armed. All memory/code checks precede
session writes; rejection returns to Online CSS without loading a stage.
"""
from .early_clear_failsafe import Asm
from .ppc import *
from . import slippi_adventure_netplay_bridge as nb
from . import slippi_direct_gateway as dg

SPECIAL_BASE = 0x7000
HOOK = 0x801A4014
MSRB_MATCH = 0x256
MSRB_ALT = 0x3C1

def lhz(rd,offset,ra): return nb.struct.pack('>I',(40<<26)|(rd<<21)|(ra<<16)|(offset&65535))
def sth(rs,offset,ra): return nb.struct.pack('>I',(44<<26)|(rs<<21)|(ra<<16)|(offset&65535))

def call(a, target): a.emit(encode_branch(a.base+len(a.data),target,link=True))
def store(a,address,reg=11):
    a.constant(12,address);a.emit(stb(reg,0,12))

def build_arm(base, *, state_addr, patch_table_addr, txrx_blob_addr,
              ss_blob_addr, ssrb_meta_blob_addr, **unused):
    """r3 = validated fresh MSRB; build a native-format session in reserved MEM1."""
    a=Asm(base);a.emit(addi(9,3,0))
    # Reject all incompatible code before reserving memory or changing hooks.
    a.constant(8,patch_table_addr);a.emit(li(7,len(nb.GUARDS)+1),nb._mtctr(7))
    a.label('validate')
    a.emit(lwz(6,0,8),lwz(10,0,6),lwz(11,4,8),cmpw(10,11,crf=7))
    a.branch('validated',12,30)
    # Menu restore deliberately retains our EXI veneer for late cleanup. A
    # second launch must accept that EXACT owned branch, but no foreign hook.
    a.constant(11,nb.SLIPPI_EXI_VENEER);a.emit(cmpw(6,11,crf=7));a.branch('reject',4,30)
    a.emit(lwz(11,8,8),cmpw(10,11,crf=7));a.branch('reject',4,30)
    a.label('validated')
    a.emit(addi(8,8,12));a.branch('validate',16,0)
    a.emit(lwz(10,nb.OFST_R13_ARENA_HI,13));a.constant(11,nb.SESSION_HIGH_BASE)
    a.emit(nb._cmplw(10,11,crf=7));a.branch('reject',12,28)
    a.constant(12,state_addr);a.emit(stw(10,nb.S_ORIG_ARENA_HI,12),stw(11,nb.OFST_R13_ARENA_HI,13))
    # Include the ODB alignment padding and every child buffer, not identity data.
    a.constant(8,nb.STABLE_ODB);a.emit(li(7,0xFC0//4),nb._mtctr(7),li(10,0))
    a.label('zero');a.emit(stw(10,0,8),addi(8,8,4));a.branch('zero',16,0)
    a.constant(8,nb.STABLE_ODB)
    for src,dst in ((3,0),(4,1)):
        a.emit(lbz(10,src,9),stb(10,dst,8))
    a.emit(lbz(10,-0x5108,13),stb(10,2,8),li(10,1),stw(10,nb.ODB_FRAME,8),
           lwz(10,5,9),stw(10,nb.ODB_RNG_OFFSET,8))
    a.constant(12,0x804D5F90);a.emit(stw(10,0,12))
    a.emit(lbz(10,9,9),cmpwi(10,1,crf=7));a.branch('delay_min',12,28)
    a.emit(cmpwi(10,15,crf=7));a.branch('delay_max',12,29);a.branch('delay_ready')
    a.label('delay_min');a.emit(li(10,1));a.branch('delay_ready')
    a.label('delay_max');a.emit(li(10,15))
    a.label('delay_ready');a.emit(stb(10,nb.ODB_DELAY_FRAMES,8))
    # SDK scene callbacks own completion; the guarded native game-end block is
    # bypassed while armed, so its optional callback is a safe no-op.
    # Supported installed InitOnlinePlay stores this pointer at ODB+0xABB.
    a.constant(10,base);a.emit(stw(10,0xABB,8))  # fixed up to final blr below
    callback_fix=len(a.data)-12
    for source,dest,size,label in ((txrx_blob_addr,nb.STABLE_ODB+nb.ODB_TXB_ADDR,8,'txrx'),
            (ss_blob_addr,nb.STABLE_ODB+nb.ODB_SSRB_ADDR,8,'ss'),
            (ssrb_meta_blob_addr,nb.STABLE_SSRB+5,24,'meta')):
        a.constant(3,source);nb._emit_copy(a,src_reg=3,dst=dest,size=size,label=label)
    a.constant(12,nb.STABLE_SSCB);a.emit(li(10,7),stb(10,1,12))
    # Match native Direct game numbering and discard confirm-button holds.
    a.absolute(8,0x803DAD40);a.emit(lwz(8,0x88,8),lhz(10,1,8),addi(10,10,1),sth(10,1,8))
    a.constant(8,0x804C20BC);a.emit(li(10,0))
    for i in range(4):a.emit(stw(10,i*68,8))
    a.constant(8,nb.STABLE_ODB);a.emit(stw(8,nb.OFST_R13_ODB_ADDR,13))
    a.constant(12,state_addr)
    for src,dst in ((0,nb.S_LOCAL_INDEX),(1,nb.S_ARM_ONLINE_INDEX),(2,nb.S_ARM_INPUT_SOURCE_INDEX)):
        a.emit(lbz(10,src,8),stb(10,dst,12))
    a.emit(li(10,0))
    for off in (nb.S_WARMUP_B0_COUNT,nb.S_B0_COUNT,nb.S_B1_COUNT,nb.S_B2_COUNT,
                nb.S_LAST_B1_FRAME,nb.S_LAST_B2_FRAME,nb.S_TRANSITION_RESET_COUNT,
                nb.S_BATCH_FRAME,nb.S_SIM_FRAME):a.emit(stw(10,off,12))
    a.emit(stb(10,nb.S_SNAPSHOT_PATCHED,12),stb(10,nb.S_FAILURE,12))
    a.constant(8,patch_table_addr);a.emit(li(7,len(nb.GUARDS)+1),nb._mtctr(7))
    a.label('patch')
    a.emit(lwz(6,0,8),lwz(11,8,8),stw(11,0,6),nb._dcbst(0,6),nb._sync(),nb._icbi(0,6),addi(8,8,12))
    a.branch('patch',16,0);a.emit(nb._sync(),nb._isync())
    a.constant(12,state_addr);a.emit(li(11,nb.PHASE_TRANSITION),stb(11,nb.S_PHASE,12),
        li(11,nb.TRACE_ARMED),stb(11,nb.S_TRACE,12),li(3,1),blr())
    a.label('reject');a.constant(12,state_addr)
    a.emit(li(11,0x20),stb(11,nb.S_FAILURE,12),li(3,0),blr())
    blob=bytearray(a.finish())
    fix=Asm(base+callback_fix);fix.constant(10,base+len(blob)-4)
    blob[callback_fix:callback_fix+8]=fix.finish()
    return bytes(blob)

def build_gateway(base,retail,*,state_addr,gateway_pending_addr,p2_identity_valid_addr,
                  netplay_arm_addr,canonical_valid_addr,canonical_local_addr,
                  canonical_remote_addr,canonical_players_addr,standalone_stages=False,
                  **identities):
    a=Asm(base)
    for address,value in ((dg.GM_CURRENT_MODE_ADDR,8),(dg.GM_SCENE_BYTE3_ADDR,4)):
        a.absolute(11,address,byte=True);a.emit(cmpwi(11,value,crf=7));a.branch('retail',4,30)
    a.emit(lbz(11,dg.OFST_R13_ONLINE_MODE,13),cmpwi(11,2,crf=7));a.branch('retail',4,30)
    a.emit(lwz(8,dg.OFST_R13_GM_MAINLIB,13),lhz(11,dg.DIRECT_MATCH_DATA_OFFSET+0xE,8),
           cmpwi(11,SPECIAL_BASE+0xA5,crf=7));a.branch('retail',12,28)
    a.emit(cmpwi(11,SPECIAL_BASE+0xB2,crf=7));a.branch('retail',12,29)
    a.emit(stwu(1,-0x30,1),mflr(0),stw(0,0x34,1),stw(30,0x28,1),stw(31,0x2C,1),
           addi(30,11,0),li(3,0));call(a,0x80005610);a.emit(addi(31,3,0))
    a.emit(cmpwi(31,0,crf=7));a.branch('reject',12,30)
    # Both peers must see the same locked selection, two humans, and valid roles.
    for off,value in ((1,1),(2,1),(MSRB_MATCH+0x61,0),(MSRB_MATCH+0x85,0)):
        a.emit(lbz(11,off,31),cmpwi(11,value,crf=7));a.branch('reject',4,30)
    a.emit(lhz(11,MSRB_MATCH+0xE,31),cmpw(11,30,crf=7));a.branch('reject',4,30)
    a.emit(addi(30,30,-SPECIAL_BASE),lbz(11,MSRB_ALT,31),cmpw(11,30,crf=7));a.branch('reject',4,30)
    if not standalone_stages:
        a.emit(cmpwi(30,0xA5,crf=7));a.branch('reject',4,30)
    a.emit(lbz(10,3,31),lbz(11,4,31),cmpwi(10,1,crf=7));a.branch('reject',12,29)
    a.emit(cmpwi(11,1,crf=7));a.branch('reject',12,29)
    a.emit(cmpw(10,11,crf=7));a.branch('reject',12,30)
    a.emit(addi(3,31,0));call(a,netplay_arm_addr)
    a.emit(cmpwi(3,1,crf=7));a.branch('reject',4,30)
    store(a,state_addr+dg.S_ALT_MODE,30)
    # Canonical identities come from this fresh negotiated MSRB on BOTH peers.
    a.emit(addi(3,31,MSRB_MATCH+0x60))
    nb._emit_copy(a,src_reg=3,dst=canonical_players_addr,size=0x48,label='players')
    for off,dest in ((3,canonical_local_addr),(4,canonical_remote_addr)):
        a.emit(lbz(11,off,31));store(a,dest)
    a.emit(addi(8,31,MSRB_MATCH));dg._snapshot_identity(a,8,**identities)
    a.emit(li(11,1))
    for dest in (canonical_valid_addr,p2_identity_valid_addr,gateway_pending_addr):store(a,dest)
    a.emit(li(11,0));store(a,dg.SLIPPI_ALT_MODE_STATIC)
    a.emit(li(11,dg.TRACE_ADVENTURE_REQUESTED));store(a,state_addr+dg.S_TRACE)
    a.emit(addi(3,31,0));call(a,nb.HSD_MEM_FREE)
    a.emit(li(3,4));call(a,dg.GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE)
    a.branch('done')
    a.label('reject')
    a.emit(li(11,dg.TRACE_NETPLAY_REJECTED));store(a,state_addr+dg.S_TRACE)
    a.emit(li(11,0));store(a,dg.SLIPPI_ALT_MODE_STATIC)
    a.emit(cmpwi(31,0,crf=7));a.branch('no_buffer',12,30)
    a.emit(addi(3,31,0));call(a,nb.HSD_MEM_FREE)
    a.label('no_buffer');a.emit(li(3,0));call(a,0x801A428C) # set current state, not next
    a.label('done');a.emit(lwz(30,0x28,1),lwz(31,0x2C,1),lwz(0,0x34,1),mtlr(0),addi(1,1,0x30),blr())
    a.label('retail');a.emit(encode_branch(a.base+len(a.data),retail))
    return a.finish()

def install(dol,runtime_index,**kwargs):
    # The bridge's menu-return wrapper already owns this entry. Preserve it.
    current=dol.read_at_address(HOOK,4);retail=decode_branch(HOOK,current)['target']
    section=next(s for s in dol.sections if s.kind=='data' and s.index==runtime_index)
    base=(section.end_address+31)&~31
    kwargs.pop('early_exi_wrapper',None)
    code=build_gateway(base+dg.STATE_SIZE,retail,state_addr=base,**kwargs)
    data=bytearray(dg.STATE_SIZE);data[:4]=b'DIR3';data+=code;data+=bytes((-len(data))%32)
    added=dol.append_to_data_section(runtime_index,data)
    assert added['address']==base
    dol.patch_at_address(HOOK,encode_branch(HOOK,base+dg.STATE_SIZE),expected=current)
    return {'state_address':base,'alt_mode_trace_address':base+dg.S_ALT_MODE,
        'trace_address':base+dg.S_TRACE,'wrapper':base+dg.STATE_SIZE,'wrapper_size':len(code),
        'hook':HOOK,'carrier_stage':None,'special_selection_base':SPECIAL_BASE,
        'gateway_stage_policy':'negotiated Page 2 ID -> native-format session -> SDK major; no retail stage',
        'live_gameplay_validated':False}
