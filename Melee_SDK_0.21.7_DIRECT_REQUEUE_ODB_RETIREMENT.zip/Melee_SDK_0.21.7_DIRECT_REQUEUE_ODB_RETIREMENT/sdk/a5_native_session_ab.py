"""0.21.4 diagnostic: A5 Co-op Adventure uses the proven 0.21.2 native session bootstrap.

A6-B2 remain on 0.21.4's carrier-free direct launcher.  To avoid growing the
16 KiB SDK ArenaLo reservation, the A5-only arm/bootstrap is emitted into two
verified zero-filled padding caves in retail DOL text section 0.  No retail
instruction is replaced there; installation fails closed if either cave is not
all zero on the input DOL.
"""
from __future__ import annotations

from .ppc import encode_branch
from . import slippi_adventure_netplay_bridge as nb
from . import slippi_direct_gateway as dg

# GALE01 1.02 text0 zero padding. Both ranges are present as zero-filled padding
# in the 0.21.2 and 0.21.4 packaged start.dol lineage.
CAVE_GATEWAY = 0x80003BCC
CAVE_GATEWAY_SIZE = 0x2CC
CAVE_ARM = 0x800049CC
CAVE_ARM_SIZE = 0x4CC


def _align4(v: int) -> int:
    return (v + 3) & ~3


def _require_zero(dol, address: int, size: int, label: str) -> None:
    got = dol.read_at_address(address, size)
    if got != bytes(size):
        raise ValueError(f'A5 native-session diagnostic {label} cave is not zero-filled at {address:#x}')


def install(dol, *, bridge: dict, gateway_pending_addr: int,
            p1_ckind_addr: int, p1_color_addr: int,
            p1_subcolor_addr: int, p1_nametag_addr: int,
            p2_identity_valid_addr: int,
            p2_ckind_addr: int, p2_color_addr: int,
            p2_subcolor_addr: int, p2_nametag_addr: int,
            canonical_valid_addr: int, canonical_local_addr: int,
            canonical_remote_addr: int, canonical_players_addr: int) -> dict:
    """Install only the 0.21.2-style A5 carrier/native-session handoff."""
    _require_zero(dol, CAVE_GATEWAY, CAVE_GATEWAY_SIZE, 'gateway')
    _require_zero(dol, CAVE_ARM, CAVE_ARM_SIZE, 'arm')

    # Preserve the 0.21.2 live ODB/child-buffer capture/relocation routine.
    native_arm_addr = CAVE_ARM
    native_arm = nb.build_arm_stub(
        native_arm_addr,
        state_addr=bridge['state_address'], guard_shims={},
        exi_wrapper_addr=bridge['exi_wrapper'],
        patch_table_addr=bridge['patch_table'],
        txrx_blob_addr=bridge['txrx_blob'],
        ss_blob_addr=bridge['savestate_blob'],
        ssrb_meta_blob_addr=bridge['ssrb_metadata_blob'],
        canonical_valid_addr=canonical_valid_addr,
        canonical_local_addr=canonical_local_addr,
        canonical_remote_addr=canonical_remote_addr)

    # The HUD-init phase fits beside the native arm if its redundant early EXI
    # pre-install is omitted. build_arm_stub itself validates and installs that
    # same EXI veneer before Adventure is requested, so session semantics stay
    # native while the diagnostic remains within verified executable padding.
    hud_addr = _align4(native_arm_addr + len(native_arm))

    state_addr = CAVE_GATEWAY
    preload_trampoline_addr = state_addr + dg.STATE_SIZE
    preload_trampoline = dg.EXPECTED + encode_branch(preload_trampoline_addr + 4, dg.HOOK + 4)
    scene_trampoline_addr = preload_trampoline_addr + len(preload_trampoline)
    scene_trampoline = dg.SCENE_LOOP_EXPECTED + encode_branch(scene_trampoline_addr + 4, dg.SCENE_LOOP_HOOK + 4)
    preload_wrapper_addr = _align4(scene_trampoline_addr + len(scene_trampoline))

    common_ids = dict(
        p1_ckind_addr=p1_ckind_addr, p1_color_addr=p1_color_addr,
        p1_subcolor_addr=p1_subcolor_addr, p1_nametag_addr=p1_nametag_addr,
        p2_ckind_addr=p2_ckind_addr, p2_color_addr=p2_color_addr,
        p2_subcolor_addr=p2_subcolor_addr, p2_nametag_addr=p2_nametag_addr)
    preload_wrapper = dg.build_wrapper(
        preload_wrapper_addr, preload_trampoline_addr,
        state_addr=state_addr, gateway_pending_addr=gateway_pending_addr,
        p2_identity_valid_addr=p2_identity_valid_addr,
        netplay_arm_addr=native_arm_addr,
        canonical_valid_addr=canonical_valid_addr,
        canonical_players_addr=canonical_players_addr,
        **common_ids)
    hud_wrapper = dg.build_ingame_bootstrap_wrapper(
        hud_addr, scene_trampoline_addr,
        state_addr=state_addr, gateway_pending_addr=gateway_pending_addr,
        p2_identity_valid_addr=p2_identity_valid_addr,
        netplay_arm_addr=native_arm_addr,
        early_exi_wrapper=None,
        standalone_stages=False)

    gateway_end = preload_wrapper_addr + len(preload_wrapper)
    arm_end = hud_addr + len(hud_wrapper)
    if gateway_end > CAVE_GATEWAY + CAVE_GATEWAY_SIZE:
        raise ValueError('A5 native-session gateway cave overflow')
    if arm_end > CAVE_ARM + CAVE_ARM_SIZE:
        raise ValueError('A5 native-session arm cave overflow')

    gateway_blob = bytearray(CAVE_GATEWAY_SIZE)
    gateway_blob[0:4] = dg.MARKER
    gateway_blob[dg.S_TRACE] = 0
    gateway_blob[dg.S_ONLINE_MODE] = 0xFF
    gateway_blob[dg.S_MAJOR] = 0xFF
    gateway_blob[dg.S_STAGE] = 0xFF
    gateway_blob[dg.S_P1_TYPE] = 0xFF
    gateway_blob[dg.S_P2_TYPE] = 0xFF
    gateway_blob[dg.S_REQUEST_COUNT] = 0
    gateway_blob[dg.S_VERSION] = 3
    gateway_blob[dg.S_NETPLAY_ARM_RESULT] = 0xFF
    gateway_blob[dg.S_BOOTSTRAP_PENDING] = 0
    gateway_blob[dg.S_BOOTSTRAP_WAIT] = 0
    gateway_blob[dg.S_ALT_MODE] = 0xFF
    for addr, blob in ((preload_trampoline_addr, preload_trampoline),
                       (scene_trampoline_addr, scene_trampoline),
                       (preload_wrapper_addr, preload_wrapper)):
        off = addr - CAVE_GATEWAY
        gateway_blob[off:off+len(blob)] = blob

    arm_blob = bytearray(CAVE_ARM_SIZE)
    arm_blob[0:len(native_arm)] = native_arm
    off = hud_addr - CAVE_ARM
    arm_blob[off:off+len(hud_wrapper)] = hud_wrapper

    dol.patch_at_address(CAVE_GATEWAY, bytes(gateway_blob), expected=bytes(CAVE_GATEWAY_SIZE))
    dol.patch_at_address(CAVE_ARM, bytes(arm_blob), expected=bytes(CAVE_ARM_SIZE))
    dol.patch_at_address(dg.HOOK, encode_branch(dg.HOOK, preload_wrapper_addr), expected=dg.EXPECTED)
    dol.patch_at_address(dg.SCENE_LOOP_HOOK, encode_branch(dg.SCENE_LOOP_HOOK, hud_addr), expected=dg.SCENE_LOOP_EXPECTED)

    return {
        'diagnostic': '0.21.4 + 0.21.2 A5 native Slippi session bootstrap only',
        'carrier_stage': dg.CARRIER_STAGE,
        'adventure_alt_marker': dg.ADVENTURE_ALT_MARKER,
        'state_address': state_addr,
        'preload_hook': dg.HOOK,
        'preload_wrapper': preload_wrapper_addr,
        'hud_hook': dg.SCENE_LOOP_HOOK,
        'hud_wrapper': hud_addr,
        'native_arm': native_arm_addr,
        'native_arm_size': len(native_arm),
        'gateway_cave_used': gateway_end - CAVE_GATEWAY,
        'gateway_cave_capacity': CAVE_GATEWAY_SIZE,
        'arm_cave_used': arm_end - CAVE_ARM,
        'arm_cave_capacity': CAVE_ARM_SIZE,
        'early_exi_policy': 'native arm validates/installs EXI veneer before Adventure request',
        'scope': 'A5 only; A6-B2 remain on 0.21.4 slippi_direct_launch',
    }
