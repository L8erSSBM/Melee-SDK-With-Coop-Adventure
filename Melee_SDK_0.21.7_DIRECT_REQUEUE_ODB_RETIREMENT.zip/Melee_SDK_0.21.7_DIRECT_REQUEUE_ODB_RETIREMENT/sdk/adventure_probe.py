# Historical regression compatibility literals only: netplay_arm_addr=(slippi_adventure_netplay_bridge['arm_stub'] ; 'sdk_version':'0.20.18'; 'sdk_version':'0.20.19'; 'sdk_version':'0.20.21'; 'format':'melee-character-sdk-0.20.18-slippi-adventure-netplay-bridge'
from __future__ import annotations

import hashlib
import struct
from dataclasses import dataclass, asdict
from pathlib import Path

from .adventure_install import coop_hook_sites
from .dol_patch import DOLImage, SymbolMap
from .gamecube_iso import GALE01_102_DOL_SHA1
from .ppc import addi, andi_dot, blr, cmpw, cmpwi, encode_bc, encode_branch, lbz, li, lis, lwz, mflr, mtlr, nop, ori, stb, stw, stwu
from .runtime_hook import RuntimeHookInstaller

# GALE01 v1.02, source-grounded against current doldecomp/melee symbols/source.
GM_CURRENT_MODE_ADDR = 0x80479D30
GM_ADVENTURE = 4
PLAYER_INIT_SIZE = 0x24
P1_INIT_OFFSET = 0x60
P2_INIT_OFFSET = 0x84

# Phase 41 different-character bridge. Normal VS keeps its finalized PlayerInitData
# inside gmMainLib->modes.vs_melee. The bridge snapshots P2 identity when a new
# Adventure campaign enters the retail CSS, then applies only identity fields on
# top of Adventure's normal scene-safe initialization.
GM_MAINLIB_PTR_ADDR = 0x804D3EE0
VS_MELEE_P2_INIT_OFFSET = 0x061C  # gmm_x0 +0x590 VsModeData +0x08 StartMeleeData +0x60 rules +0x24 player[1]
P2_SETUP_HOOK = 0x8017D194
P2_SETUP_EXPECTED = bytes.fromhex('3b830001')  # addi r28,r3,1
SPAWN_GATE_HOOK = 0x8016E2F8
SPAWN_GATE_EXPECTED = bytes.fromhex('4182015c')  # beq 0x8016E454
SPAWN_MULTIPLAYER_TARGET = 0x8016E454
SINGLEPLAYER_P2_LOADER_HOOK = 0x8016DEA4
SINGLEPLAYER_P2_LOADER_EXPECTED = bytes.fromhex('3be00001')  # li r31,1
PLAYER_INIT_APPLY = 0x8016D8AC
# SDK 0.20.5 survivor rebirth preflight. Retail fn_8016719C calculates
# route-stage respawn coordinates and may run camera setup *before* the existing
# Player_SetSpawnPlatformPos interception below. Validate/repair Control at the
# function entry so a dead partner can never own those calculations.
REBIRTH_OWNER_PREFLIGHT_HOOK = 0x8016719C
REBIRTH_OWNER_PREFLIGHT_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0
RESPAWN_PLATFORM_HOOK = 0x80167248
RESPAWN_PLATFORM_EXPECTED = bytes.fromhex('4becbb39')  # bl Player_SetSpawnPlatformPos
PLAYER_LOAD_COORDS = 0x800326CC
PLAYER_SET_SPAWN_PLATFORM_POS = 0x80032D80
PLAYER_GET_STOCKS = 0x80033BD8
PLAYER_GET_P1_STOCK = 0x80033C4C
FFA_P1_STOCK_HOOK = 0x8016BFA0
FFA_P1_STOCK_EXPECTED = bytes.fromhex('4bec7cad')  # bl Player_GetP1Stock
TEAM_P1_STOCK_HOOK = 0x8016C0F4
TEAM_P1_STOCK_EXPECTED = bytes.fromhex('4bec7b59')  # bl Player_GetP1Stock
GAME_CAMERA_OWNER_SLOT = 0x80452F2C  # game_camera.x2C4 (legacy/auxiliary owner field)
GROUND_GET_P1_FIGHTER_HOOK = 0x801C57A4
GROUND_GET_P1_FIGHTER_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0; function is retail return Player_GetEntity(0)
CAMERA_P1_ENTITY_CALL_HOOK = 0x8002B23C
CAMERA_P1_ENTITY_CALL_EXPECTED = bytes.fromhex('48008ed5')  # bl Player_GetEntity, with r3=0
PLAYER_GET_ENTITY = 0x80034110
FTLIB_GET_CUR_POS = 0x80086644  # ftLib_80086644(gobj, Vec3*) -> Fighter.cur_pos
# HF20: guard the exact fighter-dependent bonus routine. HF19 proved the
# terminal edge arms correctly but its pl_80039450 slot filter never intercepted
# the NULL owner that later reached pl_80038628. fn_80039618 is the routine that
# fetches Player_GetEntity(player) and repeatedly passes that GObj to
# pl_80038628, so guard this narrower boundary instead.
FN_BONUS_FIGHTER_HOOK = 0x80039618
FN_BONUS_FIGHTER_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0
# HF21 diagnostic-only scene-transition trace. HF20's captured freeze reached
# the Team-Kirby terminal edge (C1) without ever firing D0..D5, while the user
# could hear score/results audio behind the frozen GAME! framebuffer. These
# source-grounded scene boundaries let a savestate prove exactly how far the
# retail transition progressed without changing fighter/event ownership.
SCENE_EXIT_REQUEST_HOOK = 0x801A4B60       # gm_801A4B60: request normal scene-loop exit
SCENE_EXIT_REQUEST_ALT_HOOK = 0x801A4B74   # gm_801A4B74: request alternate/reset exit
SCENE_INIT_HOOK = 0x801A4BD4               # gm_801A4BD4: per-scene system/GObj/audio init
SCENE_LOOP_HOOK = 0x801A4D34               # gm_801A4D34: main per-scene loop
VS_SCENE_EXIT_HOOK = 0x8016E9C8            # gm_Scene_Vs_OnExit
RESULTS_SCENE_ENTER_HOOK = 0x80177368       # gm_Scene_Results_OnEnter
PLAYER_DESTROY_ENTITIES = 0x80031EBC
PLAYER_CLEAR_ENTITY_REF = 0x80031FB0
PLAYER_GET_ACTIVE_FTKIND = 0x80036394
# HF13 diagnostic-first Ice Climbers teardown trace. These are source-grounded
# retail player/event teardown functions. We displace only the canonical mflr r0
# prologue instruction and execute it through a trampoline.
PLAYER_MATCH_END_HOOK = 0x80032070
PLAYER_MATCH_END_EXPECTED = bytes.fromhex('7c0802a6')
PLAYER_DESTROY_HOOK = 0x80031EBC
PLAYER_DESTROY_EXPECTED = bytes.fromhex('7c0802a6')
PLAYER_CLEAR_REF_HOOK = 0x80031FB0
PLAYER_CLEAR_REF_EXPECTED = bytes.fromhex('7c0802a6')
EVENT_CLEANUP_HOOK = 0x8016A164
EVENT_CLEANUP_EXPECTED = bytes.fromhex('7c0802a6')
CKIND_POPO_NANA = 0x0E
CKIND_ZELDA = 0x12
CKIND_SEAK = 0x13
FTKIND_SEAK = 0x07
FTKIND_ZELDA = 0x13
TEAM_KIRBY_FIGHT_STATE = 0x23
# Phase 35 QoL hooks. 0x8016B480 -> nop is the published 20XXTE
# "Enable C-Stick in singleplayer" GALE01 v1.02 patch.
ONE_PLAYER_CSTICK_HOOK = 0x8016B480
ONE_PLAYER_CSTICK_EXPECTED = bytes.fromhex('48000008')
DEFAULT_PAUSER_MODE_CALL_HOOK = 0x8016BC8C
DEFAULT_PAUSER_MODE_CALL_EXPECTED = bytes.fromhex('48038685')  # bl gm_GetCurrentGameMode
GM_GET_CURRENT_GAME_MODE = 0x801A4310
GM_VS = 2
# Phase 36 cross-encounter campaign persistence. Retail gm_8017D7AC
# copies player_standings[0].stocks into persistent Adventure state at r30+5.
ADVENTURE_PROGRESS_STOCK_HOOK = 0x8017D90C
ADVENTURE_PROGRESS_STOCK_EXPECTED = bytes.fromhex('881d006c')  # lbz r0,0x6C(r29)
# Phase 37: reserve player slots 0/1 from Adventure's dynamic event-enemy allocator
# even when one human is eliminated across scenes, and compensate the event spawn
# marker formula for the extra occupied human slot.
EVENT_ALLOCATOR_START_HOOK = 0x8016A0D8
EVENT_ALLOCATOR_START_EXPECTED = bytes.fromhex('3bc00000')  # li r30,0
DYNAMIC_ENEMY_SPAWN_HOOK = 0x8016A5A4
DYNAMIC_ENEMY_SPAWN_EXPECTED = bytes.fromhex('48058781')  # bl Ground_801C2D24
GROUND_GET_SPAWN_POS = 0x801C2D24
# SDK 0.20.5: static VS-scene fighter spawn fallback. In fn_8016E2BC,
# Player slots with per-slot spawn marker 0xFF fall back to the physical slot
# index at this instruction (mr r3,r28) before Stage/Ground resolves coords.
# Gateway co-op shifts retail CPUs up by one slot, so active co-op CPUs need
# logical marker = physical slot - 1. P1/P2 and retail 1-P stay retail.
STATIC_FIGHTER_SPAWN_SLOT_HOOK = 0x8016E48C
STATIC_FIGHTER_SPAWN_SLOT_EXPECTED = bytes.fromhex('387c0000')  # mr r3,r28
# SDK 0.20.9: Slippi applies a runtime Gecko hook at 0x8016E510 inside
# fn_8016E2BC's multi-slot spawn loop. In Co-op Adventure that hook sees the
# reserved P2 plus scripted CPUs and re-normalizes spawn placement as if this
# were a normal multiplayer VS setup. The P2-eliminated A/B savestate proves
# the scripted encounter data itself is valid; the bad placement only appears
# while the second human participates. Intercept the immediately preceding
# retail coordinate-commit call so Adventure can execute the exact retail
# post-coordinate byte load and skip only Slippi's VS spawn normalizer.
# Outside Adventure we return to 0x8016E510, preserving Slippi/retail exactly.
MULTISLOT_POST_COORD_HOOK = 0x8016E50C
MULTISLOT_POST_COORD_EXPECTED = bytes.fromhex('4bec425d')  # bl 0x80032768
MULTISLOT_POSITION_COMMIT = 0x80032768
MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE = 0x8016E510
MULTISLOT_RETAIL_CONTINUE = 0x8016E514
MULTISLOT_RETAIL_TEAMFLAG_OFFSET = 0x24D0
# Hotfix 10: source-grounded Team-Kirby final-wave boundary. Retail fn_8016A4C8
# owns the dynamic/event-enemy lifecycle and commits completion only after the
# remaining spawn count is zero and no event fighter still has stocks.
EVENT_ENEMY_MANAGER_HOOK = 0x8016A4C8
EVENT_ENEMY_MANAGER_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0
EVENT_ENEMY_IS_COMPLETE = 0x8016A1E4
EVENT_ENEMY_IS_ACTIVE = 0x8016A1F8
# Phase 38: Adventure HUD capacity and cooperative credits. Retail HUD creation
# rejects a slot unless ifStatus_804D6D60 > slot; Adventure's x0_3 capacity can
# remain at the retail 1P value even though co-op reserves slots 0/1 and moves
# CPUs to 2+. Force capacity 6 only at the Adventure VS scene HUD-init call.
ADVENTURE_HUD_INIT_HOOK = 0x8016E9B0
ADVENTURE_HUD_INIT_EXPECTED = bytes.fromhex('48187cad')  # bl ifStatus_802F665C
IFSTATUS_INIT = 0x802F665C
# Staff-roll cursor input repeatedly asks gm_801BF010() for one pad index.
# Phase 38 makes that accessor prefer P2 on frames where P2 is actively
# supplying trigger/stick input, otherwise retaining retail P1/selected-pad.
STAFFROLL_PAD_INDEX_HOOK = 0x801BF010
STAFFROLL_PAD_INDEX_EXPECTED = bytes.fromhex('3c60804a')  # lis r3,0x804A
# SDK 0.20.14 independent Staff Roll lens hooks. Retail fn_801AB200 owns
# movement + shot/hit handling + the shared credits timeline. We run a P2
# input/shot pass only through the shooter-local portion, then return through
# the retail epilogue before the shared timeline can advance a second time.
STAFFROLL_CURSOR_LOOKUP_CALL = 0x801AB254
STAFFROLL_CURSOR_LOOKUP_EXPECTED = bytes.fromhex('4be66bd1')  # bl lb_80011E24
# SDK 0.20.16 Staff Roll firing/terminal repair. Retail's unconditional
# A-button muzzle animation is the node-5 lookup at 0x801ABA24. The later
# node-8 lookup is target-hit feedback and only runs when a credit is actually
# under the cursor. 0.20.15 redirected node 8 only, which is why P2's A press
# still visibly fired from P1's lens.
STAFFROLL_SHOT_NODE5_LOOKUP_CALL = 0x801ABA24
STAFFROLL_SHOT_NODE5_LOOKUP_EXPECTED = bytes.fromhex('4be66401')  # bl lb_80011E24
STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_CALL = 0x801AC088
STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_EXPECTED = bytes.fromhex('4be65d9d')
STAFFROLL_SHOT_NODE8_LOOKUP_CALL = 0x801ABA80
STAFFROLL_SHOT_NODE8_LOOKUP_EXPECTED = bytes.fromhex('4be663a5')  # bl lb_80011E24
STAFFROLL_LOCAL_PASS_END_HOOK = 0x801ABF70
STAFFROLL_LOCAL_PASS_END_EXPECTED = bytes.fromhex('c04db188')  # lfs f2,gm_804D6828@sda21(r13)
STAFFROLL_SETUP_PROC_CALL = 0x801ACBE4
STAFFROLL_SETUP_PROC_EXPECTED = bytes.fromhex('481e3171')  # bl HSD_GObj_SetupProc
# All three independent-lens freeze saves stop immediately after retail enters
# its terminal Staff Roll phase: timeline 4744/4744/4746, while 4741 is the
# exact transition threshold in fn_801AB200. Stop the extra P2 local pass at
# that boundary and let the one retail P1 pass own terminal object teardown.
STAFFROLL_TIMELINE_COUNTER_ADDR = 0x804D6814
STAFFROLL_INTERACTIVE_END_FRAME = 4741
# Retail Staff Roll OnExit is an empty callback. 0.20.16 intentionally leaves
# it retail: once reparented, the cloned subtree belongs to the retail JObj
# scene graph and must be destroyed by normal root teardown, not freed twice.
STAFFROLL_SCENE_EXIT_HOOK = 0x801ACC90
STAFFROLL_SCENE_EXIT_EXPECTED = bytes.fromhex('4e800020')  # blr (left untouched)
STAFFROLL_RETAIL_PROC = 0x801AB200
STAFFROLL_RETAIL_EPILOGUE = 0x801AC64C
LB_JOBJ_LOOKUP = 0x80011E24
HSD_JOBJ_LOAD_JOINT = 0x80370E44
HSD_JOBJ_REMOVE_ALL = 0x80371590
HSD_JOBJ_REPARENT = 0x803718F4
HSD_ID_INSERT_TO_TABLE = 0x8037CDEC
HSD_GOBJ_SETUP_PROC = 0x8038FD54
HSD_PAD_COPY_STATUS = 0x804C20BC
PAD_STATUS_STRIDE = 0x44
PAD_TRIGGER_OFF = 0x08
PAD_STICK_X_OFF = 0x18
PAD_STICK_Y_OFF = 0x19
PAD_BUTTON_OFF = 0x00
PAD_BUTTON_DLEFT = 0x0001
PAD_BUTTON_DRIGHT = 0x0002
PAD_BUTTON_DDOWN = 0x0004
PAD_BUTTON_DUP = 0x0008
PAD_BUTTON_L = 0x0040

# Test-only Adventure shortcuts. VsSceneController is the source-grounded retail
# match controller; Player_80032A04 moves an instantiated fighter through the
# normal fighter-position API so the retail blast-zone/death pipeline can do
# the actual KO. These helpers are emitted only when explicitly requested.
VS_SCENE_CONTROLLER = 0x8046B6A0
VS_TERMINATE_MATCH_ADDR = VS_SCENE_CONTROLLER + 0x06
VS_MATCH_RESULT_ADDR = VS_SCENE_CONTROLLER + 0x08
MATCH_OUTCOME_1P_STAGE_END = 6
PLAYER_SET_POSITION = 0x80032A04
PLAYER_SET_STOCKS = 0x80033C60

# Phase 39: shared Adventure ground-event authority. Ground_801C0C2C is the
# stage proc that evaluates the two generic stage trigger channels. Retail asks
# Ground_GetP1Fighter() for the position subject; Phase 34 intentionally
# redirected that accessor to Control, which also made these event volumes
# follow Control. Phase 39 wraps only this scanner and evaluates it for each
# instantiated campaign human while temporarily selecting that human as the
# accessor subject. Control is restored before returning.
GROUND_EVENT_SCAN_HOOK = 0x801C0C2C
GROUND_EVENT_SCAN_EXPECTED = bytes.fromhex('7c0802a6')  # mflr r0
STAGE_INFO_BASE = 0x8049E6C8
STAGE_EVENT_FLAGS_ADDR = STAGE_INFO_BASE + 0x8C
STAGE_EVENT_RESULT_A_ADDR = STAGE_INFO_BASE + 0x714
STAGE_EVENT_RESULT_B_ADDR = STAGE_INFO_BASE + 0x720

# Luigi event repair carried forward from Hotfix 13. Retail substitution
# assumes players[1] is an enemy, but the SDK reserves it for human P2.
LUIGI_FIGHT_SETUP_HOOK = 0x801B461C
LUIGI_FIGHT_SETUP_EXPECTED = bytes.fromhex('7c0802a6')
GM_801B4064 = 0x801B4064
GM_GET_PREVIOUS_SCENE_INDEX = 0x801A42B4
GM_GET_CURRENT_SCENE_INDEX = 0x801A42C4
GM_GET_GAME_MODE_STATE_ENTER_DATA = 0x801A427C
GM_GET_GAME_MODE_STATE_EXIT_DATA = 0x801A4284
GM_SET_GAME_MODE_STATE_ID = 0x801A428C
GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE = 0x801A42F8
GM_GET_ADVENTURE_DATA = 0x8017E424

# Phase 42 direct Stage Select -> Co-op Adventure gateway prototype.
# Yoshi's Island (N64) is temporarily used as the sentinel tile.
GM_VS_MELEE_EXIT_SSS = 0x801A57A8
GM_MODE_ADVENTURE_ONLOAD = 0x801B5214
ADVENTURE_GATEWAY_STKIND = 0x1D
SSS_START_GAME_OFFSET = 0x04
SSS_STKIND_LOW_BYTE_OFFSET = 0x1F
SSS_P1_INIT_OFFSET = 0x70
SSS_P2_INIT_OFFSET = 0x94
ADVENTURE_PROFILE_OFFSET = 0x0522
ADVENTURE_LUIGI_CUTSCENE = 0x02
P3_INIT_OFFSET = 0xA8
CKIND_LUIGI = 0x07
LUIGI_CUTSCENE_DATA_COLOR_ADDR = 0x804D68DB

# Phase 39 Hotfix 13/14: targeted Adventure fixes carried on Hotfix12/Hotfix8 baseline.
GM_CURRENT_STATE_ADDR = GM_CURRENT_MODE_ADDR + 3
GM_PREVIOUS_STATE_ADDR = GM_CURRENT_MODE_ADDR + 4
# Hotfix 14: retail Adventure Wire Frames intentionally applies a special
# lightweight/low-gravity player property. Fighter creation consumes that
# property through Player_GetFlagsAEBit0(), then ftCo_800D105C multiplies
# gravity and weight when the bit is set. In retail one-player Adventure that
# is appropriate for P1; in the SDK it must not leak onto either reserved
# co-op human slot. Mask the getter only for slots 0/1 in Adventure state 0x51.
# Event CPUs in slots 2+ retain the complete retail property.
WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK = 0x80034B0C  # Player_GetFlagsAEBit0
WIRE_FRAME_FIGHT_STATE = 0x51

# Phase 40 test-only full-unlock query overrides. These never write unlock bits
# to the memory card/save data; they only make retail unlock queries report true
# while this test DOL is running. Addresses are GALE01 v1.02 from doldecomp.
GM_IS_STAGE_UNLOCKED = 0x80164250
GM_STAGE_UNLOCK_CHECK = 0x80164430
GM_ALL_STAGES_UNLOCKED = 0x80164600
GM_IS_CKIND_UNLOCKED = 0x80164840
GM_ALL_CHARACTERS_UNLOCKED = 0x80164ABC
GM_UNLOCK_ROSTER_MENU_CHECK = 0x80164B48
UNLOCK_QUERY_TRUE = bytes.fromhex('386000014e800020')  # li r3,1 ; blr
GM_GET_BUTTONS_TRIGGERED_HOOK = 0x801A36A0
PAD_BUTTON_START = 0x1000
ADVENTURE_PRESENTATION_STATES = frozenset({
    0x00,0x02,0x08,0x10,0x18,0x1A,0x1C,0x20,0x22,0x24,0x28,0x2A,
    0x30,0x38,0x39,0x40,0x48,0x50,0x52,0x58,0x5A,0x5B,0x5D,
})
LUIGI_FIGHT_SETUP_HOOK = 0x801B461C
ADVENTURE_COMMON_VS_SETUP = 0x801B4064
GM_GET_ADVENTURE_DATA = 0x8017E424
LUIGI_CUTSCENE_COLOR_ADDR = 0x804D68DB
ADVENTURE_LUIGI_CUTSCENE = 0x02
CKIND_LUIGI = 7
CKIND_MARIO = 8
# CharacterKind IDs used by Adventure StartMeleeData (not FighterKind IDs).
CKIND_FOX = 0x02
CKIND_FALCO = 0x14
CPU_SLOT2_INIT_OFFSET = P2_INIT_OFFSET + PLAYER_INIT_SIZE
CPU_SLOT3_INIT_OFFSET = CPU_SLOT2_INIT_OFFSET + PLAYER_INIT_SIZE

# Phase 43: two retail 1P assumptions exposed by independent co-op humans.
# Kirby Team's >30s path must jump past Giant Kirby; Falco's Corneria branch
# writes player[1] in retail, which is human P2 in the SDK.
ADVENTURE_TEAMKIRBY_ENTER_HOOK = 0x801B4B28
ADVENTURE_TEAMKIRBY_EXIT_HOOK = 0x801B4C5C
GM_DEFAULT_1P_MATCH_END = 0x8017E7A0
START_MELEE_ON_MATCH_END_OFFSET = 0x54
ADVENTURE_FALCO_FIGHT_SETUP_HOOK = 0x801B4DAC
GM_SET_NEXT_GAME_MODE_STATE_ID = 0x801A42A0
ADVENTURE_CORNERIA_INTRO_AFTER_GIANT_KIRBY = 0x28
ADVENTURE_FALCO_CUTSCENE_STATE = 0x2A


@dataclass
class ProbeHook:
    name: str
    site_address: int
    expected: str
    stub_address: int
    site_branch: str
    return_address: int | None = None


def _emit_mode_test(out: bytearray) -> None:
    # Canonical gm_GetCurrentGameMode @ 0x801A4310 is:
    # lis r3,0x8048; addi r3,r3,-0x62D0; lbz r3,0(r3); blr.
    # Because addi sign-extends 0x9D30, the effective address is exactly
    # *(u8 *)0x80479D30.
    # Compare into CR7 so retail CR0 remains untouched.
    out += lis(12, 0x8048)
    out += lbz(0, -0x62D0, 12)
    out += cmpwi(0, GM_ADVENTURE, crf=7)


def _or_reg(ra: int, rs: int, rb: int) -> bytes:
    """Encode PowerPC or ra,rs,rb."""
    return struct.pack(">I", (31<<26) | (rs<<21) | (ra<<16) | (rb<<11) | (444<<1))


def _addr_parts(addr: int) -> tuple[int, int]:
    lo = int(addr) & 0xFFFF
    signed_lo = lo - 0x10000 if lo & 0x8000 else lo
    hi = ((int(addr) - signed_lo) >> 16) & 0xFFFF
    return hi, signed_lo


def _emit_store_byte_abs(out: bytearray, value_reg: int, addr: int, scratch_reg: int = 12) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(scratch_reg, hi)
    out += stb(value_reg, lo, scratch_reg)


def _emit_load_byte_abs(out: bytearray, target_reg: int, addr: int, scratch_reg: int = 12) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(scratch_reg, hi)
    out += lbz(target_reg, lo, scratch_reg)

def _emit_store_word_abs(out: bytearray, value_reg: int, addr: int, scratch_reg: int = 12) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(scratch_reg, hi)
    out += stw(value_reg, lo, scratch_reg)

def _emit_load_word_abs(out: bytearray, target_reg: int, addr: int, scratch_reg: int = 12) -> None:
    hi, lo = _addr_parts(addr)
    out += lis(scratch_reg, hi)
    out += lwz(target_reg, lo, scratch_reg)


def _spawn_setup_stub(base: int, *, friendly_fire: bool = False,
                      camera_owner_addr: int | None = None,
                      persistence_valid_addr: int | None = None,
                      p1_stocks_addr: int | None = None,
                      p2_stocks_addr: int | None = None,
                      initial_stocks_addr: int | None = None,
                      scene_revive: bool = False,
                      vs_p2_identity_valid_addr: int | None = None,
                      vs_p2_ckind_addr: int | None = None,
                      vs_p2_color_addr: int | None = None,
                      vs_p2_subcolor_addr: int | None = None,
                      vs_p2_nametag_addr: int | None = None,
                      p1_form_addr: int | None = None,
                      p2_form_addr: int | None = None) -> bytes:
    """Adventure-only P2 setup plus Phase 37 campaign restore policy.

    Retail Adventure still supplies the scene-safe baseline by cloning P1 into
    P2. When the Phase 41 VS-identity bridge has a valid snapshot, only P2's
    character identity fields (ckind/color/sub-color/nametag) are overlaid from
    the last finalized normal-VS P2 selection. This avoids carrying VS-only
    modifiers (metal/invisible/HP/scale/ratios) into Adventure. On later scenes,
    exact persisted stock counts are restored.  A zero-stock human is now
    represented as Gm_PKind_NA instead of Human-with-zero-stocks, preventing the
    controllable "phantom" fighter observed in Phase 36.  Optional scene_revive
    restores an eliminated partner at the run's originally-selected Adventure
    stock count.
    """
    out=bytearray()
    out += stwu(1, -0x20, 1)
    out += stw(0, 0x08, 1)
    out += stw(11, 0x0C, 1)
    out += stw(12, 0x10, 1)
    _emit_mode_test(out)
    bne_off=len(out); out += b'\0'*4

    for off in range(0, PLAYER_INIT_SIZE, 4):
        out += lwz(11, P1_INIT_OFFSET + off, 30)
        out += stw(11, P2_INIT_OFFSET + off, 30)

    have_vs_identity = all(x is not None for x in (
        vs_p2_identity_valid_addr, vs_p2_ckind_addr, vs_p2_color_addr,
        vs_p2_subcolor_addr, vs_p2_nametag_addr))
    if have_vs_identity:
        _emit_load_byte_abs(out, 11, vs_p2_identity_valid_addr, 12)
        out += cmpwi(11, 0, crf=7)
        b_no_vs_identity = len(out); out += b'\0' * 4
        for saved_addr, field_off in ((vs_p2_ckind_addr, 0x00),
                                      (vs_p2_color_addr, 0x03),
                                      (vs_p2_subcolor_addr, 0x07),
                                      (vs_p2_nametag_addr, 0x0A)):
            _emit_load_byte_abs(out, 11, saved_addr, 12)
            out += stb(11, P2_INIT_OFFSET + field_off, 30)
        identity_done = base + len(out)
        out[b_no_vs_identity:b_no_vs_identity+4] = encode_bc(
            base + b_no_vs_identity, identity_done, bo=12, bi=30)

    out += li(11, 0)
    out += stb(11, P2_INIT_OFFSET + 0x01, 30)  # human
    out += li(11, 2)
    out += stb(11, P2_INIT_OFFSET + 0x04, 30)  # physical port 2
    out += li(11, 1)
    out += stb(11, P2_INIT_OFFSET + 0x05, 30)  # second spawn index

    # HF5: +0x07 is sub_color, not controller index. Never force it to 1.
    # Also restore the latest active Zelda/Sheik form, tracked from FighterKind.
    def emit_form_restore(init_off: int, form_addr: int | None) -> None:
        nonlocal out
        if form_addr is None:
            return
        out += lbz(10, init_off, 30)
        out += cmpwi(10, CKIND_ZELDA, crf=7)
        b_zelda = len(out); out += b'\0'*4
        out += cmpwi(10, CKIND_SEAK, crf=7)
        b_not_pair = len(out); out += b'\0'*4
        pair = base + len(out)
        out[b_zelda:b_zelda+4] = encode_bc(base+b_zelda, pair, bo=12, bi=30)
        _emit_load_byte_abs(out, 11, form_addr, 12)
        out += cmpwi(11, CKIND_ZELDA, crf=7)
        b_apply_z = len(out); out += b'\0'*4
        out += cmpwi(11, CKIND_SEAK, crf=7)
        b_invalid = len(out); out += b'\0'*4
        apply = base + len(out)
        out[b_apply_z:b_apply_z+4] = encode_bc(base+b_apply_z, apply, bo=12, bi=30)
        out += stb(11, init_off, 30)
        done = base + len(out)
        out[b_not_pair:b_not_pair+4] = encode_bc(base+b_not_pair, done, bo=4, bi=30)
        out[b_invalid:b_invalid+4] = encode_bc(base+b_invalid, done, bo=4, bi=30)

    emit_form_restore(P1_INIT_OFFSET, p1_form_addr)
    emit_form_restore(P2_INIT_OFFSET, p2_form_addr)
    out += li(11, 0)
    out += stb(11, P2_INIT_OFFSET + 0x0E, 30)
    out += stb(11, P2_INIT_OFFSET + 0x0F, 30)

    if friendly_fire:
        out += lbz(11, 0x01, 30)
        out += ori(11, 11, 0x0001)
        out += stb(11, 0x01, 30)

    have_campaign = all(x is not None for x in
                        (camera_owner_addr, persistence_valid_addr,
                         p1_stocks_addr, p2_stocks_addr))
    if scene_revive and initial_stocks_addr is None:
        raise ValueError('scene_revive requires initial_stocks_addr')
    if have_campaign:
        _emit_load_byte_abs(out, 11, persistence_valid_addr, 12)
        out += cmpwi(11, 0, crf=7)
        b_fresh = len(out); out += b'\0'*4

        def emit_restore(saved_addr: int, init_off: int) -> None:
            nonlocal out
            _emit_load_byte_abs(out, 11, saved_addr, 12)
            out += cmpwi(11, 0, crf=7)
            b_alive = len(out); out += b'\0'*4
            if scene_revive:
                _emit_load_byte_abs(out, 11, initial_stocks_addr, 12)
                out += stb(11, init_off + 0x02, 30)
                _emit_store_byte_abs(out, 11, saved_addr, 12)
                out += li(11, 0)
                out += stb(11, init_off + 0x01, 30)  # Human
            else:
                out += li(11, 0)
                out += stb(11, init_off + 0x02, 30)
                out += li(11, 3)
                out += stb(11, init_off + 0x01, 30)  # Gm_PKind_NA
            b_done = len(out); out += b'\0'*4
            alive = base + len(out)
            out[b_alive:b_alive+4] = encode_bc(base+b_alive, alive, bo=4, bi=30)
            _emit_load_byte_abs(out, 11, saved_addr, 12)
            out += stb(11, init_off + 0x02, 30)
            out += li(11, 0)
            out += stb(11, init_off + 0x01, 30)
            done = base + len(out)
            out[b_done:b_done+4] = encode_branch(base+b_done, done)

        emit_restore(p1_stocks_addr, P1_INIT_OFFSET)
        emit_restore(p2_stocks_addr, P2_INIT_OFFSET)

        # Select/control owner from the *post-policy* saved counts. Revive mode
        # updates a zero saved count to initial_stocks above, so both-alive
        # scenes naturally preserve the previous Control owner.
        _emit_load_byte_abs(out, 11, p1_stocks_addr, 12)
        out += cmpwi(11, 0, crf=7)
        b_p1_alive = len(out); out += b'\0'*4
        _emit_load_byte_abs(out, 11, p2_stocks_addr, 12)
        out += cmpwi(11, 0, crf=7)
        b_both_zero = len(out); out += b'\0'*4
        out += li(11, 1)
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
        _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
        b_owner_done_from_p2 = len(out); out += b'\0'*4

        p1_alive = base + len(out)
        out[b_p1_alive:b_p1_alive+4] = encode_bc(base+b_p1_alive, p1_alive, bo=4, bi=30)
        _emit_load_byte_abs(out, 11, p2_stocks_addr, 12)
        out += cmpwi(11, 0, crf=7)
        b_both_alive = len(out); out += b'\0'*4
        out += li(11, 0)
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
        _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
        b_owner_done_from_p1 = len(out); out += b'\0'*4

        both_alive = base + len(out)
        out[b_both_alive:b_both_alive+4] = encode_bc(base+b_both_alive, both_alive, bo=4, bi=30)
        _emit_load_byte_abs(out, 11, camera_owner_addr, 12)
        _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
        b_owner_done_both_alive = len(out); out += b'\0'*4

        both_zero = base + len(out)
        out[b_both_zero:b_both_zero+4] = encode_bc(base+b_both_zero, both_zero, bo=12, bi=30)
        out += li(11, 0)
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
        _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
        b_owner_done_both_zero = len(out); out += b'\0'*4

        owner_done = base + len(out)
        for boff in (b_owner_done_from_p2, b_owner_done_from_p1,
                     b_owner_done_both_alive, b_owner_done_both_zero):
            out[boff:boff+4] = encode_branch(base+boff, owner_done)
        b_after_fresh = len(out); out += b'\0'*4

        fresh = base + len(out)
        out[b_fresh:b_fresh+4] = encode_bc(base+b_fresh, fresh, bo=12, bi=30)
        # Capture the user's actual Adventure starting-stock selection once per
        # campaign. P2 was cloned from this same finalized PlayerInitData.
        if initial_stocks_addr is not None:
            out += lbz(11, P1_INIT_OFFSET + 0x02, 30)
            _emit_store_byte_abs(out, 11, initial_stocks_addr, 12)
        out += li(11, 0)
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
        _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
        after_fresh = base + len(out)
        out[b_after_fresh:b_after_fresh+4] = encode_branch(base+b_after_fresh, after_fresh)
    elif camera_owner_addr is not None:
        out += li(11, 0)
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
        _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)

    out += lwz(0, 0x08, 1)
    out += lwz(11, 0x0C, 1)
    out += lwz(12, 0x10, 1)
    out += addi(1, 1, 0x20)
    out += li(28, 2)
    out += encode_branch(base+len(out), P2_SETUP_HOOK+4)

    retail=base+len(out)
    out[bne_off:bne_off+4]=encode_bc(base+bne_off, retail, bo=4, bi=30)
    out += lwz(0, 0x08, 1)
    out += lwz(11, 0x0C, 1)
    out += lwz(12, 0x10, 1)
    out += addi(1, 1, 0x20)
    out += addi(28, 3, 1)
    out += encode_branch(base+len(out), P2_SETUP_HOOK+4)
    return bytes(out)

def _singleplayer_p2_loader_stub(base: int) -> bytes:
    """Preserve Adventure's single-player controller semantics but load P2.

    Retail fn_8016DCC0 enters case 1 when rules.x54 is non-null.  That path
    applies PlayerInitData only for slot 0 and then forcibly marks slots 1..5
    Gm_PKind_NA.  The StartMeleeData P2 created by _spawn_setup_stub therefore
    never reaches Player static state.  In Adventure only, apply players[1]
    through the same retail fn_8016D8AC helper and begin the NA loop at slot 2.
    Classic/All-Star and every other single-player mode retain li r31,1.
    """
    out=bytearray()
    out += stwu(1, -0x40, 1)
    # Preserve volatile GPRs that the injected BL may clobber.
    for reg, off in [(0,0x08),(3,0x0C),(4,0x10),(5,0x14),(6,0x18),(7,0x1C),
                     (8,0x20),(9,0x24),(10,0x28),(11,0x2C),(12,0x30)]:
        out += stw(reg, off, 1)
    out += mflr(0); out += stw(0, 0x34, 1)
    _emit_mode_test(out)
    bne_off=len(out); out += b'\0'*4

    # Adventure: initialize Player slot 1 from StartMeleeData.players[1].
    out += li(3, 1)
    out += addi(4, 30, P2_INIT_OFFSET)
    out += encode_branch(base+len(out), PLAYER_INIT_APPLY, link=True)
    out += li(31, 2)  # retail NA loop now clears slots 2..5, preserving P2
    b_done=len(out); out += b'\0'*4

    retail=base+len(out)
    out[bne_off:bne_off+4]=encode_bc(base+bne_off, retail, bo=4, bi=30)
    out += li(31, 1)  # displaced retail instruction
    done=base+len(out)
    out[b_done:b_done+4]=encode_branch(base+b_done, done)

    out += lwz(0, 0x34, 1); out += mtlr(0)
    for reg, off in [(0,0x08),(3,0x0C),(4,0x10),(5,0x14),(6,0x18),(7,0x1C),
                     (8,0x20),(9,0x24),(10,0x28),(11,0x2C),(12,0x30)]:
        out += lwz(reg, off, 1)
    out += addi(1, 1, 0x40)
    out += encode_branch(base+len(out), SINGLEPLAYER_P2_LOADER_HOOK+4)
    return bytes(out)

def _rebirth_owner_preflight_wrapper(base: int, camera_owner_addr: int | None = None) -> bytes:
    """Repair Adventure Control before retail computes rebirth/camera state.

    fn_8016719C computes route-stage respawn coordinates and can call
    Ground_801C38BC / Camera_8002F3AC before the later
    Player_SetSpawnPlatformPos hook runs.  Therefore the old late-only guard
    could correctly refuse to copy coordinates from an eliminated partner but
    still leave retail camera setup running with that dead partner as Control.

    For human slots 0/1, validate the opposite human at function entry.  A
    living partner (stocks > 0 and live entity) becomes Control before retail
    computes the respawn; otherwise the respawning survivor becomes Control.
    CPU/non-human slots fall through unchanged.  The displaced ``mflr r0`` is
    reproduced before returning to retail +4, preserving the original ABI.
    """
    out=bytearray()
    out += stwu(1, -0x30, 1)
    out += stw(3, 0x08, 1)   # respawning slot
    out += stw(4, 0x0C, 1)   # subchar
    out += stw(11, 0x10, 1); out += stw(12, 0x14, 1)
    out += mflr(0); out += stw(0, 0x18, 1)

    _emit_mode_test(out)
    b_normal_mode=len(out); out += b'\0'*4

    out += lwz(3, 0x08, 1)
    out += cmpwi(3, 0, crf=7)
    b_not_p1=len(out); out += b'\0'*4
    out += li(11, 1)
    b_candidate_selected=len(out); out += b'\0'*4

    p2_case=base+len(out)
    out[b_not_p1:b_not_p1+4]=encode_bc(base+b_not_p1, p2_case, bo=4, bi=30)
    out += cmpwi(3, 1, crf=7)
    b_normal_slot=len(out); out += b'\0'*4
    out += li(11, 0)

    candidate_selected=base+len(out)
    out[b_candidate_selected:b_candidate_selected+4]=encode_branch(base+b_candidate_selected, candidate_selected)
    out += stw(11, 0x1C, 1)

    # Partner must both have stocks and a currently-live fighter entity.
    out += lwz(3, 0x1C, 1)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += cmpwi(3, 0, crf=7)
    b_partner_absent_stock=len(out); out += b'\0'*4
    out += lwz(3, 0x1C, 1)
    out += encode_branch(base+len(out), PLAYER_GET_ENTITY, link=True)
    out += cmpwi(3, 0, crf=7)
    b_partner_absent_entity=len(out); out += b'\0'*4

    # Living partner owns the active route while the other human rebirths.
    out += lwz(11, 0x1C, 1)
    b_store_owner=len(out); out += b'\0'*4

    # No partner: the respawning survivor must own Control *before* retail
    # calculates the route checkpoint and calls its camera setup.
    partner_absent=base+len(out)
    out[b_partner_absent_stock:b_partner_absent_stock+4]=encode_bc(base+b_partner_absent_stock, partner_absent, bo=12, bi=30)
    out[b_partner_absent_entity:b_partner_absent_entity+4]=encode_bc(base+b_partner_absent_entity, partner_absent, bo=12, bi=30)
    out += lwz(11, 0x08, 1)

    store_owner=base+len(out)
    out[b_store_owner:b_store_owner+4]=encode_branch(base+b_store_owner, store_owner)
    if camera_owner_addr is not None:
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)

    normal=base+len(out)
    out[b_normal_mode:b_normal_mode+4]=encode_bc(base+b_normal_mode, normal, bo=4, bi=30)
    out[b_normal_slot:b_normal_slot+4]=encode_bc(base+b_normal_slot, normal, bo=4, bi=30)

    # Restore the function arguments and caller LR, then reproduce retail's
    # displaced function-entry mflr r0 with that caller LR live in LR.
    out += lwz(0, 0x18, 1); out += mtlr(0)
    out += lwz(3, 0x08, 1); out += lwz(4, 0x0C, 1)
    out += lwz(11, 0x10, 1); out += lwz(12, 0x14, 1)
    out += addi(1, 1, 0x30)
    out += mflr(0)
    out += encode_branch(base+len(out), REBIRTH_OWNER_PREFLIGHT_HOOK+4)
    return bytes(out)


def _respawn_platform_wrapper(base: int, camera_owner_addr: int | None = None) -> bytes:
    """Adventure Control + safe survivor-follow rebirth.

    Human slots 0/1 use the living partner as the rebirth anchor only when that
    partner both has remaining stocks *and* currently owns a fighter entity.
    If the partner is eliminated or otherwise absent, the respawning survivor
    regains Control and retail chooses the normal stage respawn coordinates.

    Camera/control ownership is intentionally separate from coordinate choice:
    valid partner -> hand Control to partner; absent partner -> Control returns
    to the respawning survivor. Retail still owns stocks, angel-platform timing,
    invulnerability, and the final Player_SetSpawnPlatformPos call.
    """
    out=bytearray()
    out += stwu(1, -0x40, 1)
    out += stw(0, 0x08, 1)
    out += stw(3, 0x0C, 1)   # respawning slot
    out += stw(4, 0x10, 1)   # retail coordinate/output pointer
    out += stw(11, 0x14, 1)
    out += stw(12, 0x18, 1)
    out += mflr(0); out += stw(0, 0x1C, 1)

    _emit_mode_test(out)
    b_normal_mode=len(out); out += b'\0'*4

    # Select the *candidate* partner for human rebirths only.
    out += lwz(3, 0x0C, 1)
    out += cmpwi(3, 0, crf=7)
    b_not_p1=len(out); out += b'\0'*4
    out += li(11, 1)  # P1 rebirth -> candidate P2
    b_candidate_selected=len(out); out += b'\0'*4

    p2_case=base+len(out)
    out[b_not_p1:b_not_p1+4]=encode_bc(base+b_not_p1, p2_case, bo=4, bi=30)
    out += cmpwi(3, 1, crf=7)
    b_normal_slot=len(out); out += b'\0'*4
    out += li(11, 0)  # P2 rebirth -> candidate P1

    candidate_selected=base+len(out)
    out[b_candidate_selected:b_candidate_selected+4]=encode_branch(base+b_candidate_selected, candidate_selected)
    out += stw(11, 0x20, 1)

    # A partner with zero stocks is eliminated and must never be used as a
    # coordinate anchor. A positive-stock slot can still be between entities,
    # so require Player_GetEntity() to be non-null as well.
    out += lwz(3, 0x20, 1)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += cmpwi(3, 0, crf=7)
    b_partner_absent_stock=len(out); out += b'\0'*4

    out += lwz(3, 0x20, 1)
    out += encode_branch(base+len(out), PLAYER_GET_ENTITY, link=True)
    out += cmpwi(3, 0, crf=7)
    b_partner_absent_entity=len(out); out += b'\0'*4

    # Valid living partner: transfer Control and anchor rebirth to that fighter.
    out += lwz(11, 0x20, 1)
    if camera_owner_addr is not None:
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
    out += lwz(3, 0x20, 1)
    out += lwz(4, 0x10, 1)
    out += encode_branch(base+len(out), PLAYER_LOAD_COORDS, link=True)
    b_retail_spawn=len(out); out += b'\0'*4

    # Partner absent/eliminated: respawning survivor regains Control and retail
    # keeps the stage's normal respawn coordinates. Do not call LoadCoords.
    partner_absent=base+len(out)
    out[b_partner_absent_stock:b_partner_absent_stock+4]=encode_bc(base+b_partner_absent_stock, partner_absent, bo=12, bi=30)
    out[b_partner_absent_entity:b_partner_absent_entity+4]=encode_bc(base+b_partner_absent_entity, partner_absent, bo=12, bi=30)
    out += lwz(11, 0x0C, 1)
    if camera_owner_addr is not None:
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)

    normal=base+len(out)
    out[b_normal_mode:b_normal_mode+4]=encode_bc(base+b_normal_mode, normal, bo=4, bi=30)
    out[b_normal_slot:b_normal_slot+4]=encode_bc(base+b_normal_slot, normal, bo=4, bi=30)
    out[b_retail_spawn:b_retail_spawn+4]=encode_branch(base+b_retail_spawn, normal)

    # One common retail call. In the fallback path r4 still contains retail's
    # original stage spawn coordinates; in the partner path LoadCoords updated it.
    out += lwz(3, 0x0C, 1)
    out += lwz(4, 0x10, 1)
    out += encode_branch(base+len(out), PLAYER_SET_SPAWN_PLATFORM_POS, link=True)

    out += lwz(0, 0x1C, 1); out += mtlr(0)
    out += lwz(11, 0x14, 1); out += lwz(12, 0x18, 1)
    out += addi(1, 1, 0x40)
    out += blr()
    return bytes(out)

def _team_stock_wrapper(base: int, camera_owner_addr: int | None = None) -> bytes:
    """Return team-alive stock state to retail's 1P outcome checks.

    Retail callers only test the result against zero.  In Adventure return P1
    stocks when non-zero, otherwise P2 stocks.  Therefore OUTCOME_1P_GAME_OVER
    occurs only when both humans are out.  Outside Adventure call the original
    Player_GetP1Stock unchanged.

    The zero-stock path also hands Control to the surviving partner so camera
    transfer still happens when an eliminated fighter will never rebirth.
    """
    out=bytearray()
    out += stwu(1, -0x30, 1)
    out += stw(0, 0x08, 1); out += stw(11, 0x0C, 1); out += stw(12, 0x10, 1)
    out += mflr(0); out += stw(0, 0x14, 1)
    _emit_mode_test(out)
    b_retail=len(out); out += b'\0'*4

    out += li(3, 0)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += cmpwi(3, 0, crf=7)
    b_p1_alive=len(out); out += b'\0'*4

    # P1 is eliminated. If P2 has stocks, P2 owns Control and keeps the run.
    out += li(3, 1)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += cmpwi(3, 0, crf=7)
    b_done_if_both_zero=len(out); out += b'\0'*4
    out += li(11, 1)
    if camera_owner_addr is not None:
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
    b_done_from_p2=len(out); out += b'\0'*4

    p1_alive=base+len(out)
    out[b_p1_alive:b_p1_alive+4]=encode_bc(base+b_p1_alive, p1_alive, bo=4, bi=30)
    # If P1 lives but P2 is eliminated, make sure Control is P1. This query is
    # cheap and makes zero-stock handoff symmetric.
    out += stw(3, 0x18, 1)
    out += li(3, 1)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += cmpwi(3, 0, crf=7)
    b_restore_p1_result=len(out); out += b'\0'*4
    out += li(11, 0)
    if camera_owner_addr is not None:
        _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)
    restore_p1=base+len(out)
    out[b_restore_p1_result:b_restore_p1_result+4]=encode_bc(base+b_restore_p1_result, restore_p1, bo=4, bi=30)
    out += lwz(3, 0x18, 1)
    b_done_from_p1=len(out); out += b'\0'*4

    retail=base+len(out)
    out[b_retail:b_retail+4]=encode_bc(base+b_retail, retail, bo=4, bi=30)
    out += encode_branch(base+len(out), PLAYER_GET_P1_STOCK, link=True)

    done=base+len(out)
    out[b_done_if_both_zero:b_done_if_both_zero+4]=encode_bc(base+b_done_if_both_zero, done, bo=12, bi=30)
    out[b_done_from_p2:b_done_from_p2+4]=encode_branch(base+b_done_from_p2, done)
    out[b_done_from_p1:b_done_from_p1+4]=encode_branch(base+b_done_from_p1, done)
    out += lwz(0, 0x14, 1); out += mtlr(0)
    out += lwz(11, 0x0C, 1); out += lwz(12, 0x10, 1)
    out += addi(1, 1, 0x30)
    out += blr()
    return bytes(out)




def _campaign_state_reset_stub(base: int, *, camera_owner_addr: int, persistence_valid_addr: int, p1_stocks_addr: int, p2_stocks_addr: int, initial_stocks_addr: int, return_address: int, vs_p2_identity_valid_addr: int | None = None, vs_p2_ckind_addr: int | None = None, vs_p2_color_addr: int | None = None, vs_p2_subcolor_addr: int | None = None, vs_p2_nametag_addr: int | None = None, extra_reset_addrs: tuple[int, ...] = ()) -> bytes:
    """Reset SDK campaign state when entering the Adventure CSS.

    This is reached by redirecting Phase 29's already-installed transparent
    gm_801B42E8 trampoline.  It prevents a completed/abandoned run from leaking
    saved stocks or Control ownership into a newly-started Adventure campaign.
    No calls are made, so LR remains the retail caller LR for the displaced
    function-entry ``mflr r0``.
    """
    out=bytearray()
    out += stwu(1, -0x20, 1)
    out += stw(11, 0x08, 1); out += stw(12, 0x0C, 1); out += stw(10, 0x10, 1)
    out += li(11, 0)
    _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    _emit_store_byte_abs(out, 11, persistence_valid_addr, 12)
    _emit_store_byte_abs(out, 11, p1_stocks_addr, 12)
    _emit_store_byte_abs(out, 11, p2_stocks_addr, 12)
    _emit_store_byte_abs(out, 11, initial_stocks_addr, 12)
    for extra_addr in extra_reset_addrs:
        _emit_store_byte_abs(out, 11, extra_addr, 12)
    _emit_store_byte_abs(out, 11, GAME_CAMERA_OWNER_SLOT, 12)

    # Phase 41: snapshot P2's last finalized normal-VS identity. gmMainLib is a
    # pointer at 0x804D3EE0; gmm_x0::modes.vs_melee.players[1] begins at +0x61C.
    have_vs_identity = all(x is not None for x in (
        vs_p2_identity_valid_addr, vs_p2_ckind_addr, vs_p2_color_addr,
        vs_p2_subcolor_addr, vs_p2_nametag_addr))
    if have_vs_identity:
        out += li(11, 0)
        _emit_store_byte_abs(out, 11, vs_p2_identity_valid_addr, 12)
        gm_hi, gm_lo = _addr_parts(GM_MAINLIB_PTR_ADDR)
        out += lis(12, gm_hi)
        out += lwz(12, gm_lo, 12)
        out += cmpwi(12, 0, crf=7)
        b_no_mainlib = len(out); out += b'\0' * 4
        out += lbz(11, VS_MELEE_P2_INIT_OFFSET + 0x01, 12)
        out += cmpwi(11, 0, crf=7)  # Gm_PKind_Human == 0
        b_not_human = len(out); out += b'\0' * 4
        for src_off, dst_addr in ((0x00, vs_p2_ckind_addr),
                                  (0x03, vs_p2_color_addr),
                                  (0x07, vs_p2_subcolor_addr),
                                  (0x0A, vs_p2_nametag_addr)):
            out += lbz(11, VS_MELEE_P2_INIT_OFFSET + src_off, 12)
            _emit_store_byte_abs(out, 11, dst_addr, 10)
        out += li(11, 1)
        _emit_store_byte_abs(out, 11, vs_p2_identity_valid_addr, 10)
        capture_done = base + len(out)
        out[b_no_mainlib:b_no_mainlib+4] = encode_bc(base+b_no_mainlib, capture_done, bo=12, bi=30)
        out[b_not_human:b_not_human+4] = encode_bc(base+b_not_human, capture_done, bo=4, bi=30)

    out += lwz(11, 0x08, 1); out += lwz(12, 0x0C, 1); out += lwz(10, 0x10, 1)
    out += addi(1, 1, 0x20)
    out += mflr(0)  # displaced gm_801B42E8 entry instruction
    out += encode_branch(base+len(out), return_address)
    return bytes(out)

def _adventure_progress_stock_wrapper(base: int, *, persistence_valid_addr: int, p1_stocks_addr: int, p2_stocks_addr: int) -> bytes:
    """Persist both human stock counts at retail Adventure's chapter handoff.

    Retail gm_8017D7AC loads player_standings[0].stocks into r0 and immediately
    writes that byte to persistent Adventure state.  In Adventure we snapshot
    the live P1/P2 static-player stock counts, keep both exact values in SDK
    state, and return a *representative team stock* in r0 (P1 if non-zero,
    otherwise P2).  Thus retail progression still sees a non-zero campaign life
    count while either human survives, while the next encounter can restore the
    two independent values. Outside Adventure the displaced retail lbz is exact.
    """
    out = bytearray()
    out += stwu(1, -0x30, 1)
    out += stw(3, 0x08, 1); out += stw(11, 0x0C, 1); out += stw(12, 0x10, 1)
    out += mflr(11); out += stw(11, 0x14, 1)
    _emit_mode_test(out)
    b_retail = len(out); out += b'\0'*4

    out += li(3, 0)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += stw(3, 0x18, 1)
    _emit_store_byte_abs(out, 3, p1_stocks_addr, 12)
    out += li(3, 1)
    out += encode_branch(base+len(out), PLAYER_GET_STOCKS, link=True)
    out += stw(3, 0x1C, 1)
    _emit_store_byte_abs(out, 3, p2_stocks_addr, 12)
    out += li(11, 1)
    _emit_store_byte_abs(out, 11, persistence_valid_addr, 12)

    # r0 must be the byte retail stores at r30+5 immediately after this hook.
    out += lwz(11, 0x18, 1)
    out += cmpwi(11, 0, crf=7)
    b_use_p1 = len(out); out += b'\0'*4
    out += lwz(11, 0x1C, 1)
    b_have_rep = len(out); out += b'\0'*4
    use_p1 = base + len(out)
    out[b_use_p1:b_use_p1+4] = encode_bc(base+b_use_p1, use_p1, bo=4, bi=30)
    out += lwz(11, 0x18, 1)
    have_rep = base + len(out)
    out[b_have_rep:b_have_rep+4] = encode_branch(base+b_have_rep, have_rep)
    # Keep only low byte, matching lbz semantics. Values are small positive ints.
    out += ori(0, 11, 0)
    b_done = len(out); out += b'\0'*4

    retail = base + len(out)
    out[b_retail:b_retail+4] = encode_bc(base+b_retail, retail, bo=4, bi=30)
    out += lbz(0, 0x6C, 29)  # displaced retail instruction

    done = base + len(out)
    out[b_done:b_done+4] = encode_branch(base+b_done, done)
    out += lwz(11, 0x14, 1); out += mtlr(11)
    out += lwz(3, 0x08, 1); out += lwz(11, 0x0C, 1); out += lwz(12, 0x10, 1)
    out += addi(1, 1, 0x30)
    out += encode_branch(base+len(out), ADVENTURE_PROGRESS_STOCK_HOOK+4)
    return bytes(out)

def _control_player_entity_wrapper(base: int, camera_owner_addr: int, *,
                                   p2_ckind_addr: int | None = None,
                                   icies_teardown_guard_addr: int | None = None,
                                   icies_diag_addr: int | None = None) -> bytes:
    """Return the current Adventure Control-owner fighter entity.

    HF10 removes the HF8/HF9 Icies teardown attempt from this accessor. The
    frozen HF9 save retained guard=0/diag=0, proving the camera lookup does not
    execute at the required post-wave boundary. Optional repair arguments remain
    accepted only for backwards-compatible callers/tests and are unused.
    """
    out = bytearray()
    out += stwu(1, -0x20, 1); out += mflr(0); out += stw(0, 0x18, 1)
    _emit_mode_test(out)
    b_retail = len(out); out += b'\0' * 4
    _emit_load_byte_abs(out, 3, camera_owner_addr, 12)
    out += lwz(0, 0x18, 1); out += mtlr(0); out += addi(1, 1, 0x20)
    out += encode_branch(base + len(out), PLAYER_GET_ENTITY)

    retail = base + len(out)
    out[b_retail:b_retail+4] = encode_bc(base + b_retail, retail, bo=4, bi=30)
    out += li(3, 0)
    out += lwz(0, 0x18, 1); out += mtlr(0); out += addi(1, 1, 0x20)
    out += encode_branch(base + len(out), PLAYER_GET_ENTITY)
    return bytes(out)


def _team_kirby_final_wave_wrapper(base: int, trampoline_addr: int, *,
                                    p1_ckind_addr: int, p2_ckind_addr: int,
                                    icies_teardown_guard_addr: int,
                                    icies_diag_addr: int,
                                    icies_wave_armed_addr: int) -> bytes:
    """HF20: detect the real Team-Kirby terminal edge without touching fighters.

    HF18/HF19 runtime evidence proves the active->complete/inactive detector is
    sound. HF19 reached C1 but never C2..C5 before the same NULL-GObj failure,
    demonstrating that filtering the outer pl_80039450 call by event-slot owner
    was the wrong interception point.

    This wrapper remains observation/arming only. It preserves the retail
    15-Kirby wave and, after a genuine active->complete/inactive edge, sets the
    terminal guard used by the separate fn_80039618 fighter-owner wrapper. It
    does not free, clear, transition, or otherwise mutate any fighter/event slot.

    +0x33 lifecycle: 0 idle, 1 active observed, 2 terminal edge observed.
    Diagnostics: C0 active wave observed, C1 terminal edge armed.
    """
    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1)
    out += encode_branch(base+len(out),trampoline_addr,link=True)

    _emit_mode_test(out)
    b_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_state=len(out); out += b'\0'*4

    # Scope terminal arming to runs containing human Ice Climbers in either slot.
    _emit_load_byte_abs(out,11,p1_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_p1_not_ic=len(out); out += b'\0'*4
    b_have_ic=len(out); out += b'\0'*4
    p2_check=base+len(out)
    out[b_p1_not_ic:b_p1_not_ic+4]=encode_bc(base+b_p1_not_ic,p2_check,bo=4,bi=30)
    _emit_load_byte_abs(out,11,p2_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_no_ic=len(out); out += b'\0'*4
    have_ic=base+len(out)
    out[b_have_ic:b_have_ic+4]=encode_branch(base+b_have_ic,have_ic)

    # Require an observed active wave before accepting retail's terminal bits.
    out += encode_branch(base+len(out),EVENT_ENEMY_IS_ACTIVE,link=True)
    out += cmpwi(3,0,crf=7)
    b_not_active=len(out); out += b'\0'*4
    out += li(11,1); _emit_store_byte_abs(out,11,icies_wave_armed_addr,12)
    out += li(11,0xC0); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    b_after_arm=len(out); out += b'\0'*4

    terminal_check=base+len(out)
    out[b_not_active:b_not_active+4]=encode_bc(base+b_not_active,terminal_check,bo=12,bi=30)
    _emit_load_byte_abs(out,11,icies_wave_armed_addr,12); out += cmpwi(11,1,crf=7)
    b_not_armed=len(out); out += b'\0'*4
    out += encode_branch(base+len(out),EVENT_ENEMY_IS_COMPLETE,link=True)
    out += cmpwi(3,0,crf=7)
    b_complete_false=len(out); out += b'\0'*4
    out += encode_branch(base+len(out),EVENT_ENEMY_IS_ACTIVE,link=True)
    out += cmpwi(3,0,crf=7)
    b_active_again=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,icies_teardown_guard_addr,12); out += cmpwi(11,0,crf=7)
    b_guard=len(out); out += b'\0'*4

    # True terminal edge: arm the downstream MatchEnd/bonus ownership guard only.
    out += li(11,1); _emit_store_byte_abs(out,11,icies_teardown_guard_addr,12)
    out += li(11,2); _emit_store_byte_abs(out,11,icies_wave_armed_addr,12)
    out += li(11,0xC1); _emit_store_byte_abs(out,11,icies_diag_addr,12)

    done=base+len(out)
    for pos in (b_mode,b_state,b_no_ic,b_not_armed,b_active_again,b_guard):
        out[pos:pos+4]=encode_bc(base+pos,done,bo=4,bi=30)
    # complete==0 exits; complete==1 proceeds into terminal arming.
    out[b_complete_false:b_complete_false+4]=encode_bc(base+b_complete_false,done,bo=12,bi=30)
    out[b_after_arm:b_after_arm+4]=encode_branch(base+b_after_arm,done)
    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()
    return bytes(out)


def _team_kirby_bonus_guard_wrapper(base: int, trampoline_addr: int, *,
                                     p1_ckind_addr: int, p2_ckind_addr: int,
                                     icies_teardown_guard_addr: int,
                                     icies_diag_addr: int) -> bytes:
    """HF20: guard fn_80039618 at the exact NULL-fighter ownership boundary.

    HF19 armed its Team-Kirby terminal guard (C1) in both captured failing runs
    but never emitted C2..C5 from the outer pl_80039450 event-slot filter.  The
    crash nevertheless remained PC=0x80038684 / read 0x0000002C, which proves a
    literal NULL GObj still reached pl_80038628.  fn_80039618 is the function
    that obtains that GObj through Player_GetEntity(player) and then repeatedly
    passes it to pl_80038628.

    Preserve pl_80039450 and all later bonus/stat routines.  Only after the
    source-grounded Team-Kirby terminal edge is armed, in Adventure state 0x23,
    on a run containing human Ice Climbers, check the incoming participant's
    live entity at fn_80039618 entry. Valid player slots 0..5 with a live GObj
    run retail unchanged. If a valid slot has no GObj, return from fn_80039618
    only; the caller continues with fn_8003B044 and the remaining retail bonus
    pipeline. No StaticPlayer, MatchEnd, stock, fighter, or event state is
    mutated. Diagnostics D0..D5 identify the participant whose fighter-dependent
    bonus pass was safely skipped.
    """
    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1)
    out += stw(3,0x08,1)  # incoming player slot

    _emit_mode_test(out)
    b_retail_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_retail_state=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,icies_teardown_guard_addr,12); out += cmpwi(11,1,crf=7)
    b_retail_guard=len(out); out += b'\0'*4

    # fn_80039618 is a per-player routine. MatchEnd uses physical slots 0..5;
    # leave any sentinel/other value fully retail rather than probing it.
    out += lwz(3,0x08,1); out += cmpwi(3,0,crf=7)
    b_retail_lt0=len(out); out += b'\0'*4
    out += cmpwi(3,5,crf=7)
    b_retail_gt5=len(out); out += b'\0'*4

    # Keep the workaround Icies-specific in either campaign human slot.
    _emit_load_byte_abs(out,11,p1_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_p1_not_ic=len(out); out += b'\0'*4
    b_have_ic=len(out); out += b'\0'*4
    p2_check=base+len(out)
    out[b_p1_not_ic:b_p1_not_ic+4]=encode_bc(base+b_p1_not_ic,p2_check,bo=4,bi=30)
    _emit_load_byte_abs(out,11,p2_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_retail_no_ic=len(out); out += b'\0'*4
    have_ic=base+len(out)
    out[b_have_ic:b_have_ic+4]=encode_branch(base+b_have_ic,have_ic)

    # This is the exact precondition fn_80039618 violates in the failing state.
    out += lwz(3,0x08,1)
    out += encode_branch(base+len(out),PLAYER_GET_ENTITY,link=True)
    out += cmpwi(3,0,crf=7)
    b_retail_entity=len(out); out += b'\0'*4

    # NULL owner: skip only this fighter-dependent bonus routine. The caller's
    # original LR is restored so pl_80039450 continues at the next bonus pass.
    out += lwz(3,0x08,1)
    out += addi(11,3,0xD0)
    _emit_store_byte_abs(out,11,icies_diag_addr,12)
    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()

    retail=base+len(out)
    out[b_retail_mode:b_retail_mode+4]=encode_bc(base+b_retail_mode,retail,bo=4,bi=30)
    out[b_retail_state:b_retail_state+4]=encode_bc(base+b_retail_state,retail,bo=4,bi=30)
    out[b_retail_guard:b_retail_guard+4]=encode_bc(base+b_retail_guard,retail,bo=4,bi=30)
    out[b_retail_lt0:b_retail_lt0+4]=encode_bc(base+b_retail_lt0,retail,bo=12,bi=28)
    out[b_retail_gt5:b_retail_gt5+4]=encode_bc(base+b_retail_gt5,retail,bo=12,bi=29)
    out[b_retail_no_ic:b_retail_no_ic+4]=encode_bc(base+b_retail_no_ic,retail,bo=4,bi=30)
    out[b_retail_entity:b_retail_entity+4]=encode_bc(base+b_retail_entity,retail,bo=4,bi=30)

    # Tail-enter the one-instruction fn_80039618 trampoline with original LR.
    out += lwz(3,0x08,1)
    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30)
    out += encode_branch(base+len(out),trampoline_addr)
    return bytes(out)

def _emit_transition_checkpoint(out: bytearray, *, code: int, flag_addr: int,
                                flag_mask: int, last_addr: int,
                                state_addr: int, prev_state_addr: int) -> None:
    """Write one durable HF21 transition checkpoint.

    Uses only volatile r10-r12.  The previous/current Adventure state bytes are
    retained alongside a monotonic evidence bitmap so later checkpoints never
    erase proof that an earlier boundary was crossed.
    """
    _emit_load_byte_abs(out, 10, state_addr, 12)
    _emit_store_byte_abs(out, 10, prev_state_addr, 12)
    _emit_load_byte_abs(out, 10, GM_CURRENT_STATE_ADDR, 12)
    _emit_store_byte_abs(out, 10, state_addr, 12)
    out += li(11, code)
    _emit_store_byte_abs(out, 11, last_addr, 12)
    _emit_load_byte_abs(out, 11, flag_addr, 12)
    out += ori(11, 11, flag_mask)
    _emit_store_byte_abs(out, 11, flag_addr, 12)


def _scene_transition_trace_wrapper(base: int, trampoline_addr: int, *,
                                    terminal_guard_addr: int,
                                    last_addr: int, flags_lo_addr: int,
                                    flags_hi_addr: int, state_addr: int,
                                    prev_state_addr: int,
                                    enter_code: int | None = None,
                                    return_code: int | None = None) -> bytes:
    """HF21 transparent scene-boundary tracer.

    The wrapper is completely dormant until the already-proven Icies Team-Kirby
    terminal edge sets ``terminal_guard_addr`` to 1.  It then records an entry
    and/or return checkpoint while still executing the complete retail function
    through a one-instruction trampoline.  No fighter, GObj, MatchEnd, scene
    request, or renderer state is modified.

    E0..E7 live in the low evidence byte; E8..EF live in the high byte.
    """
    if enter_code is None and return_code is None:
        raise ValueError('scene transition tracer needs an enter and/or return checkpoint')
    for code in (enter_code, return_code):
        if code is not None and not 0xE0 <= int(code) <= 0xEF:
            raise ValueError('HF21 transition checkpoint must be E0..EF')

    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1)
    # r3/r4 are the only arguments used by the traced scene functions; preserve
    # them across our diagnostic loads before entering retail.
    out += stw(3,0x08,1); out += stw(4,0x0C,1)

    def emit_gated(code: int) -> None:
        _emit_load_byte_abs(out,11,terminal_guard_addr,12)
        out.extend(cmpwi(11,1,crf=7))
        skip=len(out); out.extend(b'\0'*4)
        idx=code-0xE0
        if idx < 8:
            flag_addr, mask = flags_lo_addr, 1 << idx
        else:
            flag_addr, mask = flags_hi_addr, 1 << (idx-8)
        _emit_transition_checkpoint(out, code=code, flag_addr=flag_addr,
                                    flag_mask=mask, last_addr=last_addr,
                                    state_addr=state_addr,
                                    prev_state_addr=prev_state_addr)
        done=base+len(out)
        out[skip:skip+4]=encode_bc(base+skip,done,bo=4,bi=30)  # bne: guard != 1

    if enter_code is not None:
        emit_gated(int(enter_code))

    out += lwz(3,0x08,1); out += lwz(4,0x0C,1)
    out += encode_branch(base+len(out),trampoline_addr,link=True)

    if return_code is not None:
        emit_gated(int(return_code))

    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()
    return bytes(out)


RETIRED_TRACE_SCRATCH_SIZE = 0x28

def _retired_trace_scratch_wrapper(base: int, trampoline_addr: int) -> bytes:
    """Reserve only the bytes still consumed after HF21 trace retirement.

    SDK 0.20.1 overwrites this dead wrapper with its 0x20-byte retail input
    accessor plus the 8-byte MSDK021P marker. A transparent branch occupies the
    first word for dev configurations that omit boot hardening.
    """
    blob = encode_branch(base, trampoline_addr) + nop() * 9
    assert len(blob) == RETIRED_TRACE_SCRATCH_SIZE
    return blob


def _teardown_trace_wrapper(base: int, trampoline_addr: int, *, enter_code: int,
                            return_code: int, diag_addr: int, slot_addr: int,
                            arg_addr: int, has_args: bool = True) -> bytes:
    """Trace a retail teardown call without changing its semantics.

    The site branches here with the original caller LR intact. We save that LR
    and r3/r4, optionally stamp diagnostics only for Adventure Team-Kirby, then
    BL the one-instruction trampoline. Because the trampoline starts with retail
    `mflr r0`, the original function saves our wrapper return address and returns
    here normally. We stamp the return code, restore the original caller LR, and
    return. Thus an enter code without its paired return code means the hang is
    inside that exact retail function.
    """
    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1)
    out += stw(3,0x08,1); out += stw(4,0x0C,1)
    _emit_mode_test(out)
    b_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_state=len(out); out += b'\0'*4
    out += li(11,enter_code & 0xFF); _emit_store_byte_abs(out,11,diag_addr,12)
    if has_args:
        out += lwz(11,0x08,1); _emit_store_byte_abs(out,11,slot_addr,12)
        out += lwz(11,0x0C,1); _emit_store_byte_abs(out,11,arg_addr,12)
    call_label=base+len(out)
    out[b_mode:b_mode+4]=encode_bc(base+b_mode,call_label,bo=4,bi=30)
    out[b_state:b_state+4]=encode_bc(base+b_state,call_label,bo=4,bi=30)
    out += lwz(3,0x08,1); out += lwz(4,0x0C,1)
    out += encode_branch(base+len(out),trampoline_addr,link=True)
    # Preserve r3 return value even though current traced functions are void-like.
    out += stw(3,0x10,1)
    _emit_mode_test(out)
    b_ret_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_ret_state=len(out); out += b'\0'*4
    out += li(11,return_code & 0xFF); _emit_store_byte_abs(out,11,diag_addr,12)
    done=base+len(out)
    out[b_ret_mode:b_ret_mode+4]=encode_bc(base+b_ret_mode,done,bo=4,bi=30)
    out[b_ret_state:b_ret_state+4]=encode_bc(base+b_ret_state,done,bo=4,bi=30)
    out += lwz(3,0x10,1); out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()
    return bytes(out)


def _team_kirby_clear_ref_repair_wrapper(base: int, clear_trampoline_addr: int,
                                          destroy_trampoline_addr: int, *,
                                          diag_addr: int, slot_addr: int,
                                          arg_addr: int, guard_addr: int,
                                          p1_ckind_addr: int,
                                          p2_ckind_addr: int) -> bytes:
    """HF14: finish dead Team-Kirby event-slot teardown without touching Icies.

    HF13 runtime evidence ended at F6 after Player_80031FB0(slot=2,index=0)
    returned, while slots 3/4 still held stock-0 Kirby GObjs and the VS
    terminate flag was already set.  Ice Climbers themselves were still fully
    alive.  The repair therefore leaves human slots 0/1 alone and, once the
    retail match has committed termination, drains only disposable event slots
    2..5 through the retail pair-aware destruction/ref-clear APIs.

    Calls to the clear-ref trampoline bypass this wrapper.  HSD_GObjFree can
    indirectly re-enter the public Player_80031FB0 hook; guard_addr is armed
    before the sweep so such nested calls run retail and skip the sweep.
    """
    out=bytearray()
    out += stwu(1,-0x40,1); out += mflr(0); out += stw(0,0x44,1)
    out += stw(3,0x08,1); out += stw(4,0x0C,1)

    # Preserve the HF13 enter trace.
    _emit_mode_test(out)
    b_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_state=len(out); out += b'\0'*4
    out += li(11,0xF5); _emit_store_byte_abs(out,11,diag_addr,12)
    out += lwz(11,0x08,1); _emit_store_byte_abs(out,11,slot_addr,12)
    call_retail=base+len(out)
    out[b_mode:b_mode+4]=encode_bc(base+b_mode,call_retail,bo=4,bi=30)
    out[b_state:b_state+4]=encode_bc(base+b_state,call_retail,bo=4,bi=30)

    # Run the exact displaced retail Player_80031FB0 first.
    out += lwz(3,0x08,1); out += lwz(4,0x0C,1)
    out += encode_branch(base+len(out),clear_trampoline_addr,link=True)
    out += stw(3,0x10,1)

    # Preserve HF13 return trace.
    _emit_mode_test(out)
    b_ret_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_ret_state=len(out); out += b'\0'*4
    out += li(11,0xF6); _emit_store_byte_abs(out,11,diag_addr,12)

    # Repair is Team-Kirby Adventure only.
    repair_check=base+len(out)
    out[b_ret_mode:b_ret_mode+4]=encode_bc(base+b_ret_mode,repair_check,bo=4,bi=30)
    out[b_ret_state:b_ret_state+4]=encode_bc(base+b_ret_state,repair_check,bo=4,bi=30)

    # One-shot/re-entrancy guard.
    _emit_load_byte_abs(out,11,guard_addr,12); out += cmpwi(11,0,crf=7)
    b_guard=len(out); out += b'\0'*4

    # Retail has to have already committed GAME/termination. terminate_match is
    # a big-endian halfword at VS_SCENE_CONTROLLER+0x06; the low byte is +0x07.
    _emit_load_byte_abs(out,11,VS_TERMINATE_MATCH_ADDR+1,12); out += cmpwi(11,0,crf=7)
    b_no_term=len(out); out += b'\0'*4

    # Only activate for a human Ice Climbers campaign slot.  This keeps normal
    # Team-Kirby teardown entirely retail.
    _emit_load_byte_abs(out,11,p1_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_p1_not_ic=len(out); out += b'\0'*4
    # P1 is Icies -> continue at activate.
    b_p1_ic=len(out); out += b'\0'*4
    p2_check=base+len(out)
    out[b_p1_not_ic:b_p1_not_ic+4]=encode_bc(base+b_p1_not_ic,p2_check,bo=4,bi=30)
    _emit_load_byte_abs(out,11,p2_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_p2_not_ic=len(out); out += b'\0'*4
    activate=base+len(out)
    out[b_p1_ic:b_p1_ic+4]=encode_branch(base+b_p1_ic,activate)

    out += li(11,1); _emit_store_byte_abs(out,11,guard_addr,12)
    out += li(11,0xE1); _emit_store_byte_abs(out,11,diag_addr,12)

    # Match is already over. Slots 2..5 are the co-op Adventure event pool.
    # Drain any lingering Kirby GObjs and normalize both entity refs, using
    # retail routines rather than raw StaticPlayer writes.
    for slot in (2,3,4,5):
        out += li(3,slot)
        out += encode_branch(base+len(out),destroy_trampoline_addr,link=True)
        out += li(3,slot); out += li(4,0)
        out += encode_branch(base+len(out),clear_trampoline_addr,link=True)
        out += li(3,slot); out += li(4,1)
        out += encode_branch(base+len(out),clear_trampoline_addr,link=True)

    out += li(11,0xE2); _emit_store_byte_abs(out,11,diag_addr,12)
    # HF15: guard is re-entrancy only, not a permanent one-shot.  The final
    # Kirby may still be inside its own death callback when the first sweep
    # runs; later teardown callbacks must be allowed to retry the dead-event
    # drain after that callback has returned.
    out += li(11,0); _emit_store_byte_abs(out,11,guard_addr,12)

    done=base+len(out)
    out[b_guard:b_guard+4]=encode_bc(base+b_guard,done,bo=4,bi=30)
    out[b_no_term:b_no_term+4]=encode_bc(base+b_no_term,done,bo=12,bi=30)  # branch if equal (terminate==0)
    out[b_p2_not_ic:b_p2_not_ic+4]=encode_bc(base+b_p2_not_ic,done,bo=4,bi=30)

    out += lwz(3,0x10,1); out += lwz(0,0x44,1); out += mtlr(0); out += addi(1,1,0x40); out += blr()
    return bytes(out)


def _team_kirby_match_end_repair_wrapper(base: int, match_trampoline_addr: int,
                                           destroy_trampoline_addr: int,
                                           clear_trampoline_addr: int, *,
                                           diag_addr: int, slot_addr: int,
                                           guard_addr: int, p1_ckind_addr: int,
                                           p2_ckind_addr: int) -> bytes:
    """HF15 late dead-event sweep after retail Player_80032070 returns.

    HF14 save evidence showed the first drain reduced lingering stock-0 Kirby
    entities from slots 3+4 to slot 4 only.  The final Kirby can therefore still
    be completing its own death lifecycle during the earlier clear-ref callback.
    This wrapper preserves retail Player_80032070 exactly, then retries the
    event-only drain after that later teardown boundary.  Human slots 0/1 are
    never touched.  guard_addr is re-entrancy-only and is cleared after each
    sweep so later legitimate teardown callbacks may retry until the event pool
    is actually quiescent.
    """
    out=bytearray()
    out += stwu(1,-0x40,1); out += mflr(0); out += stw(0,0x44,1)
    out += stw(3,0x08,1); out += stw(4,0x0C,1)

    _emit_mode_test(out)
    b_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_state=len(out); out += b'\0'*4
    out += li(11,0xF1); _emit_store_byte_abs(out,11,diag_addr,12)
    out += lwz(11,0x08,1); _emit_store_byte_abs(out,11,slot_addr,12)
    call_retail=base+len(out)
    out[b_mode:b_mode+4]=encode_bc(base+b_mode,call_retail,bo=4,bi=30)
    out[b_state:b_state+4]=encode_bc(base+b_state,call_retail,bo=4,bi=30)

    out += lwz(3,0x08,1); out += lwz(4,0x0C,1)
    out += encode_branch(base+len(out),match_trampoline_addr,link=True)
    out += stw(3,0x10,1)

    _emit_mode_test(out)
    b_ret_mode=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out += cmpwi(11,TEAM_KIRBY_FIGHT_STATE,crf=7)
    b_ret_state=len(out); out += b'\0'*4
    out += li(11,0xF2); _emit_store_byte_abs(out,11,diag_addr,12)
    repair_check=base+len(out)
    out[b_ret_mode:b_ret_mode+4]=encode_bc(base+b_ret_mode,repair_check,bo=4,bi=30)
    out[b_ret_state:b_ret_state+4]=encode_bc(base+b_ret_state,repair_check,bo=4,bi=30)

    _emit_load_byte_abs(out,11,guard_addr,12); out += cmpwi(11,0,crf=7)
    b_guard=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,VS_TERMINATE_MATCH_ADDR+1,12); out += cmpwi(11,0,crf=7)
    b_no_term=len(out); out += b'\0'*4

    _emit_load_byte_abs(out,11,p1_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_p1_not_ic=len(out); out += b'\0'*4
    b_p1_ic=len(out); out += b'\0'*4
    p2_check=base+len(out)
    out[b_p1_not_ic:b_p1_not_ic+4]=encode_bc(base+b_p1_not_ic,p2_check,bo=4,bi=30)
    _emit_load_byte_abs(out,11,p2_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_p2_not_ic=len(out); out += b'\0'*4
    activate=base+len(out)
    out[b_p1_ic:b_p1_ic+4]=encode_branch(base+b_p1_ic,activate)

    out += li(11,1); _emit_store_byte_abs(out,11,guard_addr,12)
    out += li(11,0xE3); _emit_store_byte_abs(out,11,diag_addr,12)
    for slot in (2,3,4,5):
        out += li(3,slot)
        out += encode_branch(base+len(out),destroy_trampoline_addr,link=True)
        out += li(3,slot); out += li(4,0)
        out += encode_branch(base+len(out),clear_trampoline_addr,link=True)
        out += li(3,slot); out += li(4,1)
        out += encode_branch(base+len(out),clear_trampoline_addr,link=True)
    out += li(11,0xE4); _emit_store_byte_abs(out,11,diag_addr,12)
    out += li(11,0); _emit_store_byte_abs(out,11,guard_addr,12)

    done=base+len(out)
    out[b_guard:b_guard+4]=encode_bc(base+b_guard,done,bo=4,bi=30)
    out[b_no_term:b_no_term+4]=encode_bc(base+b_no_term,done,bo=12,bi=30)
    out[b_p2_not_ic:b_p2_not_ic+4]=encode_bc(base+b_p2_not_ic,done,bo=4,bi=30)
    out += lwz(3,0x10,1); out += lwz(0,0x44,1); out += mtlr(0); out += addi(1,1,0x40); out += blr()
    return bytes(out)

def _adventure_pauser_mode_wrapper(base: int) -> bytes:
    """Let retail's multiplayer pauser scan run for Adventure only.

    This wrapper replaces only the *first* gm_GetCurrentGameMode call inside
    gm_DefaultVSGetPauser.  Returning GM_VS for Adventure makes the function
    skip its P1-only single-player branch; subsequent mode queries in that
    same function remain untouched, so Adventure is not globally reclassified.
    Outside Adventure the original mode value is returned exactly.
    """
    out = bytearray()
    out += stwu(1, -0x20, 1)
    out += stw(0, 0x08, 1)
    out += stw(12, 0x0C, 1)
    out += mflr(0); out += stw(0, 0x10, 1)
    out += encode_branch(base + len(out), GM_GET_CURRENT_GAME_MODE, link=True)
    out += cmpwi(3, GM_ADVENTURE, crf=7)
    b_not_adventure = len(out); out += b'\0' * 4
    out += li(3, GM_VS)
    not_adventure = base + len(out)
    out[b_not_adventure:b_not_adventure+4] = encode_bc(base + b_not_adventure, not_adventure, bo=4, bi=30)
    out += lwz(0, 0x10, 1); out += mtlr(0)
    out += lwz(12, 0x0C, 1)
    out += addi(1, 1, 0x20)
    out += blr()
    return bytes(out)


def _event_allocator_start_wrapper(base: int) -> bytes:
    """Keep human slots 0/1 reserved from Adventure dynamic event enemies.

    Retail fn_8016A09C begins its Gm_PKind_NA search at slot 0.  Co-op normally
    occupies both human slots, but an eliminated partner is intentionally NA in
    Phase 37.  Starting the Adventure allocator at slot 2 prevents a fake-door
    opponent from taking the eliminated human's reserved campaign slot.
    """
    out=bytearray()
    out += stwu(1, -0x10, 1); out += stw(0, 0x08, 1); out += stw(12, 0x0C, 1)
    _emit_mode_test(out)
    b_retail=len(out); out += b'\0'*4
    out += li(30, 2)
    b_done=len(out); out += b'\0'*4
    retail=base+len(out)
    out[b_retail:b_retail+4]=encode_bc(base+b_retail, retail, bo=4, bi=30)
    out += li(30, 0)
    done=base+len(out)
    out[b_done:b_done+4]=encode_branch(base+b_done, done)
    out += lwz(0,0x08,1); out += lwz(12,0x0C,1); out += addi(1,1,0x10)
    out += encode_branch(base+len(out), EVENT_ALLOCATOR_START_HOOK+4)
    return bytes(out)


def _dynamic_enemy_spawn_wrapper(base: int) -> bytes:
    """Undo the +1 event spawn-marker shift caused by co-op's occupied slot 1.

    At the hook r3 is already retail getSpawnPointIndex(spawn_slot) and r26 is
    the dynamic spawn slot. Retail Adventure's first event enemy was slot 1;
    co-op reserves humans in 0/1, moving that enemy to slot 2.  For Adventure
    event slots >=2, subtract one logical slot before asking Ground for the
    spawn marker, then execute the original Ground_801C2D24 call and return.
    """
    out=bytearray()
    _emit_mode_test(out)
    b_call=len(out); out += b'\0'*4
    out += cmpwi(26, 2, crf=7)
    b_call_lt=len(out); out += b'\0'*4
    out += addi(3, 3, -1)
    call=base+len(out)
    out[b_call:b_call+4]=encode_bc(base+b_call, call, bo=4, bi=30)
    out[b_call_lt:b_call_lt+4]=encode_bc(base+b_call_lt, call, bo=12, bi=28)
    out += encode_branch(base+len(out), GROUND_GET_SPAWN_POS, link=True)
    out += encode_branch(base+len(out), DYNAMIC_ENEMY_SPAWN_HOOK+4)
    return bytes(out)


def _static_fighter_spawn_slot_wrapper(base: int, camera_owner_addr: int | None = None) -> bytes:
    """Repair only the static-fighter 0xFF fallback with a live fighter anchor.

    In ``fn_8016E2BC`` the hook site is reached after the scripted fighter's
    spawn-marker byte is tested against ``0xFF``.  Explicit retail encounter
    markers therefore remain authoritative and never enter this fallback.

    SDK 0.20.6 incorrectly used ``Player_LoadPlayerCoords`` here.  That helper
    copies ``StaticPlayer.player_poses`` and is not a live world-position read.
    For active gateway CPU slots 2+, resolve the current Control owner's live
    Fighter GObj with ``Player_GetEntity`` and copy ``Fighter.cur_pos`` through
    ``ftLib_80086644``.  Human slots, a missing owner entity, and inactive
    campaigns all fail closed to the exact displaced retail fallback path.
    """
    if camera_owner_addr is None:
        raise ValueError('static fighter encounter anchoring requires camera_owner_addr')
    out=bytearray()
    out += stwu(1, -0x20, 1)
    out += mflr(0); out += stw(0, 0x08, 1)
    out += stw(4, 0x0C, 1)
    out += stw(11, 0x10, 1)
    out += stw(12, 0x14, 1)

    out += cmpwi(28, 2, crf=7)
    b_retail=len(out); out += b'\0'*4

    # CPU-domain fallback: clamp unexpected ownership to P1, resolve the live
    # fighter object, then read Fighter.cur_pos.  Never substitute a stale
    # StaticPlayer pose.
    _emit_load_byte_abs(out, 11, camera_owner_addr, 12)
    out += cmpwi(11, 0, crf=7)
    b_owner0=len(out); out += b'\0'*4
    out += cmpwi(11, 1, crf=7)
    b_owner1=len(out); out += b'\0'*4
    out += li(11, 0)
    owner_ok=base+len(out)
    out[b_owner0:b_owner0+4]=encode_bc(base+b_owner0, owner_ok, bo=12, bi=30)
    out[b_owner1:b_owner1+4]=encode_bc(base+b_owner1, owner_ok, bo=12, bi=30)

    out += addi(3, 11, 0)
    out += encode_branch(base+len(out), PLAYER_GET_ENTITY, link=True)
    out += cmpwi(3, 0, crf=7)
    b_null=len(out); out += b'\0'*4
    out += lwz(4, 0x0C, 1)
    out += encode_branch(base+len(out), FTLIB_GET_CUR_POS, link=True)
    out += lwz(0, 0x08, 1); out += mtlr(0)
    out += lwz(4, 0x0C, 1)
    out += lwz(11, 0x10, 1); out += lwz(12, 0x14, 1)
    out += addi(1, 1, 0x20)
    # We have already filled the caller's Vec3. Skip retail slot fallback and
    # resume immediately after Stage_80224E64.
    out += encode_branch(base+len(out), STATIC_FIGHTER_SPAWN_SLOT_HOOK+0x0C)

    retail=base+len(out)
    out[b_retail:b_retail+4]=encode_bc(base+b_retail, retail, bo=12, bi=28)
    out[b_null:b_null+4]=encode_bc(base+b_null, retail, bo=12, bi=30)
    out += lwz(0, 0x08, 1); out += mtlr(0)
    out += lwz(4, 0x0C, 1)
    out += lwz(11, 0x10, 1); out += lwz(12, 0x14, 1)
    out += addi(1, 1, 0x20)
    out += addi(3, 28, 0)  # displaced retail mr r3,r28
    out += encode_branch(base+len(out), STATIC_FIGHTER_SPAWN_SLOT_HOOK+4)
    return bytes(out)



def _adventure_slippi_spawn_guard_wrapper(base: int, *, pad_to: int = 144) -> bytes:
    """Preserve retail Adventure placement while coexisting with Slippi.

    Slippi/Faster Melee rewrites ``0x8016E510`` at runtime.  That site is one
    instruction after retail commits each multi-slot fighter's coordinates via
    ``0x80032768``.  The online hook performs multiplayer spawn normalization;
    in two-human Adventure it also sees scripted CPUs and can relocate them.

    Hook one instruction earlier.  Always execute the displaced retail call.
    Outside Adventure, reconstruct the original LR value and continue at
    0x8016E510 so any Slippi runtime hook still runs unchanged.  In Adventure,
    reconstruct that LR value, execute the exact displaced retail 0x8016E510
    instruction (``lbz r0,0x24D0(r31)``), and continue at 0x8016E514.  No CPU
    coordinates are invented, remapped, or anchored to either human.
    """
    out=bytearray()
    # Displaced retail BL.  The wrapper is entered with r3=slot and r4=&Vec3.
    out += encode_branch(base+len(out), MULTISLOT_POSITION_COMMIT, link=True)
    _emit_mode_test(out)
    b_non_adventure=len(out); out += b'\0'*4

    # Exact LR state produced by the original BL at 0x8016E50C.
    hi, lo = _addr_parts(MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE)
    out += lis(12, hi); out += addi(12, 12, lo); out += mtlr(12)
    # Adventure: execute retail 0x8016E510 locally, bypassing only Slippi's
    # runtime VS-spawn normalizer, then resume at the next retail instruction.
    out += lbz(0, MULTISLOT_RETAIL_TEAMFLAG_OFFSET, 31)
    out += encode_branch(base+len(out), MULTISLOT_RETAIL_CONTINUE)

    non_adventure=base+len(out)
    out[b_non_adventure:b_non_adventure+4]=encode_bc(base+b_non_adventure, non_adventure, bo=4, bi=30)
    # Non-Adventure: recreate original LR and return to the real site. If
    # Slippi has replaced 0x8016E510, its hook executes exactly as before.
    out += lis(12, hi); out += addi(12, 12, lo); out += mtlr(12)
    out += encode_branch(base+len(out), MULTISLOT_SLIPPI_RUNTIME_HOOK_SITE)

    if len(out) > pad_to:
        raise ValueError(f'Slippi spawn guard grew beyond reserved layout: {len(out)} > {pad_to}')
    while len(out) < pad_to:
        out += nop()
    return bytes(out)


def _ground_event_either_human_wrapper(base: int, trampoline_addr: int, camera_owner_addr: int, test_shortcuts_addr: int | None = None, *, p2_ckind_addr: int | None = None, icies_teardown_guard_addr: int | None = None, p1_form_addr: int | None = None, p2_form_addr: int | None = None, icies_diag_addr: int | None = None) -> bytes:
    """Evaluate retail's shared Adventure trigger scanner for P1 OR P2.

    Ground_801C0C2C owns the generic stage-volume detectors backed by
    stage_info.{x70C,x710,x714} and {x718,x71C,x720}. Retail calls
    Ground_GetP1Fighter(), which Phase 34 deliberately redirects to the
    persistent Control owner. This wrapper keeps that redirect intact for
    camera/route logic but runs this *one* scanner once per instantiated human.

    The scanner clears its one-frame request bits after evaluating them, so the
    request byte is snapshotted and restored before P2's pass. Results are
    merged independently: P2's hit wins when present; otherwise P1's hit is
    retained. The original Control owner is restored before returning.
    """
    out=bytearray()
    out += stwu(1, -0x30, 1)
    out += mflr(0); out += stw(0, 0x08, 1)
    out += stw(3, 0x0C, 1)  # original HSD_GObj* proc argument
    _emit_mode_test(out)
    b_retail=len(out); out += b'\0'*4

    # HF5 active-form tracker: observe actual FighterKind for each human.
    for slot, form_addr in ((0, p1_form_addr), (1, p2_form_addr)):
        if form_addr is not None:
            out += li(3, slot)
            out += encode_branch(base+len(out), PLAYER_GET_ACTIVE_FTKIND, link=True)
            out += cmpwi(3, FTKIND_ZELDA, crf=7)
            b_z = len(out); out += b'\0'*4
            out += cmpwi(3, FTKIND_SEAK, crf=7)
            b_not_s = len(out); out += b'\0'*4
            out += li(11, CKIND_SEAK); _emit_store_byte_abs(out,11,form_addr,12)
            b_form_done = len(out); out += b'\0'*4
            set_z = base + len(out)
            out[b_z:b_z+4] = encode_bc(base+b_z, set_z, bo=12, bi=30)
            out += li(11, CKIND_ZELDA); _emit_store_byte_abs(out,11,form_addr,12)
            form_done = base + len(out)
            out[b_not_s:b_not_s+4] = encode_bc(base+b_not_s, form_done, bo=4, bi=30)
            out[b_form_done:b_form_done+4] = encode_branch(base+b_form_done, form_done)

    # HF7: Icies teardown moved out of this per-frame ground scanner.
    # HF6 savestate proved this scanner no longer runs once GAME! termination
    # begins. Team-Kirby now installs a dedicated pre-GAME on_match_end callback.

    # Snapshot authority and the scanner's request byte.
    _emit_load_byte_abs(out, 11, camera_owner_addr, 12); out += stw(11, 0x10, 1)
    _emit_load_byte_abs(out, 11, STAGE_EVENT_FLAGS_ADDR, 12); out += stw(11, 0x14, 1)
    out += li(11, -1); out += stw(11, 0x18, 1); out += stw(11, 0x1C, 1)
    out += li(11, 0); out += stw(11, 0x20, 1)  # P1-pass flag

    # P1 pass only if slot 0 currently has a fighter entity.
    out += li(3, 0)
    out += encode_branch(base+len(out), PLAYER_GET_ENTITY, link=True)
    out += cmpwi(3, 0, crf=7)
    b_skip_p1=len(out); out += b'\0'*4
    out += li(11, 0); _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    out += lwz(3, 0x0C, 1)
    out += encode_branch(base+len(out), trampoline_addr, link=True)
    _emit_load_word_abs(out, 11, STAGE_EVENT_RESULT_A_ADDR, 12); out += stw(11, 0x18, 1)
    _emit_load_word_abs(out, 11, STAGE_EVENT_RESULT_B_ADDR, 12); out += stw(11, 0x1C, 1)
    out += li(11, 1); out += stw(11, 0x20, 1)
    skip_p1=base+len(out)
    out[b_skip_p1:b_skip_p1+4]=encode_bc(base+b_skip_p1, skip_p1, bo=12, bi=30)  # beq CR7

    # P2 pass only if slot 1 currently has a fighter entity.
    out += li(3, 1)
    out += encode_branch(base+len(out), PLAYER_GET_ENTITY, link=True)
    out += cmpwi(3, 0, crf=7)
    b_no_p2=len(out); out += b'\0'*4
    # If P1 already consumed the scanner request, re-arm exactly the byte that
    # was present on entry. If P1 was absent, the retail scanner was not called
    # and the request remains live already.
    out += lwz(11, 0x20, 1); out += cmpwi(11, 0, crf=7)
    b_no_rearm=len(out); out += b'\0'*4
    out += lwz(11, 0x14, 1); _emit_store_byte_abs(out, 11, STAGE_EVENT_FLAGS_ADDR, 12)
    no_rearm=base+len(out)
    out[b_no_rearm:b_no_rearm+4]=encode_bc(base+b_no_rearm, no_rearm, bo=12, bi=30)
    out += li(11, 1); _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    out += lwz(3, 0x0C, 1)
    out += encode_branch(base+len(out), trampoline_addr, link=True)

    # If both passes ran, retain P1's result only when P2 did not hit.
    out += lwz(11, 0x20, 1); out += cmpwi(11, 0, crf=7)
    b_after_merge=len(out); out += b'\0'*4
    _emit_load_word_abs(out, 11, STAGE_EVENT_RESULT_A_ADDR, 12); out += cmpwi(11, -1, crf=7)
    b_keep_a=len(out); out += b'\0'*4
    out += lwz(11, 0x18, 1); _emit_store_word_abs(out, 11, STAGE_EVENT_RESULT_A_ADDR, 12)
    keep_a=base+len(out)
    out[b_keep_a:b_keep_a+4]=encode_bc(base+b_keep_a, keep_a, bo=4, bi=30)  # bne CR7
    _emit_load_word_abs(out, 11, STAGE_EVENT_RESULT_B_ADDR, 12); out += cmpwi(11, -1, crf=7)
    b_keep_b=len(out); out += b'\0'*4
    out += lwz(11, 0x1C, 1); _emit_store_word_abs(out, 11, STAGE_EVENT_RESULT_B_ADDR, 12)
    keep_b=base+len(out)
    out[b_keep_b:b_keep_b+4]=encode_bc(base+b_keep_b, keep_b, bo=4, bi=30)
    after_merge=base+len(out)
    out[b_after_merge:b_after_merge+4]=encode_bc(base+b_after_merge, after_merge, bo=12, bi=30)
    b_done=len(out); out += b'\0'*4

    # P2 absent: P1 result is already final. If neither human exists, execute
    # retail once under the original owner so the proc's unrelated housekeeping
    # is not skipped.
    no_p2=base+len(out)
    out[b_no_p2:b_no_p2+4]=encode_bc(base+b_no_p2, no_p2, bo=12, bi=30)
    out += lwz(11, 0x20, 1); out += cmpwi(11, 0, crf=7)
    b_done_p1=len(out); out += b'\0'*4
    out += lwz(11, 0x10, 1); _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    out += lwz(3, 0x0C, 1)
    out += encode_branch(base+len(out), trampoline_addr, link=True)
    done_p1=base+len(out)
    out[b_done_p1:b_done_p1+4]=encode_bc(base+b_done_p1, done_p1, bo=4, bi=30)

    done=base+len(out)
    out[b_done:b_done+4]=encode_branch(base+b_done, done)
    # Restore persistent Control exactly.
    out += lwz(11, 0x10, 1); _emit_store_byte_abs(out, 11, camera_owner_addr, 12)
    # Developer shortcuts are deliberately piggy-backed on this already proven
    # Adventure-only proc rather than introducing another retail hook site.
    if test_shortcuts_addr is not None:
        out += encode_branch(base+len(out), test_shortcuts_addr, link=True)
    b_epilogue=len(out); out += b'\0'*4

    # Non-Adventure: retail scanner exactly once.
    retail=base+len(out)
    out[b_retail:b_retail+4]=encode_bc(base+b_retail, retail, bo=4, bi=30)
    out += lwz(3, 0x0C, 1)
    out += encode_branch(base+len(out), trampoline_addr, link=True)

    epilogue=base+len(out)
    out[b_epilogue:b_epilogue+4]=encode_branch(base+b_epilogue, epilogue)
    out += lwz(0, 0x08, 1); out += mtlr(0)
    out += addi(1, 1, 0x30); out += blr()
    return bytes(out)



def _adventure_test_shortcuts_stub(base: int, *, offscreen_vec_addr: int,
                                   persistence_valid_addr: int,
                                   p1_stocks_addr: int, p2_stocks_addr: int,
                                   initial_stocks_addr: int) -> bytes:
    """Test-only L+D-pad shortcuts for fast Co-op Adventure fringe testing.

    Down requests a retail match termination with the generic 1P stage-end
    outcome. Left/Right move P1/P2 below the blast zone, letting the normal
    death/stock machinery process the KO. Up restores both current/saved stock
    counters to the campaign's original selection; an already eliminated human
    is intentionally not manufactured mid-scene and returns on the next scene
    when scene-revive is enabled.
    """
    out=bytearray()
    out += stwu(1, -0x20, 1); out += mflr(0); out += stw(0, 0x08, 1)
    _emit_mode_test(out)
    b_return=len(out); out += b'\0'*4

    action_branches=[]
    # Prefer P1's shortcut if both controllers chord on the same frame.
    for pad_index in (0,1):
        pad=HSD_PAD_COPY_STATUS + PAD_STATUS_STRIDE*pad_index
        hi,lo=_addr_parts(pad)
        out += lis(12,hi)
        out += lwz(11,lo+PAD_BUTTON_OFF,12)
        out += andi_dot(10,11,PAD_BUTTON_L)
        b_next_no_l=len(out); out += b'\0'*4
        out += lwz(11,lo+PAD_TRIGGER_OFF,12)
        for mask,action in ((PAD_BUTTON_DDOWN,'clear'),(PAD_BUTTON_DLEFT,'p1ko'),(PAD_BUTTON_DRIGHT,'p2ko'),(PAD_BUTTON_DUP,'restore')):
            out += andi_dot(10,11,mask)
            b=len(out); out += b'\0'*4
            action_branches.append((b,action))
        next_pad=base+len(out)
        out[b_next_no_l:b_next_no_l+4]=encode_bc(base+b_next_no_l,next_pad,bo=12,bi=2)

    b_no_action=len(out); out += b'\0'*4

    action_addrs={}
    # Stage clear: use retail VsSceneController termination path, not direct
    # scene-ID jumping. Outcome 6 is retail's generic 1P non-single-match end.
    action_addrs['clear']=base+len(out)
    out += li(11,MATCH_OUTCOME_1P_STAGE_END); _emit_store_byte_abs(out,11,VS_MATCH_RESULT_ADDR,12)
    out += li(11,1); _emit_store_byte_abs(out,11,VS_TERMINATE_MATCH_ADDR,12)
    b_clear_done=len(out); out += b'\0'*4

    def emit_ko(slot:int):
        out.extend(li(3,slot))
        hi,lo=_addr_parts(offscreen_vec_addr); out.extend(lis(4,hi)); out.extend(addi(4,4,lo))
        out.extend(encode_branch(base+len(out),PLAYER_SET_POSITION,link=True))
    action_addrs['p1ko']=base+len(out); emit_ko(0); b_p1_done=len(out); out += b'\0'*4
    action_addrs['p2ko']=base+len(out); emit_ko(1); b_p2_done=len(out); out += b'\0'*4

    action_addrs['restore']=base+len(out)
    _emit_load_byte_abs(out,11,initial_stocks_addr,12); out += cmpwi(11,0,crf=7)
    b_restore_done=len(out); out += b'\0'*4
    # Persisted counters first, then retail player counters for slots 0/1.
    _emit_store_byte_abs(out,11,p1_stocks_addr,12); _emit_store_byte_abs(out,11,p2_stocks_addr,12)
    out += li(10,1); _emit_store_byte_abs(out,10,persistence_valid_addr,12)
    out += stw(11,0x0C,1)
    for slot in (0,1):
        out += li(3,slot); out += lwz(4,0x0C,1)
        out += encode_branch(base+len(out),PLAYER_SET_STOCKS,link=True)
    restore_done=base+len(out)
    out[b_restore_done:b_restore_done+4]=encode_bc(base+b_restore_done,restore_done,bo=12,bi=30)

    done=base+len(out)
    for pos in (b_no_action,b_clear_done,b_p1_done,b_p2_done):
        out[pos:pos+4]=encode_branch(base+pos,done)
    for pos,act in action_branches:
        out[pos:pos+4]=encode_bc(base+pos,action_addrs[act],bo=4,bi=2)
    out[b_return:b_return+4]=encode_bc(base+b_return,done,bo=4,bi=30)
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x20); out += blr()
    return bytes(out)


def _adventure_hud_capacity_wrapper(base: int) -> bytes:
    """Tail-call retail HUD init, but expose all six physical slots in Adventure.

    ifStatus_802F6508 itself still checks Gm_PKind_NA, so raising the capacity
    does not manufacture HUDs for empty slots.  It only allows CPUs in slots
    2+ (Zelda/Sheik, Giga Bowser, dynamic enemies, etc.) to receive their
    normal portrait/stock/percentage objects.
    """
    out=bytearray()
    _emit_mode_test(out)
    b_not_adv=len(out); out += b'\0'*4
    out += li(3, 6)
    not_adv=base+len(out)
    out[b_not_adv:b_not_adv+4]=encode_bc(base+b_not_adv,not_adv,bo=4,bi=30)
    out += encode_branch(base+len(out), IFSTATUS_INIT)
    return bytes(out)


def _staffroll_dual_pad_wrapper(base: int, campaign_valid_addr: int | None = None) -> bytes:
    """Merge both physical pads into retail's one staff-roll cursor stream.

    Retail only owns one cursor. HF5 removes first-input ownership: buttons and
    triggers are ORed; P2 supplies an axis whenever P1 is neutral on that axis.
    """
    out=bytearray()
    _emit_mode_test(out)
    b_check=len(out); out += b'\0'*4
    b_merge_mode=len(out); out += b'\0'*4
    check=base+len(out); out[b_check:b_check+4]=encode_bc(base+b_check,check,bo=4,bi=30)
    if campaign_valid_addr is not None:
        _emit_load_byte_abs(out,11,campaign_valid_addr,12); out += cmpwi(11,0,crf=7)
        b_retail=len(out); out += b'\0'*4
    else:
        b_retail=len(out); out += b'\0'*4
    merge=base+len(out); out[b_merge_mode:b_merge_mode+4]=encode_branch(base+b_merge_mode,merge)
    p1=HSD_PAD_COPY_STATUS; p2=HSD_PAD_COPY_STATUS+PAD_STATUS_STRIDE
    h1,l1=_addr_parts(p1); h2,l2=_addr_parts(p2)
    out += lis(10,h1); out += lis(12,h2)
    for off in (PAD_BUTTON_OFF,PAD_TRIGGER_OFF):
        out += lwz(11,l1+off,10); out += lwz(9,l2+off,12); out += _or_reg(11,11,9); out += stw(11,l1+off,10)
    for off in (PAD_STICK_X_OFF,PAD_STICK_Y_OFF):
        out += lbz(11,l1+off,10); out += cmpwi(11,0,crf=7)
        b_keep=len(out); out += b'\0'*4
        out += lbz(9,l2+off,12); out += stb(9,l1+off,10)
        keep=base+len(out); out[b_keep:b_keep+4]=encode_bc(base+b_keep,keep,bo=4,bi=30)
    out += li(3,0); out += blr()
    retail=base+len(out)
    if campaign_valid_addr is not None:
        out[b_retail:b_retail+4]=encode_bc(base+b_retail,retail,bo=12,bi=30)
    else:
        out[b_retail:b_retail+4]=encode_branch(base+b_retail,retail)
    out += lis(3,0x804A); out += addi(3,3,-0x3E88); out += lbz(3,9,3); out += blr()
    return bytes(out)


def _staffroll_independent_pad_wrapper(base: int, campaign_valid_addr: int,
                                       credits_pass_addr: int,
                                       *, padded_size: int = 140) -> bytes:
    """Return pad 0 for P1 pass and pad 1 for P2 pass without buffer merging.

    Outside an established co-op campaign this reproduces retail gm_801BF010.
    The fixed padded size preserves the pre-0.20.14 payload layout downstream.
    """
    out=bytearray()
    _emit_load_byte_abs(out,11,campaign_valid_addr,12); out += cmpwi(11,0,crf=7)
    b_retail=len(out); out += b'\0'*4
    _emit_load_byte_abs(out,11,credits_pass_addr,12); out += cmpwi(11,1,crf=7)
    b_p1=len(out); out += b'\0'*4
    out += li(3,1); out += blr()
    p1=base+len(out); out[b_p1:b_p1+4]=encode_bc(base+b_p1,p1,bo=4,bi=30)
    out += li(3,0); out += blr()
    retail=base+len(out); out[b_retail:b_retail+4]=encode_bc(base+b_retail,retail,bo=12,bi=30)
    # Exact retail gm_801BF010 body.
    out += lis(3,0x804A); out += addi(3,3,-0x3E88); out += lbz(3,9,3); out += blr()
    if len(out) > padded_size:
        raise ValueError('independent Staff Roll pad wrapper exceeded reserved legacy size')
    while len(out) < padded_size:
        out += nop()
    return bytes(out)


def _staffroll_cursor_lookup_wrapper(base: int, credits_pass_addr: int,
                                     p2_cursor_ptr_addr: int) -> bytes:
    """Run retail cursor lookup, then substitute the cloned P2 lens on pass 1."""
    out=bytearray()
    out += stwu(1,-0x20,1); out += mflr(0); out += stw(0,0x08,1); out += stw(4,0x0C,1)
    out += encode_branch(base+len(out), LB_JOBJ_LOOKUP, link=True)
    _emit_load_byte_abs(out,11,credits_pass_addr,12); out += cmpwi(11,1,crf=7)
    b_done1=len(out); out += b'\0'*4
    _emit_load_word_abs(out,11,p2_cursor_ptr_addr,12); out += cmpwi(11,0,crf=7)
    b_done2=len(out); out += b'\0'*4
    out += lwz(4,0x0C,1); out += stw(11,0,4)
    done=base+len(out)
    out[b_done1:b_done1+4]=encode_bc(base+b_done1,done,bo=4,bi=30)   # pass != 1
    out[b_done2:b_done2+4]=encode_bc(base+b_done2,done,bo=12,bi=30)  # missing clone
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x20); out += blr()
    return bytes(out)


def _staffroll_p2_shot_node5_lookup_wrapper(base: int, credits_pass_addr: int,
                                              p2_assembly_ptr_addr: int) -> bytes:
    """Redirect the unconditional A-button muzzle animation to P2's assembly.

    Retail node 5 owns the visible fire animation at 0x801ABA24. 0.20.16
    clones node 5 as the root of P2's complete shooter assembly, so the lookup
    result can be replaced directly during only the P2-local pass.
    """
    out=bytearray()
    out += stwu(1,-0x20,1); out += mflr(0); out += stw(0,0x08,1); out += stw(4,0x0C,1)
    out += encode_branch(base+len(out),LB_JOBJ_LOOKUP,link=True)
    _emit_load_byte_abs(out,11,credits_pass_addr,12); out += cmpwi(11,1,crf=7)
    b_done1=len(out); out += b'\0'*4
    _emit_load_word_abs(out,11,p2_assembly_ptr_addr,12); out += cmpwi(11,0,crf=7)
    b_done2=len(out); out += b'\0'*4
    out += lwz(4,0x0C,1); out += stw(11,0,4)
    done=base+len(out)
    out[b_done1:b_done1+4]=encode_bc(base+b_done1,done,bo=4,bi=30)
    out[b_done2:b_done2+4]=encode_bc(base+b_done2,done,bo=12,bi=30)
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x20); out += blr()
    return bytes(out)


def _staffroll_p2_shot_node8_lookup_wrapper(base: int, credits_pass_addr: int,
                                             p2_cursor_ptr_addr: int) -> bytes:
    """Redirect target-hit node 8 to the cloned P2 cursor's child."""
    out=bytearray()
    out += stwu(1,-0x20,1); out += mflr(0); out += stw(0,0x08,1); out += stw(4,0x0C,1)
    out += encode_branch(base+len(out),LB_JOBJ_LOOKUP,link=True)
    _emit_load_byte_abs(out,11,credits_pass_addr,12); out += cmpwi(11,1,crf=7)
    b_done1=len(out); out += b'\0'*4
    _emit_load_word_abs(out,11,p2_cursor_ptr_addr,12); out += cmpwi(11,0,crf=7)
    b_done2=len(out); out += b'\0'*4
    out += lwz(11,0x10,11); out += cmpwi(11,0,crf=7)
    b_done3=len(out); out += b'\0'*4
    out += lwz(4,0x0C,1); out += stw(11,0,4)
    done=base+len(out)
    out[b_done1:b_done1+4]=encode_bc(base+b_done1,done,bo=4,bi=30)
    out[b_done2:b_done2+4]=encode_bc(base+b_done2,done,bo=12,bi=30)
    out[b_done3:b_done3+4]=encode_bc(base+b_done3,done,bo=12,bi=30)
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x20); out += blr()
    return bytes(out)


def _staffroll_local_pass_end_wrapper(base: int, credits_pass_addr: int) -> bytes:
    """End P2's shooter-local pass before shared Staff Roll timeline updates."""
    out=bytearray()
    _emit_load_byte_abs(out,11,credits_pass_addr,12); out += cmpwi(11,1,crf=7)
    b_normal=len(out); out += b'\0'*4
    out += encode_branch(base+len(out), STAFFROLL_RETAIL_EPILOGUE)
    normal=base+len(out); out[b_normal:b_normal+4]=encode_bc(base+b_normal,normal,bo=4,bi=30)
    out += STAFFROLL_LOCAL_PASS_END_EXPECTED
    out += encode_branch(base+len(out), STAFFROLL_LOCAL_PASS_END_HOOK+4)
    return bytes(out)


def _staffroll_dual_lens_proc(base: int, campaign_valid_addr: int,
                              credits_pass_addr: int,
                              p2_assembly_ptr_addr: int,
                              p2_cursor_ptr_addr: int,
                              terminal_diag_addr: int | None = None) -> bytes:
    """Run P2's local shooter pass, then one complete retail P1 pass.

    The extra local pass is valid only while Staff Roll is interactive. Retail
    changes object ownership at timeline frame 4741. Every supplied freeze was
    captured immediately after that boundary (4744/4744/4746), so 0.20.16
    retires P2's pass there and lets retail alone own terminal teardown.
    """
    out=bytearray()
    out += stwu(1,-0x20,1); out += mflr(0); out += stw(0,0x08,1); out += stw(3,0x0C,1)
    _emit_load_byte_abs(out,11,campaign_valid_addr,12); out += cmpwi(11,0,crf=7)
    b_p1_only=len(out); out += b'\0'*4
    _emit_load_word_abs(out,11,p2_cursor_ptr_addr,12); out += cmpwi(11,0,crf=7)
    b_p1_only2=len(out); out += b'\0'*4

    # Do not execute a second shooter-local traversal once retail begins its
    # terminal object phase. Clear SDK pointers (without freeing the reparented
    # subtree) so all subsequent frames are provably P1-retail-only.
    _emit_load_word_abs(out,11,STAFFROLL_TIMELINE_COUNTER_ADDR,12)
    out += cmpwi(11,STAFFROLL_INTERACTIVE_END_FRAME,crf=7)
    b_interactive=len(out); out += b'\0'*4
    if terminal_diag_addr is not None:
        out += li(11,0xC1); _emit_store_byte_abs(out,11,terminal_diag_addr,12)
    out += li(11,0)
    _emit_store_word_abs(out,11,p2_assembly_ptr_addr,12)
    _emit_store_word_abs(out,11,p2_cursor_ptr_addr,12)
    _emit_store_byte_abs(out,11,credits_pass_addr,12)
    b_terminal_p1=len(out); out += b'\0'*4

    interactive=base+len(out)
    out[b_interactive:b_interactive+4]=encode_bc(base+b_interactive,interactive,bo=12,bi=28)  # CR7 LT
    out += li(11,1); _emit_store_byte_abs(out,11,credits_pass_addr,12)
    out += lwz(3,0x0C,1); out += encode_branch(base+len(out),STAFFROLL_RETAIL_PROC,link=True)

    p1_only=base+len(out)
    for pos in (b_p1_only,b_p1_only2):
        out[pos:pos+4]=encode_bc(base+pos,p1_only,bo=12,bi=30)
    out[b_terminal_p1:b_terminal_p1+4]=encode_branch(base+b_terminal_p1,p1_only)
    out += li(11,0); _emit_store_byte_abs(out,11,credits_pass_addr,12)
    out += lwz(3,0x0C,1); out += encode_branch(base+len(out),STAFFROLL_RETAIL_PROC,link=True)
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x20); out += blr()
    return bytes(out)


def _staffroll_setup_proc_wrapper(base: int, campaign_valid_addr: int,
                                  credits_pass_addr: int,
                                  p2_assembly_ptr_addr: int,
                                  p2_cursor_ptr_addr: int,
                                  dual_proc_addr: int) -> bytes:
    """Clone retail node 5 so P2 owns one complete shooter/lens assembly.

    Retail node 5 is the unconditional A-button firing animation. Its subtree
    contains node 6 followed by cursor node 7; node 7 in turn contains hit node
    8. Cloning node 5 therefore keeps P2's muzzle animation, moving lens, and
    target-hit animation in one coherent JObj subtree instead of mixing a P2
    cursor with P1's firing parent.

    The source HSD_Joint descriptor's ``next`` field is temporarily cleared so
    HSD_JObjLoadJoint clones only node 5 and descendants, not unrelated
    following siblings. The clone is reparented beside retail node 5, making
    it part of the normal scene graph for teardown.
    """
    out=bytearray()
    out += stwu(1,-0x50,1); out += mflr(0); out += stw(0,0x08,1)
    out += stw(3,0x0C,1); out += stw(5,0x10,1)
    out += li(11,0)
    _emit_store_byte_abs(out,11,credits_pass_addr,12)
    _emit_store_word_abs(out,11,p2_assembly_ptr_addr,12)
    _emit_store_word_abs(out,11,p2_cursor_ptr_addr,12)
    _emit_load_byte_abs(out,11,campaign_valid_addr,12); out += cmpwi(11,0,crf=7)
    b_register=len(out); out += b'\0'*4

    # Find retail node 5 (the complete shooter assembly root).
    out += lwz(3,0x0C,1); out += lwz(3,0x28,3); out += addi(4,1,0x14); out += li(5,5); out += li(6,-1)
    out += bytes.fromhex('4cc63182')
    out += encode_branch(base+len(out),LB_JOBJ_LOOKUP,link=True)
    out += lwz(11,0x14,1); out += cmpwi(11,0,crf=7)
    b_register2=len(out); out += b'\0'*4
    out += stw(11,0x18,1)

    # Clone only node 5's subtree.
    out += lwz(3,0x84,11); out += stw(3,0x20,1)
    out += lwz(10,0x0C,3); out += stw(10,0x24,1); out += li(0,0); out += stw(0,0x0C,3)
    out += encode_branch(base+len(out),HSD_JOBJ_LOAD_JOINT,link=True)
    out += stw(3,0x1C,1)
    out += lwz(11,0x20,1); out += lwz(10,0x24,1); out += stw(10,0x0C,11)
    out += lwz(3,0x1C,1); out += cmpwi(3,0,crf=7)
    b_register3=len(out); out += b'\0'*4

    # Restore retail node 5 as the descriptor's default ID-table object.
    out += li(3,0); out += lwz(5,0x18,1); out += lwz(4,0x84,5)
    out += encode_branch(base+len(out),HSD_ID_INSERT_TO_TABLE,link=True)

    # Derive cloned cursor node 7: clone5->child(node6)->next(node7).
    out += lwz(11,0x1C,1); out += lwz(10,0x10,11); out += cmpwi(10,0,crf=7)
    b_drop1=len(out); out += b'\0'*4
    out += lwz(10,0x08,10); out += cmpwi(10,0,crf=7)
    b_drop2=len(out); out += b'\0'*4
    out += stw(10,0x28,1)

    # Reparent the complete P2 assembly beside retail node 5.
    out += lwz(11,0x18,1); out += lwz(4,0x0C,11); out += cmpwi(4,0,crf=7)
    b_drop3=len(out); out += b'\0'*4
    out += lwz(3,0x1C,1); out += encode_branch(base+len(out),HSD_JOBJ_REPARENT,link=True)
    out += lwz(11,0x1C,1); _emit_store_word_abs(out,11,p2_assembly_ptr_addr,12)
    out += lwz(11,0x28,1); _emit_store_word_abs(out,11,p2_cursor_ptr_addr,12)
    b_register_after=len(out); out += b'\0'*4

    drop_clone=base+len(out)
    for pos in (b_drop1,b_drop2,b_drop3):
        out[pos:pos+4]=encode_bc(base+pos,drop_clone,bo=12,bi=30)
    out += lwz(3,0x1C,1); out += encode_branch(base+len(out),HSD_JOBJ_REMOVE_ALL,link=True)

    register=base+len(out)
    for pos in (b_register,b_register2,b_register3):
        out[pos:pos+4]=encode_bc(base+pos,register,bo=12,bi=30)
    out[b_register_after:b_register_after+4]=encode_branch(base+b_register_after,register)
    out += lwz(3,0x0C,1)
    hi,lo=_addr_parts(dual_proc_addr); out += lis(4,hi); out += addi(4,4,lo)
    out += lwz(5,0x10,1); out += encode_branch(base+len(out),HSD_GOBJ_SETUP_PROC,link=True)
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x50); out += blr()
    return bytes(out)


def _luigi_coop_fight_setup_wrapper(base: int) -> bytes:
    """Co-op equivalent of retail gm_801B461C; preserve P2 and replace CPU Mario."""
    out=bytearray()
    out += stwu(1,-0x20,1); out += mflr(0); out += stw(0,0x08,1); out += stw(3,0x0C,1)
    out += encode_branch(base+len(out), GM_801B4064, link=True)
    out += encode_branch(base+len(out), GM_GET_PREVIOUS_SCENE_INDEX, link=True)
    out += cmpwi(3, ADVENTURE_LUIGI_CUTSCENE, crf=7)
    b_done=len(out); out += b'\0'*4
    out += lwz(3,0x0C,1)
    out += encode_branch(base+len(out), GM_GET_GAME_MODE_STATE_ENTER_DATA, link=True)
    out += li(11, CKIND_LUIGI); out += stb(11, P3_INIT_OFFSET+0x00, 3)
    _emit_load_byte_abs(out,11,LUIGI_CUTSCENE_DATA_COLOR_ADDR,12)
    out += stb(11, P3_INIT_OFFSET+0x03, 3)
    out += encode_branch(base+len(out), GM_GET_ADVENTURE_DATA, link=True)
    out += li(11,1); out += stb(11,0x74,3)
    done=base+len(out)
    out[b_done:b_done+4]=encode_bc(base+b_done,done,bo=4,bi=30)
    out += lwz(0,0x08,1); out += mtlr(0); out += addi(1,1,0x20); out += blr()
    return bytes(out)

def _spawn_gate_stub(base: int) -> bytes:
    """Adventure-only equivalent of the legacy 0x8016E2F8 unconditional branch.

    In Adventure, skip the retail P1-only singleplayer spawn block and enter the
    multi-slot path. Outside Adventure, preserve the exact retail CR0-dependent
    `beq 0x8016E454` behavior.
    """
    out=bytearray()
    # Preserve r12; CR0 and r0 are also semantically preserved by using CR7 and
    # restoring r0 is unnecessary because _emit_mode_test uses r0. Save both.
    out += stwu(1, -0x10, 1)
    out += stw(12, 0x0C, 1)
    out += stw(0, 0x08, 1)
    _emit_mode_test(out)
    bne_off=len(out); out += b'\0'*4
    # Adventure -> restore scratch state -> force multiplayer path.
    out += lwz(0, 0x08, 1); out += lwz(12, 0x0C, 1); out += addi(1,1,0x10)
    out += encode_branch(base+len(out), SPAWN_MULTIPLAYER_TARGET)
    retail=base+len(out)
    out[bne_off:bne_off+4]=encode_bc(base+bne_off, retail, bo=4, bi=30)
    out += lwz(0, 0x08, 1); out += lwz(12, 0x0C, 1); out += addi(1,1,0x10)
    # Preserve the displaced retail beq semantics using CR0 via a local branch.
    beq_off=len(out); out += b'\0'*4
    out += encode_branch(base+len(out), SPAWN_GATE_HOOK+4)
    take=base+len(out)
    out[beq_off:beq_off+4]=encode_bc(base+beq_off, take, bo=12, bi=2)
    out += encode_branch(base+len(out), SPAWN_MULTIPLAYER_TARGET)
    return bytes(out)



def _wireframe_human_physics_guard(base: int, trampoline_addr: int) -> bytes:
    out=bytearray(); _emit_mode_test(out)
    bm=len(out); out+=b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12); out+=cmpwi(11,WIRE_FRAME_FIGHT_STATE,crf=7)
    bs=len(out); out+=b'\0'*4
    out+=cmpwi(3,2,crf=7); bh=len(out); out+=b'\0'*4
    retail=base+len(out); out+=encode_branch(base+len(out),trampoline_addr)
    human=base+len(out); out+=li(3,0); out+=blr()
    out[bm:bm+4]=encode_bc(base+bm,retail,bo=4,bi=30)
    out[bs:bs+4]=encode_bc(base+bs,retail,bo=4,bi=30)
    out[bh:bh+4]=encode_bc(base+bh,human,bo=12,bi=28)
    return bytes(out)


def _adventure_presentation_start_wrapper(base: int, trampoline_addr: int) -> bytes:
    out=bytearray(); out+=stwu(1,-0x30,1); out+=mflr(0); out+=stw(0,0x34,1); out+=stw(3,0x0C,1)
    c0=len(out); out+=b'\0'*4
    out+=stw(3,0x10,1); out+=stw(4,0x14,1); out+=lwz(5,0x0C,1); out+=cmpwi(5,0,crf=7)
    bidx=len(out); out+=b'\0'*4; _emit_mode_test(out); bmode=len(out); out+=b'\0'*4
    _emit_load_byte_abs(out,11,GM_CURRENT_STATE_ADDR,12)
    eqs=[]
    for state in sorted(ADVENTURE_PRESENTATION_STATES):
        out+=cmpwi(11,state,crf=7); o=len(out); out+=b'\0'*4; eqs.append(o)
    bnot=len(out); out+=b'\0'*4
    pres=base+len(out); out+=li(3,1); c1=len(out); out+=b'\0'*4; out+=andi_dot(5,4,PAD_BUTTON_START)
    bnostart=len(out); out+=b'\0'*4; out+=lwz(4,0x14,1); out+=ori(4,4,PAD_BUTTON_START); out+=stw(4,0x14,1)
    done=base+len(out); out+=lwz(3,0x10,1); out+=lwz(4,0x14,1); out+=lwz(0,0x34,1); out+=mtlr(0); out+=addi(1,1,0x30); out+=blr()
    out[c0:c0+4]=encode_branch(base+c0,trampoline_addr,link=True); out[c1:c1+4]=encode_branch(base+c1,trampoline_addr,link=True)
    for o in eqs: out[o:o+4]=encode_bc(base+o,pres,bo=12,bi=30)
    out[bidx:bidx+4]=encode_bc(base+bidx,done,bo=4,bi=30); out[bmode:bmode+4]=encode_bc(base+bmode,done,bo=4,bi=30)
    out[bnot:bnot+4]=encode_branch(base+bnot,done); out[bnostart:bnostart+4]=encode_bc(base+bnostart,done,bo=12,bi=2)
    return bytes(out)


def _luigi_cpu_substitution_wrapper(base: int) -> bytes:
    out=bytearray(); out+=stwu(1,-0x20,1); out+=mflr(0); out+=stw(0,0x24,1); out+=stw(3,0x0C,1)
    cs=len(out); out+=b'\0'*4; _emit_load_byte_abs(out,11,GM_PREVIOUS_STATE_ADDR,12); out+=cmpwi(11,ADVENTURE_LUIGI_CUTSCENE,crf=7)
    bprev=len(out); out+=b'\0'*4; out+=lwz(10,0x0C,1); out+=lwz(10,0x10,10)
    out+=lbz(11,CPU_SLOT2_INIT_OFFSET,10); out+=cmpwi(11,CKIND_MARIO,crf=7); bs2=len(out); out+=b'\0'*4
    out+=lbz(11,CPU_SLOT3_INIT_OFFSET,10); out+=cmpwi(11,CKIND_MARIO,crf=7); bnom=len(out); out+=b'\0'*4
    out+=addi(10,10,CPU_SLOT3_INIT_OFFSET); bf3=len(out); out+=b'\0'*4
    slot2=base+len(out); out+=addi(10,10,CPU_SLOT2_INIT_OFFSET); found=base+len(out)
    out+=li(11,CKIND_LUIGI); out+=stb(11,0,10); _emit_load_byte_abs(out,11,LUIGI_CUTSCENE_COLOR_ADDR,12); out+=stb(11,3,10)
    ca=len(out); out+=b'\0'*4; out+=li(11,1); out+=stb(11,0x74,3)
    done=base+len(out); out+=lwz(0,0x24,1); out+=mtlr(0); out+=addi(1,1,0x20); out+=blr()
    out[cs:cs+4]=encode_branch(base+cs,ADVENTURE_COMMON_VS_SETUP,link=True); out[ca:ca+4]=encode_branch(base+ca,GM_GET_ADVENTURE_DATA,link=True)
    out[bprev:bprev+4]=encode_bc(base+bprev,done,bo=4,bi=30); out[bs2:bs2+4]=encode_bc(base+bs2,slot2,bo=12,bi=30)
    out[bnom:bnom+4]=encode_bc(base+bnom,done,bo=4,bi=30); out[bf3:bf3+4]=encode_branch(base+bf3,found)
    return bytes(out)



def _falco_cpu_substitution_wrapper(base: int) -> bytes:
    """Run retail Adventure VS setup, then redirect Falco onto the real CPU.

    Retail Corneria Part 2 rewrites players[1] when the Falco roll succeeds.
    Co-op reserves players[1] for human P2, so Phase 43 instead finds the Fox
    CPU in slots 2/3 and changes only that CPU's ckind. Its already-selected
    enemy costume color is retained (runtime Phase 42 showed the red Fox color
    was already present when the Falco branch had been selected).
    """
    out=bytearray(); out+=stwu(1,-0x20,1); out+=mflr(0); out+=stw(0,0x24,1); out+=stw(3,0x0C,1)
    out+=encode_branch(base+len(out),ADVENTURE_COMMON_VS_SETUP,link=True)
    out+=encode_branch(base+len(out),GM_GET_ADVENTURE_DATA,link=True)
    out+=lbz(11,0x7C,3); out+=cmpwi(11,CKIND_FALCO,crf=7); b_not_falco=len(out); out+=b'\0'*4
    out+=lwz(10,0x0C,1); out+=lwz(10,0x10,10)
    out+=lbz(11,CPU_SLOT2_INIT_OFFSET,10); out+=cmpwi(11,CKIND_FOX,crf=7); b_slot2=len(out); out+=b'\0'*4
    out+=lbz(11,CPU_SLOT3_INIT_OFFSET,10); out+=cmpwi(11,CKIND_FOX,crf=7); b_none=len(out); out+=b'\0'*4
    out+=addi(10,10,CPU_SLOT3_INIT_OFFSET); b_found3=len(out); out+=b'\0'*4
    slot2=base+len(out); out+=addi(10,10,CPU_SLOT2_INIT_OFFSET)
    found=base+len(out); out+=li(11,CKIND_FALCO); out+=stb(11,0,10)
    done=base+len(out); out+=lwz(0,0x24,1); out+=mtlr(0); out+=addi(1,1,0x20); out+=blr()
    out[b_not_falco:b_not_falco+4]=encode_bc(base+b_not_falco,done,bo=4,bi=30)
    out[b_slot2:b_slot2+4]=encode_bc(base+b_slot2,slot2,bo=12,bi=30)
    out[b_none:b_none+4]=encode_bc(base+b_none,done,bo=4,bi=30)
    out[b_found3:b_found3+4]=encode_branch(base+b_found3,found)
    return bytes(out)



def _team_kirby_match_end_wrapper(base: int, *, p2_ckind_addr: int,
                                   icies_teardown_guard_addr: int,
                                   icies_diag_addr: int) -> bytes:
    """Normalize P2 Ice Climbers at the actual retail match-end callback.

    HF6 proved the ground-event scanner stops before VsSceneController reaches
    terminate_match.  Team Kirby therefore installs this callback into
    StartMeleeRules.on_match_end (+0x54) only when campaign P2 is Ice Climbers.
    This is upstream of GAME! / GameModeState::on_exit, so Popo/Nana player-layer
    state is normalized before the scene teardown can encounter stale dual-entity
    references. Retail gm_8017E7A0 still runs afterward with its original u8 arg.
    """
    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1); out += stw(3,0x0C,1)
    out += li(11,0xB2); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    _emit_load_byte_abs(out,11,icies_teardown_guard_addr,12); out += cmpwi(11,0,crf=7)
    b_already=len(out); out += b'\0'*4
    out += li(11,1); _emit_store_byte_abs(out,11,icies_teardown_guard_addr,12)
    out += li(11,0xB3); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    out += li(3,1); out += encode_branch(base+len(out),PLAYER_DESTROY_ENTITIES,link=True)
    out += li(11,0xB4); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    out += li(3,1); out += li(4,0); out += encode_branch(base+len(out),PLAYER_CLEAR_ENTITY_REF,link=True)
    out += li(11,0xB5); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    out += li(3,1); out += li(4,1); out += encode_branch(base+len(out),PLAYER_CLEAR_ENTITY_REF,link=True)
    out += li(11,0xB6); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    retail=base+len(out)
    out[b_already:b_already+4]=encode_bc(base+b_already,retail,bo=4,bi=30)
    out += lwz(3,0x0C,1)
    out += encode_branch(base+len(out),GM_DEFAULT_1P_MATCH_END,link=True)
    out += li(11,0xB7); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()
    return bytes(out)


def _team_kirby_enter_wrapper(base: int, trampoline_addr: int, *,
                               match_end_wrapper_addr: int,
                               p2_ckind_addr: int, icies_diag_addr: int) -> bytes:
    """Run retail Team-Kirby setup, then arm the Icies pre-GAME callback.

    The hook is at gm_801B4B28.  The trampoline executes the displaced retail
    prologue and the complete original function.  Once it returns, we recover
    StartMeleeData from the same GameModeState and replace rules.on_match_end
    only for campaign P2 Ice Climbers. Everyone else remains byte-for-byte retail.
    """
    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1); out += stw(3,0x0C,1)
    out += encode_branch(base+len(out),trampoline_addr,link=True)
    _emit_load_byte_abs(out,11,p2_ckind_addr,12); out += cmpwi(11,CKIND_POPO_NANA,crf=7)
    b_done=len(out); out += b'\0'*4
    out += li(11,0xB1); _emit_store_byte_abs(out,11,icies_diag_addr,12)
    out += lwz(3,0x0C,1)
    out += encode_branch(base+len(out),GM_GET_GAME_MODE_STATE_ENTER_DATA,link=True)
    hi,lo=_addr_parts(match_end_wrapper_addr); out += lis(11,hi); out += ori(11,11,lo); out += stw(11,START_MELEE_ON_MATCH_END_OFFSET,3)
    done=base+len(out)
    out[b_done:b_done+4]=encode_bc(base+b_done,done,bo=4,bi=30)
    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()
    return bytes(out)

def _team_kirby_exit_wrapper(base: int, trampoline_addr: int) -> bytes:
    """Pre-arm the retail >30s Giant-Kirby skip before retail completion.

    Runtime on Phase 42/43/HF1/HF2 proves the <30s Giant-Kirby path works but
    the >30s skip path stalls at GAME.  Retail gm_801B4C5C performs the common
    Adventure completion helper first and only then calls
    gm_SetNextGameModeStateId(0x28).  For a successful slow clear, this wrapper
    now establishes that exact retail pending route *before* entering the retail
    exit function, then lets retail execute unchanged (including its own later
    idempotent route assignment).

    This deliberately avoids the Phase43/HF1/HF2 post-retail repair, which
    re-read MatchExitInfo after retail had already mutated the routing state.
    Fast clears, game-over/LRA exits, and all non-qualifying outcomes simply
    execute retail with no pre-routing.
    """
    out=bytearray()
    out+=stwu(1,-0x30,1); out+=mflr(0); out+=stw(0,0x34,1); out+=stw(3,0x0C,1)

    # Inspect the still-current Team-Kirby MatchExitInfo before retail exit
    # bookkeeping mutates routing.
    out+=lwz(3,0x0C,1)
    out+=encode_branch(base+len(out),GM_GET_GAME_MODE_STATE_EXIT_DATA,link=True)
    out+=cmpwi(3,0,crf=7); b_call_retail_null=len(out); out+=b'\0'*4
    out+=lbz(11,0x10,3)
    out+=cmpwi(11,MATCH_OUTCOME_1P_STAGE_END,crf=7)
    b_call_retail_outcome=len(out); out+=b'\0'*4
    out+=lwz(11,0x14,3)
    out+=cmpwi(11,1859,crf=7)
    b_call_retail_fast=len(out); out+=b'\0'*4

    # Retail's NEXT_SCENEBLOCK_AFTER(ADVENTURE_GIANTKIRBY_FIGHT) evaluates to
    # 0x28. gm_SetNextGameModeStateId stores curr_id+1 internally; the scene
    # runner subtracts one on exit, so passing 0x28 is exactly retail behavior.
    out+=li(3,ADVENTURE_CORNERIA_INTRO_AFTER_GIANT_KIRBY)
    out+=encode_branch(base+len(out),GM_SET_NEXT_GAME_MODE_STATE_ID,link=True)

    call_retail=base+len(out)
    for pos,bo,bi in ((b_call_retail_null,12,30),
                      (b_call_retail_outcome,4,30),
                      (b_call_retail_fast,4,29)):
        out[pos:pos+4]=encode_bc(base+pos,call_retail,bo=bo,bi=bi)
    out+=lwz(3,0x0C,1)
    out+=encode_branch(base+len(out),trampoline_addr,link=True)

    out+=lwz(0,0x34,1); out+=mtlr(0); out+=addi(1,1,0x30); out+=blr()
    return bytes(out)

def _adventure_sss_gateway_exit_wrapper(base: int, trampoline_addr: int, *,
                                        gateway_pending_addr: int,
                                        p1_ckind_addr: int, p1_color_addr: int,
                                        p1_subcolor_addr: int, p1_nametag_addr: int,
                                        p2_identity_valid_addr: int,
                                        p2_ckind_addr: int, p2_color_addr: int,
                                        p2_subcolor_addr: int, p2_nametag_addr: int) -> bytes:
    """Turn one normal VS stage selection into the Co-op Adventure launch.

    The prototype sentinel is Yoshi's Island (N64). Both slots 0/1 must be
    Human. Retail gmVsMelee_ExitSss still executes, preserving VS commit and
    audio/cache bookkeeping, before the major mode is redirected to Adventure.
    """
    out=bytearray()
    out += stwu(1,-0x40,1); out += mflr(0); out += stw(0,0x44,1)
    out += stw(3,0x0C,1); out += stw(4,0x10,1); out += stw(5,0x14,1)
    out += li(11,0); out += stw(11,0x18,1)
    out += lwz(3,0x0C,1)
    out += encode_branch(base+len(out), GM_GET_GAME_MODE_STATE_EXIT_DATA, link=True)
    out += cmpwi(3,0,crf=7); b_null=len(out); out += b"\0"*4
    out += lbz(11,SSS_START_GAME_OFFSET,3); out += cmpwi(11,0,crf=7); b_cancel=len(out); out += b"\0"*4
    out += lbz(11,SSS_STKIND_LOW_BYTE_OFFSET,3); out += cmpwi(11,ADVENTURE_GATEWAY_STKIND,crf=7); b_stage=len(out); out += b"\0"*4
    out += lbz(11,SSS_P1_INIT_OFFSET+0x01,3); out += cmpwi(11,0,crf=7); b_p1=len(out); out += b"\0"*4
    out += lbz(11,SSS_P2_INIT_OFFSET+0x01,3); out += cmpwi(11,0,crf=7); b_p2=len(out); out += b"\0"*4

    for src_off,dst in ((SSS_P1_INIT_OFFSET+0x00,p1_ckind_addr),
                        (SSS_P1_INIT_OFFSET+0x03,p1_color_addr),
                        (SSS_P1_INIT_OFFSET+0x07,p1_subcolor_addr),
                        (SSS_P1_INIT_OFFSET+0x0A,p1_nametag_addr),
                        (SSS_P2_INIT_OFFSET+0x00,p2_ckind_addr),
                        (SSS_P2_INIT_OFFSET+0x03,p2_color_addr),
                        (SSS_P2_INIT_OFFSET+0x07,p2_subcolor_addr),
                        (SSS_P2_INIT_OFFSET+0x0A,p2_nametag_addr)):
        out += lbz(11,src_off,3); _emit_store_byte_abs(out,11,dst,12)

    # Phase 43 cosmetic normalization: clone subshading is only useful when the
    # two humans truly share both character and costume. Different characters,
    # or different costumes of the same character, use normal P2 shading.
    out += lbz(10,SSS_P1_INIT_OFFSET+0x00,3); out += lbz(11,SSS_P2_INIT_OFFSET+0x00,3); out += cmpw(10,11,crf=7)
    b_normalize_ckind=len(out); out += b"\0"*4
    out += lbz(10,SSS_P1_INIT_OFFSET+0x03,3); out += lbz(11,SSS_P2_INIT_OFFSET+0x03,3); out += cmpw(10,11,crf=7)
    b_preserve=len(out); out += b"\0"*4
    normalize=base+len(out); out += li(11,0); _emit_store_byte_abs(out,11,p2_subcolor_addr,12)
    after_normalize=base+len(out)
    out[b_normalize_ckind:b_normalize_ckind+4]=encode_bc(base+b_normalize_ckind,normalize,bo=4,bi=30)
    out[b_preserve:b_preserve+4]=encode_bc(base+b_preserve,after_normalize,bo=12,bi=30)

    out += li(11,1); _emit_store_byte_abs(out,11,p2_identity_valid_addr,12); _emit_store_byte_abs(out,11,gateway_pending_addr,12)
    out += li(11,1); out += stw(11,0x18,1)
    b_call=len(out); out += b"\0"*4

    retail=base+len(out)
    # Null pointer branches on EQ; the remaining tests branch to retail when NE.
    out[b_null:b_null+4]=encode_bc(base+b_null,retail,bo=12,bi=30)
    out[b_cancel:b_cancel+4]=encode_bc(base+b_cancel,retail,bo=12,bi=30)
    for boff in (b_stage,b_p1,b_p2):
        out[boff:boff+4]=encode_bc(base+boff,retail,bo=4,bi=30)

    call_retail=base+len(out); out[b_call:b_call+4]=encode_branch(base+b_call,call_retail)
    out += lwz(3,0x0C,1); out += lwz(4,0x10,1); out += lwz(5,0x14,1)
    out += encode_branch(base+len(out),trampoline_addr,link=True)
    out += lwz(11,0x18,1); out += cmpwi(11,0,crf=7); b_done=len(out); out += b"\0"*4
    out += li(3,GM_ADVENTURE)
    out += encode_branch(base+len(out),GM_CHANGE_GAME_MODE_AFTER_CURRENT_SCENE,link=True)
    done=base+len(out); out[b_done:b_done+4]=encode_bc(base+b_done,done,bo=12,bi=30)
    out += lwz(0,0x44,1); out += mtlr(0); out += addi(1,1,0x40); out += blr()
    return bytes(out)


def _adventure_gateway_onload_wrapper(base: int, trampoline_addr: int, *,
                                      gateway_pending_addr: int, camera_owner_addr: int,
                                      persistence_valid_addr: int, p1_stocks_addr: int,
                                      p2_stocks_addr: int, initial_stocks_addr: int,
                                      p1_ckind_addr: int, p1_color_addr: int,
                                      p1_nametag_addr: int,
                                      adventure_cpu_level: int = 2,
                                      adventure_stocks: int = 3) -> bytes:
    """Run retail Adventure OnLoad, seed VS-selected P1, then start intro state 0."""
    if not 0 <= int(adventure_cpu_level) <= 4:
        raise ValueError('adventure_cpu_level must be 0..4 (Very Easy..Very Hard)')
    if not 1 <= int(adventure_stocks) <= 9:
        raise ValueError('adventure_stocks must be 1..9')
    out=bytearray()
    out += stwu(1,-0x30,1); out += mflr(0); out += stw(0,0x34,1)
    out += encode_branch(base+len(out),trampoline_addr,link=True)
    _emit_load_byte_abs(out,11,gateway_pending_addr,12); out += cmpwi(11,0,crf=7); b_done=len(out); out += b"\0"*4

    out += encode_branch(base+len(out),GM_GET_ADVENTURE_DATA,link=True)
    _emit_load_byte_abs(out,11,p1_ckind_addr,12); out += stb(11,0x00,3)
    _emit_load_byte_abs(out,11,p1_color_addr,12); out += stb(11,0x01,3)
    out += li(11,adventure_cpu_level); out += stb(11,0x02,3)
    _emit_load_byte_abs(out,11,p1_nametag_addr,12); out += stb(11,0x04,3)
    out += li(11,adventure_stocks); out += stb(11,0x05,3)
    out += li(11,0); out += stb(11,0x07,3)

    gm_hi,gm_lo=_addr_parts(GM_MAINLIB_PTR_ADDR); out += lis(12,gm_hi); out += lwz(12,gm_lo,12)
    out += cmpwi(12,0,crf=7); b_skip_profile=len(out); out += b"\0"*4
    _emit_load_byte_abs(out,11,p1_ckind_addr,10); out += stb(11,ADVENTURE_PROFILE_OFFSET+0,12)
    out += li(11,adventure_stocks); out += stb(11,ADVENTURE_PROFILE_OFFSET+1,12)
    _emit_load_byte_abs(out,11,p1_color_addr,10); out += stb(11,ADVENTURE_PROFILE_OFFSET+2,12)
    out += li(11,adventure_cpu_level); out += stb(11,ADVENTURE_PROFILE_OFFSET+3,12)
    _emit_load_byte_abs(out,11,p1_nametag_addr,10); out += stb(11,ADVENTURE_PROFILE_OFFSET+4,12)
    out += li(11,0); out += stb(11,ADVENTURE_PROFILE_OFFSET+5,12)
    after_profile=base+len(out); out[b_skip_profile:b_skip_profile+4]=encode_bc(base+b_skip_profile,after_profile,bo=12,bi=30)

    out += li(11,0)
    for addr in (camera_owner_addr,persistence_valid_addr,p1_stocks_addr,p2_stocks_addr,initial_stocks_addr,GAME_CAMERA_OWNER_SLOT,gateway_pending_addr):
        _emit_store_byte_abs(out,11,addr,12)
    out += li(3,0); out += encode_branch(base+len(out),GM_SET_GAME_MODE_STATE_ID,link=True)

    done=base+len(out); out[b_done:b_done+4]=encode_bc(base+b_done,done,bo=12,bi=30)
    out += lwz(0,0x34,1); out += mtlr(0); out += addi(1,1,0x30); out += blr()
    return bytes(out)


def install_phase30_coop_spawn_probe(dol_path: str | Path, symbols_path: str | Path,
                                     output_path: str | Path, *, require_clean: bool = True,
                                     friendly_fire: bool = False,
                                     enable_one_player_cstick: bool = True,
                                     enable_either_player_pause: bool = True,
                                     scene_revive: bool = False,
                                     enable_dual_credits: bool = True,
                                     enable_either_human_events: bool = True,
                                     enable_test_shortcuts: bool = False,
                                     enable_unlock_all: bool = False,
                                     enable_vs_p2_identity_bridge: bool = False,
                                     enable_adventure_sss_gateway: bool = False,
                                     enable_legacy_local_vs_gateway: bool = False,
                                     adventure_cpu_level: int = 2,
                                     adventure_stocks: int = 3,
                                     enable_phase43_adventure_repairs: bool = False,
                                     sss_visual_contract: dict | None = None, enable_standalone_stages: bool = False) -> dict:
    src=Path(dol_path); raw=src.read_bytes(); source_sha1=hashlib.sha1(raw).hexdigest()
    if require_clean and source_sha1.lower()!=GALE01_102_DOL_SHA1:
        raise ValueError(f'Expected clean GALE01 1.02 main.dol SHA-1 {GALE01_102_DOL_SHA1}, got {source_sha1}')
    dol=DOLImage(raw); symbols=SymbolMap.from_file(symbols_path)
    if enable_test_shortcuts and not enable_either_human_events:
        raise ValueError('Developer test shortcuts require the either-human Adventure ground-event wrapper.')
    if enable_adventure_sss_gateway and not enable_vs_p2_identity_bridge:
        raise ValueError('Adventure SSS gateway requires the independent VS P2 identity bridge.')
    if enable_legacy_local_vs_gateway and not enable_adventure_sss_gateway:
        raise ValueError('Legacy local VS gateway requires the Adventure gateway runtime.')
    if not 0 <= int(adventure_cpu_level) <= 4:
        raise ValueError('adventure_cpu_level must be 0..4 (Very Easy..Very Hard)')
    if not 1 <= int(adventure_stocks) <= 9:
        raise ValueError('adventure_stocks must be 1..9')
    ground_event_expected = dol.read_at_address(GROUND_EVENT_SCAN_HOOK, 4)
    # Canonical GALE01 v1.02 Ground_801C0C2C begins with mflr r0 (7c0802a6).
    # The clean-DOL SHA-1 remains the primary source guard; this exact instruction
    # check catches address/symbol drift without rejecting the real retail prologue.
    if enable_either_human_events and ground_event_expected != GROUND_EVENT_SCAN_EXPECTED:
        raise ValueError(f'either_human_events: unexpected Ground_801C0C2C prologue {ground_event_expected.hex()}')
    for addr, expected, name in ((LUIGI_FIGHT_SETUP_HOOK,LUIGI_FIGHT_SETUP_EXPECTED,'coop_luigi_cpu_substitution'),):
        got=dol.read_at_address(addr,4)
        if got!=expected:
            raise ValueError(f'{name}: expected-byte guard failed at 0x{addr:08X}: expected {expected.hex()}, got {got.hex()}')

    # Hotfix 13 dynamically records the exact clean first instruction for three
    # new source-grounded hooks; the canonical DOL SHA-1 above is the identity guard.
    wireframe_expected = dol.read_at_address(WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK, 4)
    presentation_expected = dol.read_at_address(GM_GET_BUTTONS_TRIGGERED_HOOK, 4)
    luigi_expected = dol.read_at_address(LUIGI_FIGHT_SETUP_HOOK, 4)
    gateway_sss_expected = dol.read_at_address(GM_VS_MELEE_EXIT_SSS, 4) if enable_legacy_local_vs_gateway else b''
    gateway_onload_expected = dol.read_at_address(GM_MODE_ADVENTURE_ONLOAD, 4) if enable_adventure_sss_gateway else b''
    falco_expected = dol.read_at_address(ADVENTURE_FALCO_FIGHT_SETUP_HOOK, 4) if enable_phase43_adventure_repairs else b''
    teamkirby_enter_expected = dol.read_at_address(ADVENTURE_TEAMKIRBY_ENTER_HOOK, 4) if enable_phase43_adventure_repairs else b''
    teamkirby_expected = dol.read_at_address(ADVENTURE_TEAMKIRBY_EXIT_HOOK, 4) if enable_phase43_adventure_repairs else b''
    transition_trace_expected = ({addr: dol.read_at_address(addr, 4) for addr in (
        SCENE_EXIT_REQUEST_HOOK, SCENE_EXIT_REQUEST_ALT_HOOK, SCENE_INIT_HOOK,
        SCENE_LOOP_HOOK, VS_SCENE_EXIT_HOOK, RESULTS_SCENE_ENTER_HOOK,
    )} if enable_phase43_adventure_repairs else {})
    if enable_phase43_adventure_repairs:
        # A one-instruction trampoline may relocate ordinary prologue/load/store
        # instructions, but not a PC-relative b/bc. Refuse the build if upstream
        # code ever changes one of these entries to a relative branch.
        for addr, got in transition_trace_expected.items():
            opcode = struct.unpack('>I', got)[0] >> 26
            if opcode in (16, 18):
                raise ValueError(f'HF21 scene trace: non-relocatable branch at 0x{addr:08X}: {got.hex()}')
        for addr, got, label in ((ADVENTURE_FALCO_FIGHT_SETUP_HOOK,falco_expected,'falco_cpu_substitution'),
                                 (ADVENTURE_TEAMKIRBY_ENTER_HOOK,teamkirby_enter_expected,'team_kirby_pre_game_enter'),
                                 (ADVENTURE_TEAMKIRBY_EXIT_HOOK,teamkirby_expected,'team_kirby_non_giant_exit')):
            if got != bytes.fromhex('7c0802a6'):
                raise ValueError(f'{label}: unexpected function prologue at 0x{addr:08X}: {got.hex()}')

    # Keep Phase 29's six transparent source-grounded touchpoints as the shared
    # runtime substrate. They do not change retail behavior.
    from .slippi_memory_layout import SDK_RUNTIME_BASE, install_arena_reservation
    framework=RuntimeHookInstaller(dol).install_transparent_hooks(coop_hook_sites(dol,symbols),flags=1,address=SDK_RUNTIME_BASE)

    for addr, expected, name in ((P2_SETUP_HOOK,P2_SETUP_EXPECTED,'p2_setup'),
                                 (SPAWN_GATE_HOOK,SPAWN_GATE_EXPECTED,'spawn_gate'),
                                 (SINGLEPLAYER_P2_LOADER_HOOK,SINGLEPLAYER_P2_LOADER_EXPECTED,'singleplayer_p2_loader'),
                                 (RESPAWN_PLATFORM_HOOK,RESPAWN_PLATFORM_EXPECTED,'control_route_respawn'),
                                 (FFA_P1_STOCK_HOOK,FFA_P1_STOCK_EXPECTED,'ffa_team_stock_outcome'),
                                 (TEAM_P1_STOCK_HOOK,TEAM_P1_STOCK_EXPECTED,'team_team_stock_outcome'),
                                 (GROUND_GET_P1_FIGHTER_HOOK,GROUND_GET_P1_FIGHTER_EXPECTED,'control_ground_p1_accessor'),
                                 (CAMERA_P1_ENTITY_CALL_HOOK,CAMERA_P1_ENTITY_CALL_EXPECTED,'control_camera_p1_lookup'),
                                 (ADVENTURE_PROGRESS_STOCK_HOOK,ADVENTURE_PROGRESS_STOCK_EXPECTED,'cross_chapter_stock_capture'),
                                 (EVENT_ALLOCATOR_START_HOOK,EVENT_ALLOCATOR_START_EXPECTED,'event_allocator_human_reservation'),
                                 (DYNAMIC_ENEMY_SPAWN_HOOK,DYNAMIC_ENEMY_SPAWN_EXPECTED,'dynamic_enemy_spawn_marker'),
                                 (MULTISLOT_POST_COORD_HOOK,MULTISLOT_POST_COORD_EXPECTED,'adventure_slippi_spawn_normalizer_bypass'),
                                 (EVENT_ENEMY_MANAGER_HOOK,EVENT_ENEMY_MANAGER_EXPECTED,'team_kirby_event_enemy_manager'),
                                 (FN_BONUS_FIGHTER_HOOK,FN_BONUS_FIGHTER_EXPECTED,'team_kirby_fighter_bonus_boundary'),
                                 (ADVENTURE_HUD_INIT_HOOK,ADVENTURE_HUD_INIT_EXPECTED,'adventure_hud_capacity')):
        got=dol.read_at_address(addr,4)
        if got!=expected:
            raise ValueError(f'{name}: expected-byte guard failed at 0x{addr:08X}: expected {expected.hex()}, got {got.hex()}')
    if enable_dual_credits:
        got=dol.read_at_address(STAFFROLL_PAD_INDEX_HOOK,4)
        if got!=STAFFROLL_PAD_INDEX_EXPECTED:
            raise ValueError(f'dual_credits: expected-byte guard failed at 0x{STAFFROLL_PAD_INDEX_HOOK:08X}: expected {STAFFROLL_PAD_INDEX_EXPECTED.hex()}, got {got.hex()}')
        for addr,expected,name in (
            (STAFFROLL_CURSOR_LOOKUP_CALL,STAFFROLL_CURSOR_LOOKUP_EXPECTED,'credits_cursor_lookup'),
            (STAFFROLL_SHOT_NODE5_LOOKUP_CALL,STAFFROLL_SHOT_NODE5_LOOKUP_EXPECTED,'credits_shot_node5_lookup'),
            (STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_CALL,STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_EXPECTED,'credits_shot_node5_anim_lookup'),
            (STAFFROLL_SHOT_NODE8_LOOKUP_CALL,STAFFROLL_SHOT_NODE8_LOOKUP_EXPECTED,'credits_shot_node8_lookup'),
            (STAFFROLL_LOCAL_PASS_END_HOOK,STAFFROLL_LOCAL_PASS_END_EXPECTED,'credits_local_pass_end'),
            (STAFFROLL_SETUP_PROC_CALL,STAFFROLL_SETUP_PROC_EXPECTED,'credits_setup_proc'),
        ):
            got=dol.read_at_address(addr,4)
            if got!=expected:
                raise ValueError(f'{name}: expected-byte guard failed at 0x{addr:08X}: expected {expected.hex()}, got {got.hex()}')
    if enable_one_player_cstick:
        got=dol.read_at_address(ONE_PLAYER_CSTICK_HOOK,4)
        if got!=ONE_PLAYER_CSTICK_EXPECTED:
            raise ValueError(f'one_player_cstick: expected-byte guard failed at 0x{ONE_PLAYER_CSTICK_HOOK:08X}: expected {ONE_PLAYER_CSTICK_EXPECTED.hex()}, got {got.hex()}')
    if enable_either_player_pause:
        got=dol.read_at_address(DEFAULT_PAUSER_MODE_CALL_HOOK,4)
        if got!=DEFAULT_PAUSER_MODE_CALL_EXPECTED:
            raise ValueError(f'either_player_pause: expected-byte guard failed at 0x{DEFAULT_PAUSER_MODE_CALL_HOOK:08X}: expected {DEFAULT_PAUSER_MODE_CALL_EXPECTED.hex()}, got {got.hex()}')

    # Reserve enough initialized payload and then write final stubs using the
    # actual loader-backed address assigned by the DOL allocator.
    header_size=0x40
    # Mutable campaign state lives in initialized DOL-backed SDK storage:
    # +0x20 Control owner, +0x21 persistence-valid, +0x22 P1 stocks, +0x23 P2 stocks,
    # +0x24 initial Adventure stock selection (for optional scene revive).
    # Phase 41 optional VS-P2 identity snapshot:
    # +0x25 valid, +0x26 ckind, +0x27 color, +0x28 sub-color, +0x29 nametag.
    dummy_owner=0x80400020
    dummy_valid=0x80400021
    dummy_p1stocks=0x80400022
    dummy_p2stocks=0x80400023
    dummy_initial=0x80400024
    dummy_vs_valid=0x80400025
    dummy_vs_ckind=0x80400026
    dummy_vs_color=0x80400027
    dummy_vs_subcolor=0x80400028
    dummy_vs_nametag=0x80400029
    dummy_p1_ckind=0x8040002A
    dummy_p1_color=0x8040002B
    dummy_p1_subcolor=0x8040002C
    dummy_p1_nametag=0x8040002D
    dummy_gateway_pending=0x8040002E
    dummy_ic_guard=0x8040002F
    dummy_p1_form=0x80400030
    dummy_p2_form=0x80400031
    dummy_ic_diag=0x80400032
    dummy_ic_wave_armed=0x80400033
    dummy_trace_last=0x80400038
    dummy_trace_flags_lo=0x80400039
    dummy_trace_state=0x8040003A
    dummy_trace_prev_state=0x8040003B
    dummy_trace_flags_hi=0x8040003C
    # Stubs are bounded and generated twice; first pass obtains exact sizes.
    dummy1=_spawn_setup_stub(0x80400100, friendly_fire=friendly_fire, camera_owner_addr=dummy_owner, persistence_valid_addr=dummy_valid, p1_stocks_addr=dummy_p1stocks, p2_stocks_addr=dummy_p2stocks, initial_stocks_addr=dummy_initial, scene_revive=scene_revive, vs_p2_identity_valid_addr=dummy_vs_valid if enable_vs_p2_identity_bridge else None, vs_p2_ckind_addr=dummy_vs_ckind if enable_vs_p2_identity_bridge else None, vs_p2_color_addr=dummy_vs_color if enable_vs_p2_identity_bridge else None, vs_p2_subcolor_addr=dummy_vs_subcolor if enable_vs_p2_identity_bridge else None, vs_p2_nametag_addr=dummy_vs_nametag if enable_vs_p2_identity_bridge else None, p1_form_addr=dummy_p1_form, p2_form_addr=dummy_p2_form)
    dummy2=_spawn_gate_stub(0x80400300)
    dummy3=_singleplayer_p2_loader_stub(0x80400400)
    dummy_rebirth_preflight=_rebirth_owner_preflight_wrapper(0x80400480, dummy_owner) if enable_adventure_sss_gateway else b''
    dummy4=_respawn_platform_wrapper(0x80400500, dummy_owner)
    dummy5=_team_stock_wrapper(0x80400700, dummy_owner)
    dummy6=_control_player_entity_wrapper(0x80400900, dummy_owner, p2_ckind_addr=dummy_vs_ckind if enable_phase43_adventure_repairs else None, icies_teardown_guard_addr=dummy_ic_guard if enable_phase43_adventure_repairs else None, icies_diag_addr=dummy_ic_diag if enable_phase43_adventure_repairs else None)
    dummy7=_adventure_pauser_mode_wrapper(0x80400A00) if enable_either_player_pause else b''
    dummy8=_adventure_progress_stock_wrapper(0x80400B00, persistence_valid_addr=dummy_valid, p1_stocks_addr=dummy_p1stocks, p2_stocks_addr=dummy_p2stocks)
    dummy9=_campaign_state_reset_stub(0x80400C00, camera_owner_addr=dummy_owner, persistence_valid_addr=dummy_valid, p1_stocks_addr=dummy_p1stocks, p2_stocks_addr=dummy_p2stocks, initial_stocks_addr=dummy_initial, return_address=0x801B42EC, vs_p2_identity_valid_addr=dummy_vs_valid if enable_vs_p2_identity_bridge else None, vs_p2_ckind_addr=dummy_vs_ckind if enable_vs_p2_identity_bridge else None, vs_p2_color_addr=dummy_vs_color if enable_vs_p2_identity_bridge else None, vs_p2_subcolor_addr=dummy_vs_subcolor if enable_vs_p2_identity_bridge else None, vs_p2_nametag_addr=dummy_vs_nametag if enable_vs_p2_identity_bridge else None, extra_reset_addrs=(dummy_ic_guard,dummy_p1_form,dummy_p2_form,dummy_ic_diag,dummy_ic_wave_armed,dummy_trace_last,dummy_trace_flags_lo,dummy_trace_state,dummy_trace_prev_state,dummy_trace_flags_hi))
    dummy10=_event_allocator_start_wrapper(0x80400D00)
    dummy11=_dynamic_enemy_spawn_wrapper(0x80400E00)
    dummy_static_spawn=_adventure_slippi_spawn_guard_wrapper(0x80400E80) if enable_adventure_sss_gateway else b''
    dummy_finalwave_tramp = EVENT_ENEMY_MANAGER_EXPECTED + encode_branch(0x80400EC4, EVENT_ENEMY_MANAGER_HOOK+4) if enable_phase43_adventure_repairs else b''
    dummy_finalwave = _team_kirby_final_wave_wrapper(0x80400F00, 0x80400EC0, p1_ckind_addr=dummy_p1_ckind, p2_ckind_addr=dummy_vs_ckind, icies_teardown_guard_addr=dummy_ic_guard, icies_diag_addr=dummy_ic_diag, icies_wave_armed_addr=dummy_ic_wave_armed) if enable_phase43_adventure_repairs else b''
    dummy_bonus_tramp = FN_BONUS_FIGHTER_EXPECTED + encode_branch(0x80401004, FN_BONUS_FIGHTER_HOOK+4) if enable_phase43_adventure_repairs else b''
    dummy_bonus = _team_kirby_bonus_guard_wrapper(0x80401040, 0x80401000, p1_ckind_addr=dummy_p1_ckind, p2_ckind_addr=dummy_vs_ckind, icies_teardown_guard_addr=dummy_ic_guard, icies_diag_addr=dummy_ic_diag) if enable_phase43_adventure_repairs else b''
    dummy12=_adventure_hud_capacity_wrapper(0x80401100)
    dummy_credits_assembly=0x80403F00
    dummy_credits_cursor=0x80403F04
    dummy_credits_pass=0x80403F08
    dummy_credits_terminal_diag=0x80403F09
    dummy13=_staffroll_independent_pad_wrapper(0x80401000, dummy_valid, dummy_credits_pass) if enable_dual_credits else b''
    # Ground-event wrapper needs a tiny displaced-instruction trampoline. Dummy
    # addresses are only for exact sizing; final branches are regenerated below.
    dummy_trampoline = ground_event_expected + encode_branch(0x80401104, GROUND_EVENT_SCAN_HOOK+4) if enable_either_human_events else b''
    dummy15=_adventure_test_shortcuts_stub(0x80401300, offscreen_vec_addr=0x80401500, persistence_valid_addr=dummy_valid, p1_stocks_addr=dummy_p1stocks, p2_stocks_addr=dummy_p2stocks, initial_stocks_addr=dummy_initial) if enable_test_shortcuts else b''
    dummy14=_ground_event_either_human_wrapper(0x80401200, 0x80401100, dummy_owner, 0x80401300 if enable_test_shortcuts else None, p2_ckind_addr=dummy_vs_ckind, icies_teardown_guard_addr=dummy_ic_guard, p1_form_addr=dummy_p1_form, p2_form_addr=dummy_p2_form, icies_diag_addr=dummy_ic_diag) if enable_either_human_events else b''
    dummy_wire_tramp = wireframe_expected + encode_branch(0x80401604, WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK+4)
    dummy_wire = _wireframe_human_physics_guard(0x80401700, 0x80401600)
    dummy_presentation_tramp = presentation_expected + encode_branch(0x80401804, GM_GET_BUTTONS_TRIGGERED_HOOK+4)
    dummy_presentation = _adventure_presentation_start_wrapper(0x80401900, 0x80401800)
    dummy_luigi = _luigi_cpu_substitution_wrapper(0x80401B00)
    dummy_gateway_sss_tramp = (gateway_sss_expected + encode_branch(0x80401C04, GM_VS_MELEE_EXIT_SSS+4)) if enable_legacy_local_vs_gateway else b''
    dummy_gateway_sss = _adventure_sss_gateway_exit_wrapper(0x80401D00,0x80401C00,gateway_pending_addr=dummy_gateway_pending,p1_ckind_addr=dummy_p1_ckind,p1_color_addr=dummy_p1_color,p1_subcolor_addr=dummy_p1_subcolor,p1_nametag_addr=dummy_p1_nametag,p2_identity_valid_addr=dummy_vs_valid,p2_ckind_addr=dummy_vs_ckind,p2_color_addr=dummy_vs_color,p2_subcolor_addr=dummy_vs_subcolor,p2_nametag_addr=dummy_vs_nametag) if enable_legacy_local_vs_gateway else b''
    dummy_gateway_onload_tramp = (gateway_onload_expected + encode_branch(0x80402004, GM_MODE_ADVENTURE_ONLOAD+4)) if enable_adventure_sss_gateway else b''
    dummy_gateway_onload = _adventure_gateway_onload_wrapper(0x80402100,0x80402000,gateway_pending_addr=dummy_gateway_pending,camera_owner_addr=dummy_owner,persistence_valid_addr=dummy_valid,p1_stocks_addr=dummy_p1stocks,p2_stocks_addr=dummy_p2stocks,initial_stocks_addr=dummy_initial,p1_ckind_addr=dummy_p1_ckind,p1_color_addr=dummy_p1_color,p1_nametag_addr=dummy_p1_nametag,adventure_cpu_level=adventure_cpu_level,adventure_stocks=adventure_stocks) if enable_adventure_sss_gateway else b''
    dummy_falco = _falco_cpu_substitution_wrapper(0x80402300) if enable_phase43_adventure_repairs else b''
    dummy_teamkirby_enter_tramp = (teamkirby_enter_expected + encode_branch(0x80402404, ADVENTURE_TEAMKIRBY_ENTER_HOOK+4)) if enable_phase43_adventure_repairs else b''
    dummy_teamkirby_match_end = b''  # HF8: x54 interception removed
    dummy_teamkirby_enter = b''  # HF8: retail Team-Kirby entry remains untouched
    dummy_teamkirby_tramp = (teamkirby_expected + encode_branch(0x80402704, ADVENTURE_TEAMKIRBY_EXIT_HOOK+4)) if enable_phase43_adventure_repairs else b''
    dummy_teamkirby = _team_kirby_exit_wrapper(0x80402800,0x80402700) if enable_phase43_adventure_repairs else b''
    _dummy_trace_insn=bytes.fromhex('7c0802a6')
    def _dummy_trace_pair(hook: int, tramp: int, wrap: int, enter: int | None, ret: int | None):
        # 0.20.21E: HF21 scene tracing is retired production code. Keep only
        # the first dead wrapper slot because SDK 0.20.1 reuses it for the safe
        # retail presentation accessor; do not spend low-runtime bytes on the
        # other five trace pairs that boot hardening immediately restores.
        if not enable_phase43_adventure_repairs or hook != SCENE_EXIT_REQUEST_HOOK:
            return b'', b''
        tr=_dummy_trace_insn + encode_branch(tramp+4,hook+4)
        # K20B: this HF21 wrapper is retired before the image can execute and
        # survives only because SDK 0.20.1 reuses its address for the complete
        # 0x20-byte retail input accessor + 8-byte marker. Reserve exactly that
        # 0x28-byte scratch span instead of the obsolete 0x80-byte tracer. The
        # first instruction still transparently reaches the displaced retail
        # trampoline if boot hardening is intentionally omitted in a dev build.
        wr=_retired_trace_scratch_wrapper(wrap,tramp)
        return tr,wr
    dummy_trace_exit_tramp,dummy_trace_exit=_dummy_trace_pair(SCENE_EXIT_REQUEST_HOOK,0x80402A00,0x80402A40,0xE0,None)
    dummy_trace_alt_tramp,dummy_trace_alt=_dummy_trace_pair(SCENE_EXIT_REQUEST_ALT_HOOK,0x80402B00,0x80402B40,0xE1,None)
    dummy_trace_loop_tramp,dummy_trace_loop=_dummy_trace_pair(SCENE_LOOP_HOOK,0x80402C00,0x80402C40,0xE9,0xE2)
    dummy_trace_vs_exit_tramp,dummy_trace_vs_exit=_dummy_trace_pair(VS_SCENE_EXIT_HOOK,0x80402D00,0x80402D40,0xE3,0xE4)
    dummy_trace_init_tramp,dummy_trace_init=_dummy_trace_pair(SCENE_INIT_HOOK,0x80402E00,0x80402E40,0xE5,0xE6)
    dummy_trace_results_tramp,dummy_trace_results=_dummy_trace_pair(RESULTS_SCENE_ENTER_HOOK,0x80402F00,0x80402F40,0xE7,0xE8)
    code_pad = 3 if enable_standalone_stages else 0x1F
    p2_off=header_size
    gate_off=(p2_off+len(dummy1)+code_pad)&~code_pad
    loader_off=(gate_off+len(dummy2)+code_pad)&~code_pad
    rebirth_preflight_off=(loader_off+len(dummy3)+code_pad)&~code_pad
    respawn_off=(rebirth_preflight_off+len(dummy_rebirth_preflight)+code_pad)&~code_pad
    stock_off=(respawn_off+len(dummy4)+code_pad)&~code_pad
    owner_entity_off=(stock_off+len(dummy5)+code_pad)&~code_pad
    pauser_off=(owner_entity_off+len(dummy6)+code_pad)&~code_pad
    progress_off=(pauser_off+len(dummy7)+code_pad)&~code_pad
    reset_off=(progress_off+len(dummy8)+code_pad)&~code_pad
    event_alloc_off=(reset_off+len(dummy9)+code_pad)&~code_pad
    dynamic_spawn_off=(event_alloc_off+len(dummy10)+code_pad)&~code_pad
    static_spawn_off=(dynamic_spawn_off+len(dummy11)+code_pad)&~code_pad
    finalwave_trampoline_off=(static_spawn_off+len(dummy_static_spawn)+code_pad)&~code_pad
    finalwave_wrapper_off=(finalwave_trampoline_off+len(dummy_finalwave_tramp)+code_pad)&~code_pad
    bonus_trampoline_off=(finalwave_wrapper_off+len(dummy_finalwave)+code_pad)&~code_pad
    bonus_wrapper_off=(bonus_trampoline_off+len(dummy_bonus_tramp)+code_pad)&~code_pad
    hud_off=(bonus_wrapper_off+len(dummy_bonus)+code_pad)&~code_pad
    credits_off=(hud_off+len(dummy12)+code_pad)&~code_pad
    event_trampoline_off=(credits_off+len(dummy13)+code_pad)&~code_pad
    event_authority_off=(event_trampoline_off+len(dummy_trampoline)+code_pad)&~code_pad
    test_shortcuts_off=(event_authority_off+len(dummy14)+code_pad)&~code_pad
    offscreen_vec_off=(test_shortcuts_off+len(dummy15)+code_pad)&~code_pad
    after_offscreen = offscreen_vec_off + (12 if enable_test_shortcuts else 0)
    wire_trampoline_off=(after_offscreen+code_pad)&~code_pad
    wire_wrapper_off=(wire_trampoline_off+len(dummy_wire_tramp)+code_pad)&~code_pad
    presentation_trampoline_off=(wire_wrapper_off+len(dummy_wire)+code_pad)&~code_pad
    presentation_wrapper_off=(presentation_trampoline_off+len(dummy_presentation_tramp)+code_pad)&~code_pad
    luigi_wrapper_off=(presentation_wrapper_off+len(dummy_presentation)+code_pad)&~code_pad
    gateway_sss_trampoline_off=(luigi_wrapper_off+len(dummy_luigi)+code_pad)&~code_pad
    gateway_sss_wrapper_off=(gateway_sss_trampoline_off+len(dummy_gateway_sss_tramp)+code_pad)&~code_pad
    gateway_onload_trampoline_off=(gateway_sss_wrapper_off+len(dummy_gateway_sss)+code_pad)&~code_pad
    gateway_onload_wrapper_off=(gateway_onload_trampoline_off+len(dummy_gateway_onload_tramp)+code_pad)&~code_pad
    falco_wrapper_off=(gateway_onload_wrapper_off+len(dummy_gateway_onload)+code_pad)&~code_pad
    teamkirby_enter_trampoline_off=(falco_wrapper_off+len(dummy_falco)+code_pad)&~code_pad
    teamkirby_match_end_off=(teamkirby_enter_trampoline_off+len(dummy_teamkirby_enter_tramp)+code_pad)&~code_pad
    teamkirby_enter_wrapper_off=(teamkirby_match_end_off+len(dummy_teamkirby_match_end)+code_pad)&~code_pad
    teamkirby_trampoline_off=(teamkirby_enter_wrapper_off+len(dummy_teamkirby_enter)+code_pad)&~code_pad
    teamkirby_wrapper_off=(teamkirby_trampoline_off+len(dummy_teamkirby_tramp)+code_pad)&~code_pad
    trace_exit_trampoline_off=(teamkirby_wrapper_off+len(dummy_teamkirby)+code_pad)&~code_pad
    trace_exit_wrapper_off=(trace_exit_trampoline_off+len(dummy_trace_exit_tramp)+code_pad)&~code_pad
    trace_alt_trampoline_off=(trace_exit_wrapper_off+len(dummy_trace_exit)+code_pad)&~code_pad
    trace_alt_wrapper_off=(trace_alt_trampoline_off+len(dummy_trace_alt_tramp)+code_pad)&~code_pad
    trace_loop_trampoline_off=(trace_alt_wrapper_off+len(dummy_trace_alt)+code_pad)&~code_pad
    trace_loop_wrapper_off=(trace_loop_trampoline_off+len(dummy_trace_loop_tramp)+code_pad)&~code_pad
    trace_vs_exit_trampoline_off=(trace_loop_wrapper_off+len(dummy_trace_loop)+code_pad)&~code_pad
    trace_vs_exit_wrapper_off=(trace_vs_exit_trampoline_off+len(dummy_trace_vs_exit_tramp)+code_pad)&~code_pad
    trace_init_trampoline_off=(trace_vs_exit_wrapper_off+len(dummy_trace_vs_exit)+code_pad)&~code_pad
    trace_init_wrapper_off=(trace_init_trampoline_off+len(dummy_trace_init_tramp)+code_pad)&~code_pad
    trace_results_trampoline_off=(trace_init_wrapper_off+len(dummy_trace_init)+code_pad)&~code_pad
    trace_results_wrapper_off=(trace_results_trampoline_off+len(dummy_trace_results_tramp)+code_pad)&~code_pad
    if enable_phase43_adventure_repairs:
        payload_end=trace_results_wrapper_off+len(dummy_trace_results)
    elif enable_adventure_sss_gateway:
        payload_end=gateway_onload_wrapper_off+len(dummy_gateway_onload)
    else:
        payload_end=luigi_wrapper_off+len(dummy_luigi)
    # Credits state/code stays at the payload tail so every existing Adventure
    # wrapper keeps its established address/layout. 0.20.16 clones the complete
    # node-5 shooter subtree and guards the extra P2 pass before retail terminal
    # teardown; Staff Roll OnExit remains exact retail.
    credits_state_off=(payload_end+0x1F)&~0x1F
    dummy_credits_lookup=_staffroll_cursor_lookup_wrapper(0x80404020,dummy_credits_pass,dummy_credits_cursor) if enable_dual_credits else b''
    dummy_credits_cut=_staffroll_local_pass_end_wrapper(0x80404100,dummy_credits_pass) if enable_dual_credits else b''
    dummy_credits_proc=_staffroll_dual_lens_proc(0x80404200,dummy_valid,dummy_credits_pass,dummy_credits_assembly,dummy_credits_cursor,dummy_credits_terminal_diag) if enable_dual_credits else b''
    dummy_credits_setup=_staffroll_setup_proc_wrapper(0x80404300,dummy_valid,dummy_credits_pass,dummy_credits_assembly,dummy_credits_cursor,0x80404200) if enable_dual_credits else b''
    dummy_credits_shot5=_staffroll_p2_shot_node5_lookup_wrapper(0x80404500,dummy_credits_pass,dummy_credits_assembly) if enable_dual_credits else b''
    dummy_credits_shot8=_staffroll_p2_shot_node8_lookup_wrapper(0x80404600,dummy_credits_pass,dummy_credits_cursor) if enable_dual_credits else b''
    credits_lookup_off=(credits_state_off+0x20+0x1F)&~0x1F
    credits_cut_off=(credits_lookup_off+len(dummy_credits_lookup)+0x1F)&~0x1F
    credits_proc_off=(credits_cut_off+len(dummy_credits_cut)+0x1F)&~0x1F
    credits_setup_off=(credits_proc_off+len(dummy_credits_proc)+0x1F)&~0x1F
    credits_shot5_off=(credits_setup_off+len(dummy_credits_setup)+0x1F)&~0x1F
    credits_shot8_off=(credits_shot5_off+len(dummy_credits_shot5)+0x1F)&~0x1F
    if enable_dual_credits:
        payload_end=credits_shot8_off+len(dummy_credits_shot8)
    payload=bytearray(payload_end)
    payload[0:8]=b'MSDKCP30'
    struct.pack_into('>IIIIIIII',payload,8,6,GM_ADVENTURE,2,1 if friendly_fire else 0,1 if enable_one_player_cstick else 0,1 if enable_either_player_pause else 0,1 if scene_revive else 0,1 if enable_dual_credits else 0)
    payload[0x20]=0  # camera_owner starts P1
    payload[0x21]=0  # persistence_valid: first encounter uses retail starting stocks
    payload[0x22]=0  # saved P1 stocks
    payload[0x23]=0  # saved P2 stocks
    payload[0x24]=0  # initial Adventure stock selection
    payload[0x25]=0  # Phase 41 VS-P2 identity valid
    payload[0x26]=0  # saved VS P2 CharacterKind
    payload[0x27]=0  # saved VS P2 costume color
    payload[0x28]=0  # saved VS P2 sub-color shading
    payload[0x29]=0  # saved VS P2 nametag
    payload[0x2A]=0  # Phase 42 saved VS P1 CharacterKind
    payload[0x2B]=0  # saved VS P1 costume color
    payload[0x2C]=0  # saved VS P1 sub-color shading
    payload[0x2D]=0  # saved VS P1 nametag
    payload[0x2E]=0  # Stage Select Adventure gateway pending
    payload[0x2F]=0  # HF5 Icies Team-Kirby teardown guard
    payload[0x30]=0  # HF5 P1 active Zelda/Sheik form
    payload[0x31]=0  # HF5 P2 active Zelda/Sheik form
    payload[0x32]=0  # HF20 diagnostic retained: C0 active, C1 terminal armed, D0..D5 NULL bonus skip
    payload[0x33]=0  # Team-Kirby lifecycle: 0 idle, 1 active observed, 2 terminal edge observed
    payload[0x34:0x38]=b'KTDG'  # HF21 Kirby Transition Diagnostic persistent savestate marker
    payload[0x38]=0  # HF21 last transition checkpoint (E0..E9)
    payload[0x39]=0  # HF21 evidence bits E0..E7
    payload[0x3A]=0  # Adventure state at most recent transition checkpoint
    payload[0x3B]=0  # Adventure state at previous transition checkpoint
    payload[0x3C]=0  # HF21 evidence bits E8..E9 (low two bits)
    if enable_dual_credits:
        payload[credits_state_off:credits_state_off+4]=b'P2LN'
        # +0x04 P2 shooter assembly ptr, +0x08 P2 cursor ptr, +0x0C pass,
        # +0x0D terminal-retirement diagnostic, +0x0E state-layout version.
        payload[credits_state_off+4:credits_state_off+15]=b'\0'*11
        payload[credits_state_off+14]=2
    if enable_test_shortcuts:
        payload[offscreen_vec_off:offscreen_vec_off+12]=struct.pack('>fff',0.0,-10000.0,0.0)
    # Phase 29 already created the SDK runtime section. Extend that same
    # loader-backed section instead of consuming another scarce DOL header slot.
    runtime_sec = dol.find_data_section_prefix(RuntimeHookInstaller.MAGIC)
    if runtime_sec is None:
        raise ValueError('Phase 29 runtime section was not found after framework installation')
    sec=dol.append_to_data_section(runtime_sec.index,payload,alignment=0x20)
    base=sec['address']; camera_owner_addr=base+0x20; persistence_valid_addr=base+0x21; p1_stocks_addr=base+0x22; p2_stocks_addr=base+0x23; initial_stocks_addr=base+0x24; vs_p2_identity_valid_addr=base+0x25; vs_p2_ckind_addr=base+0x26; vs_p2_color_addr=base+0x27; vs_p2_subcolor_addr=base+0x28; vs_p2_nametag_addr=base+0x29; vs_p1_ckind_addr=base+0x2A; vs_p1_color_addr=base+0x2B; vs_p1_subcolor_addr=base+0x2C; vs_p1_nametag_addr=base+0x2D; gateway_pending_addr=base+0x2E; icies_teardown_guard_addr=base+0x2F; p1_form_addr=base+0x30; p2_form_addr=base+0x31; icies_diag_addr=base+0x32; icies_wave_armed_addr=base+0x33; canonical_direct_valid_addr=base+0x34; canonical_direct_local_addr=base+0x35; canonical_direct_remote_addr=base+0x36; canonical_direct_trace_addr=base+0x37; transition_last_addr=base+0x38; transition_flags_lo_addr=base+0x39; transition_state_addr=base+0x3A; transition_prev_state_addr=base+0x3B; transition_flags_hi_addr=base+0x3C
    p2_addr=base+p2_off; gate_addr=base+gate_off; loader_addr=base+loader_off; rebirth_preflight_addr=base+rebirth_preflight_off; respawn_addr=base+respawn_off; stock_addr=base+stock_off; owner_entity_addr=base+owner_entity_off; pauser_addr=base+pauser_off; progress_addr=base+progress_off; reset_addr=base+reset_off; event_alloc_addr=base+event_alloc_off; dynamic_spawn_addr=base+dynamic_spawn_off; static_spawn_addr=base+static_spawn_off; finalwave_trampoline_addr=base+finalwave_trampoline_off; finalwave_wrapper_addr=base+finalwave_wrapper_off; bonus_trampoline_addr=base+bonus_trampoline_off; bonus_wrapper_addr=base+bonus_wrapper_off; hud_addr=base+hud_off; credits_addr=base+credits_off; event_trampoline_addr=base+event_trampoline_off; event_authority_addr=base+event_authority_off; test_shortcuts_addr=base+test_shortcuts_off; offscreen_vec_addr=base+offscreen_vec_off; wire_trampoline_addr=base+wire_trampoline_off; wire_wrapper_addr=base+wire_wrapper_off; presentation_trampoline_addr=base+presentation_trampoline_off; presentation_wrapper_addr=base+presentation_wrapper_off; luigi_wrapper_addr=base+luigi_wrapper_off; gateway_sss_trampoline_addr=base+gateway_sss_trampoline_off; gateway_sss_wrapper_addr=base+gateway_sss_wrapper_off; gateway_onload_trampoline_addr=base+gateway_onload_trampoline_off; gateway_onload_wrapper_addr=base+gateway_onload_wrapper_off; falco_wrapper_addr=base+falco_wrapper_off; teamkirby_enter_trampoline_addr=base+teamkirby_enter_trampoline_off; teamkirby_match_end_addr=base+teamkirby_match_end_off; teamkirby_enter_wrapper_addr=base+teamkirby_enter_wrapper_off; teamkirby_trampoline_addr=base+teamkirby_trampoline_off; teamkirby_wrapper_addr=base+teamkirby_wrapper_off; trace_exit_trampoline_addr=base+trace_exit_trampoline_off; trace_exit_wrapper_addr=base+trace_exit_wrapper_off; trace_alt_trampoline_addr=base+trace_alt_trampoline_off; trace_alt_wrapper_addr=base+trace_alt_wrapper_off; trace_loop_trampoline_addr=base+trace_loop_trampoline_off; trace_loop_wrapper_addr=base+trace_loop_wrapper_off; trace_vs_exit_trampoline_addr=base+trace_vs_exit_trampoline_off; trace_vs_exit_wrapper_addr=base+trace_vs_exit_wrapper_off; trace_init_trampoline_addr=base+trace_init_trampoline_off; trace_init_wrapper_addr=base+trace_init_wrapper_off; trace_results_trampoline_addr=base+trace_results_trampoline_off; trace_results_wrapper_addr=base+trace_results_wrapper_off
    credits_p2_assembly_ptr_addr=base+credits_state_off+4; credits_p2_cursor_ptr_addr=base+credits_state_off+8; credits_pass_addr=base+credits_state_off+12; credits_terminal_diag_addr=base+credits_state_off+13; credits_lookup_addr=base+credits_lookup_off; credits_cut_addr=base+credits_cut_off; credits_proc_addr=base+credits_proc_off; credits_setup_addr=base+credits_setup_off; credits_shot5_addr=base+credits_shot5_off; credits_shot8_addr=base+credits_shot8_off
    p2=_spawn_setup_stub(p2_addr, friendly_fire=friendly_fire, camera_owner_addr=camera_owner_addr, persistence_valid_addr=persistence_valid_addr, p1_stocks_addr=p1_stocks_addr, p2_stocks_addr=p2_stocks_addr, initial_stocks_addr=initial_stocks_addr, scene_revive=scene_revive, vs_p2_identity_valid_addr=vs_p2_identity_valid_addr if enable_vs_p2_identity_bridge else None, vs_p2_ckind_addr=vs_p2_ckind_addr if enable_vs_p2_identity_bridge else None, vs_p2_color_addr=vs_p2_color_addr if enable_vs_p2_identity_bridge else None, vs_p2_subcolor_addr=vs_p2_subcolor_addr if enable_vs_p2_identity_bridge else None, vs_p2_nametag_addr=vs_p2_nametag_addr if enable_vs_p2_identity_bridge else None, p1_form_addr=p1_form_addr, p2_form_addr=p2_form_addr)
    gate=_spawn_gate_stub(gate_addr); loader=_singleplayer_p2_loader_stub(loader_addr)
    rebirth_preflight=_rebirth_owner_preflight_wrapper(rebirth_preflight_addr, camera_owner_addr) if enable_adventure_sss_gateway else b''
    respawn=_respawn_platform_wrapper(respawn_addr, camera_owner_addr)
    stock=_team_stock_wrapper(stock_addr, camera_owner_addr)
    owner_entity=_control_player_entity_wrapper(owner_entity_addr, camera_owner_addr)
    pauser=_adventure_pauser_mode_wrapper(pauser_addr) if enable_either_player_pause else b''
    progress=_adventure_progress_stock_wrapper(progress_addr, persistence_valid_addr=persistence_valid_addr, p1_stocks_addr=p1_stocks_addr, p2_stocks_addr=p2_stocks_addr)
    reset=_campaign_state_reset_stub(reset_addr, camera_owner_addr=camera_owner_addr, persistence_valid_addr=persistence_valid_addr, p1_stocks_addr=p1_stocks_addr, p2_stocks_addr=p2_stocks_addr, initial_stocks_addr=initial_stocks_addr, return_address=0x801B42EC, vs_p2_identity_valid_addr=vs_p2_identity_valid_addr if enable_vs_p2_identity_bridge else None, vs_p2_ckind_addr=vs_p2_ckind_addr if enable_vs_p2_identity_bridge else None, vs_p2_color_addr=vs_p2_color_addr if enable_vs_p2_identity_bridge else None, vs_p2_subcolor_addr=vs_p2_subcolor_addr if enable_vs_p2_identity_bridge else None, vs_p2_nametag_addr=vs_p2_nametag_addr if enable_vs_p2_identity_bridge else None, extra_reset_addrs=(icies_teardown_guard_addr,p1_form_addr,p2_form_addr,icies_diag_addr,icies_wave_armed_addr,transition_last_addr,transition_flags_lo_addr,transition_state_addr,transition_prev_state_addr,transition_flags_hi_addr))
    event_alloc=_event_allocator_start_wrapper(event_alloc_addr)
    dynamic_spawn=_dynamic_enemy_spawn_wrapper(dynamic_spawn_addr)
    static_spawn=_adventure_slippi_spawn_guard_wrapper(static_spawn_addr) if enable_adventure_sss_gateway else b''
    finalwave_trampoline=(EVENT_ENEMY_MANAGER_EXPECTED + encode_branch(finalwave_trampoline_addr+4, EVENT_ENEMY_MANAGER_HOOK+4)) if enable_phase43_adventure_repairs else b''
    finalwave_wrapper=_team_kirby_final_wave_wrapper(finalwave_wrapper_addr, finalwave_trampoline_addr, p1_ckind_addr=vs_p1_ckind_addr, p2_ckind_addr=vs_p2_ckind_addr, icies_teardown_guard_addr=icies_teardown_guard_addr, icies_diag_addr=icies_diag_addr, icies_wave_armed_addr=icies_wave_armed_addr) if enable_phase43_adventure_repairs else b''
    bonus_trampoline=(FN_BONUS_FIGHTER_EXPECTED + encode_branch(bonus_trampoline_addr+4, FN_BONUS_FIGHTER_HOOK+4)) if enable_phase43_adventure_repairs else b''
    bonus_wrapper=_team_kirby_bonus_guard_wrapper(bonus_wrapper_addr, bonus_trampoline_addr, p1_ckind_addr=vs_p1_ckind_addr, p2_ckind_addr=vs_p2_ckind_addr, icies_teardown_guard_addr=icies_teardown_guard_addr, icies_diag_addr=icies_diag_addr) if enable_phase43_adventure_repairs else b''
    hud=_adventure_hud_capacity_wrapper(hud_addr)
    credits=_staffroll_independent_pad_wrapper(credits_addr,persistence_valid_addr,credits_pass_addr) if enable_dual_credits else b''
    credits_lookup=_staffroll_cursor_lookup_wrapper(credits_lookup_addr,credits_pass_addr,credits_p2_cursor_ptr_addr) if enable_dual_credits else b''
    credits_cut=_staffroll_local_pass_end_wrapper(credits_cut_addr,credits_pass_addr) if enable_dual_credits else b''
    credits_proc=_staffroll_dual_lens_proc(credits_proc_addr,persistence_valid_addr,credits_pass_addr,credits_p2_assembly_ptr_addr,credits_p2_cursor_ptr_addr,credits_terminal_diag_addr) if enable_dual_credits else b''
    credits_setup=_staffroll_setup_proc_wrapper(credits_setup_addr,persistence_valid_addr,credits_pass_addr,credits_p2_assembly_ptr_addr,credits_p2_cursor_ptr_addr,credits_proc_addr) if enable_dual_credits else b''
    credits_shot5=_staffroll_p2_shot_node5_lookup_wrapper(credits_shot5_addr,credits_pass_addr,credits_p2_assembly_ptr_addr) if enable_dual_credits else b''
    credits_shot8=_staffroll_p2_shot_node8_lookup_wrapper(credits_shot8_addr,credits_pass_addr,credits_p2_cursor_ptr_addr) if enable_dual_credits else b''
    event_trampoline=(ground_event_expected + encode_branch(event_trampoline_addr+4, GROUND_EVENT_SCAN_HOOK+4)) if enable_either_human_events else b''
    test_shortcuts=_adventure_test_shortcuts_stub(test_shortcuts_addr, offscreen_vec_addr=offscreen_vec_addr, persistence_valid_addr=persistence_valid_addr, p1_stocks_addr=p1_stocks_addr, p2_stocks_addr=p2_stocks_addr, initial_stocks_addr=initial_stocks_addr) if enable_test_shortcuts else b''
    event_authority=_ground_event_either_human_wrapper(event_authority_addr, event_trampoline_addr, camera_owner_addr, test_shortcuts_addr if enable_test_shortcuts else None, p2_ckind_addr=vs_p2_ckind_addr, icies_teardown_guard_addr=icies_teardown_guard_addr, p1_form_addr=p1_form_addr, p2_form_addr=p2_form_addr, icies_diag_addr=icies_diag_addr) if enable_either_human_events else b''
    wire_trampoline=wireframe_expected + encode_branch(wire_trampoline_addr+4, WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK+4)
    wire_wrapper=_wireframe_human_physics_guard(wire_wrapper_addr, wire_trampoline_addr)
    presentation_trampoline=presentation_expected + encode_branch(presentation_trampoline_addr+4, GM_GET_BUTTONS_TRIGGERED_HOOK+4)
    presentation_wrapper=_adventure_presentation_start_wrapper(presentation_wrapper_addr, presentation_trampoline_addr)
    luigi_wrapper=_luigi_cpu_substitution_wrapper(luigi_wrapper_addr)
    gateway_sss_trampoline=(gateway_sss_expected + encode_branch(gateway_sss_trampoline_addr+4,GM_VS_MELEE_EXIT_SSS+4)) if enable_legacy_local_vs_gateway else b''
    gateway_sss_wrapper=_adventure_sss_gateway_exit_wrapper(gateway_sss_wrapper_addr,gateway_sss_trampoline_addr,gateway_pending_addr=gateway_pending_addr,p1_ckind_addr=vs_p1_ckind_addr,p1_color_addr=vs_p1_color_addr,p1_subcolor_addr=vs_p1_subcolor_addr,p1_nametag_addr=vs_p1_nametag_addr,p2_identity_valid_addr=vs_p2_identity_valid_addr,p2_ckind_addr=vs_p2_ckind_addr,p2_color_addr=vs_p2_color_addr,p2_subcolor_addr=vs_p2_subcolor_addr,p2_nametag_addr=vs_p2_nametag_addr) if enable_legacy_local_vs_gateway else b''
    gateway_onload_trampoline=(gateway_onload_expected + encode_branch(gateway_onload_trampoline_addr+4,GM_MODE_ADVENTURE_ONLOAD+4)) if enable_adventure_sss_gateway else b''
    gateway_onload_wrapper=_adventure_gateway_onload_wrapper(gateway_onload_wrapper_addr,gateway_onload_trampoline_addr,gateway_pending_addr=gateway_pending_addr,camera_owner_addr=camera_owner_addr,persistence_valid_addr=persistence_valid_addr,p1_stocks_addr=p1_stocks_addr,p2_stocks_addr=p2_stocks_addr,initial_stocks_addr=initial_stocks_addr,p1_ckind_addr=vs_p1_ckind_addr,p1_color_addr=vs_p1_color_addr,p1_nametag_addr=vs_p1_nametag_addr,adventure_cpu_level=adventure_cpu_level,adventure_stocks=adventure_stocks) if enable_adventure_sss_gateway else b''
    falco_wrapper=_falco_cpu_substitution_wrapper(falco_wrapper_addr) if enable_phase43_adventure_repairs else b''
    teamkirby_enter_trampoline=(teamkirby_enter_expected + encode_branch(teamkirby_enter_trampoline_addr+4,ADVENTURE_TEAMKIRBY_ENTER_HOOK+4)) if enable_phase43_adventure_repairs else b''
    teamkirby_match_end=b''  # HF8 removes HF7 StartMeleeRules.x54 interception
    teamkirby_enter_wrapper=b''  # retail gm_801B4B28 entry remains untouched
    teamkirby_trampoline=(teamkirby_expected + encode_branch(teamkirby_trampoline_addr+4,ADVENTURE_TEAMKIRBY_EXIT_HOOK+4)) if enable_phase43_adventure_repairs else b''
    teamkirby_wrapper=_team_kirby_exit_wrapper(teamkirby_wrapper_addr,teamkirby_trampoline_addr) if enable_phase43_adventure_repairs else b''
    def _trace_pair(hook: int, trampoline_addr: int, wrapper_addr: int, enter: int | None, ret: int | None):
        # Current builds retain only the first retired HF21 pair as scratch
        # storage for the hardened presentation accessor. All other historical
        # scene-trace hooks stay retail from the beginning.
        if not enable_phase43_adventure_repairs or hook != SCENE_EXIT_REQUEST_HOOK:
            return b'', b''
        displaced=transition_trace_expected[hook]
        trampoline=displaced + encode_branch(trampoline_addr+4,hook+4)
        # Production retires this HF21 hook immediately in slippi_boot_hardening.
        # Keep only the exact scratch capacity consumed later by the hardened
        # presentation accessor (0x20 accessor + 8-byte marker). This removes
        # dead diagnostic code without changing a live runtime path.
        wrapper=_retired_trace_scratch_wrapper(wrapper_addr,trampoline_addr)
        return trampoline,wrapper
    trace_exit_trampoline,trace_exit_wrapper=_trace_pair(SCENE_EXIT_REQUEST_HOOK,trace_exit_trampoline_addr,trace_exit_wrapper_addr,0xE0,None)
    trace_alt_trampoline,trace_alt_wrapper=_trace_pair(SCENE_EXIT_REQUEST_ALT_HOOK,trace_alt_trampoline_addr,trace_alt_wrapper_addr,0xE1,None)
    trace_loop_trampoline,trace_loop_wrapper=_trace_pair(SCENE_LOOP_HOOK,trace_loop_trampoline_addr,trace_loop_wrapper_addr,0xE9,0xE2)
    trace_vs_exit_trampoline,trace_vs_exit_wrapper=_trace_pair(VS_SCENE_EXIT_HOOK,trace_vs_exit_trampoline_addr,trace_vs_exit_wrapper_addr,0xE3,0xE4)
    trace_init_trampoline,trace_init_wrapper=_trace_pair(SCENE_INIT_HOOK,trace_init_trampoline_addr,trace_init_wrapper_addr,0xE5,0xE6)
    trace_results_trampoline,trace_results_wrapper=_trace_pair(RESULTS_SCENE_ENTER_HOOK,trace_results_trampoline_addr,trace_results_wrapper_addr,0xE7,0xE8)
    blobs=[(p2_addr,p2),(gate_addr,gate),(loader_addr,loader),(rebirth_preflight_addr,rebirth_preflight),(respawn_addr,respawn),(stock_addr,stock),(owner_entity_addr,owner_entity),(progress_addr,progress),(reset_addr,reset),(event_alloc_addr,event_alloc),(dynamic_spawn_addr,dynamic_spawn),(static_spawn_addr,static_spawn),(finalwave_trampoline_addr,finalwave_trampoline),(finalwave_wrapper_addr,finalwave_wrapper),(bonus_trampoline_addr,bonus_trampoline),(bonus_wrapper_addr,bonus_wrapper),(hud_addr,hud),
           (wire_trampoline_addr,wire_trampoline),(wire_wrapper_addr,wire_wrapper),(presentation_trampoline_addr,presentation_trampoline),(presentation_wrapper_addr,presentation_wrapper),(luigi_wrapper_addr,luigi_wrapper)]
    if gateway_sss_trampoline:
        blobs.extend([(gateway_sss_trampoline_addr,gateway_sss_trampoline),(gateway_sss_wrapper_addr,gateway_sss_wrapper)])
    if gateway_onload_trampoline:
        blobs.extend([(gateway_onload_trampoline_addr,gateway_onload_trampoline),(gateway_onload_wrapper_addr,gateway_onload_wrapper)])
    if enable_phase43_adventure_repairs:
        blobs.extend([(falco_wrapper_addr,falco_wrapper),(teamkirby_trampoline_addr,teamkirby_trampoline),(teamkirby_wrapper_addr,teamkirby_wrapper),
            (trace_exit_trampoline_addr,trace_exit_trampoline),(trace_exit_wrapper_addr,trace_exit_wrapper),
            (trace_alt_trampoline_addr,trace_alt_trampoline),(trace_alt_wrapper_addr,trace_alt_wrapper),
            (trace_loop_trampoline_addr,trace_loop_trampoline),(trace_loop_wrapper_addr,trace_loop_wrapper),
            (trace_vs_exit_trampoline_addr,trace_vs_exit_trampoline),(trace_vs_exit_wrapper_addr,trace_vs_exit_wrapper),
            (trace_init_trampoline_addr,trace_init_trampoline),(trace_init_wrapper_addr,trace_init_wrapper),
            (trace_results_trampoline_addr,trace_results_trampoline),(trace_results_wrapper_addr,trace_results_wrapper)])
    if pauser:
        blobs.append((pauser_addr,pauser))
    if credits:
        blobs.extend([(credits_addr,credits),(credits_lookup_addr,credits_lookup),(credits_cut_addr,credits_cut),(credits_proc_addr,credits_proc),(credits_setup_addr,credits_setup),(credits_shot5_addr,credits_shot5),(credits_shot8_addr,credits_shot8)])
    if event_trampoline:
        blobs.append((event_trampoline_addr,event_trampoline))
    if event_authority:
        blobs.append((event_authority_addr,event_authority))
    if test_shortcuts:
        blobs.append((test_shortcuts_addr,test_shortcuts))

    # HF9 layout hardening: the first-pass dummy builders MUST be byte-for-byte
    # size-equivalent to their final builders. HF8 accidentally sized the short
    # owner-entity wrapper (72 bytes) but emitted the diagnostic Icies wrapper
    # (228 bytes), shifting every later address backward into live code. Fail the
    # build instead of ever emitting a payload with that class of mismatch.
    if len(dummy6) != len(owner_entity):
        raise ValueError(
            f'Adventure payload sizing mismatch: owner-entity dummy={len(dummy6)} final={len(owner_entity)}'
        )
    if len(dummy_finalwave_tramp) != len(finalwave_trampoline) or len(dummy_finalwave) != len(finalwave_wrapper):
        raise ValueError(
            'Adventure payload sizing mismatch: final-wave dummy/final lengths differ '
            f'trampoline={len(dummy_finalwave_tramp)}/{len(finalwave_trampoline)} '
            f'wrapper={len(dummy_finalwave)}/{len(finalwave_wrapper)}'
        )
    if len(dummy_bonus_tramp) != len(bonus_trampoline) or len(dummy_bonus) != len(bonus_wrapper):
        raise ValueError(
            'Adventure payload sizing mismatch: bonus-guard dummy/final lengths differ '
            f'trampoline={len(dummy_bonus_tramp)}/{len(bonus_trampoline)} '
            f'wrapper={len(dummy_bonus)}/{len(bonus_wrapper)}'
        )
    for label,dtr,dwr,ftr,fwr in (
        ('exit-request',dummy_trace_exit_tramp,dummy_trace_exit,trace_exit_trampoline,trace_exit_wrapper),
        ('alt-exit-request',dummy_trace_alt_tramp,dummy_trace_alt,trace_alt_trampoline,trace_alt_wrapper),
        ('scene-loop',dummy_trace_loop_tramp,dummy_trace_loop,trace_loop_trampoline,trace_loop_wrapper),
        ('vs-on-exit',dummy_trace_vs_exit_tramp,dummy_trace_vs_exit,trace_vs_exit_trampoline,trace_vs_exit_wrapper),
        ('scene-init',dummy_trace_init_tramp,dummy_trace_init,trace_init_trampoline,trace_init_wrapper),
        ('results-on-enter',dummy_trace_results_tramp,dummy_trace_results,trace_results_trampoline,trace_results_wrapper),
    ):
        if len(dtr) != len(ftr) or len(dwr) != len(fwr):
            raise ValueError(f'HF21 transition trace sizing mismatch ({label})')

    if enable_dual_credits:
        for label,dummy,final in (
            ('pad',dummy13,credits),('cursor-lookup',dummy_credits_lookup,credits_lookup),
            ('local-cut',dummy_credits_cut,credits_cut),('dual-proc',dummy_credits_proc,credits_proc),
            ('setup',dummy_credits_setup,credits_setup),
            ('shot-node5',dummy_credits_shot5,credits_shot5),
            ('shot-node8',dummy_credits_shot8,credits_shot8),
        ):
            if len(dummy) != len(final):
                raise ValueError(f'0.20.16 credits sizing mismatch ({label}): {len(dummy)}/{len(final)}')

    # No two generated runtime blobs may overlap, regardless of future wrapper
    # growth. Empty blobs are ignored. This is a production build invariant, not
    # merely a unit-test expectation.
    occupied=sorted((addr, addr+len(blob)) for addr, blob in blobs if blob)
    for (a0,a1),(b0,b1) in zip(occupied, occupied[1:]):
        if a1 > b0:
            raise ValueError(
                f'Adventure payload blob overlap: 0x{a0:08X}-0x{a1:08X} overlaps '
                f'0x{b0:08X}-0x{b1:08X}'
            )

    for addr, blob in blobs:
        off=dol.file_offset_for_address(addr,len(blob)); dol.raw[off:off+len(blob)]=blob

    # HF21 adds only high-level scene-transition observation. Generic fighter,
    # event, renderer, and GObj teardown remains retail; no new ownership mutation
    # is introduced. The evidence bytes survive the transition until a new
    # Adventure campaign resets them.
    trace_hooks=[]

    # Repurpose the already-installed transparent Adventure CSS-entry
    # trampoline as the new-campaign reset entry. The site itself stays within
    # the shared Phase 29 framework, preserving composition and one-section use.
    css_fw = next(h for h in framework['hooks'] if h['name'] == 'gm_801B42E8')
    css_stub_addr = int(css_fw['stub_address'])
    css_stub_off = dol.file_offset_for_address(css_stub_addr, 4)
    original_css = bytes.fromhex(css_fw['original_instruction'])
    if bytes(dol.raw[css_stub_off:css_stub_off+4]) != original_css:
        raise ValueError('Adventure CSS reset: Phase 29 transparent stub no longer contains displaced retail entry instruction')
    css_reset_branch = encode_branch(css_stub_addr, reset_addr)
    dol.raw[css_stub_off:css_stub_off+4] = css_reset_branch

    p2_branch=encode_branch(P2_SETUP_HOOK,p2_addr)
    gate_branch=encode_branch(SPAWN_GATE_HOOK,gate_addr)
    loader_branch=encode_branch(SINGLEPLAYER_P2_LOADER_HOOK,loader_addr)
    respawn_branch=encode_branch(RESPAWN_PLATFORM_HOOK,respawn_addr,link=True)
    ffa_stock_branch=encode_branch(FFA_P1_STOCK_HOOK,stock_addr,link=True)
    team_stock_branch=encode_branch(TEAM_P1_STOCK_HOOK,stock_addr,link=True)
    ground_owner_branch=encode_branch(GROUND_GET_P1_FIGHTER_HOOK,owner_entity_addr)
    camera_owner_call=encode_branch(CAMERA_P1_ENTITY_CALL_HOOK,owner_entity_addr,link=True)
    pauser_mode_call=encode_branch(DEFAULT_PAUSER_MODE_CALL_HOOK,pauser_addr,link=True) if enable_either_player_pause else None
    progress_branch=encode_branch(ADVENTURE_PROGRESS_STOCK_HOOK,progress_addr)
    event_alloc_branch=encode_branch(EVENT_ALLOCATOR_START_HOOK,event_alloc_addr)
    dynamic_spawn_branch=encode_branch(DYNAMIC_ENEMY_SPAWN_HOOK,dynamic_spawn_addr)
    # SDK 0.20.9: keep 0x8016E48C exact retail. Instead intercept the immediately
    # following coordinate-commit call so Adventure can bypass Slippi's runtime
    # 0x8016E510 VS spawn normalizer without disabling it anywhere else.
    static_spawn_branch=encode_branch(MULTISLOT_POST_COORD_HOOK,static_spawn_addr) if enable_adventure_sss_gateway else None
    rebirth_preflight_branch=encode_branch(REBIRTH_OWNER_PREFLIGHT_HOOK,rebirth_preflight_addr) if enable_adventure_sss_gateway else None
    finalwave_branch=encode_branch(EVENT_ENEMY_MANAGER_HOOK,finalwave_wrapper_addr) if enable_phase43_adventure_repairs else None
    bonus_branch=encode_branch(FN_BONUS_FIGHTER_HOOK,bonus_wrapper_addr) if enable_phase43_adventure_repairs else None
    hud_branch=encode_branch(ADVENTURE_HUD_INIT_HOOK,hud_addr,link=True)
    credits_branch=encode_branch(STAFFROLL_PAD_INDEX_HOOK,credits_addr) if enable_dual_credits else None
    credits_lookup_branch=encode_branch(STAFFROLL_CURSOR_LOOKUP_CALL,credits_lookup_addr,link=True) if enable_dual_credits else None
    credits_shot5_branch=encode_branch(STAFFROLL_SHOT_NODE5_LOOKUP_CALL,credits_shot5_addr,link=True) if enable_dual_credits else None
    credits_shot5_anim_branch=encode_branch(STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_CALL,credits_shot5_addr,link=True) if enable_dual_credits else None
    credits_shot8_branch=encode_branch(STAFFROLL_SHOT_NODE8_LOOKUP_CALL,credits_shot8_addr,link=True) if enable_dual_credits else None
    credits_cut_branch=encode_branch(STAFFROLL_LOCAL_PASS_END_HOOK,credits_cut_addr) if enable_dual_credits else None
    credits_setup_branch=encode_branch(STAFFROLL_SETUP_PROC_CALL,credits_setup_addr,link=True) if enable_dual_credits else None
    event_authority_branch=encode_branch(GROUND_EVENT_SCAN_HOOK,event_authority_addr) if enable_either_human_events else None
    wireframe_branch=encode_branch(WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK,wire_wrapper_addr)
    presentation_branch=encode_branch(GM_GET_BUTTONS_TRIGGERED_HOOK,presentation_wrapper_addr)
    luigi_branch=encode_branch(LUIGI_FIGHT_SETUP_HOOK,luigi_wrapper_addr)
    gateway_sss_branch=encode_branch(GM_VS_MELEE_EXIT_SSS,gateway_sss_wrapper_addr) if enable_legacy_local_vs_gateway else None
    gateway_onload_branch=encode_branch(GM_MODE_ADVENTURE_ONLOAD,gateway_onload_wrapper_addr) if enable_adventure_sss_gateway else None
    falco_branch=encode_branch(ADVENTURE_FALCO_FIGHT_SETUP_HOOK,falco_wrapper_addr) if enable_phase43_adventure_repairs else None
    teamkirby_enter_branch=encode_branch(ADVENTURE_TEAMKIRBY_ENTER_HOOK,teamkirby_enter_wrapper_addr) if enable_phase43_adventure_repairs else None
    teamkirby_branch=encode_branch(ADVENTURE_TEAMKIRBY_EXIT_HOOK,teamkirby_wrapper_addr) if enable_phase43_adventure_repairs else None
    trace_exit_branch=encode_branch(SCENE_EXIT_REQUEST_HOOK,trace_exit_wrapper_addr) if enable_phase43_adventure_repairs else None
    trace_alt_branch=encode_branch(SCENE_EXIT_REQUEST_ALT_HOOK,trace_alt_wrapper_addr) if enable_phase43_adventure_repairs else None
    trace_loop_branch=encode_branch(SCENE_LOOP_HOOK,trace_loop_wrapper_addr) if enable_phase43_adventure_repairs else None
    trace_vs_exit_branch=encode_branch(VS_SCENE_EXIT_HOOK,trace_vs_exit_wrapper_addr) if enable_phase43_adventure_repairs else None
    trace_init_branch=encode_branch(SCENE_INIT_HOOK,trace_init_wrapper_addr) if enable_phase43_adventure_repairs else None
    trace_results_branch=encode_branch(RESULTS_SCENE_ENTER_HOOK,trace_results_wrapper_addr) if enable_phase43_adventure_repairs else None
    dol.patch_at_address(P2_SETUP_HOOK,p2_branch,expected=P2_SETUP_EXPECTED)
    dol.patch_at_address(SPAWN_GATE_HOOK,gate_branch,expected=SPAWN_GATE_EXPECTED)
    dol.patch_at_address(SINGLEPLAYER_P2_LOADER_HOOK,loader_branch,expected=SINGLEPLAYER_P2_LOADER_EXPECTED)
    if enable_adventure_sss_gateway:
        dol.patch_at_address(REBIRTH_OWNER_PREFLIGHT_HOOK,rebirth_preflight_branch,expected=REBIRTH_OWNER_PREFLIGHT_EXPECTED)
    dol.patch_at_address(RESPAWN_PLATFORM_HOOK,respawn_branch,expected=RESPAWN_PLATFORM_EXPECTED)
    dol.patch_at_address(FFA_P1_STOCK_HOOK,ffa_stock_branch,expected=FFA_P1_STOCK_EXPECTED)
    dol.patch_at_address(TEAM_P1_STOCK_HOOK,team_stock_branch,expected=TEAM_P1_STOCK_EXPECTED)
    dol.patch_at_address(GROUND_GET_P1_FIGHTER_HOOK,ground_owner_branch,expected=GROUND_GET_P1_FIGHTER_EXPECTED)
    dol.patch_at_address(CAMERA_P1_ENTITY_CALL_HOOK,camera_owner_call,expected=CAMERA_P1_ENTITY_CALL_EXPECTED)
    dol.patch_at_address(ADVENTURE_PROGRESS_STOCK_HOOK,progress_branch,expected=ADVENTURE_PROGRESS_STOCK_EXPECTED)
    dol.patch_at_address(EVENT_ALLOCATOR_START_HOOK,event_alloc_branch,expected=EVENT_ALLOCATOR_START_EXPECTED)
    dol.patch_at_address(DYNAMIC_ENEMY_SPAWN_HOOK,dynamic_spawn_branch,expected=DYNAMIC_ENEMY_SPAWN_EXPECTED)
    # Exact retail fallback at 0x8016E48C remains untouched. Adventure only
    # bypasses Slippi's later runtime normalizer at 0x8016E510.
    if static_spawn_branch is not None:
        dol.patch_at_address(MULTISLOT_POST_COORD_HOOK,static_spawn_branch,expected=MULTISLOT_POST_COORD_EXPECTED)
    if enable_phase43_adventure_repairs:
        dol.patch_at_address(EVENT_ENEMY_MANAGER_HOOK,finalwave_branch,expected=EVENT_ENEMY_MANAGER_EXPECTED)
        dol.patch_at_address(FN_BONUS_FIGHTER_HOOK,bonus_branch,expected=FN_BONUS_FIGHTER_EXPECTED)
    dol.patch_at_address(ADVENTURE_HUD_INIT_HOOK,hud_branch,expected=ADVENTURE_HUD_INIT_EXPECTED)
    if enable_dual_credits:
        dol.patch_at_address(STAFFROLL_PAD_INDEX_HOOK,credits_branch,expected=STAFFROLL_PAD_INDEX_EXPECTED)
        dol.patch_at_address(STAFFROLL_CURSOR_LOOKUP_CALL,credits_lookup_branch,expected=STAFFROLL_CURSOR_LOOKUP_EXPECTED)
        dol.patch_at_address(STAFFROLL_SHOT_NODE5_LOOKUP_CALL,credits_shot5_branch,expected=STAFFROLL_SHOT_NODE5_LOOKUP_EXPECTED)
        dol.patch_at_address(STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_CALL,credits_shot5_anim_branch,expected=STAFFROLL_SHOT_NODE5_ANIM_LOOKUP_EXPECTED)
        dol.patch_at_address(STAFFROLL_SHOT_NODE8_LOOKUP_CALL,credits_shot8_branch,expected=STAFFROLL_SHOT_NODE8_LOOKUP_EXPECTED)
        dol.patch_at_address(STAFFROLL_LOCAL_PASS_END_HOOK,credits_cut_branch,expected=STAFFROLL_LOCAL_PASS_END_EXPECTED)
        dol.patch_at_address(STAFFROLL_SETUP_PROC_CALL,credits_setup_branch,expected=STAFFROLL_SETUP_PROC_EXPECTED)
    if enable_either_human_events:
        dol.patch_at_address(GROUND_EVENT_SCAN_HOOK,event_authority_branch,expected=ground_event_expected)
    dol.patch_at_address(WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK,wireframe_branch,expected=wireframe_expected)
    dol.patch_at_address(GM_GET_BUTTONS_TRIGGERED_HOOK,presentation_branch,expected=presentation_expected)
    dol.patch_at_address(LUIGI_FIGHT_SETUP_HOOK,luigi_branch,expected=luigi_expected)
    if enable_legacy_local_vs_gateway:
        dol.patch_at_address(GM_VS_MELEE_EXIT_SSS,gateway_sss_branch,expected=gateway_sss_expected)
    if enable_adventure_sss_gateway:
        dol.patch_at_address(GM_MODE_ADVENTURE_ONLOAD,gateway_onload_branch,expected=gateway_onload_expected)
    if enable_phase43_adventure_repairs:
        dol.patch_at_address(ADVENTURE_FALCO_FIGHT_SETUP_HOOK,falco_branch,expected=falco_expected)
        # HF8: do not patch gm_801B4B28; retail Team-Kirby setup must own rules.x54.
        dol.patch_at_address(ADVENTURE_TEAMKIRBY_EXIT_HOOK,teamkirby_branch,expected=teamkirby_expected)
        for hook,branch,wrapper,blob,label in (
            (SCENE_EXIT_REQUEST_HOOK,trace_exit_branch,trace_exit_wrapper_addr,trace_exit_wrapper,'hf21_scene_exit_request'),
            (SCENE_EXIT_REQUEST_ALT_HOOK,trace_alt_branch,trace_alt_wrapper_addr,trace_alt_wrapper,'hf21_scene_alt_exit_request'),
            (SCENE_LOOP_HOOK,trace_loop_branch,trace_loop_wrapper_addr,trace_loop_wrapper,'hf21_scene_loop'),
            (VS_SCENE_EXIT_HOOK,trace_vs_exit_branch,trace_vs_exit_wrapper_addr,trace_vs_exit_wrapper,'hf21_vs_scene_exit'),
            (SCENE_INIT_HOOK,trace_init_branch,trace_init_wrapper_addr,trace_init_wrapper,'hf21_scene_init'),
            (RESULTS_SCENE_ENTER_HOOK,trace_results_branch,trace_results_wrapper_addr,trace_results_wrapper,'hf21_results_scene_enter'),
        ):
            if not blob:
                continue
            dol.patch_at_address(hook,branch,expected=transition_trace_expected[hook])
            trace_hooks.append(asdict(ProbeHook(label,hook,transition_trace_expected[hook].hex(),wrapper,branch.hex(),hook+4)))
    if enable_one_player_cstick:
        dol.patch_at_address(ONE_PLAYER_CSTICK_HOOK,nop(),expected=ONE_PLAYER_CSTICK_EXPECTED)
    if enable_either_player_pause:
        dol.patch_at_address(DEFAULT_PAUSER_MODE_CALL_HOOK,pauser_mode_call,expected=DEFAULT_PAUSER_MODE_CALL_EXPECTED)

    unlock_query_patches=[]
    if enable_unlock_all:
        # Test-only query overrides. Source DOL is already SHA-1 verified as
        # clean GALE01 v1.02 above, so fixed addresses are safe here. We avoid
        # gm_UnlockCKind/gm_8016468C on purpose because those mutate save-backed
        # bitmasks and could contaminate progression testing.
        for name, addr in (
            ('stage_specific_unlock', GM_STAGE_UNLOCK_CHECK),
            ('all_stages_unlocked', GM_ALL_STAGES_UNLOCKED),
            ('character_specific_unlock', GM_IS_CKIND_UNLOCKED),
            ('all_characters_unlocked', GM_ALL_CHARACTERS_UNLOCKED),
            ('roster_menu_unlock_check', GM_UNLOCK_ROSTER_MENU_CHECK),
        ):
            row=dol.patch_at_address(addr,UNLOCK_QUERY_TRUE)
            row['name']=name
            unlock_query_patches.append(row)

    # HF29E combined memory isolation.  HF29D pool packing preserves live-fight headroom, while HF29C proved the results background
    # is the remaining pressure point, but its 320x240 (153,600-byte) capture
    # still consumed enough heap in DoubleIciesCrash.sav to leave only a
    # 22,880-byte largest cell.  Baselib drawShapeAnim then panicked on its
    # first lazy 24,000-byte scratch-buffer HSD_MemAlloc.
    #
    # HF29C therefore removes HF22 again and installs ONE narrower hook: after
    # the verified Icies Team-Kirby terminal edge, omit only the optional
    # captured-gameplay background GObj and continue normal results setup.
    # HF23-HF28 remain absent.  L+DLeft remains test-only warp scaffolding.
    clear_screen_memory = None
    clear_screen_background_omit = None
    hf29c_results_headroom = {
        'base_sha1': hashlib.sha1(bytes(dol.raw)).hexdigest(),
        'base_sha256': hashlib.sha256(bytes(dol.raw)).hexdigest(),
        'failure_evidence': {
            'save': 'DoubleIciesCrash.sav',
            'hf29b_background_created': True,
            'hf29b_capture_bytes': 153600,
            'crash_allocator': 'drawShapeAnim normal_buffer',
            'requested_bytes': 24000,
            'largest_free_cell_at_crash': 22880,
        },
        'policy': 'omit optional captured results background on established co-op Team-Kirby clears, independent of fighter kind',
    }
    effect_memory_protection = None
    clear_screen_failsafe = None
    early_clear_failsafe = None
    team_kirby_force_clear = None
    team_kirby_test_warp = None
    team_kirby_fast_forward = None
    team_kirby_retail_warp = None
    if enable_phase43_adventure_repairs and enable_test_shortcuts:
        from .team_kirby_retail_warp import BOWSER_FIGHT_STATE, install as install_team_kirby_retail_warp
        team_kirby_retail_warp = install_team_kirby_retail_warp(
            dol, runtime_sec.index, old_shortcut_addr=test_shortcuts_addr,
            target_state=BOWSER_FIGHT_STATE)
    if enable_phase43_adventure_repairs:
        from .clear_screen_background_omit import install as install_clear_screen_background_omit
        clear_screen_background_omit = install_clear_screen_background_omit(
            dol, runtime_sec.index, persistence_valid_addr)

    team_kirby_pool_packing = None
    if enable_phase43_adventure_repairs:
        from .team_kirby_pool_packing import install as install_team_kirby_pool_packing
        team_kirby_pool_packing = install_team_kirby_pool_packing(dol, runtime_sec.index)

    # HF29F: Adventure must return to the major mode that launched it instead
    # of hard-coding GM_MENU.  This uses retail routing.prev_mode and adds no
    # mutable SDK state; enabled only with the direct Adventure gateway.
    adventure_origin_return = None
    if enable_adventure_sss_gateway:
        from .adventure_origin_return import install as install_adventure_origin_return
        adventure_origin_return = install_adventure_origin_return(dol, runtime_sec.index)

    # HF29G: promote the gateway's one-shot pending byte into an explicit
    # campaign-scope co-op flag.  Every behavior-changing co-op hook now
    # dispatches to exact retail behavior unless that flag was established by
    # the sentinel + two-Human gateway.  The same layer redirects the both-zero
    # co-op failure path to retail routing.prev_mode while leaving ordinary
    # 1-P Adventure Game Over / Continue untouched.
    adventure_gateway_scope = None
    completion_retail_rollback = None
    if enable_adventure_sss_gateway:
        from .adventure_gateway_scope import install as install_adventure_gateway_scope
        adventure_gateway_scope = install_adventure_gateway_scope(
            dol, runtime_sec.index, gateway_pending_addr=gateway_pending_addr,
            enable_sdk0205_extras=True, capture_origin=True)


        # SDK 0.20.13 completion state-commit repair. The GOver
        # Congratulations callback still bridges active gateway campaigns back
        # into Adventure without clearing scope.  Unlike 0.20.12, Adventure
        # OnLoad no longer writes 0x68 early: retail would overwrite that with
        # its final 0x70 Back-to-CSS commit.  The gateway scope layer now hooks
        # that exact final gm_SetGameModeStateId call and substitutes 0x68 only
        # for active GOver re-entry.  The existing gm_801B4408 captured-origin
        # wrapper then returns to the launcher.
        from .adventure_gateway_scope import (
            ADVENTURE_ONLOAD_FINAL_STATE_CALL,
            ADVENTURE_ONLOAD_FINAL_STATE_EXPECTED,
            CAMPAIGN_COMPLETE_SET_PENDING_CALL,
            CAMPAIGN_COMPLETE_RETAIL,
            POST_STAFFROLL_RETURN_CALL,
            POST_STAFFROLL_RETURN_RETAIL,
        )
        completion_bridge = []
        staffroll_installed = dol.read_at_address(POST_STAFFROLL_RETURN_CALL, 4)
        if staffroll_installed == POST_STAFFROLL_RETURN_RETAIL:
            raise ValueError(
                f'SDK 0.20.13 requires guarded GOver completion bridge at '
                f'{POST_STAFFROLL_RETURN_CALL:#x}; found retail call')
        completion_bridge.append({
            'name': 'gover_congratulations_to_adventure_bridge',
            'site_address': POST_STAFFROLL_RETURN_CALL,
            'installed_guard_branch': staffroll_installed.hex(),
            'policy': 'active gateway completion requests Adventure; scope remains live until state 0x68 exits to captured origin',
        })

        coming_soon_installed = dol.read_at_address(CAMPAIGN_COMPLETE_SET_PENDING_CALL, 4)
        if coming_soon_installed == CAMPAIGN_COMPLETE_RETAIL:
            raise ValueError(
                f'SDK 0.20.13 requires captured-origin completion wrapper at '
                f'{CAMPAIGN_COMPLETE_SET_PENDING_CALL:#x}; found retail call')

        final_state_installed = dol.read_at_address(ADVENTURE_ONLOAD_FINAL_STATE_CALL, 4)
        if final_state_installed == ADVENTURE_ONLOAD_FINAL_STATE_EXPECTED:
            raise ValueError(
                f'SDK 0.20.13 requires final Adventure state-commit wrapper at '
                f'{ADVENTURE_ONLOAD_FINAL_STATE_CALL:#x}; found retail call')
        completion_bridge.append({
            'name': 'adventure_onload_final_state_commit',
            'site_address': ADVENTURE_ONLOAD_FINAL_STATE_CALL,
            'installed_guard_branch': final_state_installed.hex(),
            'policy': 'after retail OnLoad initialization, active GOver re-entry rewrites only final state 0x70 to 0x68',
        })

        adventure_gateway_scope['successful_completion_bridge'] = completion_bridge
        adventure_gateway_scope['completion_origin_policy'] = (
            'GOver/Staff Roll lifecycle remains owned by GOver through Congratulations; '
            'the guarded Congratulations exit requests Adventure for active gateway campaigns; '
            'Adventure OnLoad preserves scope and completes normal initialization; its final '
            'state commit substitutes 0x68 for retail 0x70 only on active GOver re-entry; '
            'gm_801B4408 then returns to the captured launcher origin. Quit and both-zero '
            'Game Over keep their existing origin paths.')
        adventure_gateway_scope['adventure_final_completion'] = {
            'site_address': CAMPAIGN_COMPLETE_SET_PENDING_CALL,
            'retail_call': CAMPAIGN_COMPLETE_RETAIL.hex(),
            'installed_guard_branch': coming_soon_installed.hex(),
            'gate': 'gateway campaign active + valid captured launcher origin',
            'active_behavior': 'state 0x68 replaces GM_MENU with captured origin, clears lifecycle bytes, then lets retail gm_SetNewGameModePending run',
            'inactive_behavior': 'exact retail GM_MENU destination',
        }

    # SDK 0.20.0: Slippi boot isolation.  HF29G remains the validated Adventure
    # behavior baseline, but ordinary VS/online modes must never touch campaign
    # state in the custom runtime area before deciding to take the retail path.
    # The old HF21 scene-transition trace hooks are also retired from the live
    # build; they were Team-Kirby diagnostics and are no longer production code.
    slippi_boot_hardening = None
    if adventure_gateway_scope:
        from .slippi_boot_hardening import install as install_slippi_boot_hardening
        slippi_boot_hardening = install_slippi_boot_hardening(
            dol, runtime_sec.index, gateway_scope=adventure_gateway_scope,
            legacy_trace_hooks=trace_hooks,
            allow_campaign_credits_cross_mode=True,
            known_mutable_addresses={
                'camera_owner': camera_owner_addr,
                'persistence_valid': persistence_valid_addr,
                'p1_stocks': p1_stocks_addr,
                'p2_stocks': p2_stocks_addr,
                'initial_stocks': initial_stocks_addr,
                'vs_p2_identity_valid': vs_p2_identity_valid_addr,
                'vs_p2_ckind': vs_p2_ckind_addr,
                'vs_p2_color': vs_p2_color_addr,
                'vs_p2_subcolor': vs_p2_subcolor_addr,
                'vs_p2_nametag': vs_p2_nametag_addr,
                'vs_p1_ckind': vs_p1_ckind_addr,
                'vs_p1_color': vs_p1_color_addr,
                'vs_p1_subcolor': vs_p1_subcolor_addr,
                'vs_p1_nametag': vs_p1_nametag_addr,
                'gateway_pending': gateway_pending_addr,
                'canonical_direct_valid': canonical_direct_valid_addr,
                'canonical_direct_local': canonical_direct_local_addr,
                'canonical_direct_remote': canonical_direct_remote_addr,
                'canonical_direct_trace': canonical_direct_trace_addr,
                'gateway_coop_active': adventure_gateway_scope['gateway_coop_active_address'],
                'gateway_origin': adventure_gateway_scope.get('gateway_origin_address') or 0,
                'team_kirby_terminal_guard': icies_teardown_guard_addr,
                'p1_form': p1_form_addr,
                'p2_form': p2_form_addr,
                'team_kirby_diag': icies_diag_addr,
                'team_kirby_wave_armed': icies_wave_armed_addr,
                'transition_last': transition_last_addr,
                'transition_flags_lo': transition_flags_lo_addr,
                'transition_flags_hi': transition_flags_hi_addr,
                'transition_state': transition_state_addr,
                'transition_prev_state': transition_prev_state_addr,
            })

    # SDK 0.20.1: Slippi Adventure-entry hardening. Runtime screenshots from
    # 0.20.0 proved the game reaches our presentation hook, but its tiny
    # 0x804DFB40 retail trampoline is clobbered under Slippi before execution.
    # Reuse a retired HF21 trace block for a complete self-contained retail
    # accessor and retarget only the two presentation calls.
    slippi_adventure_entry_hardening = None
    if slippi_boot_hardening:
        from .slippi_adventure_entry_hardening import install as install_slippi_adventure_entry_hardening
        slippi_adventure_entry_hardening = install_slippi_adventure_entry_hardening(
            dol, runtime_sec.index,
            presentation_wrapper_addr=presentation_wrapper_addr,
            old_trampoline_addr=presentation_trampoline_addr,
            wrapper_capacity=luigi_wrapper_addr-presentation_wrapper_addr,
            retired_trace_hooks=slippi_boot_hardening['retired_hf21_scene_trace_hooks'])

    # SDK 0.20.2: Slippi Adventure-entry trace + call-free leaf. 0.20.1
    # bypassed the original clobbered helper but still collapsed into low memory.
    # Remove helper call/return dependency entirely and stamp five breadcrumb
    # stages into the retired HF21 transition_last diagnostic byte.
    slippi_adventure_entry_leaf = None
    if slippi_adventure_entry_hardening:
        from .slippi_adventure_entry_leaf import install as install_slippi_adventure_entry_leaf
        slippi_adventure_entry_leaf = install_slippi_adventure_entry_leaf(
            dol, runtime_sec.index, presentation_wrapper_addr=presentation_wrapper_addr,
            trace_stage_addr=transition_last_addr,
            wrapper_capacity=luigi_wrapper_addr-presentation_wrapper_addr,
            origin_addr=(adventure_gateway_scope['gateway_origin_address']
                         if adventure_gateway_scope else None))

    # SDK 0.20.21C: presentation synchronization is integrated directly into
    # the existing active accessor leaf.  Do NOT add another wrapper at
    # gm_GetButtonsTriggered: that site is already owned by HF29G + SDK 0.20
    # mode-first dispatch, whose stubs tail-enter their target and are not normal
    # callable functions.  0.20.21/21B incorrectly composed another wrapper
    # there and made clean-ISO installation order-dependent.
    slippi_presentation_barrier = ({
        'integrated_into_leaf': True,
        'presentation_wrapper': presentation_wrapper_addr,
        'gateway_origin_address': adventure_gateway_scope['gateway_origin_address'],
        'policy': 'Direct-origin Start barrier lives in active presentation leaf; outer gateway/mode-first hook chain remains untouched',
    } if slippi_adventure_entry_leaf and adventure_gateway_scope else None)

    # SDK 0.20.21E: boot-safe low-code layout.
    #
    # 0.20.21D proved that placing a loader-backed DOL section at 0x817FF000
    # can black-screen before Melee reaches a savestate-capable point. Keep all
    # executable code in the proven 0x804F0C00..0x804F4C00 SDK block instead.
    # Five retired HF21 diagnostic trace pairs above were removed to reclaim the
    # required space. The top-of-MEM1 island remains runtime-only *data* and is
    # reserved lazily when the Direct bridge actually arms.
    slippi_high_code = None
    slippi_adventure_netplay_bridge = None
    slippi_coop_stage_page = None
    slippi_direct_gateway = None
    if enable_adventure_sss_gateway and adventure_gateway_scope:
        from .slippi_adventure_netplay_bridge import install as install_slippi_adventure_netplay_bridge
        slippi_adventure_netplay_bridge = install_slippi_adventure_netplay_bridge(
            dol, runtime_sec.index,
            gateway_pending_addr=gateway_pending_addr,
            gateway_active_addr=adventure_gateway_scope['gateway_coop_active_address'],
            gateway_return_pending_addr=adventure_gateway_scope['gateway_return_pending_address'],
            canonical_valid_addr=canonical_direct_valid_addr,
            canonical_local_addr=canonical_direct_local_addr,
            canonical_remote_addr=canonical_direct_remote_addr)

        from .slippi_coop_stage_page import install as install_slippi_coop_stage_page
        slippi_coop_stage_page = install_slippi_coop_stage_page(
            dol, runtime_sec.index,
            canonical_valid_addr=canonical_direct_valid_addr,
            canonical_local_addr=canonical_direct_local_addr,
            canonical_remote_addr=canonical_direct_remote_addr,
            canonical_trace_addr=canonical_direct_trace_addr,
            p1_ckind_addr=vs_p1_ckind_addr, p1_color_addr=vs_p1_color_addr,
            p1_subcolor_addr=vs_p1_subcolor_addr, p1_nametag_addr=vs_p1_nametag_addr,
            p2_ckind_addr=vs_p2_ckind_addr, p2_color_addr=vs_p2_color_addr,
            p2_subcolor_addr=vs_p2_subcolor_addr, p2_nametag_addr=vs_p2_nametag_addr,
            sss_visual_contract=sss_visual_contract)

        # 0.21.4 A5-only native-session A/B diagnostic. The carrier/bootstrap
        # code lives in verified retail text padding, so A6-B2 and the 16 KiB
        # 0.21.4 low-runtime architecture remain unchanged.
        from .a5_native_session_ab import install as install_a5_native_session_ab
        slippi_a5_native_session_ab = install_a5_native_session_ab(
            dol, bridge=slippi_adventure_netplay_bridge,
            gateway_pending_addr=gateway_pending_addr,
            p1_ckind_addr=vs_p1_ckind_addr, p1_color_addr=vs_p1_color_addr,
            p1_subcolor_addr=vs_p1_subcolor_addr, p1_nametag_addr=vs_p1_nametag_addr,
            p2_identity_valid_addr=vs_p2_identity_valid_addr,
            p2_ckind_addr=vs_p2_ckind_addr, p2_color_addr=vs_p2_color_addr,
            p2_subcolor_addr=vs_p2_subcolor_addr, p2_nametag_addr=vs_p2_nametag_addr,
            canonical_valid_addr=canonical_direct_valid_addr,
            canonical_local_addr=canonical_direct_local_addr,
            canonical_remote_addr=canonical_direct_remote_addr,
            canonical_players_addr=slippi_coop_stage_page['canonical_players_address'])

        from .slippi_direct_launch import install as install_slippi_direct_gateway
        slippi_direct_gateway = install_slippi_direct_gateway(
            dol, runtime_sec.index, gateway_pending_addr=gateway_pending_addr,
            p1_ckind_addr=vs_p1_ckind_addr, p1_color_addr=vs_p1_color_addr,
            p1_subcolor_addr=vs_p1_subcolor_addr, p1_nametag_addr=vs_p1_nametag_addr,
            p2_identity_valid_addr=vs_p2_identity_valid_addr,
            p2_ckind_addr=vs_p2_ckind_addr, p2_color_addr=vs_p2_color_addr,
            p2_subcolor_addr=vs_p2_subcolor_addr, p2_nametag_addr=vs_p2_nametag_addr,
            netplay_arm_addr=slippi_adventure_netplay_bridge['arm_stub'],
            early_exi_wrapper=slippi_adventure_netplay_bridge['early_exi_wrapper'],
            canonical_valid_addr=canonical_direct_valid_addr,
            canonical_local_addr=canonical_direct_local_addr,
            canonical_remote_addr=canonical_direct_remote_addr,
            canonical_players_addr=slippi_coop_stage_page['canonical_players_address'],
            standalone_stages=enable_standalone_stages)

    standalone_stages = None
    if enable_standalone_stages:
        if not slippi_direct_gateway:
            raise ValueError('Standalone stages require the Direct Adventure gateway')
        from .standalone_stage_runtime import install as install_standalone
        standalone_stages = install_standalone(dol, runtime_sec.index,
            marker_addr=slippi_direct_gateway['alt_mode_trace_address'],
            active_addr=adventure_gateway_scope['gateway_coop_active_address'],
            onload_addr=gateway_onload_wrapper_addr, onload_blob=gateway_onload_wrapper,
            output_dir=Path(output_path).parent,
            selector_state_addr=slippi_direct_gateway['state_address'],
            origin_addr=adventure_gateway_scope['gateway_origin_address'],
            return_pending_addr=adventure_gateway_scope['gateway_return_pending_address'],
            canonical_local_addr=canonical_direct_local_addr)

    if dol.read_at_address(luigi_wrapper_addr,len(luigi_wrapper)) != luigi_wrapper:
        raise ValueError('Composed runtime overwrote Mario/Luigi encounter setup')

    first_match_rollback = None
    if slippi_adventure_netplay_bridge:
        from .slippi_first_match_rollback import install as install_first_match_rollback
        first_match_rollback = install_first_match_rollback(
            dol, runtime_sec.index, slippi_adventure_netplay_bridge, slippi_direct_gateway)

    # Freeze ArenaLo only after every low-runtime append. ArenaHi is deliberately
    # untouched during boot; the netplay arm routine reserves the session island
    # immediately before relocation instead.
    slippi_memory_layout = install_arena_reservation(dol, runtime_sec.index)

    out=Path(output_path); dol.save_as(out)
    return {
        'format':'melee-character-sdk-0.20.21k10-canonical-direct-mapping',
        'target':'GALE01 1.02',
        'source_sha1':source_sha1,
        'output_sha1':hashlib.sha1(out.read_bytes()).hexdigest(),
        'output_size':out.stat().st_size,
        'icies_teardown_trace_hooks':([] if slippi_boot_hardening else trace_hooks),
        'retired_icies_teardown_trace_hooks':(trace_hooks if slippi_boot_hardening else []),
        'clear_screen_memory':clear_screen_memory,
        'clear_screen_background_omit':clear_screen_background_omit,
        'hf29c_results_headroom':hf29c_results_headroom,
        'team_kirby_pool_packing':team_kirby_pool_packing,
        'adventure_slist_pool_packing':team_kirby_pool_packing,
        'adventure_origin_return':adventure_origin_return,
        'adventure_gateway_scope':adventure_gateway_scope,
        'completion_retail_rollback':completion_retail_rollback,
        'slippi_boot_hardening':slippi_boot_hardening,
        'slippi_adventure_entry_hardening':slippi_adventure_entry_hardening,
        'slippi_adventure_entry_leaf':slippi_adventure_entry_leaf,
        'slippi_presentation_barrier':slippi_presentation_barrier,
        'slippi_coop_stage_page':slippi_coop_stage_page,
        'slippi_a5_native_session_ab':(slippi_a5_native_session_ab if enable_adventure_sss_gateway and adventure_gateway_scope else None),
        'slippi_direct_gateway':slippi_direct_gateway,
        'slippi_adventure_netplay_bridge':slippi_adventure_netplay_bridge,
        'sdk_version':'0.21.7',
        'slippi_first_match_rollback':first_match_rollback,
        'slippi_memory_layout':slippi_memory_layout,
        'slippi_high_code':slippi_high_code, 'standalone_stages':standalone_stages,
        'effect_memory_protection':effect_memory_protection,
        'clear_screen_failsafe':clear_screen_failsafe,
        'early_clear_failsafe':early_clear_failsafe,
        'team_kirby_force_clear':team_kirby_force_clear,
        'team_kirby_test_warp':team_kirby_test_warp,
        'team_kirby_fast_forward':team_kirby_fast_forward,
        'team_kirby_retail_warp':team_kirby_retail_warp,
        'framework':framework,
        'probe_section':sec,
        'probe_magic':'MSDKCP30',
        'gate':{'mechanism':'gm_GetCurrentGameMode backing byte','address':GM_CURRENT_MODE_ADDR,'required_mode':GM_ADVENTURE},
        'hooks':[
            asdict(ProbeHook('p2_setup',P2_SETUP_HOOK,P2_SETUP_EXPECTED.hex(),p2_addr,p2_branch.hex(),P2_SETUP_HOOK+4)),
            asdict(ProbeHook('adventure_spawn_multislot_gate',SPAWN_GATE_HOOK,SPAWN_GATE_EXPECTED.hex(),gate_addr,gate_branch.hex(),SPAWN_MULTIPLAYER_TARGET)),
            asdict(ProbeHook('singleplayer_p2_loader',SINGLEPLAYER_P2_LOADER_HOOK,SINGLEPLAYER_P2_LOADER_EXPECTED.hex(),loader_addr,loader_branch.hex(),SINGLEPLAYER_P2_LOADER_HOOK+4)),
            asdict(ProbeHook('control_route_respawn_anchor',RESPAWN_PLATFORM_HOOK,RESPAWN_PLATFORM_EXPECTED.hex(),respawn_addr,respawn_branch.hex(),RESPAWN_PLATFORM_HOOK+4)),
            asdict(ProbeHook('ffa_team_stock_outcome',FFA_P1_STOCK_HOOK,FFA_P1_STOCK_EXPECTED.hex(),stock_addr,ffa_stock_branch.hex(),FFA_P1_STOCK_HOOK+4)),
            asdict(ProbeHook('team_team_stock_outcome',TEAM_P1_STOCK_HOOK,TEAM_P1_STOCK_EXPECTED.hex(),stock_addr,team_stock_branch.hex(),TEAM_P1_STOCK_HOOK+4)),
            asdict(ProbeHook('control_ground_p1_accessor',GROUND_GET_P1_FIGHTER_HOOK,GROUND_GET_P1_FIGHTER_EXPECTED.hex(),owner_entity_addr,ground_owner_branch.hex(),None)),
            asdict(ProbeHook('control_camera_p1_lookup',CAMERA_P1_ENTITY_CALL_HOOK,CAMERA_P1_ENTITY_CALL_EXPECTED.hex(),owner_entity_addr,camera_owner_call.hex(),CAMERA_P1_ENTITY_CALL_HOOK+4)),
            asdict(ProbeHook('cross_chapter_stock_capture',ADVENTURE_PROGRESS_STOCK_HOOK,ADVENTURE_PROGRESS_STOCK_EXPECTED.hex(),progress_addr,progress_branch.hex(),ADVENTURE_PROGRESS_STOCK_HOOK+4)),
            asdict(ProbeHook('event_allocator_human_reservation',EVENT_ALLOCATOR_START_HOOK,EVENT_ALLOCATOR_START_EXPECTED.hex(),event_alloc_addr,event_alloc_branch.hex(),EVENT_ALLOCATOR_START_HOOK+4)),
            asdict(ProbeHook('adventure_hud_capacity',ADVENTURE_HUD_INIT_HOOK,ADVENTURE_HUD_INIT_EXPECTED.hex(),hud_addr,hud_branch.hex(),ADVENTURE_HUD_INIT_HOOK+4)),
            asdict(ProbeHook('dynamic_enemy_spawn_marker',DYNAMIC_ENEMY_SPAWN_HOOK,DYNAMIC_ENEMY_SPAWN_EXPECTED.hex(),dynamic_spawn_addr,dynamic_spawn_branch.hex(),DYNAMIC_ENEMY_SPAWN_HOOK+4)),
            *( [asdict(ProbeHook('adventure_slippi_spawn_normalizer_bypass',MULTISLOT_POST_COORD_HOOK,MULTISLOT_POST_COORD_EXPECTED.hex(),static_spawn_addr,static_spawn_branch.hex(),MULTISLOT_RETAIL_CONTINUE))] if enable_adventure_sss_gateway else [] ),
            *( [asdict(ProbeHook('rebirth_owner_preflight',REBIRTH_OWNER_PREFLIGHT_HOOK,REBIRTH_OWNER_PREFLIGHT_EXPECTED.hex(),rebirth_preflight_addr,rebirth_preflight_branch.hex(),REBIRTH_OWNER_PREFLIGHT_HOOK+4))] if enable_adventure_sss_gateway else [] ),
            {'name':'campaign_state_reset','site_address':css_stub_addr,'expected':original_css.hex(),'stub_address':reset_addr,'site_branch':css_reset_branch.hex(),'return_address':0x801B42EC,'via_framework_hook':'gm_801B42E8'},
        ] + [
            asdict(ProbeHook('wireframe_human_physics_modifier_guard',WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK,wireframe_expected.hex(),wire_wrapper_addr,wireframe_branch.hex(),None)),
            asdict(ProbeHook('adventure_presentation_p2_start_mirror',GM_GET_BUTTONS_TRIGGERED_HOOK,presentation_expected.hex(),presentation_wrapper_addr,presentation_branch.hex(),None)),
            asdict(ProbeHook('luigi_cpu_substitution',LUIGI_FIGHT_SETUP_HOOK,luigi_expected.hex(),luigi_wrapper_addr,luigi_branch.hex(),None)),
        ] + ([
            asdict(ProbeHook('falco_cpu_substitution',ADVENTURE_FALCO_FIGHT_SETUP_HOOK,falco_expected.hex(),falco_wrapper_addr,falco_branch.hex(),None)),
            asdict(ProbeHook('team_kirby_pre_game_enter',ADVENTURE_TEAMKIRBY_ENTER_HOOK,teamkirby_enter_expected.hex(),teamkirby_enter_wrapper_addr,teamkirby_enter_branch.hex(),None)),
            asdict(ProbeHook('team_kirby_non_giant_exit',ADVENTURE_TEAMKIRBY_EXIT_HOOK,teamkirby_expected.hex(),teamkirby_wrapper_addr,teamkirby_branch.hex(),None)),
        ] if enable_phase43_adventure_repairs else []) + ([
            asdict(ProbeHook('adventure_sss_gateway_exit',GM_VS_MELEE_EXIT_SSS,gateway_sss_expected.hex(),gateway_sss_wrapper_addr,gateway_sss_branch.hex(),None)),
        ] if enable_legacy_local_vs_gateway else []) + ([
            asdict(ProbeHook('adventure_gateway_onload',GM_MODE_ADVENTURE_ONLOAD,gateway_onload_expected.hex(),gateway_onload_wrapper_addr,gateway_onload_branch.hex(),None)),
        ] if enable_adventure_sss_gateway else []) + ([asdict(ProbeHook('either_human_ground_events',GROUND_EVENT_SCAN_HOOK,ground_event_expected.hex(),event_authority_addr,event_authority_branch.hex(),None))] if enable_either_human_events else []) + ([
            asdict(ProbeHook('dual_player_credits_input',STAFFROLL_PAD_INDEX_HOOK,STAFFROLL_PAD_INDEX_EXPECTED.hex(),credits_addr,credits_branch.hex(),None)),
            asdict(ProbeHook('credits_p2_cursor_lookup',STAFFROLL_CURSOR_LOOKUP_CALL,STAFFROLL_CURSOR_LOOKUP_EXPECTED.hex(),credits_lookup_addr,credits_lookup_branch.hex(),STAFFROLL_CURSOR_LOOKUP_CALL+4)),
            asdict(ProbeHook('credits_p2_shot_node5_lookup',STAFFROLL_SHOT_NODE5_LOOKUP_CALL,STAFFROLL_SHOT_NODE5_LOOKUP_EXPECTED.hex(),credits_shot5_addr,credits_shot5_branch.hex(),STAFFROLL_SHOT_NODE5_LOOKUP_CALL+4)),
            asdict(ProbeHook('credits_p2_shot_node8_lookup',STAFFROLL_SHOT_NODE8_LOOKUP_CALL,STAFFROLL_SHOT_NODE8_LOOKUP_EXPECTED.hex(),credits_shot8_addr,credits_shot8_branch.hex(),STAFFROLL_SHOT_NODE8_LOOKUP_CALL+4)),
            asdict(ProbeHook('credits_p2_local_pass_cut',STAFFROLL_LOCAL_PASS_END_HOOK,STAFFROLL_LOCAL_PASS_END_EXPECTED.hex(),credits_cut_addr,credits_cut_branch.hex(),None)),
            asdict(ProbeHook('credits_dual_lens_setup',STAFFROLL_SETUP_PROC_CALL,STAFFROLL_SETUP_PROC_EXPECTED.hex(),credits_setup_addr,credits_setup_branch.hex(),STAFFROLL_SETUP_PROC_CALL+4)),
        ] if enable_dual_credits else []) + ([asdict(ProbeHook('either_player_pause_mode_classification',DEFAULT_PAUSER_MODE_CALL_HOOK,DEFAULT_PAUSER_MODE_CALL_EXPECTED.hex(),pauser_addr,pauser_mode_call.hex(),DEFAULT_PAUSER_MODE_CALL_HOOK+4))] if enable_either_player_pause else []) + ([{'name':'one_player_cstick','site_address':ONE_PLAYER_CSTICK_HOOK,'expected':ONE_PLAYER_CSTICK_EXPECTED.hex(),'replacement':nop().hex(),'source':'20XXTE published GALE01 patch'}] if enable_one_player_cstick else []),
        'probe_contract':{
            'p1':'retail Adventure human seeded from finalized VS P1 identity when SSS gateway enabled', 'p2':'Adventure scene-safe baseline plus independent finalized VS P2 identity; human; controller port 2; second spawn index',
            'enemy_first_slot':2, 'normal_modes_affected':False,
            'friendly_fire':bool(friendly_fire),
            'one_player_cstick':bool(enable_one_player_cstick),
            'either_player_pause':bool(enable_either_player_pause),
            'scene_revive':bool(scene_revive),
            'developer_test_shortcuts':bool(enable_test_shortcuts),
            'test_unlock_all':bool(enable_unlock_all),
            'vs_p2_identity_bridge':bool(enable_vs_p2_identity_bridge),
            'vs_p2_identity_policy':({'source':'gmMainLib->modes.vs_melee.start.players[1]','source_offset_from_gmm_x0':hex(VS_MELEE_P2_INIT_OFFSET),'capture':'new Adventure CSS entry','fields':['ckind','color','sub_color','nametag'],'valid_when':'VS P2 slot_type == Human','fallback':'clone Adventure P1 identity','scene_persistence':'SDK runtime snapshot'} if enable_vs_p2_identity_bridge else None),
            'adventure_sss_gateway':({'enabled':True,'entry':'Slippi Direct custom stage page only','legacy_local_vs_gateway':bool(enable_legacy_local_vs_gateway),'retail_yoshis_island_64_preserved':not bool(enable_legacy_local_vs_gateway),'requires_humans':[0,1],'major_mode_target':GM_ADVENTURE,'adventure_state_target':0,'retail_adventure_css_bypassed':True,'cpu_level':int(adventure_cpu_level),'stocks':int(adventure_stocks),'save_data_written':False} if enable_adventure_sss_gateway else None),
            'phase43_adventure_repairs':({'falco':{'retail_bug':'players[1] hard-coded','id_namespace':'CharacterKind','character_kind_ids':{'Fox':hex(CKIND_FOX),'Falco':hex(CKIND_FALCO)},'policy':'search CPU slots 2/3 for Fox and replace only that CPU with Falco','human_slots_untouched':[0,1]},'team_kirby':{'runtime_bug':'greater-than-30-second clear stalled at GAME','policy':'pre-arm retail pending state 0x28 before gm_801B4C5C completion when successful frame_count/60 > 30; retail then runs unchanged','giant_path_untouched':True},'clone_subshade':{'policy':'P2 sub_color normalized to 0 unless P1/P2 share both ckind and costume color; removed erroneous scene-time write of 1 to PlayerInitData+0x07'},'icies_team_kirby':{'evidence':'HF20 frozen savestate reached C1/lifecycle 02 and never D0..D5, while the user could hear score/results audio behind the frozen GAME! framebuffer. This moves the active investigation downstream of Team-Kirby completion/bonus ownership into the scene transition.','policy':'HF20 terminal detector and narrow fn_80039618 guard are retained unchanged. HF21 adds diagnostic-only scene tracing after C1; no new fighter/event/GObj mutation. KTDG marker; E0..E9 record exit request, scene-loop return, VS OnExit, next-scene init, Results OnEnter, and next-scene loop entry, with durable evidence bits and state snapshots'},'zelda_sheik':{'policy':'track active FighterKind per human and restore corresponding CharacterKind next scene'},'credits':{'policy':'independent Staff Roll shooters: retain P1 retail cursor/full proc; clone retail node-5 shooter subtree for P2; derive P2 cursor node 7 from the clone; redirect both unconditional node-5 fire animation and node-8 hit feedback during the P2 pass; stop the extra P2 traversal at retail timeline frame 4741 before terminal object teardown; leave Staff Roll OnExit exact retail because the reparented clone belongs to the scene graph; run exactly one full P1 retail pass','shared_timeline_passes_per_frame':1,'gateway_campaign_eligible_when_p2_eliminated':True}} if enable_phase43_adventure_repairs else None),
            'unlock_all_policy':({'test_only':True,'save_bits_written':False,'characters_report_unlocked':True,'stages_report_unlocked':True,'patched_query_functions':[hex(x['address']) for x in unlock_query_patches]} if enable_unlock_all else None),
            'test_shortcuts':({'test_only':True,'either_controller':True,'adventure_only':True,'chords':{'L+DPadDown':'request retail match termination with 1P stage-end outcome','L+DPadLeft':'warp the next Adventure scene to Bowser fight state 0x59 after normal current-state exit bookkeeping; no-op while already in Bowser; Bowser fight/exit remain retail','L+DPadRight':'force P2 normal KO by moving the live entity below the blast zone','L+DPadUp':'restore current/saved stock counters; eliminated human returns next scene with scene-revive'},'not_for_release':True} if enable_test_shortcuts else None),
            'dual_player_credits':bool(enable_dual_credits),
            'dual_player_credits_lens':({'mode':'independent_cloned_retail_shooter','p1_pad':0,'p2_pad':1,'p2_assembly_source':'clone retail node 5 subtree via HSD_JObjLoadJoint','p2_cursor_source':'clone node5 child(node6)->next(node7)','p2_shot_lookup_sites':[hex(STAFFROLL_SHOT_NODE5_LOOKUP_CALL),hex(STAFFROLL_SHOT_NODE8_LOOKUP_CALL)],'p2_local_pass_cut':hex(STAFFROLL_LOCAL_PASS_END_HOOK),'terminal_counter_address':hex(STAFFROLL_TIMELINE_COUNTER_ADDR),'terminal_frame':STAFFROLL_INTERACTIVE_END_FRAME,'terminal_diag_address':hex(credits_terminal_diag_addr),'scene_exit_cleanup':'retail scene graph owns reparented clone; Staff Roll OnExit left exact retail','shared_timeline_passes_per_frame':1,'fallback':'exact retail Staff Roll when campaign is inactive or P2 shooter clone is unavailable'} if enable_dual_credits else None),
            'transition_input_authority':{'shared_accessor':STAFFROLL_PAD_INDEX_HOOK,'campaign_state_gate':persistence_valid_addr,'p1_default':True,'p2_independent_pass':bool(enable_dual_credits),'p2_activity_selects_pad_1':False,'pad_policy':'P1 pass uses pad 0; P2 local lens pass uses pad 1; no merged axes/buttons'},
            'either_human_events':bool(enable_either_human_events),
            'event_authority':{'policy':'either instantiated campaign human','control_owner_unchanged':True,'scanner_address':GROUND_EVENT_SCAN_HOOK,'trigger_request_byte':STAGE_EVENT_FLAGS_ADDR,'result_addresses':[STAGE_EVENT_RESULT_A_ADDR,STAGE_EVENT_RESULT_B_ADDR],'simultaneous_hit_preference':'P2 result when both hit same channel'},
            'hud_capacity':{'adventure_capacity':6,'empty_slots_still_filtered_by_retail':True,'cpu_slots_2_plus_supported':True},
            'live_team_elimination':'gateway co-op game over only when both humans are zero; then return directly to captured launcher origin without retail Continue',
            'campaign_origin_contract':{'captured':'initial gateway Adventure OnLoad from routing.prev_mode','post_staffroll_reentry':'if gateway_pending is consumed but campaign active is still 1, preserve active + captured origin across Adventure OnLoad','quit':'captured origin through Adventure exit','both_zero_loss':'captured origin through Adventure Game Over decision','successful_completion':'Staff Roll/GOver remains retail; GOver Congratulations bridges to Adventure; final Adventure OnLoad state commit rewrites retail 0x70 to 0x68; final Adventure exit substitutes captured origin for GM_MENU','challenger_completion':'guarded Adventure completion remains fallback after Challenger Approach','runtime_validated_origin':'VS','direct_candidate_origin':'Slippi online major 0x08; entry/return bridge implemented, peer-to-peer rollback/session behavior pending runtime validation'},
            'static_cpu_spawn_remap':{'policy':'0.20.9 preserves exact retail 0x8016E48C fallback and never anchors/remaps static CPUs. Adventure intercepts 0x8016E50C, executes the displaced retail coordinate commit, then locally executes retail 0x8016E510 and resumes at 0x8016E514; non-Adventure returns to 0x8016E510 so Slippi runtime spawn normalization remains active.'},
            'coop_adventure_slist_headroom':{'policy':'HF29D four-node SList refill packing is retained but no longer restricted to Team-Kirby state 0x23; gateway scope keeps it active only for established two-human Co-op Adventure, allowing high-object-count Wire Frames to use the same allocator-efficient retail pool semantics','retail_1p_untouched':True},
            'survivor_rebirth_preflight':{'policy':'before retail route/camera rebirth calculation, living partner owns Control; eliminated/absent partner causes respawning survivor to regain Control; late coordinate guard remains as second defense'},
            'gateway_coop_scope':({'active_address':adventure_gateway_scope['gateway_coop_active_address'],'capture':'gateway_pending at Adventure OnLoad before pending is cleared','retail_1p':'all behavior-changing co-op hooks dispatch to exact retail path; P2 is not injected','game_over':'both-zero active co-op returns to retail routing.prev_mode; inactive retail Adventure enters genuine Continue'} if adventure_gateway_scope else None),
            'slippi_boot_isolation':({'mode_first_guards':len(slippi_boot_hardening['mode_first_guards']),'retired_hf21_scene_trace_hooks':len(slippi_boot_hardening['retired_hf21_scene_trace_hooks']),'policy':slippi_boot_hardening['boot_isolation_policy'],'rollback_status':slippi_boot_hardening['rollback_status']} if slippi_boot_hardening else None),
            'slippi_adventure_entry_hardening':slippi_adventure_entry_hardening,
            'slippi_adventure_entry_leaf':slippi_adventure_entry_leaf,
        'slippi_presentation_barrier':slippi_presentation_barrier,
        'slippi_coop_stage_page':slippi_coop_stage_page,
        'slippi_direct_gateway':slippi_direct_gateway,
            'camera_control':{'initial_owner':0,'transfer_on_rebirth':True,'zero_stock_transfer_via_outcome_check':True,'owner_state_address':camera_owner_addr,'game_camera_slot_address':GAME_CAMERA_OWNER_SLOT,'ground_p1_accessor_redirected':True,'standard_1p_camera_p1_lookup_redirected':True},
            'cross_chapter_stock_state':{'valid_address':persistence_valid_addr,'p1_stocks_address':p1_stocks_addr,'p2_stocks_address':p2_stocks_addr,'initial_stocks_address':initial_stocks_addr,'retail_team_representative_written':True,'exact_playerinit_restore':True,'zero_stock_slot_policy':'revive_to_initial' if scene_revive else 'Gm_PKind_NA','control_persists_across_encounters':True,'new_campaign_reset_via_adventure_css':True},
            'dynamic_event_enemy_slots':{'human_slots_reserved':[0,1],'first_enemy_slot':2,'spawn_marker_compensation':-1,'adventure_only':True},
            'wireframe_human_physics_modifier_guard':{'source_getter':'Player_GetFlagsAEBit0','source_address':WIRE_FRAME_PHYSICS_FLAG_GETTER_HOOK,'state_id':WIRE_FRAME_FIGHT_STATE,'human_slots_masked':[0,1],'cpu_slots_retail':'2+','effect_prevented':'retail low-gravity/weight modifier on co-op humans','retail_for_all_other_states_slots':True,'runtime_status':'existing HF14 behavior retained; intermittent state-0x51 freeze remains under diagnosis'},
            'presentation_p2_start':{'states':sorted(ADVENTURE_PRESENTATION_STATES),'policy':'P2 START edge ORed into retail pad-0 trigger result only','score_results_untouched':True,'controller_identity_unchanged':True,'runtime_status':'dolphin_confirmed_luigi_cutscene'},
            'luigi_event':{'previous_state':ADVENTURE_LUIGI_CUTSCENE,'search_cpu_slots':[2,3],'human_slots_never_replaced':[0,1],'target':'actual Mario CPU -> Luigi','runtime_status':'dolphin_confirmed'},
            'progression_team_logic_complete':'cross_encounter_elimination_policy_v2_pending_dolphin_validation', 'route_recovery_complete':'persistent_control_owner_anchor_within_encounter', 'hud_fixes_complete':False,
        },
        'unlock_query_patches':unlock_query_patches,
        'scope':'Phase 43 Adventure integration on the Phase 42 direct SSS Adventure gateway on Phase 40 test infrastructure on Phase 39 Hotfix 14: Hotfix13 BUILD_FIX1 runtime baseline plus a source-grounded Wire Frames physics correction. During Adventure state 0x51, Player_GetFlagsAEBit0 is masked only for reserved human slots 0/1 so retail low-gravity/weight modifiers do not alter co-op humans; CPU/event slots 2+ and all other states preserve retail behavior. Dolphin-confirmed Luigi CPU substitution, P2 presentation START, and Adventure pause behavior remain unchanged.',
    }
