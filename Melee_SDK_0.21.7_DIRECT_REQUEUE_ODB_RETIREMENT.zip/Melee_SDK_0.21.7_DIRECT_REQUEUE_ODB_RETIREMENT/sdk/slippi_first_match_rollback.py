"""Prime the host's cached rollback range before the first Online match.

SlippiSavestate caches processedLocs until the emulator loads another ISO.
Installing the EXI wrapper only when an SDK selection arms is too late after
an ordinary Direct match has already constructed that cache. Install the same
phase-aware wrapper at Online scene entry, before native InitOnlinePlay/B0.
Only the exact supported native veneer is replaced; foreign code is untouched.
"""
from .early_clear_failsafe import Asm
from .ppc import blr, cmpw, cmpwi, decode_branch, encode_branch, lbz, lwz, mflr, stw
from . import slippi_adventure_netplay_bridge as nb

SITE = 0x801A4014

# Slippi 3.6.4 match-status HUD helper observed in the Pokemon Stadium crash.
# The function formats the "Desync Risk" label through HSD_SisLib.  Adventure
# can keep the native Direct session alive after the normal VS text object has
# been torn down, leaving HSD_Text::alloc_data (+0x64) null.  Calling the
# formatter in that state aliases low MEM1 and turns the disc header into a
# bogus allocation size.  Patch only the exact known helper signature.
SLIPPI_DESYNC_TEXT_HELPER = 0x806666C8
SLIPPI_DESYNC_TEXT_CONTINUE = SLIPPI_DESYNC_TEXT_HELPER + 4
SLIPPI_DESYNC_TEXT_SIGNATURE = (
    (0x00, 0x7C0802A6),  # mflr r0
    (0x30, 0x3D80803A),  # lis r12,0x803a
    (0x34, 0x618C6B98),  # ori r12,r12,0x6b98 (HSD_SisLib_803A6B98)
)
HSD_TEXT_ALLOC_DATA_OFFSET = 0x64


def desync_text_guard(base):
    """Skip only the invalid Slippi HUD draw; valid text follows retail."""
    a = Asm(base)
    a.emit(cmpwi(3, 0, crf=7)); a.branch('skip', 12, 30)
    a.emit(lwz(12, HSD_TEXT_ALLOC_DATA_OFFSET, 3), cmpwi(12, 0, crf=7))
    a.branch('skip', 12, 30)
    # Re-execute the displaced helper prologue instruction and tail-enter +4.
    a.emit(mflr(0))
    a.emit(encode_branch(base + len(a.data), SLIPPI_DESYNC_TEXT_CONTINUE))
    a.label('skip')
    a.emit(blr())
    return a.finish()


def wrapper(base, retail, exi_wrapper, desync_guard=None):
    a = Asm(base)
    a.constant(12, nb.GM_SCENE_WORD_ADDR)
    a.emit(lbz(11, 0, 12), cmpwi(11, nb.GM_ONLINE_MAJOR, crf=7))
    a.branch('retail', 4, 30)
    a.constant(12, nb.SLIPPI_EXI_VENEER)
    a.emit(lwz(11, 0, 12))
    a.constant(10, int.from_bytes(nb.SLIPPI_EXI_VENEER_EXPECTED, 'big'))
    a.emit(cmpw(11, 10, crf=7)); a.branch('retail', 4, 30)
    a.constant(11, int.from_bytes(encode_branch(nb.SLIPPI_EXI_VENEER, exi_wrapper), 'big'))
    a.emit(stw(11, 0, 12), nb._dcbst(0, 12), nb._sync(), nb._icbi(0, 12), nb._isync())

    # 0.21.6: Adventure keeps the native Slippi session but not the VS HUD text
    # lifetime.  Install a null alloc_data guard only when this is the exact
    # Slippi helper that called HSD_SisLib_803A6B98 in the captured crash.
    if desync_guard is not None:
        a.constant(12, SLIPPI_DESYNC_TEXT_HELPER)
        for off, expected in SLIPPI_DESYNC_TEXT_SIGNATURE:
            a.emit(lwz(11, off, 12))
            a.constant(10, expected)
            a.emit(cmpw(11, 10, crf=7)); a.branch('retail', 4, 30)
        a.constant(11, int.from_bytes(encode_branch(
            SLIPPI_DESYNC_TEXT_HELPER, desync_guard), 'big'))
        a.emit(stw(11, 0, 12), nb._dcbst(0, 12), nb._sync(),
               nb._icbi(0, 12), nb._isync())

    a.label('retail')
    a.emit(encode_branch(base + len(a.data), retail))
    return a.finish()


def install(dol, runtime_index, bridge, gateway):
    old = dol.read_at_address(SITE, 4)
    target = decode_branch(SITE, old)['target']
    if target != gateway['wrapper']:
        raise ValueError('First-match rollback hook must chain the SDK Direct gateway')
    section = next(s for s in dol.sections if s.kind == 'data' and s.index == runtime_index)
    base = (section.end_address + 31) & ~31

    # Keep the externally hooked first-match wrapper at the section base for
    # continuity.  Its size is independent of the guard target, so a sizing
    # pass gives us the exact address of the appended guard stub.
    sizing = wrapper(base, target, bridge['exi_wrapper'], base)
    guard_base = base + len(sizing)
    guard_base = (guard_base + 3) & ~3
    code = wrapper(base, target, bridge['exi_wrapper'], guard_base)
    if len(code) != len(sizing):
        raise ValueError('First-match rollback wrapper sizing changed unexpectedly')
    guard = desync_text_guard(guard_base)
    payload = code + bytes(guard_base - (base + len(code))) + guard
    payload += bytes((-len(payload)) % 32)
    if base + len(payload) > nb.SDK_RUNTIME_BASE + nb.SDK_RUNTIME_SIZE:
        raise ValueError('First-match rollback hook exceeds the SDK runtime reservation')
    added = dol.append_to_data_section(runtime_index, payload)
    assert added['address'] == base
    dol.patch_at_address(SITE, encode_branch(SITE, base), expected=old)
    return dict(site=SITE, wrapper=base, size=len(code), chained_wrapper=target,
                exi_wrapper=bridge['exi_wrapper'],
                heap_start=nb.FULL_ROLLBACK_HEAP_START,
                heap_end=nb.FULL_ROLLBACK_HEAP_END,
                desync_text_guard={
                    'helper': SLIPPI_DESYNC_TEXT_HELPER,
                    'guard': guard_base,
                    'size': len(guard),
                    'alloc_data_offset': HSD_TEXT_ALLOC_DATA_OFFSET,
                    'signature': [[off, word] for off, word in SLIPPI_DESYNC_TEXT_SIGNATURE],
                    'policy': 'Exact Slippi helper signature only; skip HUD draw only when text or alloc_data is null',
                },
                policy='Install frame-one EXI priming on first Online scene entry; phase OFF retains native session behavior',
                live_two_peer_validated=False)
