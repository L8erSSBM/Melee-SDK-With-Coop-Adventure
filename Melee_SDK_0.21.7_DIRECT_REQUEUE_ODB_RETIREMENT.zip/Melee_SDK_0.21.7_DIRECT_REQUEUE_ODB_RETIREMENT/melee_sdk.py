# Historical regression compatibility literal: 0.20.18 — Slippi Adventure Netplay Bridge
from __future__ import annotations

import json
import sys
import threading
import tempfile
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, simpledialog, ttk

from sdk.melee_dat import FighterDAT, CommonFighterDAT, COMMON_ATTRS, GLOBAL_FIGHTER_ATTRS, analyze_figatree_archive
from sdk.stage import StageDAT, STAGE_CATALOG
from sdk.character_schemas import CHARACTER_ATTR_SCHEMAS
from sdk.workspace import MeleeProject, MANIFEST_NAME
from sdk.gui_iso_build import build_project_iso, validate_options
from sdk.gamecube_iso import (GALE01_102_SHA1, verify_melee_102, fresh_rebuild, quick_update, export_xdelta_package)
from sdk.ui_metadata import pretty_name, category_for_attr, decimal_text, slider_spec, editor_mode, move_group, move_friendly_name, GLOBAL_STATE_FAMILIES, COMMON_ATTR_GROUP_ORDER
from sdk.runtime_authoring import install_authored_stage_runtime, install_fighter_prototype_runtime
from sdk.package_import import inspect_mod_package, import_stage_package, import_fighter_package
from sdk.stage_assets import StageAssetEditor
from sdk.stage_builder_catalog import stage_builder_report, ASSET_CLASSES
from sdk.stage_architecture import ARCHITECTURE_TYPE_LABELS, ASSET_LIBRARY_TYPE_LABELS, TOURNAMENT_REFERENCE_FILES, MOTION_PATH_PRESETS
from sdk.stage_preview import render_stage_draft_png
from sdk.stage_primitives import (PRIMITIVES, PRIMITIVE_BY_KEY, compatible_joint_indices,
                                  suggested_joint_index, add_primitive, add_library_collision_line)
from sdk.dol_patch import DOLImage, SymbolMap
from sdk.game_modes import OnePlayerModeEditor, CustomModeRecipe, ModePlayer
from sdk.adventure_coop import CoopAdventureCampaign, write_campaign_bundle
from sdk.adventure_runtime import build_route_partner_atlas, preflight_runtime_dol, write_runtime_prep_bundle, runtime_touchpoint_report
from sdk.event_match import EventMatchArchive, PKIND_NAMES, PKIND_HUMAN, PKIND_CPU, CHKIND_NONE
from sdk.project_health import audit_sdk
from sdk.one_player_resources import inspect_one_player_resources, import_one_player_resources, adventure_resource_audit
from sdk.stage_select_pages import (build_project_page_set, load_project_page_set, save_project_page_set, inspect_sss_menu, runtime_plan as stage_page_runtime_plan, preflight_sss_dol, visual_manifest as stage_page_visual_manifest, write_hub_bundle, StagePageEntry, MAX_VISIBLE_SLOTS, RETAIL_SLOT_SKINS)

APP_TITLE = 'Melee SDK — 0.21.7 — Open Testing ISO Builder'

HITBOX_EDIT_FIELDS = [
    ('damage', 'Damage', int, 0, 1023),
    ('angle', 'Angle', int, 0, 511),
    ('knockback_growth', 'KBG', int, 0, 511),
    ('base_knockback', 'BKB', int, 0, 511),
    ('weight_set_knockback', 'Weight-set KB', int, 0, 511),
    ('size', 'Size', float, 0, 30),
    ('offset_x', 'Offset X', float, -30, 30),
    ('offset_y', 'Offset Y', float, -30, 30),
    ('offset_z', 'Offset Z', float, -30, 30),
    ('bone', 'Bone', int, 0, 255),
    ('hit_group', 'Hit group', int, 0, 7),
    ('element', 'Element', int, 0, 31),
    ('shield_damage', 'Shield damage', int, -128, 127),
    ('hit_sfx_severity', 'SFX severity', int, 0, 7),
    ('hit_sfx_kind', 'SFX kind', int, 0, 31),
]
BOOL_HITBOX_FIELDS = [
    ('hit_grounded', 'Hits grounded'),
    ('hit_aerial', 'Hits aerial'),
    ('clank', 'Clank'),
    ('rebound', 'Rebound'),
]

PLAYABLE_ORDER = [
    'Mario','Drmario','Luigi','Koopa','Peach','Yoshi','Donkey','Captain','Ganon',
    'Falco','Fox','Ness','Popo','Nana','Kirby','Samus','Zelda','Seak','Link','Clink',
    'Pichu','Pikachu','Purin','Mewtwo','Gamewatch','Mars','Emblem'
]
DISPLAY_NAMES = {
    'Drmario':'Dr. Mario','Koopa':'Bowser','Captain':'Captain Falcon','Ganon':'Ganondorf',
    'Popo':'Ice Climbers (Popo)','Nana':'Ice Climbers (Nana)','Seak':'Sheik','Clink':'Young Link',
    'Purin':'Jigglypuff','Gamewatch':'Mr. Game & Watch','Mars':'Marth','Emblem':'Roy',
    'Crazyhand':'Crazy Hand','Masterhand':'Master Hand','Gkoopa':'Giga Bowser'
}
SPECIAL_SECTION_ORDER = ['Neutral Special','Side Special','Up Special','Down Special','Character mechanics / misc']

def display_fighter_name(name: str) -> str:
    return DISPLAY_NAMES.get(name, name)

def special_section_for_field(name: str) -> str:
    n=name.lower()
    if n.startswith(('blaster_', 'specialn_')): return 'Neutral Special'
    if n.startswith(('illusion_', 'specials_')): return 'Side Special'
    if n.startswith(('firefox_', 'specialhi_')): return 'Up Special'
    if n.startswith(('reflector_', 'speciallw_')): return 'Down Special'
    return 'Character mechanics / misc'

class CollapsibleSection(ttk.Frame):
    def __init__(self, parent, title: str, subtitle: str = '', expanded: bool = False):
        super().__init__(parent)
        self.expanded = tk.BooleanVar(value=expanded)
        self.header = ttk.Frame(self)
        self.header.pack(fill='x')
        self.toggle = ttk.Button(self.header, width=3, command=self._toggle)
        self.toggle.pack(side='left', padx=(0,5))
        ttk.Label(self.header, text=title, font=('TkDefaultFont', 10, 'bold')).pack(side='left')
        if subtitle:
            ttk.Label(self.header, text=subtitle, foreground='#666666').pack(side='left', padx=(8,0))
        self.body = ttk.Frame(self, padding=(28,5,4,8))
        self._sync()
    def _toggle(self):
        self.expanded.set(not self.expanded.get()); self._sync()
    def _sync(self):
        self.toggle.configure(text='−' if self.expanded.get() else '+')
        if self.expanded.get():
            self.body.pack(fill='x', expand=True)
        else:
            self.body.pack_forget()


class NumericRow:
    """Base-10 field editor with a control chosen from validated UI semantics.

    Slider: only for fields with a useful, understood numeric range.
    Number: direct base-10 entry for numeric fields where a slider could mislead.
    Toggle: reserved for true boolean/on-off fields.
    """
    def __init__(self, parent, row, name, offset, typ, value, on_apply=None, show_offset=False, column_offset=0):
        self.name = name
        self.typ = typ
        self.mode = editor_mode(name, typ)
        self.updating = False
        self.lo = self.hi = self.step = None
        self.scale = None

        label = pretty_name(name)
        ttk.Label(parent, text=label).grid(row=row, column=column_offset, sticky='w', padx=(4,10), pady=3)
        self.offset_label = ttk.Label(parent, text=f'0x{offset:03X}', foreground='#666666')
        if show_offset:
            self.offset_label.grid(row=row, column=column_offset+1, sticky='e', padx=4)

        if self.mode == 'toggle':
            self.var = tk.BooleanVar(value=bool(value))
            self.entry = ttk.Checkbutton(parent, variable=self.var, text='Enabled')
            self.entry.grid(row=row, column=column_offset+2, sticky='w', padx=4)
            ttk.Label(parent, text='On / Off state', foreground='#666666').grid(row=row, column=column_offset+3, sticky='w', padx=6)
        else:
            self.var = tk.StringVar(value=decimal_text(value, typ))
            self.entry = ttk.Entry(parent, textvariable=self.var, width=13)
            self.entry.grid(row=row, column=column_offset+2, sticky='w', padx=4)

            if self.mode == 'slider':
                self.slider_var = tk.DoubleVar(value=float(value))
                lo, hi, step = slider_spec(name, float(value), typ)
                self.lo, self.hi, self.step = lo, hi, step
                self.scale = ttk.Scale(parent, from_=lo, to=hi, variable=self.slider_var, length=190, command=self._slider_changed)
                self.scale.grid(row=row, column=column_offset+3, sticky='ew', padx=6)
                self.entry.bind('<FocusOut>', self._entry_to_slider)
            else:
                ttk.Label(parent, text='Direct numeric value', foreground='#666666').grid(row=row, column=column_offset+3, sticky='w', padx=6)

            # Values are committed at section/group level. Pressing Enter only
            # synchronizes the convenience slider; it never silently writes the DAT.
            self.entry.bind('<Return>', self._entry_to_slider)

        self.apply_btn = None
        if on_apply is not None:
            self.apply_btn = ttk.Button(parent, text='Apply', width=7, command=on_apply)
            self.apply_btn.grid(row=row, column=column_offset+4, padx=(4,8))

    def _slider_changed(self, _=None):
        if self.mode != 'slider' or self.updating:
            return
        v = self.slider_var.get()
        if self.typ == 'int':
            v = round(v)
        elif self.step:
            v = round(v / self.step) * self.step
        self.updating = True
        self.var.set(decimal_text(v, self.typ))
        self.updating = False

    def _entry_to_slider(self, _=None):
        if self.mode != 'slider':
            return
        try:
            v = float(self.var.get())
        except ValueError:
            return
        # Slider is only an aid. Typed values outside its range remain valid.
        self.slider_var.set(min(self.hi, max(self.lo, v)))

    def set_value(self, value):
        if self.mode == 'toggle':
            self.var.set(bool(value))
        else:
            self.var.set(decimal_text(value, self.typ))
            self._entry_to_slider()

    def parsed_value(self):
        """Return the current UI value using the field's real storage type."""
        raw = self.var.get()
        if self.typ == 'bool':
            return bool(raw)
        text = str(raw).strip()
        if self.typ == 'float':
            return float(text)
        return int(text, 10)


class MeleeSDK(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry('1380x880')
        self.minsize(1080, 720)
        self.fighter: FighterDAT | None = None
        self.global_common: CommonFighterDAT | None = None
        self.project: MeleeProject | None = None
        self.current_move = None
        self.current_hitbox_event = None
        self.current_timer_event = None
        self.move_undo_stack = []
        self.move_redo_stack = []
        self.aj_bytes: bytes | None = None
        self.aj_dirty = False
        self.dirty = False
        self.global_dirty = False
        self.show_offsets = tk.BooleanVar(value=False)
        self.attr_rows: dict[str, NumericRow] = {}
        self.special_rows: dict[str, NumericRow] = {}
        self.global_rows: dict[str, NumericRow] = {}
        self.runtime_state_vars: dict[str, tk.BooleanVar] = {}
        self.hit_vars: dict[str, tk.StringVar] = {}
        self.hit_bool_vars: dict[str, tk.BooleanVar] = {}
        self.hitbox_clipboard = None
        self.script_clipboard = None
        self.stage: StageDAT | None = None
        self.stage_dirty = False
        self.stage_vertex_index: int | None = None
        self._apply_modern_theme()
        self._build_ui()

    def _apply_modern_theme(self):
        """Modern dark visual foundation shared by the SDK."""
        self.configure(background='#0f1720')
        style = ttk.Style(self)
        try:
            style.theme_use('clam')
        except tk.TclError:
            pass
        bg='#0f1720'; panel='#16212c'; panel2='#1d2a36'; fg='#e8edf2'; muted='#9aa8b5'
        accent='#2d7dd2'; border='#344454'; select='#245f9e'
        style.configure('.', background=bg, foreground=fg, fieldbackground=panel,
                        bordercolor=border, lightcolor=border, darkcolor=border,
                        troughcolor=panel2, focuscolor=accent)
        style.configure('TFrame', background=bg)
        style.configure('Panel.TFrame', background=panel)
        style.configure('Card.TFrame', background=panel2, relief='solid', borderwidth=1)
        style.configure('TLabel', background=bg, foreground=fg)
        style.configure('Muted.TLabel', background=bg, foreground=muted)
        style.configure('Title.TLabel', background=bg, foreground='#ffffff', font=('TkDefaultFont',13,'bold'))
        style.configure('Section.TLabel', background=bg, foreground='#ffffff', font=('TkDefaultFont',10,'bold'))
        style.configure('TButton', background=panel2, foreground=fg, borderwidth=1, padding=(8,5))
        style.map('TButton', background=[('active','#263746'),('pressed','#1b2834')], foreground=[('disabled','#65727e')])
        style.configure('Accent.TButton', background=accent, foreground='#ffffff', borderwidth=1, padding=(10,6))
        style.map('Accent.TButton', background=[('active','#388fe5'),('pressed','#2368ad')])
        style.configure('TEntry', fieldbackground='#101820', foreground=fg, insertcolor=fg, bordercolor=border)
        style.configure('TCombobox', fieldbackground='#101820', background=panel2, foreground=fg, arrowcolor=fg)
        style.map('TCombobox', fieldbackground=[('readonly','#101820')], foreground=[('readonly',fg)])
        style.configure('TCheckbutton', background=bg, foreground=fg)
        style.map('TCheckbutton', background=[('active',bg)])
        style.configure('TLabelframe', background=bg, foreground=fg, bordercolor=border)
        style.configure('TLabelframe.Label', background=bg, foreground='#ffffff', font=('TkDefaultFont',9,'bold'))
        style.configure('TNotebook', background=bg, borderwidth=0)
        style.configure('TNotebook.Tab', background=panel2, foreground=muted, padding=(12,7), borderwidth=0)
        style.map('TNotebook.Tab', background=[('selected',select),('active','#263746')], foreground=[('selected','#ffffff'),('active','#ffffff')])
        style.configure('Treeview', background='#111b24', fieldbackground='#111b24', foreground=fg, bordercolor=border, rowheight=24)
        style.configure('Treeview.Heading', background=panel2, foreground='#ffffff', relief='flat')
        style.map('Treeview', background=[('selected',select)], foreground=[('selected','#ffffff')])
        style.map('Treeview.Heading', background=[('active','#263746')])
        style.configure('TPanedwindow', background=bg)
        self.option_add('*Text.background','#111b24'); self.option_add('*Text.foreground',fg)
        self.option_add('*Text.insertBackground',fg); self.option_add('*Listbox.background','#111b24')
        self.option_add('*Listbox.foreground',fg); self.option_add('*Listbox.selectBackground',select)

    # ---------- UI ----------
    def _build_ui(self):
        # HF6: two-tier toolbar. The old single row exceeded 1920 px and
        # clipped everything after 1P Resources on common displays.
        top = ttk.Frame(self, padding=(8,8,8,2))
        top.pack(fill='x')
        ttk.Button(top, text='Create Project…', command=self.create_project).pack(side='left')
        ttk.Button(top, text='Open Project…', command=self.open_project).pack(side='left', padx=(6,0))
        ttk.Separator(top, orient='vertical').pack(side='left', fill='y', padx=8)
        ttk.Label(top, text='Character:').pack(side='left')
        self.character_var = tk.StringVar()
        self.character_combo = ttk.Combobox(top, textvariable=self.character_var, state='readonly', width=20)
        self.character_combo.pack(side='left', padx=(5,0))
        self.character_combo.bind('<<ComboboxSelected>>', self.on_character_changed)
        ttk.Button(top, text='Save Working', command=self.save_working).pack(side='left', padx=(8,0))
        ttk.Button(top, text='Build Modified Files', command=self.build_project).pack(side='left', padx=(6,0))
        ttk.Button(top, text='ISO / Patch…', command=self.open_iso_patch_dialog).pack(side='left', padx=(6,0))

        tools_button = ttk.Menubutton(top, text='Tools ▾')
        tools_menu = tk.Menu(tools_button, tearoff=False)
        tools_menu.add_command(label='SDK Health…', command=self.open_sdk_health)
        tools_menu.add_command(label='Project Compatibility…', command=self.open_project_compatibility)
        tools_menu.add_separator()
        tools_menu.add_command(label='Reset Character', command=self.reset_character)
        tools_menu.add_command(label='Open DAT…', command=self.open_dat)
        tools_menu.add_command(label='Validate AJ', command=self.validate_aj)
        tools_menu.add_command(label='Export JSON…', command=self.export_json)
        tools_button.configure(menu=tools_menu)
        tools_button.pack(side='right')

        editbar = ttk.Frame(self, padding=(8,2,8,4))
        editbar.pack(fill='x')
        ttk.Button(editbar, text='Character Slot Lab…', command=self.open_character_slot_lab).pack(side='left')
        ttk.Button(editbar, text='Quick Import Mod…', command=self.quick_import_mod).pack(side='left', padx=(6,0))
        ttk.Button(editbar, text='1P / Duo Lab…', command=self.open_game_mode_lab).pack(side='left', padx=(6,0))
        ttk.Button(editbar, text='1P Resources…', command=self.open_one_player_resources).pack(side='left', padx=(6,0))
        ttk.Button(editbar, text='Stage Pages…', command=self.open_stage_page_lab).pack(side='left', padx=(6,0))
        ttk.Button(editbar, text='Stage Workbench', command=self._select_stage_workbench).pack(side='left', padx=(6,0))

        info = ttk.Frame(self, padding=(8,0,8,6))
        info.pack(fill='x')
        self.project_label = ttk.Label(info, text='No project open. Create a project to manage safe Original / Working / Build copies.')
        self.project_label.pack(side='left')
        ttk.Checkbutton(info, text='Show binary offsets (advanced)', variable=self.show_offsets, command=self._refresh_attribute_views).pack(side='right')

        self.status = ttk.Label(self, text='Ready. Values are displayed and edited in base 10.', padding=(8,0,8,5))
        self.status.pack(fill='x')

        self.tabs = ttk.Notebook(self)
        self.tabs.pack(fill='both', expand=True, padx=8, pady=(0,8))

        self.overview = ttk.Frame(self.tabs, padding=10)
        self.attrs = ttk.Frame(self.tabs, padding=10)
        self.special = ttk.Frame(self.tabs, padding=10)
        self.global_mechanics = ttk.Frame(self.tabs, padding=10)
        self.moves = ttk.Frame(self.tabs, padding=10)
        self.stages_tab = ttk.Frame(self.tabs, padding=10)
        self.tabs.add(self.overview, text='Overview')
        self.tabs.add(self.attrs, text='Common Attributes')
        self.tabs.add(self.special, text='Character-specific')
        self.tabs.add(self.global_mechanics, text='Global Mechanics')
        self.tabs.add(self.moves, text='Moves / Hitboxes')
        self.tabs.add(self.stages_tab, text='Stage Workbench')

        self.overview_text = tk.Text(self.overview, wrap='word', font=('Consolas', 10))
        self.overview_text.pack(fill='both', expand=True)

        self.attr_form = self._make_scroll_form(self.attrs)
        self.special_form = self._make_scroll_form(self.special)
        self.global_form = self._make_scroll_form(self.global_mechanics)

        # Stage workbench: source-validated HSD/public-symbol + collision primitives.
        stage_top = ttk.Frame(self.stages_tab)
        stage_top.pack(fill='x', pady=(0,8))
        ttk.Button(stage_top, text='Import Stages From ISO…', command=self.import_stages_from_iso).pack(side='left')
        ttk.Button(stage_top, text='Import SSS/CSS From ISO…', command=self.import_menu_archives_from_iso).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Open Stage DAT…', command=self.open_stage_dat).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Save Stage Working', command=self.save_stage_working).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Reset Stage', command=self.reset_stage_working).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Layout / Collision…', command=self.open_stage_authoring_tools).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Create NEW Stage…', command=self.create_new_stage_wizard).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Quick Inject Stage…', command=self.quick_inject_stage).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Stage Builder…', style='Accent.TButton', command=self.open_stage_asset_lab).pack(side='left', padx=(6,0))
        ttk.Button(stage_top, text='Build / Test Stage…', command=self.install_current_stage_as_new_slot).pack(side='left', padx=(6,0))
        self.stage_status = ttk.Label(stage_top, text='No stage loaded.', foreground='#666666')
        self.stage_status.pack(side='left', padx=(12,0))

        stage_left = ttk.Frame(self.stages_tab)
        stage_center = ttk.Frame(self.stages_tab)
        stage_right = ttk.Frame(self.stages_tab)
        stage_left.pack(side='left', fill='y')
        stage_center.pack(side='left', fill='both', expand=True, padx=8)
        stage_right.pack(side='right', fill='y')

        ttk.Label(stage_left, text='Project stage resources').pack(anchor='w')
        self.stage_tree = ttk.Treeview(stage_left, columns=('file',), show='tree headings', height=30, selectmode='browse')
        self.stage_tree.heading('#0', text='Stage')
        self.stage_tree.heading('file', text='DAT')
        self.stage_tree.column('#0', width=190)
        self.stage_tree.column('file', width=100)
        self.stage_tree.pack(fill='both', expand=True, pady=(4,0))
        self.stage_tree.bind('<<TreeviewSelect>>', self.on_stage_selected)
        ttk.Label(stage_left, text='All Gr*.dat archives are preserved. Named entries use the decomp StageData catalog.', wraplength=280, justify='left', foreground='#666666').pack(anchor='w', pady=(6,0))

        ttk.Label(stage_center, text='Collision geometry preview').pack(anchor='w')
        self.stage_canvas = tk.Canvas(stage_center, background='white', highlightthickness=1, highlightbackground='#aaaaaa')
        self.stage_canvas.pack(fill='both', expand=True, pady=(4,6))
        self.stage_canvas.bind('<Configure>', lambda e: self.refresh_stage_preview())
        self.stage_coll_summary = ttk.Label(stage_center, text='Load a stage with coll_data to inspect geometry.', justify='left')
        self.stage_coll_summary.pack(anchor='w')

        ttk.Label(stage_right, text='Stage inspector', font=('TkDefaultFont', 10, 'bold')).pack(anchor='w')
        self.stage_symbol_text = tk.Text(stage_right, width=38, height=10, wrap='none', font=('Consolas', 9))
        self.stage_symbol_text.pack(fill='x', pady=(4,8))
        gp = ttk.LabelFrame(stage_right, text='Source-validated GroundParam', padding=8)
        gp.pack(fill='x')
        self.stage_scale_var = tk.StringVar(value='1.0')
        self.stage_fixed_cam_var = tk.BooleanVar(value=False)
        ttk.Label(gp, text='Stage scale').grid(row=0, column=0, sticky='w')
        ttk.Entry(gp, textvariable=self.stage_scale_var, width=12).grid(row=0, column=1, sticky='e')
        ttk.Checkbutton(gp, text='Fixed camera flag', variable=self.stage_fixed_cam_var).grid(row=1, column=0, columnspan=2, sticky='w', pady=(5,0))
        ttk.Button(gp, text='Apply GroundParam', command=self.apply_stage_ground_param).grid(row=2, column=0, columnspan=2, sticky='ew', pady=(7,0))
        ttk.Label(gp, text='Only fields with source-confirmed meaning are editable. Camera/blast bounds are JObj marker-driven and are not guessed.', wraplength=280, justify='left', foreground='#666666').grid(row=3, column=0, columnspan=2, sticky='w', pady=(6,0))

        ve = ttk.LabelFrame(stage_right, text='Collision vertex', padding=8)
        ve.pack(fill='x', pady=(8,0))
        self.stage_vertex_label = ttk.Label(ve, text='Select a preview vertex')
        self.stage_vertex_label.grid(row=0, column=0, columnspan=2, sticky='w')
        self.stage_vertex_x = tk.StringVar()
        self.stage_vertex_y = tk.StringVar()
        ttk.Label(ve, text='X').grid(row=1, column=0, sticky='w', pady=(5,0))
        ttk.Entry(ve, textvariable=self.stage_vertex_x, width=12).grid(row=1, column=1, sticky='e', pady=(5,0))
        ttk.Label(ve, text='Y').grid(row=2, column=0, sticky='w')
        ttk.Entry(ve, textvariable=self.stage_vertex_y, width=12).grid(row=2, column=1, sticky='e')
        ttk.Button(ve, text='Apply Vertex', command=self.apply_stage_vertex).grid(row=3, column=0, columnspan=2, sticky='ew', pady=(6,0))
        self.stage_canvas.bind('<Button-1>', self.select_stage_vertex_from_canvas)

        # Moves split view.
        left = ttk.Frame(self.moves)
        center = ttk.Frame(self.moves)
        right = ttk.Frame(self.moves)
        left.pack(side='left', fill='y')
        center.pack(side='left', fill='both', expand=True, padx=8)
        right.pack(side='right', fill='y')

        ttk.Label(left, text='Actions — grouped by type').pack(anchor='w')
        self.move_filter = tk.StringVar()
        ent = ttk.Entry(left, textvariable=self.move_filter, width=34)
        ent.pack(fill='x', pady=(2,6))
        ent.insert(0, '')
        self.move_filter.trace_add('write', lambda *args: self.populate_moves())
        self.move_tree = ttk.Treeview(left, columns=('index','hitbox'), show='tree headings', height=28, selectmode='browse')
        self.move_tree.heading('#0', text='Action')
        self.move_tree.heading('index', text='#')
        self.move_tree.heading('hitbox', text='Hitboxes')
        self.move_tree.column('#0', width=225, stretch=True)
        self.move_tree.column('index', width=46, anchor='e', stretch=False)
        self.move_tree.column('hitbox', width=62, anchor='center', stretch=False)
        self.move_tree.pack(fill='both', expand=True)
        self.move_tree.bind('<<TreeviewSelect>>', self.on_move_selected)
        move_buttons = ttk.Frame(left)
        move_buttons.pack(fill='x', pady=(5,0))
        ttk.Button(move_buttons, text='Expand all', command=lambda: self._set_move_tree_open(True)).pack(side='left')
        ttk.Button(move_buttons, text='Collapse all', command=lambda: self._set_move_tree_open(False)).pack(side='left', padx=(5,0))
        ttk.Label(left, text='Hitboxes = number of decoded Spawn Hitbox events.\nUse the search box to filter within all groups.', justify='left', foreground='#666666').pack(anchor='w', pady=(6,0))

        ttk.Label(center, text='Decoded command stream — numeric values are base 10').pack(anchor='w')
        asm = ttk.Frame(center)
        asm.pack(fill='x', pady=(3,5))
        ttk.Button(asm, text='Duplicate', command=self.assembler_duplicate_event).pack(side='left')
        ttk.Button(asm, text='Delete', command=self.assembler_delete_event).pack(side='left', padx=(4,0))
        ttk.Button(asm, text='Move ↑', command=lambda:self.assembler_move_event(-1)).pack(side='left', padx=(4,0))
        ttk.Button(asm, text='Move ↓', command=lambda:self.assembler_move_event(1)).pack(side='left', padx=(4,0))
        ttk.Separator(asm, orient='vertical').pack(side='left', fill='y', padx=7)
        ttk.Button(asm, text='Insert Sync Timer…', command=lambda:self.assembler_insert_timer(1)).pack(side='left')
        ttk.Button(asm, text='Insert Async Timer…', command=lambda:self.assembler_insert_timer(2)).pack(side='left', padx=(4,0))
        ttk.Button(asm, text='Insert Clear', command=lambda:self.assembler_insert_simple(16)).pack(side='left', padx=(4,0))
        ttk.Button(asm, text='Insert IASA', command=lambda:self.assembler_insert_simple(23)).pack(side='left', padx=(4,0))
        ttk.Button(asm, text='Loop Event…', command=self.assembler_wrap_loop).pack(side='left', padx=(4,0))
        ttk.Button(asm, text='Add Hitbox Phase…', command=self.assembler_add_hitbox_phase).pack(side='left', padx=(7,0))
        ttk.Button(asm, text='Copy Script', command=self.assembler_copy_script).pack(side='right')
        ttk.Button(asm, text='Paste Script', command=self.assembler_paste_script).pack(side='right', padx=(0,4))
        author = ttk.Frame(center)
        author.pack(fill='x', pady=(0,5))
        ttk.Button(author, text='Analyze Control Flow', command=self.assembler_analyze_cfg).pack(side='left')
        ttk.Button(author, text='Export Script JSON…', command=self.assembler_export_json).pack(side='left', padx=(5,0))
        ttk.Button(author, text='Import Script JSON…', command=self.assembler_import_json).pack(side='left', padx=(5,0))
        ttk.Label(author, text='Graph-aware: loops, Subroutine and Goto pointers are decoded/relocated.', foreground='#666666').pack(side='left', padx=(10,0))

        self.events = ttk.Treeview(center, columns=('frame','offset','opcode','name','details'), show='headings')
        for col, w in [('frame',70),('offset',90),('opcode',65),('name',180),('details',420)]:
            self.events.heading(col, text=col.title())
            self.events.column(col, width=w, stretch=(col=='details'))
        self.events.pack(fill='both', expand=True)
        self.events.bind('<<TreeviewSelect>>', self.on_event_selected)

        ttk.Label(right, text='Context inspector').pack(anchor='w')
        self.inspector_host = ttk.Frame(right)
        self.inspector_host.pack(fill='both', expand=True)

        # Action/event information shown whenever the selected thing is not a hitbox.
        self.action_inspector = ttk.Frame(self.inspector_host)
        self.action_title = ttk.Label(self.action_inspector, text='Select an action', font=('TkDefaultFont', 10, 'bold'))
        self.action_title.pack(anchor='w', pady=(4,6))
        self.action_info = ttk.Label(self.action_inspector, text='The hitbox editor appears only when a Spawn Hitbox event is selected.', justify='left', wraplength=250)
        self.action_info.pack(anchor='w')
        self.action_buttons = ttk.Frame(self.action_inspector)
        self.action_buttons.pack(fill='x', pady=(10,0))
        self.common_link_btn = ttk.Button(self.action_buttons, text='Open Common Attributes', command=lambda:self.tabs.select(self.attrs))
        self.common_link_btn.pack(fill='x')
        self.global_link_btn = ttk.Button(self.action_buttons, text='Open Global Mechanics', command=lambda:self.tabs.select(self.global_mechanics))
        self.global_link_btn.pack(fill='x', pady=(5,0))

        self.frame_data_box = ttk.LabelFrame(self.action_inspector, text='Frame data editor', padding=8)
        self.frame_data_box.pack(fill='x', pady=(12,0))
        self.frame_summary = ttk.Label(self.frame_data_box, text='Select an action to derive timing.', justify='left', wraplength=250)
        self.frame_summary.pack(anchor='w', pady=(0,6))
        self.frame_vars = {k: tk.StringVar() for k in ('startup','active_end','recovery','interrupt','script_end')}
        labels = [
            ('startup','First active frame'),
            ('active_end','First inactive frame'),
            ('recovery','Recovery frames'),
            ('interrupt','Interrupt / IASA frame'),
            ('script_end','Script end frame'),
        ]
        frame_grid = ttk.Frame(self.frame_data_box)
        frame_grid.pack(fill='x')
        for r,(key,label) in enumerate(labels):
            ttk.Label(frame_grid, text=label).grid(row=r, column=0, sticky='w', pady=2)
            ttk.Spinbox(frame_grid, textvariable=self.frame_vars[key], from_=0, to=67108863, increment=1, width=9).grid(row=r, column=1, sticky='e', pady=2)
        frame_grid.columnconfigure(0, weight=1)
        ttk.Button(self.frame_data_box, text='Apply Frame Data', command=self.apply_frame_data).pack(fill='x', pady=(7,0))
        hist = ttk.Frame(self.frame_data_box)
        hist.pack(fill='x', pady=(5,0))
        ttk.Button(hist, text='Undo Move Edit', command=self.undo_move_edit).pack(side='left', fill='x', expand=True)
        ttk.Button(hist, text='Redo', command=self.redo_move_edit).pack(side='left', fill='x', expand=True, padx=(5,0))
        ttk.Label(self.frame_data_box, text='Milestones are derived from the decoded command stream. Frame Data uses timer anchors. The graph-aware Script Assembler can resize scripts while preserving loops and relocating Subroutine/Goto targets.', foreground='#666666', wraplength=250, justify='left').pack(anchor='w', pady=(6,0))

        self.script_timing_box = ttk.LabelFrame(self.action_inspector, text='Advanced timing scale', padding=8)
        self.script_timing_box.pack(fill='x', pady=(12,0))
        ttk.Label(self.script_timing_box, text='Timing scale (0.5 = command events occur about twice as early):', wraplength=240, justify='left').pack(anchor='w')
        timing_row = ttk.Frame(self.script_timing_box)
        timing_row.pack(fill='x', pady=(5,0))
        self.script_timing_scale = tk.StringVar(value='0.5')
        ttk.Entry(timing_row, textvariable=self.script_timing_scale, width=8).pack(side='left')
        ttk.Button(timing_row, text='Scale Script Timing', command=self.scale_current_move_timing).pack(side='left', padx=(6,0))
        ttk.Label(self.script_timing_box, text='Scales only fighter-script timers. Use Full Move Speed below when you want the actual AJ keyframe animation retimed too.', foreground='#666666', wraplength=250, justify='left').pack(anchor='w', pady=(6,0))

        self.full_speed_box = ttk.LabelFrame(self.action_inspector, text='Full move speed — script + AJ animation', padding=8)
        self.full_speed_box.pack(fill='x', pady=(10,0))
        ttk.Label(self.full_speed_box, text='Speed multiplier (1.30 = 30% faster):', wraplength=240, justify='left').pack(anchor='w')
        speed_row = ttk.Frame(self.full_speed_box)
        speed_row.pack(fill='x', pady=(5,0))
        self.full_move_speed = tk.StringVar(value='1.30')
        ttk.Entry(speed_row, textvariable=self.full_move_speed, width=8).pack(side='left')
        ttk.Button(speed_row, text='Retiming Preview', command=self.preview_full_move_speed).pack(side='left', padx=(5,0))
        ttk.Button(self.full_speed_box, text='Apply Full Move Speed', command=self.apply_full_move_speed).pack(fill='x', pady=(6,0))
        ttk.Button(self.full_speed_box, text='Clone Full Move From Action…', command=self.clone_full_move_from_action).pack(fill='x', pady=(5,0))
        ttk.Label(self.full_speed_box, text='Project mode only. Retimes script timers plus the embedded FigaTree frames/startframes/key waits, safely rebuilding AJ offsets if the chunk size changes. Full Move Clone duplicates both the command graph and an independent renamed AJ chunk.', foreground='#666666', wraplength=250, justify='left').pack(anchor='w', pady=(6,0))

        self.bulk_hitbox_box = ttk.LabelFrame(self.action_inspector, text='Action hitbox tools', padding=8)
        self.bulk_hitbox_box.pack(fill='x', pady=(10,0))
        bulk_grid = ttk.Frame(self.bulk_hitbox_box)
        bulk_grid.pack(fill='x')
        self.bulk_damage_scale = tk.StringVar(value='1.0')
        self.bulk_size_scale = tk.StringVar(value='1.0')
        ttk.Label(bulk_grid, text='Damage ×').grid(row=0, column=0, sticky='w')
        ttk.Entry(bulk_grid, textvariable=self.bulk_damage_scale, width=8).grid(row=0, column=1, sticky='e')
        ttk.Label(bulk_grid, text='Size ×').grid(row=1, column=0, sticky='w', pady=(3,0))
        ttk.Entry(bulk_grid, textvariable=self.bulk_size_scale, width=8).grid(row=1, column=1, sticky='e', pady=(3,0))
        bulk_grid.columnconfigure(0, weight=1)
        ttk.Button(self.bulk_hitbox_box, text='Apply to All Spawn Hitboxes', command=self.bulk_scale_hitboxes).pack(fill='x', pady=(6,0))
        ttk.Label(self.bulk_hitbox_box, text='Applies only to existing Spawn Hitbox commands in this action. Command count and DAT size stay unchanged.', foreground='#666666', wraplength=250, justify='left').pack(anchor='w', pady=(5,0))

        # Single timer editor, shown when a Synchronous/Asynchronous Timer command is selected.
        self.timer_inspector = ttk.Frame(self.inspector_host)
        ttk.Label(self.timer_inspector, text='Selected timer — frames', font=('TkDefaultFont', 10, 'bold')).pack(anchor='w')
        self.timer_info = ttk.Label(self.timer_inspector, text='', justify='left', wraplength=250)
        self.timer_info.pack(anchor='w', pady=(5,8))
        timer_row = ttk.Frame(self.timer_inspector)
        timer_row.pack(fill='x')
        ttk.Label(timer_row, text='Timer value').pack(side='left')
        self.timer_value_var = tk.StringVar()
        ttk.Spinbox(timer_row, textvariable=self.timer_value_var, from_=0, to=67108863, increment=1, width=10).pack(side='right')
        ttk.Button(self.timer_inspector, text='Apply timer edit', command=self.apply_timer_edit).pack(fill='x', pady=(8,0))
        ttk.Label(self.timer_inspector, text='Synchronous Timer = relative wait. Asynchronous Timer = absolute script frame target.', foreground='#666666', wraplength=250, justify='left').pack(anchor='w', pady=(7,0))

        # Hitbox editor, only shown for an actual Spawn Hitbox event.
        self.hitbox_inspector = ttk.Frame(self.inspector_host)
        ttk.Label(self.hitbox_inspector, text='Selected hitbox — base 10', font=('TkDefaultFont', 10, 'bold')).pack(anchor='w')
        hform = ttk.Frame(self.hitbox_inspector)
        hform.pack(fill='y')
        for r,(key,label,typ,lo,hi) in enumerate(HITBOX_EDIT_FIELDS):
            ttk.Label(hform, text=label).grid(row=r, column=0, sticky='e', padx=3, pady=2)
            var = tk.StringVar()
            self.hit_vars[key] = var
            spin = ttk.Spinbox(hform, textvariable=var, from_=lo, to=hi, increment=(1 if typ is int else 0.125), width=12)
            spin.grid(row=r, column=1, sticky='w', padx=3, pady=2)
        start_h = len(HITBOX_EDIT_FIELDS)
        for i,(key,label) in enumerate(BOOL_HITBOX_FIELDS):
            var = tk.BooleanVar(value=False)
            self.hit_bool_vars[key] = var
            ttk.Checkbutton(hform, text=label, variable=var).grid(row=start_h+i, column=0, columnspan=2, sticky='w', padx=5, pady=2)
        ttk.Button(self.hitbox_inspector, text='Apply hitbox edits', command=self.apply_hitbox).pack(fill='x', pady=(8,0))
        hb_clip = ttk.Frame(self.hitbox_inspector)
        hb_clip.pack(fill='x', pady=(5,0))
        ttk.Button(hb_clip, text='Copy Values', command=self.copy_hitbox_values).pack(side='left', fill='x', expand=True)
        ttk.Button(hb_clip, text='Paste Values', command=self.paste_hitbox_values).pack(side='left', fill='x', expand=True, padx=(5,0))
        ttk.Label(self.hitbox_inspector, text='Copy/Paste overwrites parameters on another existing Spawn Hitbox; it does not insert a new hitbox command.\nMovement and physics values live in Common Attributes or Global Mechanics.', justify='left', wraplength=260).pack(anchor='w', pady=(8,0))
        self._show_action_inspector()

    def _make_scroll_form(self, parent):
        canvas = tk.Canvas(parent, highlightthickness=0)
        sb = ttk.Scrollbar(parent, orient='vertical', command=canvas.yview)
        form = ttk.Frame(canvas)
        form.bind('<Configure>', lambda e: canvas.configure(scrollregion=canvas.bbox('all')))
        window = canvas.create_window((0,0), window=form, anchor='nw')
        canvas.bind('<Configure>', lambda e: canvas.itemconfigure(window, width=e.width))
        canvas.configure(yscrollcommand=sb.set)
        canvas.pack(side='left', fill='both', expand=True)
        sb.pack(side='right', fill='y')
        return form

    # ---------- Stage workbench ----------
    def populate_stage_tree(self):
        if not hasattr(self, 'stage_tree'):
            return
        self.stage_tree.delete(*self.stage_tree.get_children())
        if not self.project:
            return
        for st in sorted(self.project.stages, key=lambda x: x.display_name.lower()):
            self.stage_tree.insert('', 'end', iid='stage:'+st.filename.lower(), text=st.display_name, values=(st.filename,))

    def import_stages_from_iso(self):
        if not self.project:
            messagebox.showinfo('Project required', 'Open or create a project first.'); return
        p = filedialog.askopenfilename(title='Select clean Melee ISO containing Gr*.dat stages', filetypes=[('GameCube ISO','*.iso *.gcm'),('All files','*.*')])
        if not p:
            return
        try:
            count = self.project.import_stages_from_iso(p)
            self.populate_stage_tree()
            self.stage_status.configure(text=f'Imported/synchronized {count} Gr*.dat resources into Original/ + Working/.')
            self.status.configure(text=f'Stage resource snapshot ready: {count} Gr*.dat files discovered in the ISO.')
        except Exception as e:
            messagebox.showerror('Stage import failed', str(e))

    def import_menu_archives_from_iso(self):
        if not self.project:
            messagebox.showinfo('Import menu archives', 'Open or create a project first.')
            return
        iso = filedialog.askopenfilename(title='Select clean GALE01 1.02 ISO',
                                         filetypes=[('GameCube ISO', '*.iso'), ('All files', '*.*')])
        if not iso:
            return
        try:
            verify_melee_102(iso, full_hash=True)
            result = self.project.import_menu_archives_from_iso(iso)
            names = ', '.join(result['files']) if result['files'] else 'none found'
            messagebox.showinfo('Menu archives imported',
                                f"Imported {result['count']} validated Stage Select / Character Select archive(s):\n{names}\n\n"
                                'These are now snapshotted in Original/ and Working/ for the visual slot-authoring phase.')
        except Exception as e:
            messagebox.showerror('Menu archive import failed', str(e))

    def open_stage_dat(self):
        p = filedialog.askopenfilename(title='Open Melee stage DAT', filetypes=[('Stage DAT','Gr*.dat'),('DAT','*.dat'),('All files','*.*')])
        if not p:
            return
        try:
            self.stage = StageDAT(p)
            self.stage_dirty = False
            self.stage_vertex_index = None
            self.refresh_stage_view()
        except Exception as e:
            messagebox.showerror('Stage DAT', str(e))

    def on_stage_selected(self, event=None):
        if not self.project:
            return
        sel = self.stage_tree.selection()
        if not sel:
            return
        filename = self.stage_tree.item(sel[0], 'values')[0]
        if self.stage_dirty:
            ans = messagebox.askyesnocancel('Unsaved stage changes', 'Save the current stage Working DAT before switching?')
            if ans is None:
                return
            if ans and not self.save_stage_working():
                return
        try:
            self.stage = StageDAT(self.project.working_stage_path(filename))
            self.stage_dirty = False
            self.stage_vertex_index = None
            self.refresh_stage_view()
        except Exception as e:
            messagebox.showerror('Stage load failed', str(e))

    def refresh_stage_view(self):
        if not self.stage:
            return
        cat = self.stage.catalog
        title = cat.name if cat else self.stage.filename
        self.stage_status.configure(text=f'{title} — {self.stage.filename}')
        self.stage_symbol_text.configure(state='normal')
        self.stage_symbol_text.delete('1.0', 'end')
        self.stage_symbol_text.insert('end', 'Public symbols\n')
        for p in self.stage.archive.publics:
            self.stage_symbol_text.insert('end', f'0x{p.offset:08X}  {p.name}\n')
        self.stage_symbol_text.configure(state='disabled')
        try:
            gp = self.stage.ground_param()
        except Exception:
            gp = None
        if gp:
            self.stage_scale_var.set(f"{gp['stage_scale']:.9g}")
            self.stage_fixed_cam_var.set(bool(gp['fixed_camera']))
        else:
            self.stage_scale_var.set('')
            self.stage_fixed_cam_var.set(False)
        try:
            cs = self.stage.collision_summary()
            if cs:
                self.stage_coll_summary.configure(text=(
                    f'Vertices {cs.vertex_count}   Lines {cs.line_count}   Joints {cs.joint_count}   |   '
                    f'Floors {cs.floor_count}  Ceilings {cs.ceiling_count}  '
                    f'R-walls {cs.right_wall_count}  L-walls {cs.left_wall_count}  Dynamic {cs.dynamic_count}'
                ))
            else:
                self.stage_coll_summary.configure(text='This archive has no public coll_data root.')
        except Exception as e:
            self.stage_coll_summary.configure(text=f'Collision parse error: {e}')
        self.refresh_stage_preview()

    def _stage_preview_transform(self):
        if not self.stage:
            return None
        verts = self.stage.vertices()
        if not verts:
            return None
        xs=[v[0] for v in verts]; ys=[v[1] for v in verts]
        minx,maxx=min(xs),max(xs); miny,maxy=min(ys),max(ys)
        if maxx-minx < 1e-6: maxx=minx+1
        if maxy-miny < 1e-6: maxy=miny+1
        w=max(50,self.stage_canvas.winfo_width()); h=max(50,self.stage_canvas.winfo_height()); pad=24
        sx=(w-2*pad)/(maxx-minx); sy=(h-2*pad)/(maxy-miny); scale=min(sx,sy)
        ox=(w-(maxx-minx)*scale)/2-minx*scale
        oy=(h+(maxy-miny)*scale)/2+miny*scale
        return verts, scale, ox, oy

    def refresh_stage_preview(self):
        if not hasattr(self, 'stage_canvas'):
            return
        self.stage_canvas.delete('all')
        if not self.stage or not self.stage.has_public('coll_data'):
            return
        try:
            tx=self._stage_preview_transform()
            if not tx: return
            verts,scale,ox,oy=tx
            lines=self.stage.lines()
            for ln in lines:
                if ln['v0'] >= len(verts) or ln['v1'] >= len(verts): continue
                a=verts[ln['v0']]; b=verts[ln['v1']]
                self.stage_canvas.create_line(ox+a[0]*scale, oy-a[1]*scale, ox+b[0]*scale, oy-b[1]*scale, width=2)
            # Draw vertices last so selection points remain clickable.
            for i,(x,y) in enumerate(verts):
                px,py=ox+x*scale,oy-y*scale
                r=4 if i == self.stage_vertex_index else 2
                self.stage_canvas.create_oval(px-r,py-r,px+r,py+r, fill='black', tags=(f'v{i}',))
        except Exception as e:
            self.stage_canvas.create_text(10,10,anchor='nw',text=f'Preview unavailable: {e}')

    def select_stage_vertex_from_canvas(self, event):
        if not self.stage or not self.stage.has_public('coll_data'):
            return
        try:
            tx=self._stage_preview_transform()
            if not tx: return
            verts,scale,ox,oy=tx
            best=None
            for i,(x,y) in enumerate(verts):
                px,py=ox+x*scale,oy-y*scale
                d=(px-event.x)**2+(py-event.y)**2
                if best is None or d < best[0]: best=(d,i)
            if not best or best[0] > 18**2:
                return
            i=best[1]; x,y=verts[i]
            self.stage_vertex_index=i
            self.stage_vertex_label.configure(text=f'Vertex #{i}')
            self.stage_vertex_x.set(f'{x:.9g}'); self.stage_vertex_y.set(f'{y:.9g}')
            self.refresh_stage_preview()
        except Exception as e:
            messagebox.showerror('Collision vertex', str(e))

    def apply_stage_vertex(self):
        if not self.stage or self.stage_vertex_index is None:
            messagebox.showinfo('Collision vertex', 'Select a collision vertex in the preview first.'); return
        try:
            self.stage.set_vertex(self.stage_vertex_index, float(self.stage_vertex_x.get()), float(self.stage_vertex_y.get()))
            self.stage_dirty=True
            self.refresh_stage_view()
            self.status.configure(text=f'Edited stage collision vertex #{self.stage_vertex_index}; Save Stage Working to commit.')
        except Exception as e:
            messagebox.showerror('Collision edit', str(e))

    def apply_stage_ground_param(self):
        if not self.stage:
            messagebox.showinfo('Stage', 'Load a stage first.'); return
        if not self.stage.has_public('grGroundParam'):
            messagebox.showinfo('GroundParam', 'This archive does not expose grGroundParam.'); return
        try:
            self.stage.set_stage_scale(float(self.stage_scale_var.get()))
            self.stage.set_fixed_camera(bool(self.stage_fixed_cam_var.get()))
            self.stage_dirty=True
            self.refresh_stage_view()
            self.status.configure(text='Applied source-validated GroundParam edits in memory; Save Stage Working to commit.')
        except Exception as e:
            messagebox.showerror('GroundParam', str(e))

    def save_stage_working(self):
        if not self.stage:
            return False
        try:
            # Validate fully before serializing.
            self.stage.validate()
            if self.project and self.stage.path and self.stage.path.parent.resolve() == self.project.working_dir.resolve():
                target=self.project.save_stage(self.stage)
                self.stage=StageDAT(target)
            elif self.project and self.stage.path and any(x.filename.lower()==self.stage.path.name.lower() for x in self.project.stages):
                target=self.project.working_dir/self.stage.path.name
                self.stage.save_as(target); self.stage=StageDAT(target)
            else:
                p=filedialog.asksaveasfilename(defaultextension='.dat', initialfile=(self.stage.filename.replace('.dat','_mod.dat')), filetypes=[('DAT','*.dat')])
                if not p: return False
                self.stage.save_as(p); self.stage=StageDAT(p)
            self.stage_dirty=False
            self.refresh_stage_view()
            self.status.configure(text=f'Saved and revalidated stage {self.stage.filename}.')
            return True
        except Exception as e:
            messagebox.showerror('Stage save failed', str(e)); return False

    def reset_stage_working(self):
        if not self.project or not self.stage or not self.stage.path:
            messagebox.showinfo('Project stage required', 'Load a stage from the current Project first.'); return
        filename=self.stage.path.name
        try:
            self.project.stage_by_filename(filename)
        except KeyError:
            messagebox.showinfo('Project stage required', 'The loaded DAT is not a registered project stage.'); return
        if not messagebox.askyesno('Reset stage', f'Restore Working/{filename} from immutable Original/?'):
            return
        try:
            p=self.project.reset_stage(filename)
            self.stage=StageDAT(p); self.stage_dirty=False; self.stage_vertex_index=None
            self.refresh_stage_view()
        except Exception as e:
            messagebox.showerror('Reset stage', str(e))


    def open_stage_authoring_tools(self):
        if not self.stage:
            messagebox.showinfo('Stage Authoring', 'Load a stage first.'); return
        win=tk.Toplevel(self); win.title('Phase 18 Stage Authoring Tools'); win.geometry('820x820')
        body=ttk.Frame(win,padding=10); body.pack(fill='both',expand=True)
        # Camera / blast markers
        mk=ttk.LabelFrame(body,text='Camera + Blast Zone markers (0x94–0x98)',padding=8); mk.pack(fill='x')
        try: bounds=self.stage.camera_blast_bounds()
        except Exception as e: bounds={'camera':None,'blast':None}; ttk.Label(mk,text=f'Marker parse unavailable: {e}',foreground='#aa0000').pack(anchor='w')
        vars={}
        labels=[('center_x','Center X'),('center_y','Center Y'),('left','Left'),('right','Right'),('bottom','Bottom'),('top','Top')]
        cam=bounds.get('camera') or {}
        for r,(k,lbl) in enumerate(labels):
            ttk.Label(mk,text=lbl).grid(row=r,column=0,sticky='w'); v=tk.StringVar(value=str(cam.get(k,''))); vars['cam_'+k]=v; ttk.Entry(mk,textvariable=v,width=14).grid(row=r,column=1,sticky='w')
        blast=bounds.get('blast') or {}
        for r,k in enumerate(('left','right','bottom','top')):
            ttk.Label(mk,text='Blast '+k.title()).grid(row=r,column=2,sticky='w',padx=(16,0)); v=tk.StringVar(value=str(blast.get(k,''))); vars['blast_'+k]=v; ttk.Entry(mk,textvariable=v,width=14).grid(row=r,column=3,sticky='w')
        def apply_bounds():
            try:
                self.stage.set_camera_bounds(center_x=float(vars['cam_center_x'].get()),center_y=float(vars['cam_center_y'].get()),left=float(vars['cam_left'].get()),right=float(vars['cam_right'].get()),bottom=float(vars['cam_bottom'].get()),top=float(vars['cam_top'].get()))
                self.stage.set_blast_bounds(left=float(vars['blast_left'].get()),right=float(vars['blast_right'].get()),bottom=float(vars['blast_bottom'].get()),top=float(vars['blast_top'].get()))
                self.stage_dirty=True; self.refresh_stage_view(); messagebox.showinfo('Stage Authoring','Camera and blast markers updated in memory.',parent=win)
            except Exception as e: messagebox.showerror('Marker edit',str(e),parent=win)
        ttk.Button(mk,text='Apply Camera + Blast Bounds',command=apply_bounds).grid(row=6,column=0,columnspan=4,sticky='ew',pady=(8,0))
        # Marker list
        ml=ttk.LabelFrame(body,text='Resolved stage markers',padding=8); ml.pack(fill='both',expand=True,pady=(8,0))
        tree=ttk.Treeview(ml,columns=('id','x','y','z'),show='headings',height=9); [tree.heading(c,text=c.upper()) for c in ('id','x','y','z')]; tree.pack(fill='both',expand=True)
        try:
            for m in self.stage.markers(): tree.insert('', 'end', values=(f'0x{m.marker_id:02X} {m.name}',f'{m.world_x:.3f}',f'{m.world_y:.3f}',f'{m.world_z:.3f}'))
        except Exception: pass
        ge=ttk.Frame(ml); ge.pack(fill='x',pady=(5,0))
        mid=tk.StringVar(value='0'); mx=tk.StringVar(); my=tk.StringVar(); mz=tk.StringVar(value='0')
        for c,(lbl,v) in enumerate((('Marker ID',mid),('World X',mx),('World Y',my),('World Z',mz))):
            ttk.Label(ge,text=lbl).grid(row=0,column=c*2); ttk.Entry(ge,textvariable=v,width=10).grid(row=0,column=c*2+1)
        def load_marker():
            try:
                n=int(mid.get(),0); m=next(x for x in self.stage.markers() if x.marker_id==n); mx.set(f'{m.world_x:.9g}'); my.set(f'{m.world_y:.9g}'); mz.set(f'{m.world_z:.9g}')
            except Exception as e: messagebox.showerror('Marker',str(e),parent=win)
        def save_marker():
            try:
                self.stage.set_marker_world(int(mid.get(),0),float(mx.get()),float(my.get()),float(mz.get() or 0)); self.stage_dirty=True; self.refresh_stage_view()
            except Exception as e: messagebox.showerror('Marker',str(e),parent=win)
        ttk.Button(ge,text='Load Marker',command=load_marker).grid(row=1,column=0,columnspan=4,sticky='ew',pady=(4,0)); ttk.Button(ge,text='Apply World Position',command=save_marker).grid(row=1,column=4,columnspan=4,sticky='ew',pady=(4,0))
        # Surface editor
        sf=ttk.LabelFrame(body,text='Collision surface flags',padding=8); sf.pack(fill='x',pady=(8,0))
        li=tk.StringVar(value='0'); mat=tk.StringVar(value='0'); plat=tk.BooleanVar(); ledge=tk.BooleanVar(); dyn=tk.BooleanVar()
        ttk.Label(sf,text='Line #').grid(row=0,column=0); ttk.Entry(sf,textvariable=li,width=8).grid(row=0,column=1); ttk.Label(sf,text='Material ID 0–255').grid(row=0,column=2,padx=(10,0)); ttk.Entry(sf,textvariable=mat,width=8).grid(row=0,column=3)
        ttk.Checkbutton(sf,text='Platform / pass-through',variable=plat).grid(row=1,column=0,columnspan=2,sticky='w'); ttk.Checkbutton(sf,text='Ledge-grabbable',variable=ledge).grid(row=1,column=2,sticky='w'); ttk.Checkbutton(sf,text='Dynamic-floor source bit',variable=dyn).grid(row=1,column=3,sticky='w')
        def load_line():
            try:
                x=self.stage.line_surface(int(li.get())); mat.set(str(x['material_id'])); plat.set(x['platform']); ledge.set(x['ledge']); dyn.set(x['dynamic_platform_source'])
            except Exception as e: messagebox.showerror('Surface',str(e),parent=win)
        def save_line():
            try:
                self.stage.set_line_surface(int(li.get()),material_id=int(mat.get()),platform=plat.get(),ledge=ledge.get(),dynamic_platform_source=dyn.get()); self.stage_dirty=True; self.refresh_stage_preview()
            except Exception as e: messagebox.showerror('Surface',str(e),parent=win)
        ttk.Button(sf,text='Load Line',command=load_line).grid(row=2,column=0,columnspan=2,sticky='ew',pady=(5,0)); ttk.Button(sf,text='Apply Flags',command=save_line).grid(row=2,column=2,columnspan=2,sticky='ew',pady=(5,0))
        def split_line():
            try:
                frac=simpledialog.askfloat('Split collision line','Split fraction (0..1):',initialvalue=0.5,minvalue=0.001,maxvalue=0.999,parent=win)
                if frac is None:return
                r=self.stage.split_collision_line(int(li.get()),frac); self.stage_dirty=True; self.refresh_stage_view(); messagebox.showinfo('Split line',f"Created line {r['new_line_index']} at vertex {r['new_vertex_index']}.",parent=win)
            except Exception as e:messagebox.showerror('Split line',str(e),parent=win)
        def delete_line():
            try:
                idx=int(li.get())
                if not messagebox.askyesno('Delete collision line',f'Delete collision line {idx}? Unused endpoint vertices will be compacted.',parent=win):return
                r=self.stage.delete_collision_line(idx); self.stage_dirty=True; self.refresh_stage_view(); messagebox.showinfo('Delete line',f"Deleted line {idx}; removed vertices {r['removed_vertices']}.",parent=win)
            except Exception as e:messagebox.showerror('Delete line',str(e),parent=win)
        def join_line():
            try:
                other=simpledialog.askinteger('Join collision lines','Second line index:',parent=win)
                if other is None:return
                r=self.stage.join_collision_lines(int(li.get()),other); self.stage_dirty=True; self.refresh_stage_view(); messagebox.showinfo('Join lines',f"Joined into line {r['joined_into']}.",parent=win)
            except Exception as e:messagebox.showerror('Join lines',str(e),parent=win)
        ttk.Button(sf,text='Split…',command=split_line).grid(row=3,column=0,sticky='ew',pady=(5,0)); ttk.Button(sf,text='Join…',command=join_line).grid(row=3,column=1,sticky='ew',pady=(5,0)); ttk.Button(sf,text='Delete',command=delete_line).grid(row=3,column=2,columnspan=2,sticky='ew',pady=(5,0))
        # Dynamic collision joint translator
        jf=ttk.LabelFrame(body,text='Collision joint / dynamic platform base geometry',padding=8); jf.pack(fill='x',pady=(8,0))
        ji=tk.StringVar(value='0'); dx=tk.StringVar(value='0'); dy=tk.StringVar(value='0')
        for c,(lbl,v) in enumerate((('Joint #',ji),('ΔX',dx),('ΔY',dy))): ttk.Label(jf,text=lbl).grid(row=0,column=c*2); ttk.Entry(jf,textvariable=v,width=10).grid(row=0,column=c*2+1)
        def move_joint():
            try: self.stage.translate_joint_vertices(int(ji.get()),float(dx.get()),float(dy.get())); self.stage_dirty=True; self.refresh_stage_view()
            except Exception as e: messagebox.showerror('Joint edit',str(e),parent=win)
        ttk.Button(jf,text='Translate Joint Vertex Range + Bounds',command=move_joint).grid(row=1,column=0,columnspan=6,sticky='ew',pady=(6,0))
        # Template-based new stage
        nf=ttk.LabelFrame(body,text='Create new stage from this template',padding=8); nf.pack(fill='x',pady=(8,0))
        ttk.Label(nf,text='Creates an independent Gr*.dat authoring resource. To play it without a new stage-select slot, install it into an existing stage slot.').pack(anchor='w')
        def clone_stage():
            if not self.project: messagebox.showinfo('Project required','Open a project first.',parent=win); return
            name=simpledialog.askstring('New stage resource','New filename, e.g. GrMy.dat:',parent=win)
            if not name:return
            disp=simpledialog.askstring('Stage name','Display name:',initialvalue='Custom Stage',parent=win) or 'Custom Stage'
            try:
                src=self.stage.path.name; p=self.project.clone_stage_variant(src,name,disp); self.populate_stage_tree(); messagebox.showinfo('Created',f'Created {p.name} from {src}.',parent=win)
            except Exception as e: messagebox.showerror('Create stage',str(e),parent=win)
        def install_slot():
            if not self.project or not self.stage.path:return
            choices='\n'.join(f'{s.filename} — {s.display_name}' for s in self.project.stages if s.filename.lower()!=self.stage.path.name.lower())
            target=simpledialog.askstring('Install into stage slot','Target existing Gr*.dat filename:\n'+choices,parent=win)
            if not target:return
            try: p=self.project.install_stage_into_slot(self.stage.path.name,target); messagebox.showinfo('Installed',f'Working/{p.name} now contains this authored stage. Build/ISO rebuild will replace that slot.',parent=win)
            except Exception as e: messagebox.showerror('Install stage',str(e),parent=win)
        ttk.Button(nf,text='Create Variant From Current Stage…',command=clone_stage).pack(side='left',pady=(6,0)); ttk.Button(nf,text='Install Current Stage Into Existing Slot…',command=install_slot).pack(side='left',padx=(6,0),pady=(6,0))
        ttk.Button(nf,text='Install as NEW Runtime Stage…',command=self.install_current_stage_as_new_slot).pack(side='left',padx=(6,0),pady=(6,0))
        # Structural topology authoring
        af=ttk.LabelFrame(body,text='Add collision segment',padding=8); af.pack(fill='x',pady=(8,0))
        aj=tk.StringVar(value='0'); ac=tk.StringVar(value='Floor'); ax0=tk.StringVar(value='-10'); ay0=tk.StringVar(value='5'); ax1=tk.StringVar(value='10'); ay1=tk.StringVar(value='5'); amat=tk.StringVar(value='0'); apl=tk.BooleanVar(); ald=tk.BooleanVar()
        for c,(lbl,var) in enumerate((('Joint',aj),('Category',ac),('X0',ax0),('Y0',ay0),('X1',ax1),('Y1',ay1),('Material',amat))):
            ttk.Label(af,text=lbl).grid(row=0,column=c*2,sticky='w'); ttk.Entry(af,textvariable=var,width=9).grid(row=0,column=c*2+1,sticky='w')
        ttk.Checkbutton(af,text='Platform',variable=apl).grid(row=1,column=0,columnspan=2,sticky='w'); ttk.Checkbutton(af,text='Ledge',variable=ald).grid(row=1,column=2,columnspan=2,sticky='w')
        def add_seg():
            try:
                r=self.stage.add_collision_segment(joint_index=int(aj.get()),category=ac.get(),x0=float(ax0.get()),y0=float(ay0.get()),x1=float(ax1.get()),y1=float(ay1.get()),material_id=int(amat.get()),platform=apl.get(),ledge=ald.get())
                self.stage_dirty=True; self.refresh_stage_view(); messagebox.showinfo('Collision segment',f"Added {r['category']} line {r['line_index']} with vertices {r['vertex_indices']}.",parent=win)
            except Exception as e: messagebox.showerror('Add collision segment',str(e),parent=win)
        ttk.Button(af,text='Add Segment Structurally',command=add_seg).grid(row=2,column=0,columnspan=14,sticky='ew',pady=(6,0))

    def create_new_stage_wizard(self):
        """Create an authored stage without ever treating the requested new name as a donor.

        Phase 18 used three free-text prompts.  A mistyped/overwritten donor field could
        therefore turn the *new* filename into the lookup key and produce the cryptic
        KeyError shown as ``'GrXz.dat'``.  Phase 19 uses a constrained donor selector,
        validates everything before writing, and only opens the new StageDAT after the
        clone transaction has committed.
        """
        if not self.project:
            messagebox.showinfo('Create new stage', 'Open a project first.'); return
        if not self.project.stages:
            messagebox.showinfo('Create new stage', 'Import or load at least one donor stage first.'); return

        win=tk.Toplevel(self); win.title('Create NEW Stage'); win.transient(self); win.grab_set(); win.resizable(False,False)
        body=ttk.Frame(win,padding=12); body.pack(fill='both',expand=True)
        stages=sorted(self.project.stages,key=lambda x:x.display_name.lower())
        labels=[f'{x.display_name}  [{x.filename}]' for x in stages]
        default_i=0
        if self.stage and self.stage.path:
            for i,x in enumerate(stages):
                if x.filename.lower()==self.stage.path.name.lower(): default_i=i; break
        donor_var=tk.StringVar(value=labels[default_i]); file_var=tk.StringVar(value='GrMy.dat'); display_var=tk.StringVar(value='My Stage')
        ttk.Label(body,text='Template / donor stage').grid(row=0,column=0,sticky='w')
        donor_box=ttk.Combobox(body,textvariable=donor_var,values=labels,state='readonly',width=48); donor_box.grid(row=0,column=1,sticky='ew',padx=(8,0))
        ttk.Label(body,text='New DAT filename').grid(row=1,column=0,sticky='w',pady=(8,0)); ttk.Entry(body,textvariable=file_var,width=28).grid(row=1,column=1,sticky='w',padx=(8,0),pady=(8,0))
        ttk.Label(body,text='Project display name').grid(row=2,column=0,sticky='w',pady=(8,0)); ttk.Entry(body,textvariable=display_var,width=28).grid(row=2,column=1,sticky='w',padx=(8,0),pady=(8,0))
        status=ttk.Label(body,text='The donor must already exist. The new filename must not exist yet.',foreground='#666666'); status.grid(row=3,column=0,columnspan=2,sticky='w',pady=(10,0))
        buttons=ttk.Frame(body); buttons.grid(row=4,column=0,columnspan=2,sticky='e',pady=(12,0))
        result={'path':None,'filename':None,'donor':None}
        def create():
            try:
                idx=labels.index(donor_var.get()); donor=stages[idx].filename
                filename=Path(file_var.get().strip()).name
                display=display_var.get().strip() or Path(filename).stem
                # Full preflight happens before clone_stage_variant writes either file.
                self.project.preflight_new_stage(donor,filename)
                path=self.project.clone_stage_variant(donor,filename,display)
                result.update(path=path,filename=filename,donor=donor); win.destroy()
            except Exception as e:
                messagebox.showerror('Create new stage',str(e),parent=win)
        ttk.Button(buttons,text='Cancel',command=win.destroy).pack(side='right')
        ttk.Button(buttons,text='Create Stage',command=create).pack(side='right',padx=(0,6))
        self.wait_window(win)
        if not result['path']: return
        try:
            self.populate_stage_tree(); self.stage=StageDAT(result['path']); self.stage_dirty=False; self.refresh_stage_view()
        except Exception as e:
            messagebox.showerror('Open created stage',f'The stage was created, but reopening it failed:\n{e}',parent=self); return
        filename=result['filename']; donor=result['donor']
        messagebox.showinfo(
            'Stage created',
            f'{filename} was created successfully from {donor}.\n\n'
            'You can edit, preview, and save the stage now. Runtime installation is intentionally deferred.\n\n'
            'When you are ready to test it in Melee, use “Build / Test Stage…” from the Stage Workbench or Stage Builder.',
            parent=self)

    def install_current_stage_as_new_slot(self):
        if not self.project or not self.stage or not self.stage.path:
            messagebox.showinfo('New stage slot', 'Open a project and load an authored Gr*.dat stage first.')
            return
        row = next((r for r in self.project.manifest.get('resources', [])
                    if r['filename'].lower() == self.stage.path.name.lower()), {})
        src_rel = str(row.get('source_relative', ''))
        donor = 'GrNBa.dat'
        if src_rel.startswith('<authored from ') and src_rel.endswith('>'):
            donor = src_rel[len('<authored from '):-1]
        clean = filedialog.askopenfilename(title='Build / Test Stage — select clean GALE01 1.02 ISO',
                                           filetypes=[('GameCube ISO', '*.iso'), ('All files', '*.*')])
        if not clean:
            return
        try:
            verify_melee_102(clean, full_hash=True)
            plan = install_authored_stage_runtime(self.project, clean, self.stage.path.name, donor)
            messagebox.showinfo(
                'Stage ready for test build',
                f"{self.stage.path.name} is prepared for Melee using its authored donor profile ({donor}).\n\n"
                'The required runtime and disc-file entries are now staged in Working/.\n'
                'Next: use Build Modified Files / ISO tools to create the test ISO.\n\n'
                f"Advanced runtime identity: StKind 0x{plan['stkind']:02X} / GrKind 0x{plan['grkind']:02X}.",
                parent=self)
        except Exception as e:
            messagebox.showerror('New stage slot failed', str(e), parent=self)

    def open_character_slot_lab(self):
        if not self.project:
            messagebox.showinfo('Character Slot Lab', 'Open a project first.')
            return
        win = tk.Toplevel(self)
        win.title('Character Slot Lab — Boy/Girl Prototype')
        win.geometry('650x410')
        win.transient(self)
        body = ttk.Frame(win, padding=12)
        body.pack(fill='both', expand=True)
        ttk.Label(body,
                  text='Prototype a custom fighter on Melee’s reserved Male/Female Wireframe FighterKind.',
                  font=('TkDefaultFont', 10, 'bold')).pack(anchor='w')
        ttk.Label(body,
                  text=('This clones a donor fighter DAT/AJ into PlBo/PlGl, renames the ftData public root, '
                        'and patches source-validated FtKind callback tables. The reserved wireframe costume/model '
                        'remains in place for bring-up.'),
                  wraplength=610, justify='left').pack(anchor='w', pady=(5, 12))
        donor = tk.StringVar(value=self.fighter.fighter_name if self.fighter else 'Fox')
        target = tk.StringVar(value='Boy')
        row = ttk.Frame(body)
        row.pack(fill='x')
        ttk.Label(row, text='Donor fighter').pack(side='left')
        cb = ttk.Combobox(row, textvariable=donor, state='readonly',
                          values=[f.fighter_name for f in self.project.fighters], width=20)
        cb.pack(side='left', padx=(6, 16))
        ttk.Label(row, text='Prototype slot').pack(side='left')
        ttk.Combobox(row, textvariable=target, state='readonly', values=['Boy', 'Girl'], width=10).pack(side='left', padx=(6, 0))
        info = tk.Text(body, height=10, wrap='word')
        info.pack(fill='both', expand=True, pady=(12, 8))
        info.insert('1.0',
                    'Current milestone:\n'
                    '• New FighterKind table expansion is avoided initially.\n'
                    '• Boy/Girl already have CharacterKind/FighterKind identities and filenames.\n'
                    '• CSS icon/portrait integration remains separate from the runtime prototype.\n'
                    '• Final skeleton/model/animation authoring can be done after the slot boots reliably.\n')
        info.configure(state='disabled')

        def build_proto():
            clean = filedialog.askopenfilename(parent=win, title='Select clean GALE01 1.02 ISO',
                                               filetypes=[('GameCube ISO', '*.iso'), ('All files', '*.*')])
            if not clean:
                return
            try:
                verify_melee_102(clean, full_hash=True)
                plan = install_fighter_prototype_runtime(self.project, clean, donor.get(), target.get())
                messagebox.showinfo(
                    'Prototype prepared',
                    f"{target.get()} now uses the {donor.get()} prototype asset/callback profile.\n"
                    f"DOL patches: {plan['dol_patch_count']}\n\n"
                    'Build Modified Files, then rebuild the ISO. CSS visibility is not yet automatic.',
                    parent=win)
            except Exception as e:
                messagebox.showerror('Prototype failed', str(e), parent=win)
        ttk.Button(body, text='Prepare Prototype Fighter', command=build_proto).pack(anchor='e')


    def quick_import_mod(self):
        if not self.project:
            messagebox.showinfo('Quick Import Mod', 'Open a project first.'); return
        path=filedialog.askopenfilename(title='Select custom stage/fighter DAT or ZIP',
            filetypes=[('Mod packages', '*.zip *.dat'), ('ZIP files','*.zip'), ('DAT files','*.dat'), ('All files','*.*')])
        if not path: return
        try: report=inspect_mod_package(path)
        except Exception as e: messagebox.showerror('Quick Import Mod',str(e)); return
        if report['stage_count'] and not report['fighter_base_count']:
            self._quick_import_stage_path(path); return
        if report['fighter_base_count'] and not report['stage_count']:
            self._quick_import_fighter_path(path); return
        if report['stage_count'] and report['fighter_base_count']:
            choice=messagebox.askyesnocancel('Mixed mod package','This package contains both stage and fighter resources.\n\nYes = import stage\nNo = import fighter\nCancel = stop')
            if choice is True: self._quick_import_stage_path(path)
            elif choice is False: self._quick_import_fighter_path(path)
            return
        messagebox.showwarning('Quick Import Mod','No valid Gr*.dat stage or standard Pl*.dat fighter resource was found.')

    def _quick_import_stage_path(self,path):
        if not self.project: return
        names=[s.filename for s in self.project.stages]
        as_new=messagebox.askyesno('Stage import mode','Install this as a NEW independent stage resource?\n\nChoose No to replace an existing stage slot for fastest testing.')
        try:
            if as_new:
                fn=simpledialog.askstring('New stage filename','New Gr*.dat filename:',initialvalue='GrCustom.dat',parent=self)
                if not fn:return
                result=import_stage_package(self.project,path,as_new=True,new_filename=fn)
            else:
                target=simpledialog.askstring('Replace stage','Existing target DAT filename:',initialvalue='GrNBa.dat',parent=self)
                if not target:return
                result=import_stage_package(self.project,path,target_filename=target)
            self.populate_stage_tree()
            self.stage=StageDAT(self.project.working_dir/result['installed_file']); self.stage_dirty=False; self.refresh_stage_view()
            messagebox.showinfo('Stage imported',f"Installed {result['source_file']} → Working/{result['installed_file']}\n\nBuild/repack the ISO when ready.")
        except Exception as e: messagebox.showerror('Stage import failed',str(e))

    def quick_inject_stage(self):
        if not self.project:
            messagebox.showinfo('Quick Inject Stage','Open a project first.'); return
        path=filedialog.askopenfilename(title='Select custom stage DAT or ZIP',filetypes=[('Stage/mod files','*.dat *.zip'),('All files','*.*')])
        if path:self._quick_import_stage_path(path)

    def _quick_import_fighter_path(self,path):
        if not self.project:return
        target=simpledialog.askstring('Fighter import','Optional target prefix (leave blank for drop-in names, e.g. PlFx):',initialvalue='',parent=self)
        try:
            result=import_fighter_package(self.project,path,target_prefix=(target.strip() if target and target.strip() else None))
            messagebox.showinfo('Fighter package imported',f"Installed {result['count']} fighter resource(s) into Working/.\n\n"+'\n'.join(result['installed'][:18]))
            self._after_project_open('Fighter package imported into Working/.')
        except Exception as e: messagebox.showerror('Fighter import failed',str(e))

    def _stage_builder_snapshot(self):
        """Save an in-memory undo point for friendly-builder mutations."""
        if not self.stage:
            return
        if not hasattr(self, '_stage_builder_undo'):
            self._stage_builder_undo=[]
        self._stage_builder_undo.append((self.stage.filename, self.stage.bytes()))
        # Builder undo is intentionally shallow and session-local.
        if len(self._stage_builder_undo) > 20:
            del self._stage_builder_undo[0]

    def _stage_builder_undo_last(self, parent=None):
        stack=getattr(self, '_stage_builder_undo', [])
        if not self.stage or not stack:
            messagebox.showinfo('Builder Undo','There is no Stage Builder add/delete action to undo.',parent=parent or self)
            return False
        old=self.stage
        filename, raw=stack[-1]
        if filename != old.filename:
            stack.clear()
            messagebox.showinfo('Builder Undo','The undo history belongs to a different stage and was cleared.',parent=parent or self)
            return False
        stack.pop()
        restored=StageDAT(raw)
        restored.path=old.path
        restored.filename=old.filename
        restored.catalog=old.catalog
        self.stage=restored
        self.stage_dirty=True
        self.refresh_stage_view()
        return True

    def open_add_stage_asset_dialog(self, parent=None, *, primitive_key='slope', library_row=None, source_label=''):
        """Friendly collision-construction layer above the existing Advanced editor.

        New primitives and retail-library copies use the same source-validated
        StageDAT structural insertion routine. The existing Layout/Collision tool
        remains the precision/advanced surface editor.
        """
        if not self.stage:
            messagebox.showinfo('Add Asset','Load a stage first.',parent=parent or self); return False
        win=tk.Toplevel(parent or self)
        is_library=library_row is not None
        win.title('Add Retail Collision Asset' if is_library else 'Add Architecture Primitive')
        win.geometry('720x650' if is_library else '720x700')
        win.transient(parent or self); win.grab_set(); win.configure(background='#0f1720')
        body=ttk.Frame(win,padding=12); body.pack(fill='both',expand=True)
        ttk.Label(body,text='Add to Working Stage',style='Title.TLabel').pack(anchor='w')
        subtitle=('Copy one source collision record. Visual JObjs, textures and animation are intentionally not copied.'
                  if is_library else
                  'Create clean gameplay collision without having to edit raw MapLine records.')
        ttk.Label(body,text=subtitle,style='Muted.TLabel',wraplength=675,justify='left').pack(anchor='w',pady=(2,10))

        form=ttk.Frame(body); form.pack(fill='x')
        if is_library:
            category=str(library_row.get('category','Floor'))
            ttk.Label(form,text='Retail source').grid(row=0,column=0,sticky='w')
            ttk.Label(form,text=source_label or 'Catalogued collision record',font=('TkDefaultFont',10,'bold')).grid(row=0,column=1,columnspan=3,sticky='w',padx=(8,0))
            ttk.Label(form,text='Collision category').grid(row=1,column=0,sticky='w',pady=(8,0))
            ttk.Label(form,text=category).grid(row=1,column=1,sticky='w',padx=(8,0),pady=(8,0))
            offx=tk.StringVar(value='0'); offy=tk.StringVar(value='0'); scalex=tk.StringVar(value='1'); scaley=tk.StringVar(value='1'); flipx=tk.BooleanVar(value=False)
            labels=(('Offset X',offx),('Offset Y',offy),('Scale X',scalex),('Scale Y',scaley))
            for i,(lbl,var) in enumerate(labels):
                r=2+i//2; c=(i%2)*2
                ttk.Label(form,text=lbl).grid(row=r,column=c,sticky='w',pady=(8,0)); ttk.Entry(form,textvariable=var,width=13).grid(row=r,column=c+1,sticky='w',padx=(8,18),pady=(8,0))
            ttk.Checkbutton(form,text='Flip horizontally',variable=flipx).grid(row=4,column=0,columnspan=2,sticky='w',pady=(8,0))
            p0=library_row.get('p0',[0,0]); p1=library_row.get('p1',[10,0])
            material=tk.StringVar(value=str(library_row.get('material_id',0)))
            platform=tk.BooleanVar(value=bool(library_row.get('platform',False)))
            ledge=tk.BooleanVar(value=bool(library_row.get('ledge',False)))
            dynamic=tk.BooleanVar(value=bool(library_row.get('dynamic_platform_source',False)))
        else:
            keys=[p.key for p in PRIMITIVES]; labels=[p.label for p in PRIMITIVES]
            if primitive_key not in PRIMITIVE_BY_KEY: primitive_key='slope'
            primvar=tk.StringVar(value=PRIMITIVE_BY_KEY[primitive_key].label)
            ttk.Label(form,text='Primitive').grid(row=0,column=0,sticky='w')
            primbox=ttk.Combobox(form,textvariable=primvar,values=labels,state='readonly',width=34); primbox.grid(row=0,column=1,columnspan=3,sticky='w',padx=(8,0))
            category=PRIMITIVE_BY_KEY[primitive_key].category
            x0=tk.StringVar(); y0=tk.StringVar(); x1=tk.StringVar(); y1=tk.StringVar(); material=tk.StringVar(value='0')
            platform=tk.BooleanVar(); ledge=tk.BooleanVar(); dynamic=tk.BooleanVar()
            p0=p1=None

        jointvar=tk.StringVar()
        joint_map={}
        ttk.Label(form,text='Collision owner').grid(row=5,column=0,sticky='w',pady=(10,0))
        jointbox=ttk.Combobox(form,textvariable=jointvar,state='readonly',width=48); jointbox.grid(row=5,column=1,columnspan=3,sticky='w',padx=(8,0),pady=(10,0))
        descvar=tk.StringVar()
        ttk.Label(body,textvariable=descvar,wraplength=675,justify='left',style='Muted.TLabel').pack(anchor='w',pady=(10,6))

        coords=ttk.LabelFrame(body,text='Placement / Collision',padding=8); coords.pack(fill='x',pady=(4,0))
        if not is_library:
            for i,(lbl,var) in enumerate((('X0',x0),('Y0',y0),('X1',x1),('Y1',y1))):
                ttk.Label(coords,text=lbl).grid(row=0,column=i*2,sticky='w'); ttk.Entry(coords,textvariable=var,width=10).grid(row=0,column=i*2+1,sticky='w',padx=(4,12))
        ttk.Label(coords,text='Material ID').grid(row=1,column=0,sticky='w',pady=(8,0)); ttk.Entry(coords,textvariable=material,width=10).grid(row=1,column=1,sticky='w',padx=(4,12),pady=(8,0))
        ttk.Checkbutton(coords,text='Soft / pass-through flag',variable=platform).grid(row=2,column=0,columnspan=2,sticky='w',pady=(8,0))
        ttk.Checkbutton(coords,text='Grab / ledge flag',variable=ledge).grid(row=2,column=2,columnspan=2,sticky='w',pady=(8,0))
        ttk.Checkbutton(coords,text='Dynamic-floor source bit',variable=dynamic).grid(row=2,column=4,columnspan=3,sticky='w',pady=(8,0))
        ttk.Label(coords,text='These are the same source-known properties exposed in Advanced Collision; the advanced editor remains available for precise follow-up changes.',wraplength=640,justify='left',style='Muted.TLabel').grid(row=3,column=0,columnspan=8,sticky='w',pady=(8,0))

        preview=ttk.LabelFrame(body,text='Placement Preview',padding=6); preview.pack(fill='both',expand=True,pady=(10,0))
        canvas=tk.Canvas(preview,height=190,bg='#111922',highlightthickness=0); canvas.pack(fill='both',expand=True)

        current={'key':primitive_key,'category':category}
        def refresh_joint_choices(cat):
            joint_map.clear(); vals=[]; joints=self.stage.map_joints()
            for idx in compatible_joint_indices(self.stage,cat):
                j=joints[idx]; label=f"Joint {idx}  •  vertices {j.get('vtx_count',0)}  •  bounds {j.get('left_bound',0):.0f},{j.get('bottom_bound',0):.0f} → {j.get('right_bound',0):.0f},{j.get('top_bound',0):.0f}"
                vals.append(label); joint_map[label]=idx
            jointbox['values']=vals
            if vals:
                try: sug=suggested_joint_index(self.stage,cat); chosen=next(v for v in vals if joint_map[v]==sug)
                except Exception: chosen=vals[0]
                jointvar.set(chosen)
            else: jointvar.set('')

        def endpoint_values():
            if is_library:
                sx=float(scalex.get()); sy=float(scaley.get()); ox=float(offx.get()); oy=float(offy.get())
                if flipx.get(): sx=-sx
                return (float(p0[0])*sx+ox,float(p0[1])*sy+oy,float(p1[0])*sx+ox,float(p1[1])*sy+oy)
            return tuple(float(v.get()) for v in (x0,y0,x1,y1))

        def draw_preview(*_):
            canvas.delete('all'); w=max(canvas.winfo_width(),640); h=max(canvas.winfo_height(),180)
            canvas.create_rectangle(0,0,w,h,fill='#111922',outline='')
            for gx in range(0,w,32): canvas.create_line(gx,0,gx,h,fill='#1d2a36')
            for gy in range(0,h,32): canvas.create_line(0,gy,w,gy,fill='#1d2a36')
            canvas.create_line(w/2,0,w/2,h,fill='#3b5368'); canvas.create_line(0,h/2,w,h/2,fill='#3b5368')
            try: a,b,c,d=endpoint_values()
            except Exception:
                canvas.create_text(12,12,anchor='nw',fill='#d4a8a8',text='Enter valid numeric placement values.'); return
            span=max(abs(a),abs(c),abs(b),abs(d),25.0); scale=min((w-100)/(2*span),(h-50)/(2*span))
            tx=lambda x:w/2+x*scale; ty=lambda y:h/2-y*scale
            canvas.create_line(tx(a),ty(b),tx(c),ty(d),fill='#69c0ff',width=4)
            canvas.create_oval(tx(a)-5,ty(b)-5,tx(a)+5,ty(b)+5,fill='#e8eef5',outline='')
            canvas.create_oval(tx(c)-5,ty(d)-5,tx(c)+5,ty(d)+5,fill='#e8eef5',outline='')
            canvas.create_text(12,12,anchor='nw',fill='#bac8d6',text=f'({a:.1f}, {b:.1f})  →  ({c:.1f}, {d:.1f})')

        def load_primitive(*_):
            if is_library:
                refresh_joint_choices(category); descvar.set('Collision-only retail copy. After insertion, use Advanced Collision for line-level flags/indices or to split/join/delete it.'); draw_preview(); return
            key=keys[labels.index(primvar.get())]; p=PRIMITIVE_BY_KEY[key]; current.update(key=key,category=p.category)
            for var,val in ((x0,p.x0),(y0,p.y0),(x1,p.x1),(y1,p.y1)): var.set(str(val))
            platform.set(p.platform); ledge.set(p.ledge); dynamic.set(p.dynamic_platform_source)
            descvar.set(p.description); refresh_joint_choices(p.category); draw_preview()
        if not is_library: primbox.bind('<<ComboboxSelected>>',load_primitive)
        for var in ([offx,offy,scalex,scaley] if is_library else [x0,y0,x1,y1]): var.trace_add('write',draw_preview)
        if is_library: flipx.trace_add('write',draw_preview)
        canvas.bind('<Configure>',draw_preview)
        load_primitive()

        buttons=ttk.Frame(body); buttons.pack(fill='x',pady=(10,0))
        def advanced():
            win.destroy(); self.open_stage_authoring_tools()
        ttk.Button(buttons,text='Advanced Collision…',command=advanced).pack(side='left')
        result={'added':False}
        def commit():
            try:
                if not jointvar.get(): raise ValueError('No compatible collision owner is available for this category.')
                ji=joint_map[jointvar.get()]
                self._stage_builder_snapshot()
                if is_library:
                    r=add_library_collision_line(self.stage,library_row,joint_index=ji,
                        offset_x=float(offx.get()),offset_y=float(offy.get()),scale_x=float(scalex.get()),scale_y=float(scaley.get()),flip_x=flipx.get())
                    # Allow intentional flag/material override after the source copy.
                    self.stage.set_line_surface(r['line_index'],material_id=int(material.get()),platform=platform.get(),ledge=ledge.get(),dynamic_platform_source=dynamic.get())
                    label='retail collision asset'
                else:
                    a,b,c,d=endpoint_values(); key=current['key']
                    r=add_primitive(self.stage,key,joint_index=ji,x0=a,y0=b,x1=c,y1=d,material_id=int(material.get()),platform=platform.get(),ledge=ledge.get(),dynamic_platform_source=dynamic.get())
                    label=PRIMITIVE_BY_KEY[key].label
                self.stage_dirty=True; self.refresh_stage_view(); result['added']=True; win.destroy()
                messagebox.showinfo('Asset added',f"Added {label} as collision line {r['line_index']} on Joint {r['joint_index']}.\n\nUse Advanced Collision… for exact flags, splitting, joining, or deletion.",parent=parent or self)
            except Exception as e:
                # Roll back atomically if any part of the friendly builder operation fails.
                if getattr(self,'_stage_builder_undo',None): self._stage_builder_undo_last(win)
                messagebox.showerror('Add Asset failed',str(e),parent=win)
        ttk.Button(buttons,text='Cancel',command=win.destroy).pack(side='right')
        ttk.Button(buttons,text='Add to Stage',style='Accent.TButton',command=commit).pack(side='right',padx=(0,6))
        self.wait_window(win)
        return result['added']

    def open_stage_asset_lab(self):
        """Human-oriented stage builder inventory.

        Earlier phases exposed JObjs and textures as a reverse-engineering lab.  The
        same safe writers remain, but the window is now organized around stage-
        building tasks and explicitly labels what is editable, partial, inventoried,
        external, or still undecoded.
        """
        if not self.stage:
            messagebox.showinfo('Stage Builder','Load a stage first.'); return
        win=tk.Toplevel(self); win.title('Stage Builder Studio — Architecture, Assets, Gameplay & Preview'); win.geometry('1320x820'); win.minsize(1100,720); win.transient(self); win.configure(background='#0f1720')
        body=ttk.Frame(win,padding=10); body.pack(fill='both',expand=True)
        ed=StageAssetEditor(self.stage)
        try: report=stage_builder_report(self.stage)
        except Exception as e:
            messagebox.showerror('Stage Builder',f'Could not catalogue the loaded stage:\n{e}',parent=win); win.destroy(); return

        top=ttk.Frame(body); top.pack(fill='x',pady=(0,8))
        ttk.Label(top,text=f"{report['name']}",style='Title.TLabel').pack(side='left')
        ttk.Label(top,text=f"  {report['filename']}",style='Muted.TLabel').pack(side='left')
        ttk.Label(top,text=f"{report['family']}  •  {report['archive']['bytes']:,} bytes",foreground='#666666').pack(side='left',padx=(10,0))
        ttk.Button(top,text='Build / Test Stage…',style='Accent.TButton',command=self.install_current_stage_as_new_slot).pack(side='right')
        ttk.Button(top,text='Advanced Collision…',command=self.open_stage_authoring_tools).pack(side='right',padx=(0,6))
        def show_draft_preview():
            try:
                path=Path(tempfile.gettempdir())/f'melee_sdk_{Path(report["filename"]).stem}_draft.png'
                render_stage_draft_png(self.stage,path)
                pv=tk.Toplevel(win); pv.title(f'Draft Preview — {report["name"]}'); pv.geometry('1120x690'); pv.transient(win)
                img=tk.PhotoImage(file=str(path)); pv._stage_preview_image=img
                frame=ttk.Frame(pv,padding=8); frame.pack(fill='both',expand=True)
                ttk.Label(frame,image=img).pack(fill='both',expand=True)
                bf=ttk.Frame(frame); bf.pack(fill='x',pady=(6,0))
                ttk.Label(bf,text='Orthographic gameplay-layout preview: grid + collision + known markers. This is not yet a Dolphin/HSD mesh renderer.',foreground='#555555').pack(side='left')
                def save_preview():
                    dst=filedialog.asksaveasfilename(parent=pv,title='Save draft preview',defaultextension='.png',filetypes=[('PNG image','*.png')])
                    if dst:
                        Path(dst).write_bytes(path.read_bytes())
                ttk.Button(bf,text='Save Screenshot…',command=save_preview).pack(side='right')
            except Exception as e: messagebox.showerror('Draft preview',str(e),parent=win)
        ttk.Button(top,text='Draft Preview…',command=show_draft_preview).pack(side='right',padx=(0,6))
        def add_asset_top():
            if self.open_add_stage_asset_dialog(win,primitive_key='slope'):
                win.destroy(); self.open_stage_asset_lab()
        ttk.Button(top,text='+ Add Asset',style='Accent.TButton',command=add_asset_top).pack(side='right',padx=(0,6))
        def undo_builder():
            if self._stage_builder_undo_last(win):
                win.destroy(); self.open_stage_asset_lab()
        ttk.Button(top,text='Undo Builder',command=undo_builder).pack(side='right',padx=(0,6))

        nb=ttk.Notebook(body); nb.pack(fill='both',expand=True)
        ov=ttk.Frame(nb,padding=8); lib=ttk.Frame(nb,padding=8); ar=ttk.Frame(nb,padding=8); mk=ttk.Frame(nb,padding=8); jt=ttk.Frame(nb,padding=8); tx=ttk.Frame(nb,padding=8); adv=ttk.Frame(nb,padding=8)
        nb.add(ov,text='Builder Overview'); nb.add(lib,text='Asset Library'); nb.add(ar,text='Current Stage Architecture'); nb.add(mk,text='Gameplay Markers'); nb.add(jt,text='Scene Objects'); nb.add(tx,text='Textures'); nb.add(adv,text='Advanced / Undecoded')

        # Overview: the important part is making capability boundaries obvious.
        c=report['layout']['collision'] or {}
        summary=(f"Collision: {c.get('vertex_count','—')} vertices / {c.get('line_count','—')} lines / {report['layout']['map_joint_count']} MapJoints    "
                 f"Markers: {report['layout']['marker_count']}    JObjs: {report['visuals']['jobj_count']}    "
                 f"Textures: {report['visuals']['texture_count']} ({report['visuals']['png_replaceable_count']} PNG-replaceable)")
        ttk.Label(ov,text=summary,font=('TkDefaultFont',10,'bold'),wraplength=990,justify='left').pack(anchor='w',pady=(0,8))
        ttk.Label(ov,text='Builder status tells you whether an asset is safe to edit now or merely understood enough to inventory. Unknown data stays visible instead of being given a guessed meaning.',wraplength=990,justify='left',foreground='#555555').pack(anchor='w',pady=(0,8))
        tree=ttk.Treeview(ov,columns=('area','status','storage','support'),show='headings',height=22)
        for col,title,width in [('area','Area',135),('status','Status',95),('storage','Stored in',250),('support','What the SDK can do now',520)]:
            tree.heading(col,text=title); tree.column(col,width=width,stretch=(col=='support'))
        for a in ASSET_CLASSES:
            tree.insert('', 'end', values=(a.area,f'{a.status} — {a.label}',a.storage,a.builder_support))
        tree.pack(fill='both',expand=True)

        # Type-first retail architecture library: browse an asset need first,
        # then compare which source stages contain it.
        library_path=Path(__file__).resolve().parent/'data'/'stage_builder_catalog'/'stage_architecture_asset_library.json'
        try: library=json.loads(library_path.read_text(encoding='utf-8'))
        except Exception: library={'types':{},'type_labels':{}}
        lp=ttk.Panedwindow(lib,orient='horizontal'); lp.pack(fill='both',expand=True)
        lleft=ttk.Frame(lp,padding=(0,0,8,0)); lright=ttk.Frame(lp); lp.add(lleft,weight=1); lp.add(lright,weight=2)
        ltree=ttk.Treeview(lleft,columns=('count',),show='tree headings'); ltree.heading('#0',text='Asset type → source stage'); ltree.heading('count',text='Lines'); ltree.column('#0',width=330); ltree.column('count',width=60,anchor='e')
        stage_lookup={}
        for key,label in library.get('type_labels',{}).items():
            parent='type:'+key; stages=library.get('types',{}).get(key,[]); ltree.insert('', 'end',iid=parent,text=label,values=(sum(x['line_count'] for x in stages),),open=False)
            for i,st in enumerate(stages):
                iid=f'{key}:{i}'; stage_lookup[iid]=(key,st); ref=' ★' if st.get('reference_groups') else ''
                ltree.insert(parent,'end',iid=iid,text=f"{st['stage_name']} [{st['filename']}]"+ref,values=(st['line_count'],))
        ltree.pack(fill='both',expand=True)
        ldetail=ttk.Treeview(lright,columns=('line','category','props','xy'),show='headings')
        for col,title,width in [('line','Line',55),('category','Category',110),('props','Properties',210),('xy','Geometry',360)]: ldetail.heading(col,text=title); ldetail.column(col,width=width,stretch=(col=='xy'))
        ldetail.pack(fill='both',expand=True)
        lnote=tk.StringVar(value='Choose an asset type, then a source stage. ★ marks the competitive-reference group. Select a collision record and use Add Selected Collision to copy its gameplay geometry. Visual/JObj/texture/animation transplantation remains a later layer.')
        ttk.Label(lright,textvariable=lnote,wraplength=700,justify='left',foreground='#555555').pack(anchor='w',pady=(7,0))
        asset_line_lookup={}; selected_source={'label':''}
        def lib_select(_evt=None):
            asset_line_lookup.clear()
            for x in ldetail.get_children(): ldetail.delete(x)
            sel=ltree.selection()
            if not sel or sel[0] not in stage_lookup:return
            key,st=stage_lookup[sel[0]]; selected_source['label']=f"{st['stage_name']} [{st['filename']}]"
            for n,r in enumerate(st['lines']):
                props=[]
                if r.get('platform'):props.append('soft/drop-through')
                if r.get('ledge'):props.append('ledge/grab')
                if r.get('dynamic_platform_source'):props.append('dynamic source')
                if r.get('is_slope'):props.append('slope')
                iid=f'assetline:{n}'; asset_line_lookup[iid]=r
                ldetail.insert('', 'end',iid=iid,values=(r['index'],r['category'],', '.join(props) or 'plain',f"({r['p0'][0]:.1f},{r['p0'][1]:.1f}) → ({r['p1'][0]:.1f},{r['p1'][1]:.1f})"))
            lnote.set(f"{ARCHITECTURE_TYPE_LABELS.get(key,key)} from {st['stage_name']} — {st['line_count']} source collision record(s). Collision-only copying is available below. Visual/JObj/texture/animation ownership is intentionally not transplanted yet.")
        ltree.bind('<<TreeviewSelect>>',lib_select)
        libbuttons=ttk.Frame(lright); libbuttons.pack(fill='x',pady=(7,0))
        ttk.Label(libbuttons,text='Copies gameplay collision only; source visuals stay behind.',style='Muted.TLabel').pack(side='left')
        def add_selected_library_asset():
            sel=ldetail.selection()
            if not sel or sel[0] not in asset_line_lookup:
                messagebox.showinfo('Asset Library','Select a collision record on the right first.',parent=win); return
            if self.open_add_stage_asset_dialog(win,library_row=asset_line_lookup[sel[0]],source_label=selected_source['label']):
                win.destroy(); self.open_stage_asset_lab()
        ttk.Button(libbuttons,text='Add Selected Collision to Stage…',style='Accent.TButton',command=add_selected_library_asset).pack(side='right')

        # Architecture: present collision in the language of stage design.
        arch=report['architecture_assets']['architecture']
        af=ttk.Frame(ar); af.pack(fill='x',pady=(0,7))
        group=', '.join(report['architecture_assets']['reference_groups']) or 'General retail resource'
        ttk.Label(af,text=f'Reference group: {group}',font=('TkDefaultFont',10,'bold')).pack(side='left')
        ttk.Label(af,text='  •  Soft platforms use the source-known platform flag; ceilings stay explicit.',foreground='#555555').pack(side='left')
        panes=ttk.Panedwindow(ar,orient='horizontal'); panes.pack(fill='both',expand=True)
        left=ttk.Frame(panes,padding=(0,0,8,0)); right=ttk.Frame(panes); panes.add(left,weight=1); panes.add(right,weight=2)
        atree=ttk.Treeview(left,columns=('count',),show='tree headings',height=18); atree.heading('#0',text='Asset type'); atree.heading('count',text='Lines'); atree.column('#0',width=260); atree.column('count',width=70,anchor='e')
        for key,label in ASSET_LIBRARY_TYPE_LABELS.items():
            atree.insert('', 'end', iid=key,text=label,values=(arch['type_counts'].get(key,0),))
        atree.pack(fill='both',expand=True)
        detail=ttk.Treeview(right,columns=('line','category','flags','material','geometry'),show='headings')
        for col,title,width in [('line','Line',55),('category','Collision category',125),('flags','Builder properties',210),('material','Material',70),('geometry','Endpoints / angle',320)]: detail.heading(col,text=title); detail.column(col,width=width,stretch=(col=='geometry'))
        detail.pack(fill='both',expand=True)
        helpv=tk.StringVar(value='Select an architecture type. Ledge records show grab-enabled collision edges; soft platforms are one-way/drop-through candidates without inventing ceiling geometry.')
        ttk.Label(right,textvariable=helpv,wraplength=690,justify='left',foreground='#555555').pack(anchor='w',pady=(7,0))
        archbuttons=ttk.Frame(right); archbuttons.pack(fill='x',pady=(7,0))
        ttk.Button(archbuttons,text='+ Add Primitive…',style='Accent.TButton',command=lambda: (win.destroy(), self.open_add_stage_asset_dialog(self,primitive_key='slope'), self.open_stage_asset_lab())).pack(side='left')
        ttk.Button(archbuttons,text='Advanced Collision…',command=self.open_stage_authoring_tools).pack(side='left',padx=(6,0))
        def remove_current_line():
            sel=detail.selection()
            if not sel: messagebox.showinfo('Remove collision','Select a collision line first.',parent=win); return
            vals=detail.item(sel[0],'values')
            try: idx=int(vals[0])
            except Exception: return
            if not messagebox.askyesno('Remove collision',f'Delete collision line {idx} from the working stage?\n\nThis can be undone with Undo Builder until the SDK is closed.',parent=win): return
            try:
                self._stage_builder_snapshot(); self.stage.delete_collision_line(idx); self.stage_dirty=True; self.refresh_stage_view(); win.destroy(); self.open_stage_asset_lab()
            except Exception as e:
                if getattr(self,'_stage_builder_undo',None): self._stage_builder_undo_last(win)
                messagebox.showerror('Remove collision',str(e),parent=win)
        ttk.Button(archbuttons,text='Remove Selected',command=remove_current_line).pack(side='right')
        def refresh_arch(_evt=None):
            for x in detail.get_children(): detail.delete(x)
            sel=atree.selection()
            if not sel:return
            key=sel[0]
            rows=arch['types'].get(key,[])
            for r in rows:
                flags=[]
                if r.get('platform'): flags.append('soft/drop-through')
                if r.get('ledge'): flags.append('ledge/grab')
                if r.get('dynamic_platform_source'): flags.append('dynamic source')
                if r.get('is_slope'): flags.append('slope')
                detail.insert('', 'end',values=(r['index'],r['category'],', '.join(flags) or 'plain',r['material_id'],f"({r['p0'][0]:.2f}, {r['p0'][1]:.2f}) → ({r['p1'][0]:.2f}, {r['p1'][1]:.2f})  {r['angle_deg']:.1f}°"))
            helpv.set(f"{ARCHITECTURE_TYPE_LABELS.get(key,key)}: {len(rows)} line record(s) in {report['name']}. The packaged corpus catalogue indexes the same category across all 71 retail resources.")
        atree.bind('<<TreeviewSelect>>',refresh_arch); atree.selection_set('base_floor'); refresh_arch()
        mot=ttk.LabelFrame(ar,text='Moving-platform path vocabulary (authoring roadmap)',padding=6); mot.pack(fill='x',pady=(8,0))
        ttk.Label(mot,text='  •  '.join(f"{x['label']} [{x['runtime_status']}]" for x in MOTION_PATH_PRESETS),wraplength=1000,justify='left').pack(anchor='w')
        ttk.Label(mot,text='Horizontal Back-and-Forth is the Smashville-style first target; Rectangular Loop is the Randall-style target. Paths are defined now for builder/preview work, but runtime animation-track writing remains intentionally disabled until AnimJoint/FObj ownership is safe.',wraplength=1000,justify='left',foreground='#7a4d00').pack(anchor='w',pady=(3,0))

        # Markers: separate source-known gameplay markers from stage-specific unknowns.
        mt=ttk.Treeview(mk,columns=('id','meaning','x','y','z','state'),show='headings')
        for col,title,width in [('id','ID',65),('meaning','Meaning',260),('x','World X',110),('y','World Y',110),('z','World Z',110),('state','Semantic status',150)]: mt.heading(col,text=title); mt.column(col,width=width)
        markers=self.stage.markers()
        for i,m in enumerate(markers):
            known=not m.name.startswith('Marker 0x')
            mt.insert('', 'end', iid=str(i), values=(f'0x{m.marker_id:02X}',m.name,f'{m.world_x:.3f}',f'{m.world_y:.3f}',f'{m.world_z:.3f}','Known' if known else 'Undecoded'))
        mt.pack(fill='both',expand=True)
        mf=ttk.Frame(mk); mf.pack(fill='x',pady=(7,0))
        ttk.Label(mf,text='0x00–0x07 = player/respawn markers; 0x94–0x98 = camera/blast markers. Other IDs are deliberately not guessed.',foreground='#555555').pack(side='left')
        def edit_marker():
            sel=mt.selection()
            if not sel:return
            m=markers[int(sel[0])]
            val=simpledialog.askstring('Edit marker world position',f'{m.name}\nX, Y, Z:',initialvalue=f'{m.world_x}, {m.world_y}, {m.world_z}',parent=win)
            if not val:return
            try:
                xyz=[float(x.strip()) for x in val.split(',')]
                if len(xyz)!=3: raise ValueError('Enter exactly X, Y, Z')
                occurrence=sum(1 for x in markers[:int(sel[0])] if x.marker_id==m.marker_id)
                self.stage.set_marker_world(m.marker_id,*xyz,occurrence=occurrence); self.stage_dirty=True; self.refresh_stage_view(); win.destroy(); self.open_stage_asset_lab()
            except Exception as e: messagebox.showerror('Marker edit failed',str(e),parent=win)
        ttk.Button(mf,text='Edit Selected Marker…',command=edit_marker).pack(side='right')

        # Scene objects / JObjs.
        joints=ed.joint_inventory(); jtree=ttk.Treeview(jt,columns=('root','off','parent','pos','scale','dobj'),show='headings')
        for col,title,width in [('root','Root',55),('off','Offset',90),('parent','Parent',65),('pos','Position',260),('scale','Scale',220),('dobj','Draw object',90)]: jtree.heading(col,text=title); jtree.column(col,width=width)
        for j in joints:
            jtree.insert('', 'end', iid=str(j['offset']), values=(j['root_index'],f"0x{j['offset']:X}",j['parent_index'] if j['parent_index'] is not None else '—',', '.join(f'{v:.3f}' for v in j['position']),', '.join(f'{v:.3f}' for v in j['scale']),'Yes' if j.get('has_dobj') else 'No'))
        jtree.pack(fill='both',expand=True)
        jf=ttk.Frame(jt); jf.pack(fill='x',pady=(6,0)); ttk.Label(jf,text='These are visual/base transforms. Gameplay collision is edited separately.',foreground='#555555').pack(side='left')
        def edit_joint():
            sel=jtree.selection()
            if not sel:return
            off=int(sel[0]); j=next(x for x in joints if x['offset']==off)
            val=simpledialog.askstring('Edit JObj position','X, Y, Z:',initialvalue=', '.join(str(v) for v in j['position']),parent=win)
            if not val:return
            try:
                xyz=[float(x.strip()) for x in val.split(',')]; ed.set_joint_transform(off,position=xyz); self.stage_dirty=True; self.refresh_stage_view(); win.destroy(); self.open_stage_asset_lab()
            except Exception as e:messagebox.showerror('JObj edit failed',str(e),parent=win)
        ttk.Button(jf,text='Edit Selected Position…',command=edit_joint).pack(side='right')

        # Textures.
        textures=ed.textures(); ttree=ttk.Treeview(tx,columns=('fmt','size','mip','editable'),show='tree headings'); ttree.heading('#0',text='Texture symbol'); ttree.heading('fmt',text='GX format'); ttree.heading('size',text='Dimensions'); ttree.heading('mip',text='Mip'); ttree.heading('editable',text='PNG import'); ttree.column('#0',width=470)
        for i,t in enumerate(textures): ttree.insert('', 'end', iid=str(i),text=t.symbol,values=(t.format_name,f'{t.width}x{t.height}',t.mipmap,'Yes' if t.png_replace_supported else 'Read-only'))
        ttree.pack(fill='both',expand=True)
        tf=ttk.Frame(tx); tf.pack(fill='x',pady=(6,0)); ttk.Label(tf,text='PNG replacement preserves the existing texture dimensions/descriptor. Paletted and mipmapped textures remain read-only.',foreground='#555555').pack(side='left')
        def replace_tex():
            sel=ttree.selection()
            if not sel:return
            rec=textures[int(sel[0])]
            png=filedialog.askopenfilename(parent=win,title=f'Replace {rec.symbol}',filetypes=[('PNG image','*.png')])
            if not png:return
            try: ed.replace_texture_png(rec.symbol,png); self.stage_dirty=True; messagebox.showinfo('Texture replaced',f'{rec.symbol}\n{rec.width}x{rec.height} {rec.format_name}',parent=win)
            except Exception as e:messagebox.showerror('Texture import failed',str(e),parent=win)
        ttk.Button(tf,text='Replace Selected From PNG…',command=replace_tex).pack(side='right')

        # Advanced inventory: raw symbols are useful, but no longer dominate the UX.
        left=ttk.Frame(adv); left.pack(side='left',fill='both',expand=True); right=ttk.Frame(adv); right.pack(side='right',fill='both',expand=True,padx=(10,0))
        ttk.Label(left,text='Common stage asset publics',font=('TkDefaultFont',10,'bold')).pack(anchor='w')
        pubtree=ttk.Treeview(left,columns=('present','meaning'),show='headings',height=12); pubtree.heading('present',text='Present'); pubtree.heading('meaning',text='Public / builder interpretation'); pubtree.column('present',width=70); pubtree.column('meaning',width=430)
        for x in report['publics']['common_families']: pubtree.insert('', 'end',values=('Yes' if x['present'] else 'No',f"{x['symbol']} — {x['label']}"))
        pubtree.pack(fill='both',expand=True,pady=(4,8))
        ttk.Label(right,text='Other public symbols (preserved; not automatically semantic)',font=('TkDefaultFont',10,'bold')).pack(anchor='w')
        raw=tk.Text(right,wrap='none',font=('Consolas',9)); raw.pack(fill='both',expand=True,pady=(4,0))
        raw.insert('1.0','\n'.join(report['publics']['other_symbols'])); raw.configure(state='disabled')
        unknown=report['layout']['unknown_marker_ids']
        ttk.Label(adv,text=('Unknown marker IDs in this stage: '+(', '.join(f'0x{x:02X}' for x in unknown) if unknown else 'none')+'\nUnknown does not mean useless: it means the SDK will show and preserve the data without inventing a label.'),wraplength=1000,justify='left',foreground='#7a4d00').pack(side='bottom',fill='x',pady=(8,0))

    # ---------- Project workflow ----------
    def create_project(self):
        source = filedialog.askdirectory(title='Select extracted Melee disc/root folder')
        if not source:
            return
        dest = filedialog.askdirectory(title='Select an empty/new folder for the Melee SDK project')
        if not dest:
            return
        project_root = Path(dest)
        # If an existing non-project folder was selected, create a named child to avoid mixing files.
        if any(project_root.iterdir()) and not (project_root / MANIFEST_NAME).exists():
            project_root = project_root / 'MeleeModProject'
        try:
            self.project = MeleeProject.create(source, project_root)
        except Exception as e:
            messagebox.showerror('Project creation failed', str(e)); return
        self._after_project_open(f'Created project with {len(self.project.manifest["resources"])} fighter resources.')

    def open_project(self):
        folder = filedialog.askdirectory(title=f'Select folder containing {MANIFEST_NAME}')
        if not folder:
            return
        if not self._confirm_dirty_before_switch():
            return
        try:
            self.project = MeleeProject(folder)
        except Exception as e:
            messagebox.showerror('Open project failed', str(e)); return
        self._after_project_open('Project opened.')

    def _after_project_open(self, message='Project opened.'):
        raw_names = [f.fighter_name for f in self.project.fighters]
        order_index = {n:i for i,n in enumerate(PLAYABLE_ORDER)}
        names = sorted(raw_names, key=lambda n: (0, order_index[n]) if n in order_index else (1, n.lower()))
        self.character_name_lookup = {display_fighter_name(n): n for n in names}
        self.character_combo['values'] = [display_fighter_name(n) for n in names]
        self.project_label.configure(text=f'Project: {self.project.root}   |   Source remains untouched: {self.project.manifest.get("source_root", "")}')
        self.populate_stage_tree()

        self.global_common = None
        common_path = self.project.working_common_path()
        if common_path:
            try:
                self.global_common = CommonFighterDAT(common_path)
            except Exception as e:
                messagebox.showwarning('PlCo.dat', f'Project opened, but global fighter data could not be parsed:\n{e}')
        self.global_dirty = False

        if names:
            preferred = 'Fox' if 'Fox' in names else names[0]
            self.character_var.set(display_fighter_name(preferred))
            self.load_project_character(preferred)
        self.status.configure(text=message + ' Editing targets Working/, never the extracted disc source.')

    def open_project_compatibility(self):
        if not self.project:
            messagebox.showinfo('Project Compatibility', 'Open a project first.')
            return
        report = self.project.compatibility_report()
        win = tk.Toplevel(self)
        win.title('Project Compatibility / Migration')
        win.geometry('760x520')
        frm = ttk.Frame(win, padding=12); frm.pack(fill='both', expand=True)
        status = 'COMPATIBLE' if report.compatible else 'NEEDS ATTENTION'
        ttk.Label(frm, text=f'{status} — detected Phase {report.detected_generation}-era project → Phase {report.target_generation}', font=('TkDefaultFont', 11, 'bold')).pack(anchor='w')
        ttk.Label(frm, text=f'Resources: {report.resource_count}   Fighters: {report.fighter_count}   Stages: {report.stage_count}   Manifest format: {report.manifest_format}').pack(anchor='w', pady=(5,8))
        box = tk.Text(frm, height=17, wrap='word')
        box.pack(fill='both', expand=True)
        lines = []
        lines += [f'• {x}' for x in report.notes]
        if report.original_missing:
            lines.append('\nMissing Original/: ' + ', '.join(report.original_missing[:20]))
        if report.working_missing:
            lines.append('\nMissing Working/: ' + ', '.join(report.working_missing[:20]))
        if report.original_hash_mismatches:
            lines.append('\nOriginal hash mismatches: ' + ', '.join(report.original_hash_mismatches[:20]))
        if report.compatible:
            lines.append('\nOlder projects can remain in their current folder. Newer feature blocks are created only when you use those features.')
            lines.append('For the first in-game SSS/co-op runtime tests, a separate test clone is recommended so your established project remains untouched.')
        box.insert('1.0', '\n'.join(lines)); box.configure(state='disabled')
        actions = ttk.Frame(frm); actions.pack(fill='x', pady=(10,0))
        def upgrade():
            if not report.compatible: return
            try:
                backup=self.project.upgrade_metadata()
                messagebox.showinfo('Metadata upgraded', f'Project metadata upgraded without changing Original/ or Working/ resource bytes.\n\nBackup: {backup}')
                win.destroy()
            except Exception as e:
                messagebox.showerror('Upgrade failed', str(e))
        def clone():
            if not report.compatible: return
            dest=filedialog.askdirectory(title='Select an empty folder for a runtime test clone')
            if not dest: return
            try:
                out=self.project.create_test_clone(dest)
                messagebox.showinfo('Test clone created', f'Created isolated runtime-test project:\n{out}\n\nYour current project was not modified.')
            except Exception as e:
                messagebox.showerror('Test clone failed', str(e))
        ttk.Button(actions, text='Upgrade Metadata Safely', command=upgrade, state=('normal' if report.compatible else 'disabled')).pack(side='left')
        ttk.Button(actions, text='Create Runtime Test Clone…', command=clone, state=('normal' if report.compatible else 'disabled')).pack(side='left', padx=(8,0))
        ttk.Button(actions, text='Close', command=win.destroy).pack(side='right')

    def on_character_changed(self, event=None):
        if not self.project:
            return
        if not self._confirm_dirty_before_switch():
            if self.fighter:
                self.character_var.set(display_fighter_name(self.fighter.fighter_name))
            return
        selected = self.character_var.get()
        name = getattr(self, 'character_name_lookup', {}).get(selected, selected)
        self.load_project_character(name)

    def load_project_character(self, name):
        try:
            self.fighter = FighterDAT(self.project.working_fighter_path(name))
        except Exception as e:
            messagebox.showerror('Character load failed', str(e)); return
        self.dirty = False
        self.move_undo_stack.clear()
        self.move_redo_stack.clear()
        self.aj_bytes = None
        self.aj_dirty = False
        aj_path = self.project.working_aj_path(name)
        if aj_path and aj_path.exists():
            try:
                self.aj_bytes = aj_path.read_bytes()
            except Exception as exc:
                messagebox.showwarning('AJ load', f'Character loaded, but {aj_path.name} could not be read:\n{exc}')
        if self.character_var.get() != display_fighter_name(name):
            self.character_var.set(display_fighter_name(name))
        self._refresh_all()
        self.status.configure(text=f'{display_fighter_name(name)} loaded from Working/{self.fighter.path.name}. Changes stay in memory until Save Working.')

    def _has_pending_ui_changes(self):
        try:
            if self.fighter and self.attr_rows:
                current = self.fighter.common_attributes()
                for name, row in self.attr_rows.items():
                    typ = next(x[2] for x in COMMON_ATTRS if x[0] == name)
                    if not self._value_matches(current[name]['value'], row.parsed_value(), typ):
                        return True
            if self.fighter and self.special_rows:
                current = self.fighter.character_attributes()
                schema = CHARACTER_ATTR_SCHEMAS.get(self.fighter.fighter_name, [])
                types = {n:t for n,_,t in schema}
                for name, row in self.special_rows.items():
                    typ = types[name]
                    if not self._value_matches(current[name]['value'], row.parsed_value(), typ):
                        return True
            if self.global_common and self.global_rows:
                current = self.global_common.attributes()
                types = {n:t for n,_,t in GLOBAL_FIGHTER_ATTRS}
                for name, row in self.global_rows.items():
                    typ = types[name]
                    if not self._value_matches(current[name]['value'], row.parsed_value(), typ):
                        return True
        except Exception:
            # An invalid pending entry should still trigger the save/discard prompt.
            return True
        return False

    def _apply_all_pending_before_save(self):
        """Commit every visible numeric editor atomically by logical group.

        This makes Save Working a safe top-level action: users never need to
        remember a row-level Apply before saving.
        """
        try:
            if self.fighter and self.attr_rows:
                categories = []
                for name, _, _ in COMMON_ATTRS:
                    cat = category_for_attr(name)
                    if cat not in categories:
                        categories.append(cat)
                for cat in categories:
                    self.apply_attr_group(cat, announce=False)
            if self.fighter and self.special_rows:
                for sec in SPECIAL_SECTION_ORDER:
                    self.apply_special_group(sec, announce=False)
            if self.global_common and self.global_rows:
                self.apply_global_group(tuple(self.global_rows.keys()), 'all global mechanics', announce=False)
            return True
        except Exception as e:
            messagebox.showerror('Cannot save pending edits', str(e))
            return False

    def _confirm_dirty_before_switch(self):
        pending_ui = self._has_pending_ui_changes()
        if not self.dirty and not self.global_dirty and not self.aj_dirty and not self.stage_dirty and not pending_ui:
            return True
        kinds = []
        if self.dirty: kinds.append('character')
        if self.global_dirty: kinds.append('global')
        if self.aj_dirty: kinds.append('animation AJ')
        if self.stage_dirty: kinds.append('stage')
        if pending_ui: kinds.append('pending editor')
        ans = messagebox.askyesnocancel('Unsaved changes', f'Save current in-memory {" and ".join(kinds)} changes to Working/ before switching?')
        if ans is None:
            return False
        if ans:
            return self.save_working()
        return True

    def save_working(self):
        if not self.fighter and not self.global_common and not self.stage:
            return False
        # Save is authoritative: commit any values currently typed/slid in the
        # UI before serializing. This prevents a missed Apply Group from losing
        # edits when the DAT is re-opened after verification.
        if not self._apply_all_pending_before_save():
            return False
        if self.project:
            try:
                saved = []
                fighter_name = self.fighter.fighter_name if self.fighter else None
                if self.fighter and self.dirty:
                    target = self.project.save_fighter(self.fighter)
                    self.fighter = FighterDAT(target)  # re-open bytes from disk as verification
                    self.dirty = False
                    saved.append(target.name)
                if fighter_name and self.aj_dirty and self.aj_bytes is not None:
                    target_aj = self.project.save_aj_bytes(fighter_name, self.aj_bytes)
                    # Re-read the exact bytes we wrote before clearing dirty state.
                    self.aj_bytes = target_aj.read_bytes()
                    self.aj_dirty = False
                    saved.append(target_aj.name)
                if self.global_common and self.global_dirty:
                    target_common = self.project.save_common(self.global_common)
                    self.global_common = CommonFighterDAT(target_common)  # verify written PlCo.dat
                    self.global_dirty = False
                    saved.append(target_common.name)
                if self.stage and self.stage_dirty and self.stage.path and any(x.filename.lower() == self.stage.path.name.lower() for x in self.project.stages):
                    # Stage tab Apply buttons already validate semantic edits; validate structure again at save boundary.
                    self.stage.validate()
                    target_stage = self.project.working_dir / self.stage.path.name
                    self.stage.save_as(target_stage)
                    self.stage = StageDAT(target_stage)
                    self.stage_dirty = False
                    saved.append(target_stage.name)
                    self.refresh_stage_view()
                self._refresh_all()
                if saved:
                    self.status.configure(text=f'Saved and re-opened {", ".join(saved)} in Working/. Source and Original/ were not modified.')
                else:
                    self.status.configure(text='Nothing new to save; Working/ already matches the current in-memory state.')
                return True
            except Exception as e:
                messagebox.showerror('Save failed', str(e)); return False
        if not self.fighter:
            return False
        p = filedialog.asksaveasfilename(defaultextension='.dat', initialfile=self.fighter.path.stem+'_mod.dat', filetypes=[('DAT','*.dat')])
        if not p:
            return False
        self.fighter.save_as(p)
        self.dirty = False
        self.status.configure(text=f'Saved {p}')
        return True

    def reset_character(self):
        if not self.project or not self.fighter:
            messagebox.showinfo('Project required', 'Open or create a project first.'); return
        name = self.fighter.fighter_name
        if not messagebox.askyesno('Reset character', f'Restore all {name} Working resources from the immutable Original snapshot?\n\nThis discards Working changes for this character.'):
            return
        try:
            restored = self.project.reset_fighter(name)
            self.project.reset_fighter_state_overrides(name)
            self.load_project_character(name)
            self.status.configure(text=f'Restored {len(restored)} {name} resource(s) from Original/ to Working/ and cleared its project runtime-state overrides.')
        except Exception as e:
            messagebox.showerror('Reset failed', str(e))

    def build_project(self):
        if not self.project:
            messagebox.showinfo('Project required', 'Open or create a project first.'); return
        if (self.dirty or self.global_dirty or self.aj_dirty or self.stage_dirty) and not self.save_working():
            return
        try:
            result = self.project.build()
        except Exception as e:
            messagebox.showerror('Build failed', str(e)); return
        files = [x['filename'] for x in result['modified_files']]
        runtime_overrides = result.get('runtime_overrides', {})
        pending_note = ''
        if runtime_overrides:
            pending_note = '\n\nRuntime state selections are recorded in build_manifest.json but are NOT yet active in-game; they require the upcoming DOL/code-patch backend.'
        if files:
            messagebox.showinfo('Build complete', f"Built {len(files)} modified file(s) into:\n{self.project.build_dir}\n\n" + '\n'.join(files[:20]) + pending_note)
        else:
            messagebox.showinfo('Build complete', f'No Working DAT files differ from Original/.\n\nBuild manifest written to:\n{self.project.build_dir}' + pending_note)

    def _ensure_clean_iso_verified(self, clean_iso: str) -> dict:
        """Verify the embedded canonical main.dol once per unchanged disc path/size/mtime, then cache it."""
        if not self.project:
            raise ValueError('Open a project first.')
        p = Path(clean_iso).resolve()
        st = p.stat()
        settings = self.project.build_target_settings()
        cached = settings.get('clean_iso_verification', {})
        if (cached.get('path') == str(p) and cached.get('size') == st.st_size and
                cached.get('mtime_ns') == st.st_mtime_ns and cached.get('sha1') == GALE01_102_SHA1):
            # Re-read the disc header/FST even when the DOL hash is cached.
            result = verify_melee_102(p, full_hash=False)
            result['sha1'] = GALE01_102_SHA1
            result['canonical'] = True
            result['cached'] = True
            return result
        result = verify_melee_102(p, full_hash=True)
        self.project.set_build_target_settings(clean_iso=str(p), clean_iso_verification={
            'path': str(p), 'size': st.st_size, 'mtime_ns': st.st_mtime_ns,
            'sha1': result['sha1'], 'verified_canonical': True,
        })
        result['cached'] = False
        return result

    def open_iso_patch_dialog(self):
        if not self.project:
            messagebox.showinfo('Project required', 'Open or create a project first.')
            return
        if (self.dirty or self.global_dirty or self.aj_dirty or self.stage_dirty) and not self.save_working():
            return
        try:
            self.project.build()
        except Exception as e:
            messagebox.showerror('Build failed', str(e)); return

        settings = self.project.build_target_settings()
        dlg = tk.Toplevel(self)
        dlg.title('ISO / Patch Build Targets — K20Q Co-op Direct')
        dlg.geometry('860x730')
        dlg.transient(self)
        dlg.grab_set()

        body = ttk.Frame(dlg, padding=14)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text='Melee 1.02 Build Pipeline', font=('TkDefaultFont', 12, 'bold')).grid(row=0, column=0, columnspan=3, sticky='w')
        ttk.Label(body, text=(
            'Build a complete Melee ISO with project DAT/AJ resources and optional Co-op Adventure. '
            'The clean ISO is preserved. Co-op settings apply to every build and patch export.'),
            wraplength=760, foreground='#555555').grid(row=1, column=0, columnspan=3, sticky='w', pady=(4,12))

        clean_var = tk.StringVar(value=settings.get('clean_iso', ''))
        out_default = str(self.project.root / 'ISO' / 'Melee_SDK_Test.iso')
        out_var = tk.StringVar(value=settings.get('output_iso', out_default))
        xd_var = tk.StringVar(value=settings.get('xdelta3', ''))

        def path_row(row, label, var, browse, button='Browse…'):
            ttk.Label(body, text=label).grid(row=row, column=0, sticky='w', pady=5)
            ttk.Entry(body, textvariable=var).grid(row=row, column=1, sticky='ew', padx=8)
            ttk.Button(body, text=button, command=browse).grid(row=row, column=2, sticky='ew')

        def browse_clean():
            p = filedialog.askopenfilename(parent=dlg, title='Select clean NTSC-U Melee 1.02 ISO', filetypes=[('GameCube ISO','*.iso *.gcm'),('All files','*.*')])
            if p: clean_var.set(p)
        def browse_out():
            p = filedialog.asksaveasfilename(parent=dlg, title='Output modded ISO', defaultextension='.iso', initialfile=Path(out_var.get()).name if out_var.get() else 'Melee_SDK_Test.iso', filetypes=[('GameCube ISO','*.iso'),('All files','*.*')])
            if p: out_var.set(p)
        def browse_xd():
            p = filedialog.askopenfilename(parent=dlg, title='Select xdelta3.exe', filetypes=[('xdelta3','xdelta3.exe'),('Executable','*.exe'),('All files','*.*')])
            if p: xd_var.set(p)

        path_row(2, 'Clean Melee 1.02 ISO', clean_var, browse_clean)
        path_row(3, 'Test / final output ISO', out_var, browse_out)
        path_row(4, 'xdelta3 executable (for patch export)', xd_var, browse_xd)
        body.columnconfigure(1, weight=1)

        opts = settings.get('coop_options', {})
        option_vars = {
            'coop_direct': tk.BooleanVar(value=opts.get('coop_direct', True)),
            'adventure_difficulty': tk.StringVar(value=opts.get('adventure_difficulty', 'normal')),
            'adventure_stocks': tk.StringVar(value=str(opts.get('adventure_stocks', 3))),
            **{key: tk.BooleanVar(value=opts.get(key, default)) for key, default in
               [('friendly_fire', True), ('scene_revive', False), ('test_shortcuts', False), ('unlock_all', True)]},
        }
        options_box = ttk.LabelFrame(body, text='Co-op Adventure / Slippi Direct', padding=10)
        options_box.grid(row=5, column=0, columnspan=3, sticky='ew', pady=8)
        ttk.Checkbutton(options_box, text='Include Co-op Adventure + rollback + D-Pad Down stage page',
                        variable=option_vars['coop_direct']).grid(row=0, column=0, columnspan=4, sticky='w')
        ttk.Label(options_box, text='Difficulty').grid(row=1, column=0, sticky='w')
        ttk.Combobox(options_box, textvariable=option_vars['adventure_difficulty'],
                     values=('very_easy','easy','normal','hard','very_hard'), state='readonly', width=13).grid(row=1,column=1,padx=8)
        ttk.Label(options_box, text='Starting stocks').grid(row=1,column=2)
        ttk.Spinbox(options_box, from_=1, to=9, width=4, textvariable=option_vars['adventure_stocks']).grid(row=1,column=3,padx=8)
        for i,(key,label) in enumerate([('friendly_fire','Friendly fire'),('scene_revive','Revive between scenes'),
                                        ('unlock_all','Unlock characters / stages'),('test_shortcuts','Enable test shortcuts')]):
            ttk.Checkbutton(options_box,text=label,variable=option_vars[key]).grid(row=2+i//2,column=(i%2)*2,columnspan=2,sticky='w')
        ttk.Label(options_box,text='Both peers must use the same built ISO. Settings are saved with this project.').grid(row=4,column=0,columnspan=4,sticky='w',pady=(6,0))
        build_options = {}
        xdelta_executable = None

        ttk.Separator(body).grid(row=6, column=0, columnspan=3, sticky='ew', pady=12)
        explain = ttk.Label(body, text=(
            'All buttons rebuild from clean with project resources and these co-op settings.\n'
            'Fresh Rebuild: starts from the clean ISO and either injects exact-size resources or rebuilds FST file placement for resized DAT/AJ files.\n'
            'Export xdelta Package: first builds the configured ISO, then creates an xdelta patch + drag-and-drop BAT for friends.'),
            justify='left', wraplength=760)
        explain.grid(row=7, column=0, columnspan=3, sticky='w')

        progress = ttk.Progressbar(body, mode='indeterminate')
        progress.grid(row=8, column=0, columnspan=3, sticky='ew', pady=(14,4))
        status_var = tk.StringVar(value='Ready.')
        ttk.Label(body, textvariable=status_var, foreground='#555555').grid(row=9, column=0, columnspan=3, sticky='w')

        buttons = ttk.Frame(body)
        buttons.grid(row=10, column=0, columnspan=3, sticky='ew', pady=(16,0))
        action_buttons = []

        def set_busy(busy: bool, text=''):
            for b in action_buttons:
                b.configure(state='disabled' if busy else 'normal')
            if busy:
                progress.start(12)
                status_var.set(text)
            else:
                progress.stop()

        def validate_paths():
            nonlocal build_options, xdelta_executable
            build_options = validate_options({key: var.get() for key, var in option_vars.items()})
            xdelta_executable = xd_var.get().strip() or None
            clean = clean_var.get().strip(); out = out_var.get().strip()
            if not clean or not Path(clean).is_file():
                raise ValueError('Select your clean Melee 1.02 ISO.')
            if not out:
                raise ValueError('Choose an output ISO path.')
            if Path(clean).resolve() == Path(out).resolve():
                raise ValueError('The output ISO cannot be the clean source ISO.')
            self.project.set_build_target_settings(clean_iso=str(Path(clean).resolve()), output_iso=str(Path(out).resolve()), xdelta3=xdelta_executable, coop_options=build_options)
            return clean, out

        def run_async(label, fn, success):
            try:
                clean, out = validate_paths()
            except Exception as e:
                messagebox.showerror('Build settings', str(e), parent=dlg); return
            set_busy(True, label)
            def worker():
                try:
                    result = fn(clean, out)
                except Exception as e:
                    self.after(0, lambda err=e: (set_busy(False), status_var.set('Failed.'), messagebox.showerror('Build failed', str(err), parent=dlg)))
                else:
                    self.after(0, lambda result=result: (set_busy(False), status_var.set('Complete.'), success(result)))
            threading.Thread(target=worker, daemon=True).start()

        def preverified(clean):
            return self._ensure_clean_iso_verified(clean)

        def do_quick(clean, out):
            preverified(clean)
            return build_project_iso(clean, out, self.project.build_dir, build_options)
        def do_fresh(clean, out):
            preverified(clean)
            return build_project_iso(clean, out, self.project.build_dir, build_options, fresh=True)
        def done_iso(result):
            names = [x['filename'] for x in result.get('applied_files', [])]
            restored = result.get('restored_files', [])
            extra = f'\nRestored from clean: {len(restored)}' if restored else ''
            messagebox.showinfo('ISO build complete', f"{result['mode'].replace('_',' ').title()} complete.\n\n{result['output_iso']}\n\nApplied resources: {len(names)}{extra}", parent=dlg)

        # Patch export needs its directory picker on the UI thread. Do that before starting worker.
        def start_patch():
            try:
                clean, out = validate_paths()
            except Exception as e:
                messagebox.showerror('Build settings', str(e), parent=dlg); return
            package = filedialog.askdirectory(parent=dlg, title='Choose patch-package output folder')
            if not package: return
            set_busy(True, 'Updating test ISO and generating xdelta package…')
            def worker():
                try:
                    preverified(clean)
                    build_project_iso(clean, out, self.project.build_dir, build_options)
                    result = export_xdelta_package(clean, out, package, xdelta3=xdelta_executable, verify_hash=False)
                except Exception as e:
                    self.after(0, lambda err=e: (set_busy(False), status_var.set('Failed.'), messagebox.showerror('Patch export failed', str(err), parent=dlg)))
                else:
                    self.after(0, lambda result=result: (set_busy(False), status_var.set('Complete.'), messagebox.showinfo('Patch package complete', f"Created:\n{result['patch']}\n\nPackage folder:\n{result['package_dir']}", parent=dlg)))
            threading.Thread(target=worker, daemon=True).start()

        b1 = ttk.Button(buttons, text='Quick Update Test ISO', command=lambda: run_async('Quick-updating test ISO…', do_quick, done_iso))
        b2 = ttk.Button(buttons, text='Fresh Rebuild ISO', command=lambda: run_async('Building a fresh ISO from clean source…', do_fresh, done_iso))
        b3 = ttk.Button(buttons, text='Export xdelta Package', command=start_patch)
        b4 = ttk.Button(buttons, text='Close', command=dlg.destroy)
        for b in (b1,b2,b3):
            b.pack(side='left', padx=(0,8)); action_buttons.append(b)
        b4.pack(side='right'); action_buttons.append(b4)
        dlg.protocol('WM_DELETE_WINDOW', lambda: None if str(b1.cget('state')) == 'disabled' else dlg.destroy())

        ttk.Label(body, text=f'Canonical Melee 1.02 main.dol SHA-1: {GALE01_102_SHA1}', foreground='#777777').grid(row=11, column=0, columnspan=3, sticky='w', pady=(18,0))

    def open_dat(self):
        if not self._confirm_dirty_before_switch():
            return
        p = filedialog.askopenfilename(filetypes=[('Melee DAT','*.dat'),('All files','*.*')])
        if not p: return
        try:
            self.fighter = FighterDAT(p)
        except Exception as e:
            messagebox.showerror('Open failed', str(e)); return
        self.project = None
        self.global_common = None
        self.move_undo_stack.clear()
        self.move_redo_stack.clear()
        self.aj_bytes = None
        self.aj_dirty = False
        guessed_aj = Path(p).with_name(Path(p).stem + 'AJ.dat')
        if guessed_aj.exists():
            try:
                self.aj_bytes = guessed_aj.read_bytes()
            except Exception:
                self.aj_bytes = None
        self.global_dirty = False
        self.character_combo['values'] = []
        self.character_var.set('')
        self.project_label.configure(text='Standalone DAT mode — use Save Working to Save As. A Project is safer for real mod work.')
        self.dirty = False
        self._refresh_all()

    # ---------- Views ----------
    def _refresh_all(self):
        if not self.fighter: return
        self.populate_overview(); self.populate_attrs(); self.populate_special(); self.populate_global(); self.populate_moves()

    def _select_stage_workbench(self):
        """Open the Stage Workbench tab from the compact editor toolbar."""
        if hasattr(self, 'tabs') and hasattr(self, 'stages_tab'):
            self.tabs.select(self.stages_tab)

    def _refresh_attribute_views(self):
        if self.fighter:
            self.populate_attrs(); self.populate_special(); self.populate_global()

    def populate_overview(self):
        f = self.fighter
        if not f: return
        project_lines = []
        if self.project:
            resource = self.project.fighter_by_name(f.fighter_name)
            project_lines = [
                'PROJECT WORKSPACE',
                f'Project: {self.project.root}',
                f'Original snapshot: {self.project.original_dir / resource.base_filename}',
                f'Working file:      {self.project.working_dir / resource.base_filename}',
                f'Build output:      {self.project.build_dir}',
                f'Animation file:    {resource.aj_filename or "not found"}',
                '',
            ]
        lines = project_lines + [
            f'Loaded file: {f.path}',
            f'Fighter: {f.fighter_name}',
            f'Animation entries: {f.anim_count}',
            '',
            'NORMAL EDITING VIEW',
            '• Attribute and hitbox values are shown in ordinary base-10 numbers.',
            '• Example: weight 75, gravity 0.23, damage 7, angle 361.',
            '• Labels such as 0x088 are NOT values. They are binary offsets used internally by the DAT format.',
            '• Enable “Show binary offsets (advanced)” only when you want those locations visible.',
            '',
            'SAFE WORKSPACE MODEL',
            '• Source extraction: never written by the SDK.',
            '• Original/: project snapshot used as the known-good baseline.',
            '• Working/: editable copies. Save Working writes here.',
            '• Build/: only files that differ from Original/, ready for your disc patching workflow.',
            '',
            'ADVANCED STRUCTURE',
            f'Public root: {f.root.name} @ data+0x{f.root.offset:X}',
            f'Common attributes: data+0x{f.common_attrs_offset:X}',
            f'Character-specific attributes: data+0x{f.ext_attrs_offset:X}',
            f'Animation table: data+0x{f.anim_table_offset:X}',
        ]
        self.overview_text.delete('1.0','end'); self.overview_text.insert('1.0','\n'.join(lines))

    def populate_attrs(self):
        for child in self.attr_form.winfo_children(): child.destroy()
        self.attr_rows.clear()
        if not self.fighter: return
        attrs = self.fighter.common_attributes()
        row = 0
        ttk.Label(
            self.attr_form,
            text='Edit values in base 10, then apply a whole group at once. Save Working also auto-applies any pending values before writing the DAT.',
            font=('TkDefaultFont', 10, 'bold')
        ).grid(row=row, column=0, columnspan=5, sticky='w', padx=4, pady=(2,10)); row += 1

        groups = {}
        for spec in COMMON_ATTRS:
            groups.setdefault(category_for_attr(spec[0]), []).append(spec)

        descriptions = {
            'Ground Movement': 'Walk, dash, run, turning and traction. Does not copy jump or airborne physics.',
            'Jump': 'Jump-squat/startup, launch velocities, jump momentum and additional jumps.',
            'Air Physics': 'Normal gravity, fall-speed cap, drift, aerial friction and fast fall. These can also affect specials that reuse common aerial physics.',
            'Landing': 'Normal and aerial landing-lag values.',
            'Combat / Shield': 'Common attack timing, shield, clank and item-throw tuning stored with the fighter.',
            'Ledge / Wall': 'Ledge jump, wall jump and passive wall/ceiling movement values.',
            'Other': 'Validated common fighter values that do not fit the movement-focused groups above.',
        }

        ordered_categories = [c for c in COMMON_ATTR_GROUP_ORDER if c in groups] + [c for c in groups if c not in COMMON_ATTR_GROUP_ORDER]
        for category in ordered_categories:
            fields = groups[category]
            ttk.Separator(self.attr_form, orient='horizontal').grid(row=row, column=0, columnspan=5, sticky='ew', pady=(8,3)); row += 1
            ttk.Label(self.attr_form, text=category, font=('TkDefaultFont', 10, 'bold')).grid(row=row, column=0, columnspan=3, sticky='w', padx=4, pady=(1,2))
            controls = ttk.Frame(self.attr_form)
            controls.grid(row=row, column=3, columnspan=2, sticky='e', padx=(4,8), pady=(1,2))
            ttk.Button(controls, text='Copy Group From…', command=lambda c=category: self.copy_attr_group_from(c)).pack(side='left', padx=(0,5))
            ttk.Button(controls, text='Apply Group', command=lambda c=category: self.apply_attr_group(c)).pack(side='left')
            row += 1
            ttk.Label(self.attr_form, text=descriptions.get(category, ''), foreground='#666666').grid(row=row, column=0, columnspan=5, sticky='w', padx=4, pady=(0,4)); row += 1
            for name, off, typ in fields:
                nr = NumericRow(self.attr_form, row, name, off, typ, attrs[name]['value'], None, self.show_offsets.get())
                self.attr_rows[name] = nr
                row += 1
        self.attr_form.columnconfigure(3, weight=1)

    def populate_special(self):
        for child in self.special_form.winfo_children(): child.destroy()
        self.special_rows.clear()
        if not self.fighter:
            return

        fighter_name = self.fighter.fighter_name
        friendly = display_fighter_name(fighter_name)
        schema = CHARACTER_ATTR_SCHEMAS.get(fighter_name, [])

        ttk.Label(
            self.special_form,
            text=f'{friendly} — character-specific properties',
            font=('TkDefaultFont', 12, 'bold')
        ).pack(anchor='w', padx=4, pady=(2,2))
        ttk.Label(
            self.special_form,
            text='Expand a section to view its properties. Sections without verified fields are intentionally placeholders until their DAT layout is confirmed.',
            foreground='#555555'
        ).pack(anchor='w', padx=4, pady=(0,10))

        fields_by_section = {section: [] for section in SPECIAL_SECTION_ORDER}
        for field in schema:
            fields_by_section[special_section_for_field(field[0])].append(field)

        attrs = self.fighter.character_attributes() if schema else {}
        first_verified = True
        for section_name in SPECIAL_SECTION_ORDER:
            fields = fields_by_section[section_name]
            if fields:
                subtitle = f'{len(fields)} verified field' + ('s' if len(fields) != 1 else '')
                expanded = first_verified
                first_verified = False
            else:
                subtitle = 'schema pending'
                expanded = False

            section = CollapsibleSection(self.special_form, section_name, subtitle, expanded=expanded)
            section.pack(fill='x', padx=4, pady=(2,6))

            if not fields:
                ttk.Label(
                    section.body,
                    text='No safely editable fields have been mapped for this section yet.\nThe SDK will expose controls here as offsets, types, and semantics are validated against the decomp and real DATs.',
                    foreground='#666666', justify='left'
                ).pack(anchor='w', pady=4)
                continue

            section.body.columnconfigure(3, weight=1)
            for r,(name,off,typ) in enumerate(fields):
                nr = NumericRow(section.body, r, name, off, typ, attrs[name]['value'],
                                None, self.show_offsets.get())
                self.special_rows[name] = nr
            ttk.Button(
                section.body, text='Apply Section',
                command=lambda sec=section_name: self.apply_special_group(sec)
            ).grid(row=len(fields), column=4, sticky='e', padx=(4,8), pady=(8,2))

        note = ttk.LabelFrame(self.special_form, text='Validation / mapping status', padding=10)
        note.pack(fill='x', padx=4, pady=(8,4))
        if schema:
            status_text = (
                f'Core roster validation: PASS for {friendly} on the supplied vanilla fighter resources.\n'
                f'Character-specific semantic mapping: {len(schema)} source-validated editable fields currently exposed.\n'
                'Core validation covers the standard DAT, common attributes, action-script walk, hitbox round-trip, and AJ chunk layout. '
                'Fields omitted here are intentionally withheld when the decomp still names them ambiguously.'
            )
        else:
            status_text = (
                f'Core roster validation: PASS for {friendly} on the supplied vanilla fighter resources.\n'
                'Character-specific semantic mapping: pending. The DAT itself is not broken or unmapped structurally.\n'
                'Common attributes, action scripts, AJ data, and decoded hitboxes are validated; only safely named character-specific ext_attr controls remain withheld.'
            )
        ttk.Label(note, text=status_text, justify='left', wraplength=1150).pack(anchor='w')

    def populate_global(self):
        for child in self.global_form.winfo_children():
            child.destroy()
        self.global_rows.clear()
        self.runtime_state_vars.clear()

        ttk.Label(self.global_form, text='Global Fighter Mechanics — PlCo.dat', font=('TkDefaultFont', 12, 'bold')).pack(anchor='w', padx=4, pady=(2,2))
        ttk.Label(self.global_form, text='These values are shared by the roster. They are not stored separately in each character DAT.', foreground='#555555').pack(anchor='w', padx=4, pady=(0,4))
        ttk.Label(self.global_form, text='Important: normal gravity and terminal velocity are per-character Common Attributes. There is no single global gravity value for ordinary falling; global gravity-related fields below are special-case multipliers.', foreground='#555555', wraplength=1100).pack(anchor='w', padx=4, pady=(0,8))

        if not self.project:
            ttk.Label(self.global_form, text='Open a Melee Project to edit global mechanics safely. Standalone character-DAT mode does not automatically load PlCo.dat.', justify='left').pack(anchor='w', padx=4, pady=8)
            return
        if not self.global_common:
            ttk.Label(self.global_form, text='PlCo.dat was not found or could not be parsed in this project.', foreground='#8a0000').pack(anchor='w', padx=4, pady=8)
            return

        warning = ttk.LabelFrame(self.global_form, text='Scope', padding=8)
        warning.pack(fill='x', padx=4, pady=(2,8))
        ttk.Label(warning, text='GLOBAL — changes here affect all fighters that use the common mechanic. The original PlCo.dat snapshot remains untouched.', justify='left').pack(anchor='w')
        ttk.Label(warning, text='Editor controls: slider = validated numeric range  |  direct value = numeric field without an assumed range  |  checkbox = true on/off state. Numeric changes are applied by section/family; Save Working auto-applies anything still pending.', foreground='#555555', justify='left').pack(anchor='w', pady=(4,0))
        ttk.Label(warning, text='Runtime-state checkboxes are per selected character. They are saved in the project manifest now, but are marked pending until the SDK adds the DOL/code-patch backend needed to force those states in-game.', foreground='#7a5200', justify='left', wraplength=1200).pack(anchor='w', pady=(4,0))

        attrs = self.global_common.attributes()
        specs = {name:(off,typ) for name,off,typ in GLOBAL_FIGHTER_ATTRS}
        labels = {
            'horizontal_stick_deadzone':'Horizontal Stick Deadzone',
            'vertical_stick_deadzone':'Vertical Stick Deadzone',
            'shield_press_threshold':'Shield Press Threshold',
            'walk_stick_threshold':'Walk Stick Threshold',
            'dash_smash_stick_threshold':'Dash / Smash Stick Threshold',
            'dash_smash_window':'Dash / Smash Input Window',
            'tap_jump_threshold':'Tap Jump Threshold',
            'tap_jump_window':'Tap Jump Input Window',
            'tap_jump_release_threshold':'Tap Jump Release Threshold',
            'relaxed_tap_jump_threshold':'Relaxed Tap Jump Threshold',
            'kb_min':'Minimum Applied Knockback',
            'kb_squat_mul':'Crouch Knockback Multiplier',
            'max_grounded_kb_on_landing':'Max Ground Knockback on Landing',
            'aerial_friction_oob':'Aerial Overspeed Friction',
            'knockback_frame_decay':'Knockback Velocity Decay / Frame',
            'start_shield_health':'Starting / Maximum Shield Health',
            'powershield_input_window':'Powershield Input Window',
            'escapeair_deadzone_x':'Stick Deadzone X',
            'escapeair_deadzone_y':'Stick Deadzone Y',
            'escapeair_timer':'Air Dodge Timer',
            'escapeair_force':'Initial Directional Speed',
            'escapeair_decay':'Velocity Retention / Decay',
            'grab_timer_decrement':'Grab Escape Timer Decrement',
            'shield_knockback_frame_decay':'Shield Knockback Decay / Frame',
            'shield_ground_friction_multiplier':'Shield Ground Friction Multiplier',
            'teeter_walk_threshold':'Teeter / Edge Walk Threshold',
            'ledge_cooldown':'Ledge Regrab Cooldown',
            'sdi_min_stick_mag':'SDI Minimum Stick Magnitude',
            'sdi_stick_window':'SDI Stick Input Window',
            'sdi_pos_scale':'SDI Distance Scale',
            'metal_armor':'Metal Armor Threshold',
            'kb_ice_mul':'Frozen Knockback Multiplier',
            'passive_wall_vel_y_base':'Wall Tech Vertical Velocity Base',
            'damageice_gravity_mult':'Frozen Gravity Multiplier',
            'kb_smashcharge_mul':'Smash-Charge Knockback Multiplier',
            'hit_weight_mul':'Weight Calculation Hit Multiplier',
        }

        sections = [
            ('Controller / Input Thresholds',
             ['horizontal_stick_deadzone','vertical_stick_deadzone','shield_press_threshold','walk_stick_threshold','dash_smash_stick_threshold','dash_smash_window','tap_jump_threshold','tap_jump_window','tap_jump_release_threshold','relaxed_tap_jump_threshold'],
             'Shared controller thresholds used by movement and action-state input checks. These change how the entire roster interprets stick/trigger input.'),
            ('Air Dodge',
             ['escapeair_deadzone_x','escapeair_deadzone_y','escapeair_timer','escapeair_force','escapeair_decay'],
             'EscapeAir uses the stick angle to set initial velocity. Initial Directional Speed controls its magnitude; Velocity Retention multiplies X/Y velocity each physics update.'),
            ('Knockback / Air Physics',
             ['kb_min','kb_squat_mul','max_grounded_kb_on_landing','aerial_friction_oob','knockback_frame_decay'],
             "Global rules applied around knockback and common aerial overspeed handling. These are not substitutes for a character's own gravity, friction, or fall speed."),
            ('Shield / Defense',
             ['start_shield_health','powershield_input_window','shield_knockback_frame_decay','shield_ground_friction_multiplier'],
             'Shared shield health, powershield timing, and shield-knockback behavior.'),
            ('SDI / Hit Repositioning',
             ['sdi_min_stick_mag','sdi_stick_window','sdi_pos_scale'],
             'Shared Smash DI thresholds/window and positional displacement scale used during hitlag/shield interactions.'),
            ('Grab / Ledge / Recovery',
             ['grab_timer_decrement','teeter_walk_threshold','ledge_cooldown','passive_wall_vel_y_base'],
             'Common grab timer, edge/ledge timing, and wall-tech related behavior.'),
            ('State / Effect Families',
             [],
             'Related runtime states and their shared PlCo.dat modifiers. Each family combines the editable numeric tuning with the state/trigger information that causes it to be used.'),
        ]

        for i,(title,names,desc) in enumerate(sections):
            if title == 'State / Effect Families':
                total_fields = sum(len(meta['fields']) for meta in GLOBAL_STATE_FAMILIES.values())
                section = CollapsibleSection(self.global_form, title, f'{len(GLOBAL_STATE_FAMILIES)} families / {total_fields} editable global values', expanded=False)
                section.pack(fill='x', padx=4, pady=(2,6))
                ttk.Label(section.body, text=desc, justify='left', wraplength=1050, foreground='#555555').pack(anchor='w', padx=4, pady=(0,8))

                for family_index, (family_name, meta) in enumerate(GLOBAL_STATE_FAMILIES.items()):
                    family = CollapsibleSection(section.body, family_name, f"{len(meta['fields'])} editable value{'s' if len(meta['fields']) != 1 else ''}", expanded=(family_index == 0))
                    family.pack(fill='x', padx=(4,0), pady=(2,5))
                    ttk.Label(family.body, text=meta['description'], justify='left', wraplength=1000, foreground='#555555').grid(row=0, column=0, columnspan=5, sticky='w', padx=4, pady=(0,6))
                    family.body.columnconfigure(3, weight=1)
                    row = 1
                    selected_fighter = self.fighter.fighter_name if self.fighter else None
                    for state_key, toggle_label, toggle_text in meta.get('runtime_toggles', []):
                        enabled = self.project.fighter_state_override(selected_fighter, state_key) if (self.project and selected_fighter) else False
                        var = tk.BooleanVar(value=enabled)
                        self.runtime_state_vars[state_key] = var
                        cb = ttk.Checkbutton(
                            family.body,
                            text=toggle_label,
                            variable=var,
                            command=lambda k=state_key, v=var: self.apply_runtime_state_override(k, v.get()),
                        )
                        cb.grid(row=row, column=0, columnspan=3, sticky='w', padx=4, pady=2)
                        ttk.Label(family.body, text=toggle_text, foreground='#7a5200', wraplength=650).grid(row=row, column=3, columnspan=2, sticky='w', padx=6, pady=2)
                        row += 1
                    if meta.get('runtime_toggles'):
                        ttk.Separator(family.body, orient='horizontal').grid(row=row, column=0, columnspan=5, sticky='ew', padx=4, pady=(5,6))
                        row += 1
                    for fact_label, source_name, fact_text in meta.get('state_facts', []):
                        ttk.Label(family.body, text=fact_label).grid(row=row, column=0, sticky='w', padx=(4,10), pady=2)
                        ttk.Label(family.body, text=source_name, font=('TkDefaultFont', 9, 'bold')).grid(row=row, column=2, sticky='w', padx=4, pady=2)
                        ttk.Label(family.body, text=fact_text, foreground='#666666', wraplength=650).grid(row=row, column=3, columnspan=2, sticky='w', padx=6, pady=2)
                        row += 1
                    if meta.get('state_facts'):
                        ttk.Separator(family.body, orient='horizontal').grid(row=row, column=0, columnspan=5, sticky='ew', padx=4, pady=(5,6))
                        row += 1
                    for name in meta['fields']:
                        off,typ = specs[name]
                        nr = NumericRow(family.body, row, name, off, typ, attrs[name]['value'], None, self.show_offsets.get())
                        for w in family.body.grid_slaves(row=row, column=0):
                            if isinstance(w, ttk.Label):
                                w.configure(text=labels.get(name, pretty_name(name)))
                        self.global_rows[name] = nr
                        row += 1
                    if meta['fields']:
                        ttk.Button(
                            family.body, text='Apply Family',
                            command=lambda ns=tuple(meta['fields']), label=family_name: self.apply_global_group(ns, label)
                        ).grid(row=row, column=4, sticky='e', padx=(4,8), pady=(8,2))
                        row += 1
                continue

            section = CollapsibleSection(self.global_form, title, f'{len(names)} source-validated fields', expanded=(i < 2))
            section.pack(fill='x', padx=4, pady=(2,6))
            ttk.Label(section.body, text=desc, justify='left', wraplength=1050, foreground='#555555').grid(row=0, column=0, columnspan=5, sticky='w', padx=4, pady=(0,8))
            section.body.columnconfigure(3, weight=1)
            for r,name in enumerate(names, start=1):
                off,typ = specs[name]
                nr = NumericRow(section.body, r, name, off, typ, attrs[name]['value'], None, self.show_offsets.get())
                for w in section.body.grid_slaves(row=r, column=0):
                    if isinstance(w, ttk.Label):
                        w.configure(text=labels.get(name, pretty_name(name)))
                self.global_rows[name] = nr
            ttk.Button(
                section.body, text='Apply Section',
                command=lambda ns=tuple(names), label=title: self.apply_global_group(ns, label)
            ).grid(row=1+len(names), column=4, sticky='e', padx=(4,8), pady=(8,2))
            if title == 'Air Dodge':
                ttk.Label(section.body, text='For a wavedash-speed experiment, change only Initial Directional Speed first, Save Working, Build Modified Files, then test.', foreground='#555555', wraplength=1000).grid(row=2+len(names), column=0, columnspan=4, sticky='w', padx=4, pady=(8,2))

        ttk.Button(self.global_form, text='Reset PlCo.dat to Original', command=self.reset_global).pack(anchor='w', padx=8, pady=(4,8))

    def apply_runtime_state_override(self, state_key: str, enabled: bool):
        if not self.project or not self.fighter:
            return
        fighter_name = self.fighter.fighter_name
        try:
            self.project.set_fighter_state_override(fighter_name, state_key, bool(enabled))
            state_name = state_key.replace('_', ' ').title()
            value_text = 'ON' if enabled else 'OFF'
            self.status.configure(
                text=f'{display_fighter_name(fighter_name)} runtime override {state_name}: {value_text}. '
                     'Saved to project manifest; in-game activation is pending the code-patch backend.'
            )
        except Exception as e:
            messagebox.showerror('Runtime state override failed', str(e))

    def apply_global(self, name):
        return self.apply_global_group((name,), pretty_name(name))

    def reset_global(self):
        if not self.project:
            return
        if not messagebox.askyesno('Reset global mechanics', 'Restore Working/PlCo.dat from the immutable Original snapshot?\n\nThis discards all saved and in-memory global mechanic edits.'):
            return
        try:
            p = self.project.reset_common()
            self.global_common = CommonFighterDAT(p)
            self.global_dirty = False
            self.populate_global()
            self.status.configure(text='Restored PlCo.dat from Original/ to Working/.')
        except Exception as e:
            messagebox.showerror('Reset failed', str(e))

    # ---------- Editors ----------
    @staticmethod
    def _value_matches(actual, candidate, typ):
        if typ == 'bool':
            return bool(actual) == bool(candidate)
        if typ == 'int':
            return int(actual) == int(candidate)
        # UI text intentionally rounds float32 noise. Compare at a tolerance
        # tighter than any displayed editing precision so unchanged fields are
        # not rewritten merely because 0.2 decoded as 0.20000000298.
        return abs(float(actual) - float(candidate)) <= 5e-7 * max(1.0, abs(float(actual)), abs(float(candidate)))

    def _parse_rows_atomically(self, names, rows, type_lookup):
        parsed = []
        for name in names:
            if name not in rows:
                continue
            try:
                parsed.append((name, type_lookup(name), rows[name].parsed_value()))
            except Exception as exc:
                raise ValueError(f'{pretty_name(name)}: {exc}') from exc
        return parsed

    def copy_attr_group_from(self, category):
        """Copy one Common Attributes group from another fighter's Working DAT.

        The values are copied into the editor only. They are not written into the
        current fighter until Apply Group or Save Working, which makes the copy
        inspectable/reversible before committing.
        """
        if not self.project or not self.fighter:
            messagebox.showinfo('Project required', 'Copy Group From is available inside a Melee SDK project.')
            return
        current = self.fighter.fighter_name
        names = [r.fighter_name for r in self.project.fighters if r.fighter_name != current]
        if not names:
            messagebox.showinfo('No source fighter', 'No other fighter Working DAT is available in this project.')
            return

        dlg = tk.Toplevel(self)
        dlg.title(f'Copy {category} From')
        dlg.transient(self)
        dlg.grab_set()
        dlg.resizable(False, False)
        body = ttk.Frame(dlg, padding=12)
        body.pack(fill='both', expand=True)
        ttk.Label(body, text=f'Copy {category} values into {display_fighter_name(current)}:', font=('TkDefaultFont', 10, 'bold')).grid(row=0, column=0, columnspan=2, sticky='w', pady=(0,8))
        display_lookup = {display_fighter_name(n): n for n in names}
        src_var = tk.StringVar(value=display_fighter_name(names[0]))
        combo = ttk.Combobox(body, textvariable=src_var, values=list(display_lookup), state='readonly', width=28)
        combo.grid(row=1, column=0, columnspan=2, sticky='ew')
        ttk.Label(body, text="Copies from the source fighter's Working/ DAT into the visible editor only.\nApply Group or Save Working to commit it.", foreground='#666666', justify='left').grid(row=2, column=0, columnspan=2, sticky='w', pady=(8,10))

        def do_copy():
            try:
                src_name = display_lookup[src_var.get()]
                source = FighterDAT(self.project.working_fighter_path(src_name))
                src_attrs = source.common_attributes()
                field_names = [n for n, _, _ in COMMON_ATTRS if category_for_attr(n) == category and n in self.attr_rows]
                for n in field_names:
                    self.attr_rows[n].set_value(src_attrs[n]['value'])
                self.status.configure(text=f'Copied {category} from {display_fighter_name(src_name)} into the editor for {display_fighter_name(current)}. Apply Group or Save Working to commit.')
                dlg.destroy()
            except Exception as exc:
                messagebox.showerror('Copy group failed', str(exc), parent=dlg)

        ttk.Button(body, text='Copy Values', command=do_copy).grid(row=3, column=0, sticky='ew', padx=(0,4))
        ttk.Button(body, text='Cancel', command=dlg.destroy).grid(row=3, column=1, sticky='ew', padx=(4,0))
        combo.focus_set()
        dlg.wait_window()

    def apply_attr_group(self, category, announce=True):
        if not self.fighter:
            return True
        names = [name for name, _, _ in COMMON_ATTRS if category_for_attr(name) == category and name in self.attr_rows]
        type_lookup = lambda n: next(x[2] for x in COMMON_ATTRS if x[0] == n)
        try:
            parsed = self._parse_rows_atomically(names, self.attr_rows, type_lookup)
            current = self.fighter.common_attributes()
            changed = []
            for name, typ, value in parsed:
                if not self._value_matches(current[name]['value'], value, typ):
                    self.fighter.set_common_attribute(name, value)
                    changed.append(name)
            refreshed = self.fighter.common_attributes()
            for name, typ, _ in parsed:
                self.attr_rows[name].set_value(refreshed[name]['value'])
            if changed:
                self.dirty = True
                if announce:
                    self._mark_dirty(f'Applied {category}: {len(changed)} changed value(s)')
            elif announce:
                self.status.configure(text=f'{category}: no values changed.')
            return True
        except Exception as e:
            if announce:
                messagebox.showerror(f'{category} — invalid value', str(e))
            else:
                raise
            return False

    def apply_special_group(self, section_name, announce=True):
        if not self.fighter:
            return True
        schema = CHARACTER_ATTR_SCHEMAS.get(self.fighter.fighter_name, [])
        names = [name for name, _, _ in schema if special_section_for_field(name) == section_name and name in self.special_rows]
        type_lookup = lambda n: next(x[2] for x in schema if x[0] == n)
        try:
            parsed = self._parse_rows_atomically(names, self.special_rows, type_lookup)
            current = self.fighter.character_attributes()
            changed = []
            for name, typ, value in parsed:
                if not self._value_matches(current[name]['value'], value, typ):
                    self.fighter.set_character_attribute(name, value)
                    changed.append(name)
            refreshed = self.fighter.character_attributes()
            for name, typ, _ in parsed:
                self.special_rows[name].set_value(refreshed[name]['value'])
            if changed:
                self.dirty = True
                if announce:
                    self._mark_dirty(f'Applied {section_name}: {len(changed)} changed value(s)')
            elif announce:
                self.status.configure(text=f'{section_name}: no values changed.')
            return True
        except Exception as e:
            if announce:
                messagebox.showerror(f'{section_name} — invalid value', str(e))
            else:
                raise
            return False

    def apply_global_group(self, names, label='Global mechanics', announce=True):
        if not self.global_common:
            return True
        names = [n for n in names if n in self.global_rows]
        type_lookup = lambda n: next(x[2] for x in GLOBAL_FIGHTER_ATTRS if x[0] == n)
        try:
            parsed = self._parse_rows_atomically(names, self.global_rows, type_lookup)
            current = self.global_common.attributes()
            changed = []
            for name, typ, value in parsed:
                if not self._value_matches(current[name]['value'], value, typ):
                    self.global_common.set_attribute(name, value)
                    changed.append(name)
            refreshed = self.global_common.attributes()
            for name, typ, _ in parsed:
                self.global_rows[name].set_value(refreshed[name]['value'])
            if changed:
                self.global_dirty = True
                if announce:
                    self.status.configure(text=f'Applied global {label}: {len(changed)} changed value(s) — in memory; click Save Working. This affects all fighters.')
            elif announce:
                self.status.configure(text=f'{label}: no global values changed.')
            return True
        except Exception as e:
            if announce:
                messagebox.showerror(f'{label} — invalid value', str(e))
            else:
                raise
            return False

    # Backward-compatible one-field wrappers used by older integrations/tests.
    def apply_special(self, name):
        return self.apply_special_group(special_section_for_field(name))

    def apply_attr(self, name):
        return self.apply_attr_group(category_for_attr(name))

    def _mark_dirty(self, text):
        self.dirty = True
        suffix = ' — in memory; click Save Working' if self.project else ' — in memory; save before closing'
        self.status.configure(text=text + suffix)


    def _show_action_inspector(self, action=None, event=None):
        self.hitbox_inspector.pack_forget()
        self.timer_inspector.pack_forget()
        self.action_inspector.pack(fill='both', expand=True)
        if action is None:
            self.action_title.configure(text='Select an action')
            self.action_info.configure(text='The hitbox editor appears only when a Spawn Hitbox event is selected. Movement/physics values are edited in Common Attributes or Global Mechanics.')
            self.common_link_btn.pack(fill='x')
            self.global_link_btn.pack_forget()
            self._refresh_frame_editor(None)
            return
        group, subgroup = move_group(action.action_name)
        title = f'{move_friendly_name(action.action_name)}  ({action.action_name})'
        self.action_title.configure(text=title)
        if event is not None:
            info = f"Selected command: {event['name']} at frame {event['frame']:.0f}. This command is not a hitbox, so there are no hitbox values to edit in the right pane."
            if event.get('event_details'):
                detail_lines = []
                for k, v in event['event_details'].items():
                    label = k.replace('_', ' ').title()
                    detail_lines.append(f"{label}: {v}")
                info += '\n\nDecoded parameters:\n' + '\n'.join(detail_lines)
        else:
            info = f'Category: {group} / {subgroup}. Action-table entry #{action.index:03d}. Selecting a Spawn Hitbox command will switch this pane to the hitbox editor.'
        if action.action_name == 'EscapeAir':
            info += '\n\nAir Dodge movement speed is not encoded in this action script. Its initial speed and per-frame decay are global ftCommonData values in Working/PlCo.dat. Use Global Mechanics → Air Dodge.'
            self.global_link_btn.pack(fill='x', pady=(5,0))
        else:
            self.global_link_btn.pack_forget()
        if group == 'Movement':
            info += '\n\nPer-character locomotion values such as walk/run speed, dash velocity, jump velocity, gravity and aerial drift are under Common Attributes.'
            self.common_link_btn.pack(fill='x')
        else:
            self.common_link_btn.pack_forget()
        self.action_info.configure(text=info)
        self._refresh_frame_editor(action)

    def _refresh_frame_editor(self, action=None):
        if not hasattr(self, 'frame_vars'):
            return
        if not self.fighter or action is None:
            self.frame_baseline = {}
            for v in self.frame_vars.values():
                v.set('')
            if hasattr(self, 'frame_summary'):
                self.frame_summary.configure(text='Select an action to derive timing.')
            return
        try:
            t = self.fighter.analyze_move_timing(action)
        except Exception as exc:
            self.frame_baseline = {}
            self.frame_summary.configure(text=f'Timing analysis failed: {exc}')
            return
        def f(v):
            return '' if v is None else str(int(round(float(v))))
        values = {
            'startup': f(t['first_active']),
            'active_end': f(t['active_end']),
            'recovery': f(t['recovery']),
            'interrupt': f(t['interrupt_frame']),
            'script_end': f(t['script_end']),
        }
        self.frame_baseline = dict(values)
        for k, v in values.items():
            self.frame_vars[k].set(v)
        windows = ', '.join(
            f"{int(round(w['start']))}-{max(int(round(w['start'])), int(round(w['end']))-1)}"
            for w in t['active_windows']
        ) or 'none'
        recovery = 'n/a' if t['recovery'] is None else str(int(round(t['recovery'])))
        iasa = 'none' if t['interrupt_frame'] is None else str(int(round(t['interrupt_frame'])))
        self.frame_summary.configure(
            text=f"Active window(s): {windows}\nRecovery after last active frame: {recovery} frame(s)\nAllow Interrupt / IASA: {iasa}\nScript end: {int(round(t['script_end']))}"
        )

    def _move_snapshot(self):
        if not self.fighter:
            return None
        return (bytes(self.fighter.archive.raw), bytes(self.aj_bytes) if self.aj_bytes is not None else None, bool(self.aj_dirty))

    def _restore_move_snapshot(self, snapshot):
        if not self.fighter or snapshot is None:
            return
        dat_bytes, aj_bytes, aj_dirty = snapshot
        # Reconstruct the parser because Phase 12 assembler edits can resize the HSD archive.
        from sdk.melee_dat import HSDArchive
        self.fighter.archive = HSDArchive(dat_bytes)
        self.fighter._refresh_from_archive()
        self.aj_bytes = aj_bytes
        self.aj_dirty = aj_dirty
        if self.current_move:
            idx = self.current_move.index
            if idx < len(self.fighter.animations):
                self.current_move = self.fighter.animations[idx]

    def _record_move_edit(self):
        snapshot = self._move_snapshot()
        if snapshot is None:
            return
        self.move_undo_stack.append(snapshot)
        if len(self.move_undo_stack) > 20:
            del self.move_undo_stack[0]
        self.move_redo_stack.clear()

    def undo_move_edit(self):
        if not self.fighter or not self.move_undo_stack:
            self.status.configure(text='Nothing to undo in the current fighter editing session.')
            return
        self.move_redo_stack.append(self._move_snapshot())
        self._restore_move_snapshot(self.move_undo_stack.pop())
        self.dirty = True
        self._mark_dirty('Undid last move/script/animation edit')
        if self.current_move:
            self.on_move_selected()

    def redo_move_edit(self):
        if not self.fighter or not self.move_redo_stack:
            self.status.configure(text='Nothing to redo in the current fighter editing session.')
            return
        self.move_undo_stack.append(self._move_snapshot())
        self._restore_move_snapshot(self.move_redo_stack.pop())
        self.dirty = True
        self._mark_dirty('Redid move/script/animation edit')
        if self.current_move:
            self.on_move_selected()

    def apply_frame_data(self):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        baseline = getattr(self, 'frame_baseline', {})
        requested = {k: self.frame_vars[k].get().strip() for k in self.frame_vars}
        changed = [k for k in requested if requested[k] != baseline.get(k, '')]
        if not changed:
            self.status.configure(text='No frame-data milestones changed.')
            return
        # Blank means "not present" for optional milestones, not deletion.
        for k in changed:
            if not requested[k]:
                messagebox.showerror('Frame data edit failed', 'A derived milestone cannot be deleted. Enter a frame number or leave the original value unchanged.')
                self._refresh_frame_editor(self.current_move)
                return
            try:
                int(requested[k], 10)
            except ValueError:
                messagebox.showerror('Frame data edit failed', f'{k.replace("_", " ").title()} must be a whole frame number.')
                return

        snapshot = bytes(self.fighter.archive.raw)
        self._record_move_edit()
        descriptions = []
        try:
            # Only fields the user actually changed are applied. This is important:
            # changing startup alone shifts the downstream move while preserving its
            # relative active/recovery timing instead of forcing stale UI values back.
            if 'startup' in changed:
                self.fighter.set_first_active_frame(self.current_move, int(requested['startup']))
                descriptions.append(f"first active → {requested['startup']}")
            if 'active_end' in changed:
                self.fighter.set_active_end_frame(self.current_move, int(requested['active_end']))
                descriptions.append(f"first inactive → {requested['active_end']}")
            if 'recovery' in changed:
                if 'script_end' in changed:
                    raise ValueError('Change either Recovery Frames or Script End Frame in one Apply, not both.')
                now = self.fighter.analyze_move_timing(self.current_move)
                if now['active_end'] is None:
                    raise ValueError('Recovery cannot be set because this action has no decoded active hitbox window.')
                target_end = int(round(now['active_end'])) + int(requested['recovery'])
                self.fighter.set_script_end_frame(self.current_move, target_end)
                descriptions.append(f"recovery → {requested['recovery']}")
            if 'interrupt' in changed:
                self.fighter.set_interrupt_frame(self.current_move, int(requested['interrupt']))
                descriptions.append(f"IASA → {requested['interrupt']}")
            if 'script_end' in changed:
                self.fighter.set_script_end_frame(self.current_move, int(requested['script_end']))
                descriptions.append(f"script end → {requested['script_end']}")
        except Exception as exc:
            self.fighter.archive.raw[:] = snapshot
            if self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Frame data edit failed', str(exc))
            self._refresh_frame_editor(self.current_move)
            return
        self._mark_dirty('Applied frame data: ' + ', '.join(descriptions))
        self.on_move_selected()

    def _show_hitbox_inspector(self):
        self.action_inspector.pack_forget()
        self.timer_inspector.pack_forget()
        self.hitbox_inspector.pack(fill='both', expand=True)

    def _set_move_tree_open(self, opened: bool):
        def walk(parent=''):
            for iid in self.move_tree.get_children(parent):
                if iid not in self._move_rows:
                    self.move_tree.item(iid, open=opened)
                    walk(iid)
        walk('')

    def populate_moves(self):
        # Hierarchical action browser. Groups are UI-only; the exact animation/action
        # index and symbol remain unchanged in FighterDAT.
        self.move_tree.delete(*self.move_tree.get_children())
        self._move_rows = {}
        if not self.fighter:
            return

        actions = self.fighter.find_moves(self.move_filter.get())
        grouped = {}
        for a in actions:
            group, subgroup = move_group(a.action_name)
            grouped.setdefault(group, {}).setdefault(subgroup, []).append(a)

        preferred = [
            'Grounded Attacks', 'Aerial Attacks', 'Special Moves', 'Items / Item Actions', 'Grabs / Throws',
            'Movement', 'Defense / Evasion', 'Ledge Actions', 'Status / Reactions', 'Unclassified'
        ]
        group_names = [g for g in preferred if g in grouped] + [g for g in grouped if g not in preferred]
        filter_active = bool(self.move_filter.get().strip())

        for gi, group in enumerate(group_names):
            gid = f'grp:{gi}'
            total = sum(len(v) for v in grouped[group].values())
            self.move_tree.insert('', 'end', iid=gid, text=f'{group}  ({total})', open=(filter_active or group in ('Grounded Attacks','Aerial Attacks')))
            for si, (subgroup, rows) in enumerate(grouped[group].items()):
                # Avoid a redundant subgroup level for generic buckets.
                parent = gid
                if len(grouped[group]) > 1 or subgroup not in (group, 'Unclassified', 'Grab / Character Throw', 'Ledge', 'Shield / Dodge / Recovery'):
                    sid = f'{gid}:sub:{si}'
                    self.move_tree.insert(gid, 'end', iid=sid, text=f'{subgroup}  ({len(rows)})', open=filter_active)
                    parent = sid
                for a in rows:
                    iid = f'action:{a.index}'
                    self._move_rows[iid] = a
                    hb_count = len(self.fighter.hitboxes_for_animation(a))
                    self.move_tree.insert(parent, 'end', iid=iid, text=move_friendly_name(a.action_name), values=(f'{a.index:03d}', str(hb_count) if hb_count else ''))

    def on_move_selected(self,event=None):
        if not self.fighter:return
        sel=self.move_tree.selection()
        if not sel:return
        iid=sel[0]
        a=self._move_rows.get(iid)
        if a is None:
            if self.move_tree.exists(iid):
                self.move_tree.item(iid, open=not self.move_tree.item(iid, 'open'))
            return
        self.current_move=a
        self.events.delete(*self.events.get_children())
        for ev in self.fighter.parse_script(a):
            details=''
            if 'hitbox' in ev:
                h=ev['hitbox']; details=f"HB{h['id']} dmg={h['damage']} angle={h['angle']} KBG={h['knockback_growth']} BKB={h['base_knockback']} size={decimal_text(h['size'],'float')} bone={h['bone']}"
            elif 'timer_value' in ev:
                details=f"timer={ev['timer_value']}"
            elif 'hitbox_adjust' in ev:
                details=str(ev['hitbox_adjust'])
            elif ev.get('event_details'):
                parts=[]
                for k,v in ev['event_details'].items():
                    if k == 'meaning' or v is None:
                        continue
                    label=k.replace('_',' ')
                    parts.append(f"{label}={v}")
                details='; '.join(parts[:5])
            eid=f"{ev['offset']:X}"
            self.events.insert('', 'end', iid=eid, values=(f"{ev['frame']:.0f}",f"0x{ev['offset']:X}",ev['opcode'],ev['name'],details))
        self.current_hitbox_event=None
        self.current_timer_event=None
        for v in self.hit_vars.values(): v.set('')
        for v in self.hit_bool_vars.values(): v.set(False)
        self._show_action_inspector(a)

    def on_event_selected(self,event=None):
        if not self.fighter or not self.current_move:return
        sel=self.events.selection()
        if not sel:return
        off=int(sel[0],16)
        ev=next((e for e in self.fighter.parse_script(self.current_move) if e['offset']==off),None)
        if ev and ev.get('opcode') in (1, 2):
            self.current_hitbox_event=None
            for v in self.hit_vars.values(): v.set('')
            for v in self.hit_bool_vars.values(): v.set(False)
            self._show_timer_inspector(ev)
            return
        if not ev or 'hitbox' not in ev:
            self.current_hitbox_event=None
            for v in self.hit_vars.values():v.set('')
            for v in self.hit_bool_vars.values():v.set(False)
            self._show_action_inspector(self.current_move, ev)
            return
        self.current_hitbox_event=ev
        h=ev['hitbox']
        for key,_,typ,_,_ in HITBOX_EDIT_FIELDS:
            self.hit_vars[key].set(decimal_text(h[key], 'int' if typ is int else 'float'))
        for key,_ in BOOL_HITBOX_FIELDS:
            self.hit_bool_vars[key].set(bool(h[key]))
        self._show_hitbox_inspector()

    def _show_timer_inspector(self, event):
        self.action_inspector.pack_forget()
        self.hitbox_inspector.pack_forget()
        self.timer_inspector.pack(fill='both', expand=True)
        self.current_timer_event = event
        self.timer_value_var.set(str(int(event['timer_value'])))
        kind = 'relative wait duration' if event['opcode'] == 1 else 'absolute script frame target'
        self.timer_info.configure(text=f"{event['name']} at advanced offset 0x{event['offset']:X}. Current value: {event['timer_value']} frame(s); this is a {kind}.")

    def apply_timer_edit(self):
        if not self.fighter or not getattr(self, 'current_timer_event', None):
            messagebox.showinfo('No timer', 'Select a timer command first.')
            return
        snapshot = bytes(self.fighter.archive.raw)
        recorded = False
        try:
            value = int(self.timer_value_var.get().strip(), 10)
            self._record_move_edit(); recorded = True
            result = self.fighter.set_timer_event(self.current_timer_event['offset'], value)
        except Exception as exc:
            self.fighter.archive.raw[:] = snapshot
            if recorded and self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Timer edit failed', str(exc))
            return
        self.dirty = True
        self._mark_dirty(f"Applied {self.current_timer_event['name']} = {result['timer_value']} frame(s)")
        self.on_move_selected()

    def scale_current_move_timing(self):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        snapshot = bytes(self.fighter.archive.raw)
        recorded = False
        try:
            factor = float(self.script_timing_scale.get().strip())
            self._record_move_edit(); recorded = True
            changes = self.fighter.scale_script_timing(self.current_move, factor)
        except Exception as exc:
            self.fighter.archive.raw[:] = snapshot
            if recorded and self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Timing scale failed', str(exc))
            return
        if changes:
            self.dirty = True
            self._mark_dirty(f'Scaled {move_friendly_name(self.current_move.action_name)} script timing by {factor:g}; {len(changes)} timer command(s) changed. Save Working to commit.')
            self.on_move_selected()
        else:
            if recorded and self.move_undo_stack:
                self.move_undo_stack.pop()
            self.status.configure(text='No timer values changed for this action.')

    def apply_hitbox(self):
        if not self.fighter or not self.current_hitbox_event:
            messagebox.showinfo('No hitbox','Select a Spawn Hitbox row first.');return
        updates={}
        snapshot = bytes(self.fighter.archive.raw)
        recorded = False
        try:
            for key,label,typ,lo,hi in HITBOX_EDIT_FIELDS:
                txt=self.hit_vars[key].get().strip()
                updates[key]=typ(txt)
            for key,_ in BOOL_HITBOX_FIELDS:
                updates[key]=1 if self.hit_bool_vars[key].get() else 0
            self._record_move_edit(); recorded = True
            h=self.fighter.set_hitbox(self.current_hitbox_event['offset'],updates)
        except Exception as e:
            self.fighter.archive.raw[:] = snapshot
            if recorded and self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Hitbox edit failed',str(e));return
        self._mark_dirty(f"Applied hitbox {h['id']} at advanced offset 0x{self.current_hitbox_event['offset']:X}")
        self.on_move_selected()

    def copy_hitbox_values(self):
        if not self.current_hitbox_event or 'hitbox' not in self.current_hitbox_event:
            messagebox.showinfo('No hitbox', 'Select a Spawn Hitbox row first.')
            return
        self.hitbox_clipboard = dict(self.current_hitbox_event['hitbox'])
        self.status.configure(text=f"Copied hitbox {self.hitbox_clipboard['id']} values. Select another Spawn Hitbox and choose Paste Values.")

    def paste_hitbox_values(self):
        if not self.fighter or not self.current_hitbox_event:
            messagebox.showinfo('No hitbox', 'Select a destination Spawn Hitbox row first.')
            return
        if not self.hitbox_clipboard:
            messagebox.showinfo('Clipboard empty', 'Copy a Spawn Hitbox first.')
            return
        dest = self.current_hitbox_event['hitbox']
        updates = {k: v for k, v in self.hitbox_clipboard.items() if k not in ('id', 'hit_group')}
        snapshot = bytes(self.fighter.archive.raw)
        self._record_move_edit()
        try:
            self.fighter.set_hitbox(self.current_hitbox_event['offset'], updates)
        except Exception as exc:
            self.fighter.archive.raw[:] = snapshot
            if self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Paste hitbox failed', str(exc))
            return
        self._mark_dirty(f"Pasted hitbox values onto HB{dest['id']}")
        self.on_move_selected()

    def clone_full_move_from_action(self):
        if not self.project:
            messagebox.showinfo('Project required', 'Full Move Clone changes both the fighter DAT and AJ resource. Open the fighter through a Project first.')
            return
        if not self.fighter or not self.current_move or self.aj_bytes is None:
            messagebox.showinfo('AJ required', 'Select a fighter action with its Working AJ resource loaded.')
            return
        idx = simpledialog.askinteger(
            'Clone full move',
            f'Clone script + animation INTO {move_friendly_name(self.current_move.action_name)}.\n\nSource action index (shown in the left action list):',
            parent=self, minvalue=0, maxvalue=max(0, len(self.fighter.animations)-1),
        )
        if idx is None:
            return
        if idx == self.current_move.index:
            messagebox.showinfo('Same action', 'Choose a different source action.'); return
        source = self.fighter.animations[idx]
        if not source.symbol or not source.script_offset or not source.anim_archive_size:
            messagebox.showerror('Clone full move', 'That action does not have a complete script + AJ animation resource.'); return
        if not messagebox.askyesno(
            'Clone full move',
            f"Replace {move_friendly_name(self.current_move.action_name)} with an independent clone of\n"
            f"#{idx:03d} — {move_friendly_name(source.action_name)}?\n\n"
            'This changes both Working PlXX.dat and PlXXAJ.dat. Undo is available.'
        ):
            return
        snapshot = self._move_snapshot(); self._record_move_edit()
        try:
            new_aj, result = self.fighter.clone_full_move(source, self.current_move, self.aj_bytes)
            self.aj_bytes = bytearray(new_aj)
            self.dirty = True; self.aj_dirty = True
            self.current_move = self.fighter.animations[self.current_move.index]
        except Exception as exc:
            self._restore_move_snapshot(snapshot)
            messagebox.showerror('Clone full move', str(exc)); return
        self.populate_moves(); self.on_move_selected()
        self._mark_dirty(
            f"Cloned full move from #{idx:03d}. Fighter script {result['script']['old_script_bytes']} → "
            f"{result['script']['new_script_bytes']} bytes; AJ grew by {result['aj_size_delta']} bytes."
        )

    def bulk_scale_hitboxes(self):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        try:
            dmg_scale = float(self.bulk_damage_scale.get().strip())
            size_scale = float(self.bulk_size_scale.get().strip())
            if dmg_scale <= 0 or size_scale <= 0:
                raise ValueError('Damage and size multipliers must be greater than 0')
        except Exception as exc:
            messagebox.showerror('Bulk hitbox edit failed', str(exc))
            return
        hit_events = self.fighter.hitboxes_for_animation(self.current_move)
        if not hit_events:
            messagebox.showinfo('No hitboxes', 'This action has no decoded Spawn Hitbox commands.')
            return
        snapshot = bytes(self.fighter.archive.raw)
        self._record_move_edit()
        changed = 0
        try:
            for ev in hit_events:
                h = ev['hitbox']
                damage = max(0, min(1023, int(round(h['damage'] * dmg_scale))))
                size = max(0.0, min(255.99609375, h['size'] * size_scale))
                self.fighter.set_hitbox(ev['offset'], {'damage': damage, 'size': size})
                changed += 1
        except Exception as exc:
            self.fighter.archive.raw[:] = snapshot
            if self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Bulk hitbox edit failed', str(exc))
            return
        self._mark_dirty(f'Bulk-edited {changed} Spawn Hitbox command(s): damage ×{dmg_scale:g}, size ×{size_scale:g}')
        self.on_move_selected()

    def _selected_event_index(self, default_before_end=False):
        if not self.fighter or not self.current_move:
            return None
        events = self.fighter.parse_script(self.current_move)
        sel = self.events.selection()
        if sel:
            try:
                off = int(sel[0], 16)
                return next(i for i, e in enumerate(events) if e['offset'] == off)
            except Exception:
                pass
        return max(0, len(events) - 1) if default_before_end and events else None

    def _run_assembler_edit(self, label, operation):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        snapshot = self._move_snapshot()
        self._record_move_edit()
        try:
            action_index = self.current_move.index
            result = operation()
            self.current_move = self.fighter.animations[action_index]
        except Exception as exc:
            self._restore_move_snapshot(snapshot)
            if self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Script assembler', str(exc))
            return
        self.dirty = True
        self._mark_dirty(
            f"{label}. Script {result.get('old_script_bytes','?')} → "
            f"{result.get('new_script_bytes','?')} bytes; fighter archive offsets rebuilt safely."
        )
        self.populate_moves()
        self.on_move_selected()

    def assembler_duplicate_event(self):
        idx = self._selected_event_index()
        if idx is None:
            messagebox.showinfo('Select event', 'Select a command row to duplicate.')
            return
        self._run_assembler_edit('Duplicated script event', lambda: self.fighter.duplicate_event(self.current_move, idx))

    def assembler_delete_event(self):
        idx = self._selected_event_index()
        if idx is None:
            messagebox.showinfo('Select event', 'Select a command row to delete.')
            return
        if not messagebox.askyesno('Delete script event', 'Delete the selected command from this action script?\n\nThe HSD archive will be rebuilt; Undo is available.'):
            return
        self._run_assembler_edit('Deleted script event', lambda: self.fighter.delete_event(self.current_move, idx))

    def assembler_move_event(self, delta):
        idx = self._selected_event_index()
        if idx is None:
            messagebox.showinfo('Select event', 'Select a command row to move.')
            return
        self._run_assembler_edit('Reordered script event', lambda: self.fighter.move_event(self.current_move, idx, delta))

    def assembler_insert_timer(self, opcode):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        value = simpledialog.askinteger(
            'Insert timer',
            ('Relative wait duration in frames:' if opcode == 1 else 'Absolute target frame:'),
            parent=self, minvalue=0, maxvalue=67108863,
        )
        if value is None:
            return
        idx = self._selected_event_index(default_before_end=True)
        words = self.fighter.make_timer_words(opcode, value)
        self._run_assembler_edit(
            'Inserted ' + ('Synchronous Timer' if opcode == 1 else 'Asynchronous Timer'),
            lambda: self.fighter.insert_event(self.current_move, idx, words),
        )

    def assembler_insert_simple(self, opcode):
        if not self.fighter or not self.current_move:
            return
        idx = self._selected_event_index(default_before_end=True)
        words = self.fighter.make_simple_event_words(opcode, 0)
        name = {16:'Deactivate All Hitboxes', 23:'Allow Interrupt / IASA'}.get(opcode, f'Opcode {opcode}')
        self._run_assembler_edit('Inserted ' + name, lambda: self.fighter.insert_event(self.current_move, idx, words))

    def assembler_copy_script(self):
        if not self.fighter or not self.current_move:
            return
        try:
            model = self.fighter.script_editor_model(self.current_move)
        except Exception as exc:
            messagebox.showerror('Copy script', str(exc))
            return
        self.script_clipboard = {
            'fighter': self.fighter.fighter_name,
            'action_name': self.current_move.action_name,
            'model': json.loads(json.dumps(model)),
        }
        ptrs = sum(1 for e in model if (e['words'][0] >> 26) in (5, 7))
        self.status.configure(text=f"Copied graph-aware script from {move_friendly_name(self.current_move.action_name)} ({len(model)} root events, {ptrs} pointer command(s)).")

    def assembler_paste_script(self):
        if not self.script_clipboard:
            messagebox.showinfo('Script clipboard empty', 'Copy an action script first.')
            return
        if not self.fighter or not self.current_move:
            return
        src = self.script_clipboard
        model = json.loads(json.dumps(src.get('model', [])))
        has_ptr = any((e.get('words',[0])[0] >> 26) in (5,7) for e in model if e.get('words'))
        if src.get('fighter') != self.fighter.fighter_name and has_ptr:
            messagebox.showerror(
                'Cross-character control flow',
                'This script contains Subroutine/Goto targets into the source fighter DAT. Those helper offsets are fighter-specific, so Phase 13 will not paste them across characters.\n\nUse a script without pointer commands, or copy within the same fighter.'
            )
            return
        if src.get('fighter') != self.fighter.fighter_name:
            if not messagebox.askyesno('Cross-character script paste', 'This script was copied from another fighter. GFX/SFX/article IDs may not have the same meaning. Paste anyway?'):
                return
        if not messagebox.askyesno('Replace action script', f"Replace {move_friendly_name(self.current_move.action_name)} with the copied {src.get('action_name','')} command graph?\n\nUndo is available."):
            return
        # Source offsets describe the copied action, not this destination root.
        for row in model:
            row.pop('source_offset', None)
        self._run_assembler_edit('Replaced action with copied command graph', lambda: self.fighter.replace_script_graph(self.current_move, model))

    def assembler_wrap_loop(self):
        if not self.fighter or not self.current_move:
            return
        idx = self._selected_event_index()
        if idx is None:
            messagebox.showinfo('Select event', 'Select one normal command to wrap in a loop.')
            return
        count = simpledialog.askinteger('Loop selected event', 'Total loop executions:', parent=self, initialvalue=2, minvalue=1, maxvalue=67108863)
        if count is None:
            return
        self._run_assembler_edit(f'Wrapped event in {count}× loop', lambda: self.fighter.wrap_event_in_loop(self.current_move, idx, count))

    def assembler_analyze_cfg(self):
        if not self.fighter or not self.current_move:
            return
        try:
            cfg = self.fighter.analyze_script_control_flow(self.current_move)
            root = self.fighter.parse_script(self.current_move)
        except Exception as exc:
            messagebox.showerror('Control-flow analysis', str(exc)); return
        messagebox.showinfo(
            'Action control-flow graph',
            f"{move_friendly_name(self.current_move.action_name)}\n\n"
            f"Root storage events: {len(root)}\n"
            f"Reachable unique commands: {len(cfg['nodes'])}\n"
            f"Edges: {len(cfg['edges'])}\n"
            f"Set Loop commands: {cfg['loops']}\n"
            f"Subroutines: {cfg['subroutines']}\n"
            f"Gotos: {cfg['gotos']}\n"
            f"Returns: {cfg['returns']}\n"
            f"Reachable cycles: {len(cfg['cycles'])}\n\n"
            'Subroutine/Goto pointer words are checked against the HSD relocation table.'
        )

    def assembler_export_json(self):
        if not self.fighter or not self.current_move:
            return
        try:
            model = self.fighter.script_editor_model(self.current_move)
        except Exception as exc:
            messagebox.showerror('Export script', str(exc)); return
        path = filedialog.asksaveasfilename(parent=self, title='Export move script graph', defaultextension='.json',
                                            initialfile=f'{self.fighter.fighter_name}_{self.current_move.action_name}.json',
                                            filetypes=[('JSON','*.json'),('All files','*.*')])
        if not path: return
        payload = {
            'format': 'melee-sdk-script-graph-v1',
            'fighter': self.fighter.fighter_name,
            'action': self.current_move.action_name,
            'events': model,
        }
        Path(path).write_text(json.dumps(payload, indent=2), encoding='utf-8')
        self.status.configure(text=f'Exported script graph: {path}')

    def assembler_import_json(self):
        if not self.fighter or not self.current_move:
            return
        path = filedialog.askopenfilename(parent=self, title='Import move script graph', filetypes=[('JSON','*.json'),('All files','*.*')])
        if not path: return
        try:
            payload = json.loads(Path(path).read_text(encoding='utf-8'))
            if payload.get('format') != 'melee-sdk-script-graph-v1':
                raise ValueError('Not a Melee SDK script-graph v1 file')
            model = payload.get('events')
            if not isinstance(model, list):
                raise ValueError('Script JSON does not contain an events array')
            source_fighter = payload.get('fighter')
            has_ptr = any((e.get('words',[0])[0] >> 26) in (5,7) for e in model if e.get('words'))
            if source_fighter != self.fighter.fighter_name and has_ptr:
                raise ValueError('Pointer-bearing script graphs cannot be imported across fighters because helper targets are DAT-specific')
            for row in model:
                row.pop('source_offset', None)
        except Exception as exc:
            messagebox.showerror('Import script', str(exc)); return
        if not messagebox.askyesno('Import script graph', f'Replace the selected action with {len(model)} authored root events?\n\nUndo is available.'):
            return
        self._run_assembler_edit('Imported authored script graph', lambda: self.fighter.replace_script_graph(self.current_move, model))

    def assembler_add_hitbox_phase(self):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        hits = self.fighter.hitboxes_for_animation(self.current_move)
        if not hits:
            messagebox.showinfo('No template hitbox', 'This action needs at least one existing Spawn Hitbox to use as a validated template.')
            return
        frame = simpledialog.askinteger('New hitbox phase', 'Start frame:', parent=self, minvalue=0, maxvalue=67108863)
        if frame is None:
            return
        duration = simpledialog.askinteger('New hitbox phase', 'Active duration in frames:', parent=self, initialvalue=3, minvalue=1, maxvalue=67108863)
        if duration is None:
            return
        template_offset = self.current_hitbox_event['offset'] if self.current_hitbox_event else hits[0]['offset']
        self._run_assembler_edit(
            f'Added hitbox phase at frame {frame} for {duration} frame(s)',
            lambda: self.fighter.add_hitbox_phase(self.current_move, frame, duration, template_offset),
        )

    def _current_aj_chunk_info(self):
        if not self.fighter or not self.current_move or self.aj_bytes is None:
            return None
        a = self.current_move
        if not a.anim_archive_offset or not a.anim_archive_size:
            return None
        end = a.anim_archive_offset + a.anim_archive_size
        if end > len(self.aj_bytes):
            raise ValueError('Current action AJ chunk is outside the loaded AJ file')
        return analyze_figatree_archive(self.aj_bytes[a.anim_archive_offset:end])

    def preview_full_move_speed(self):
        if not self.fighter or not self.current_move:
            messagebox.showinfo('No action', 'Select an action first.')
            return
        if self.aj_bytes is None:
            messagebox.showinfo('AJ required', 'Load this fighter through a Project containing the matching AJ DAT.')
            return
        try:
            speed = float(self.full_move_speed.get().strip())
            if speed <= 0:
                raise ValueError('Speed multiplier must be greater than zero')
            factor = 1.0 / speed
            timing = self.fighter.analyze_move_timing(self.current_move)
            aj = self._current_aj_chunk_info()
        except Exception as exc:
            messagebox.showerror('Retiming preview', str(exc))
            return
        def scaled(v):
            return 'n/a' if v is None else str(int(round(float(v) * factor)))
        messagebox.showinfo(
            'Full move retiming preview',
            f"{move_friendly_name(self.current_move.action_name)}\n\n"
            f"Speed: {speed:g}×   Time factor: {factor:.6g}\n\n"
            f"First active: {timing['first_active']} → {scaled(timing['first_active'])}\n"
            f"Script end: {timing['script_end']} → {scaled(timing['script_end'])}\n"
            f"AJ FigaTree length: {aj['frames']:.3f} → {aj['frames'] * factor:.3f}\n"
            f"Animation tracks: {aj['track_count']}\nEncoded key waits: {aj['wait_count']}\n\n"
            'Apply Full Move Speed changes both the command timeline and the actual animation timeline.'
        )

    def apply_full_move_speed(self):
        if not self.project:
            messagebox.showinfo('Project required', 'Full move animation retiming changes both PlXX.dat and PlXXAJ.dat. Use a Project so both Working files are saved atomically.')
            return
        if not self.fighter or not self.current_move or self.aj_bytes is None:
            messagebox.showinfo('AJ required', 'The selected fighter does not have a loaded Working AJ resource.')
            return
        try:
            speed = float(self.full_move_speed.get().strip())
            if speed <= 0:
                raise ValueError('Speed multiplier must be greater than zero')
        except Exception as exc:
            messagebox.showerror('Full move speed', str(exc))
            return
        snapshot = self._move_snapshot()
        self._record_move_edit()
        try:
            action_index = self.current_move.index
            new_aj, result = self.fighter.retime_full_move(self.current_move, self.aj_bytes, speed)
            self.aj_bytes = new_aj
            self.aj_dirty = True
            self.dirty = True
            self.current_move = self.fighter.animations[action_index]
        except Exception as exc:
            self._restore_move_snapshot(snapshot)
            if self.move_undo_stack:
                self.move_undo_stack.pop()
            messagebox.showerror('Full move speed failed', str(exc))
            return
        a = result['animation']
        self._mark_dirty(
            f"Full move speed {speed:g}× applied: script timers changed={result['script_timers_changed']}; "
            f"AJ frames {a['old_frames']:.3f}→{a['new_frames']:.3f}; "
            f"AJ size delta {result['aj_size_delta']:+d} bytes. Save Working commits both DATs."
        )
        self.populate_moves()
        self.on_move_selected()

    def validate_aj(self):
        if not self.fighter:
            messagebox.showinfo('No fighter','Open a fighter first.');return
        if self.project:
            p = self.project.working_aj_path(self.fighter.fighter_name)
            if p and p.exists():
                try: r=self.fighter.validate_animation_archive(p)
                except Exception as e: messagebox.showerror('Validation failed',str(e));return
                self._show_aj_result(r, p); return
        p=filedialog.askopenfilename(title='Select matching AJ DAT',filetypes=[('Melee animation DAT','*AJ.dat'),('DAT','*.dat')])
        if not p:return
        try:r=self.fighter.validate_animation_archive(p)
        except Exception as e:messagebox.showerror('Validation failed',str(e));return
        self._show_aj_result(r, p)

    def _show_aj_result(self, r, p):
        if r['errors']:
            messagebox.showwarning('AJ validation',f"Valid unique chunks: {r['valid_chunks']}/{r['checked_unique_chunks']}\n\n"+'\n'.join(r['errors'][:10]))
        else:
            messagebox.showinfo('AJ validation',f"{Path(p).name}\n\nAll {r['valid_chunks']} unique referenced animation chunks match their embedded HSD archive sizes.\nAJ size: 0x{r['aj_size']:X}")

    def export_json(self):
        if not self.fighter:return
        p=filedialog.asksaveasfilename(defaultextension='.json',initialfile=self.fighter.path.stem+'_decoded.json',filetypes=[('JSON','*.json')])
        if not p:return
        Path(p).write_text(json.dumps(self.fighter.export_summary(),indent=2),encoding='utf-8')
        self.status.configure(text=f'Exported {p}')

    def _phase20_symbol_map(self):
        return SymbolMap.from_file(Path(__file__).resolve().parent / 'data' / 'runtime_symbols_GALE01.txt')

    def _ensure_runtime_dol(self):
        if not self.project:
            raise ValueError('Open or create a Project first.')
        p=self.project.working_dir/'start.dol'
        if p.exists():
            return p
        iso=filedialog.askopenfilename(title='Select clean GALE01 1.02 ISO to import main.dol',filetypes=[('GameCube ISO','*.iso'),('All files','*.*')])
        if not iso: return None
        return self.project.import_runtime_dol_from_iso(iso)

    def open_one_player_resources(self):
        if not self.project:
            messagebox.showinfo('1P Resources','Open or create a Project first.'); return
        win=tk.Toplevel(self); win.title('Phase 23 — Retail 1P Resource Library'); win.geometry('1050x700')
        ttk.Label(win,text='Imports Melee retail 1P resources into the project without recreating Adventure. Ending .mth movies are optional: a normal ISO build leaves the original movies in place unless you explicitly replace them.',wraplength=990,justify='left').pack(anchor='w',padx=10,pady=(10,6))
        status=tk.StringVar(value='No 1P package inspected yet.')
        ttk.Label(win,textvariable=status,wraplength=990,justify='left').pack(anchor='w',padx=10,pady=(0,8))
        nb=ttk.Notebook(win); nb.pack(fill='both',expand=True,padx=10,pady=6)
        inv=ttk.Frame(nb); adv=ttk.Frame(nb); nb.add(inv,text='1P package inventory'); nb.add(adv,text='Adventure stage resources')
        cols=('file','category','size')
        tree=ttk.Treeview(inv,columns=cols,show='headings');
        for c,w in zip(cols,(420,260,120)):
            tree.heading(c,text=c.title()); tree.column(c,width=w,anchor='w')
        tree.pack(fill='both',expand=True)
        acols=('stkind','chapter','name','file','type','available')
        atree=ttk.Treeview(adv,columns=acols,show='headings')
        for c,w in zip(acols,(70,70,300,120,100,90)):
            atree.heading(c,text=c.title()); atree.column(c,width=w,anchor='w')
        atree.pack(fill='both',expand=True)
        audit_status=tk.StringVar(value='')
        ttk.Label(adv,textvariable=audit_status,wraplength=980,justify='left').pack(anchor='w',pady=6)

        def refresh_audit():
            for x in atree.get_children(): atree.delete(x)
            a=adventure_resource_audit(self.project)
            for row in a['segments']:
                atree.insert('', 'end', values=(f"0x{row['stkind']:02X}",row['chapter'],row['name'],row['filename'],row['encounter_type'],'YES' if row['available'] else 'NO'))
            if a['ready_for_retail_adventure_stage_assets']:
                audit_status.set(f"Retail Adventure stages ready: {a['available_required_stage_files']}/{a['required_stage_file_count']} unique required stage archives are present. Missing Stadium auxiliary archives: {', '.join(a['missing_auxiliary_stage_files']) or 'none'}")
            else:
                audit_status.set(f"Retail Adventure stage resources incomplete: {a['available_required_stage_files']}/{a['required_stage_file_count']} present. Missing: {', '.join(a['missing_stage_files'])}")

        def inspect_package(path):
            try: r=inspect_one_player_resources(path)
            except Exception as exc: messagebox.showerror('1P Resources',str(exc),parent=win); return
            for x in tree.get_children(): tree.delete(x)
            for row in r.entries:
                tree.insert('', 'end', values=(row.filename,row.category,f'{row.size:,}'))
            cats=', '.join(f'{k}: {v}' for k,v in r.categories.items())
            movie_note='No MTH movies in package — OK; retail ISO movies can remain untouched.' if r.movie_count==0 else f'{r.movie_count} movie files detected.'
            status.set(f'{r.file_count} files, {r.total_bytes:,} bytes. {cats}. {movie_note}')
            return r

        def choose_inspect():
            path=filedialog.askopenfilename(parent=win,title='Select 1P resource ZIP',filetypes=[('ZIP','*.zip'),('All files','*.*')])
            if path: inspect_package(path)

        def choose_import():
            path=filedialog.askopenfilename(parent=win,title='Select 1P resource ZIP',filetypes=[('ZIP','*.zip'),('All files','*.*')])
            if not path: return
            try:
                r=inspect_package(path)
                if r is None: return
                res=import_one_player_resources(self.project,path,include_movies=False)
                refresh_audit()
                messagebox.showinfo('1P Resources',f"Imported {len(res['imported'])} retail 1P resources into Original/ and Working/.\n\nMovies imported: no. The base ISO's existing MTH files will remain intact during normal builds.",parent=win)
            except Exception as exc: messagebox.showerror('1P Resources',str(exc),parent=win)

        bar=ttk.Frame(win); bar.pack(fill='x',padx=10,pady=(0,10))
        ttk.Button(bar,text='Inspect 1P ZIP…',command=choose_inspect).pack(side='left')
        ttk.Button(bar,text='Import 1P ZIP Into Project…',command=choose_import).pack(side='left',padx=6)
        ttk.Button(bar,text='Refresh Adventure Audit',command=refresh_audit).pack(side='left',padx=6)
        refresh_audit()

    def open_sdk_health(self):
        root=Path(__file__).resolve().parent
        checks=audit_sdk(root)
        win=tk.Toplevel(self); win.title('Phase 21 SDK Health'); win.geometry('780x520')
        tree=ttk.Treeview(win,columns=('status','detail'),show='headings')
        tree.heading('status',text='Status'); tree.heading('detail',text='Check / detail')
        tree.column('status',width=90,anchor='center'); tree.column('detail',width=650)
        tree.pack(fill='both',expand=True,padx=10,pady=10)
        for c in checks:
            tree.insert('', 'end', values=('PASS' if c.ok else 'FAIL', f'{c.name} — {c.detail}'))
        bad=sum(not c.ok for c in checks)
        ttk.Label(win,text=f'{len(checks)-bad}/{len(checks)} checks passed. Distribution caches are intentionally excluded from release ZIPs.').pack(anchor='w',padx=10,pady=(0,10))

    def open_game_mode_lab(self):
        if not self.project:
            messagebox.showinfo('1P / Duo Lab','Open or create a Project first.'); return
        try:
            dol_path=self._ensure_runtime_dol()
            if not dol_path: return
            editor=OnePlayerModeEditor(DOLImage(dol_path), self._phase20_symbol_map())
        except Exception as exc:
            messagebox.showerror('1P / Duo Lab',str(exc)); return
        win=tk.Toplevel(self); win.title('Phase 23 — 1P / Event / Duo / Retail Co-op Adventure Lab'); win.geometry('1120x780')
        nb=ttk.Notebook(win); nb.pack(fill='both',expand=True,padx=8,pady=8)
        classic=ttk.Frame(nb,padding=8); adv=ttk.Frame(nb,padding=8); event=ttk.Frame(nb,padding=8); duo=ttk.Frame(nb,padding=8); coopadv=ttk.Frame(nb,padding=8)
        nb.add(classic,text='Classic table'); nb.add(adv,text='Adventure table'); nb.add(event,text='Event Match / Duo runtime'); nb.add(duo,text='Duo recipes'); nb.add(coopadv,text='Co-op Adventure')

        # Phase 22: one continuous 12-chapter Adventure campaign authoring.
        coop_campaign=CoopAdventureCampaign.vanilla_sequence()
        ttk.Label(coopadv,text="Single-sequence two-player Adventure authoring layered onto Melee's existing retail Adventure mode. Stage identities now resolve to the actual Gr*.dat resources used by retail; this is not a replacement campaign.",wraplength=980,justify='left').pack(anchor='w',pady=(0,8))
        ctree=ttk.Treeview(coopadv,columns=('chapter','stkind','type','file','name','risk'),show='headings',height=20)
        for k,t,w in [('chapter','Chapter',65),('stkind','StKind',60),('type','Type',80),('file','Retail DAT',105),('name','Segment',275),('risk','Co-op runtime concern',360)]:
            ctree.heading(k,text=t); ctree.column(k,width=w,anchor='w' if k in ('file','name','risk') else 'center')
        risks={x['stkind']:x for x in coop_campaign.compatibility_report()}
        for ch in coop_campaign.chapters:
            for seg in ch.segments:
                r=risks[seg.stkind]
                ctree.insert('', 'end',values=(ch.number,f'0x{seg.stkind:02X}',seg.kind,seg.filename or '',seg.name,f"{r['risk']}: {r['reason']}"))
        ctree.pack(fill='both',expand=True,pady=6)
        cf=ttk.Frame(coopadv); cf.pack(fill='x')
        p2kind=tk.StringVar(value='')
        ttk.Label(cf,text='P2 CharacterKind (optional)').pack(side='left'); ttk.Entry(cf,textvariable=p2kind,width=10).pack(side='left',padx=4)
        def export_coop_adventure():
            out=filedialog.askdirectory(parent=win,title='Choose folder for Co-op Adventure campaign bundle')
            if not out:return
            try:
                c=CoopAdventureCampaign.vanilla_sequence('Co-op Adventure')
                if p2kind.get().strip(): c.rules.p2_character_kind=int(p2kind.get(),0)
                write_campaign_bundle(out,c)
                messagebox.showinfo('Co-op Adventure',f'Created complete campaign bundle in:\n{out}\n\nIncludes the 12-chapter sequence, compatibility audit, and source-hook runtime plan.',parent=win)
            except Exception as exc: messagebox.showerror('Co-op Adventure',str(exc),parent=win)
        ttk.Button(cf,text='Create Complete Co-op Adventure Bundle…',command=export_coop_adventure).pack(side='left',padx=8)
        ttk.Label(coopadv,text="Runtime constraint: StartMeleeData has four player records. Reserving P1 + P2 leaves two simultaneous CPU slots; large Adventure team fights must keep Melee's wave/replacement behavior.",foreground='#555555',wraplength=1000,justify='left').pack(anchor='w',pady=(6,0))

        # Phase 25: runtime preparation and route-partner atlas.  These tools
        # intentionally stop at guarded preflight; they do not claim the final
        # PowerPC hook is installed until exact replacement code is validated.
        p24=ttk.LabelFrame(coopadv,text='Phase 25 — Runtime Preparation'); p24.pack(fill='x',pady=(12,0))
        p24_status=tk.StringVar(value='Ready: source-grounded P1-only touchpoints + four retail route-stage partner profiles.')
        ttk.Label(p24,textvariable=p24_status,wraplength=970,justify='left').pack(anchor='w',padx=8,pady=(6,4))
        p24bar=ttk.Frame(p24); p24bar.pack(fill='x',padx=6,pady=(0,8))
        def _project_stage_folder():
            if not self.project: raise ValueError('Open a project first.')
            return self.project.working_dir
        def export_route_atlas():
            try:
                atlas=build_route_partner_atlas(_project_stage_folder())
                out=filedialog.asksaveasfilename(parent=win,title='Save route partner atlas',defaultextension='.json',initialfile='coop_route_partner_atlas.json',filetypes=[('JSON','*.json')])
                if not out:return
                Path(out).write_text(json.dumps(atlas,indent=2),encoding='utf-8')
                p24_status.set(f"Route atlas: {len(atlas['profiles'])}/4 retail route stages profiled; status {atlas['status']}.")
            except Exception as exc: messagebox.showerror('Co-op Route Atlas',str(exc),parent=win)
        def runtime_preflight():
            try:
                if not self.project: raise ValueError('Open a project first.')
                dol=self.project.working_dir/'start.dol'
                if not dol.exists(): raise ValueError('Working/start.dol is not present. Import main.dol from a clean GALE01 1.02 ISO first.')
                syms=Path(__file__).parent/'data'/'runtime_symbols_GALE01.txt'
                report=preflight_runtime_dol(dol,syms)
                out=self.project.build_dir/'coop_adventure_runtime_preflight.json'; out.parent.mkdir(parents=True,exist_ok=True)
                out.write_text(json.dumps(report,indent=2),encoding='utf-8')
                p24_status.set(f"Runtime preflight PASS: {len(report['hooks'])} hook sites captured; canonical clean={report['canonical_clean']}.")
                messagebox.showinfo('Co-op Runtime Preflight', f'PASS\n\nCaptured {len(report["hooks"])} source-grounded hook sites.\nSaved: {out}\n\nNo executable co-op hook has been installed yet.', parent=win)
            except Exception as exc: messagebox.showerror('Co-op Runtime Preflight',str(exc),parent=win)
        def create_runtime_prep_bundle():
            try:
                if not self.project: raise ValueError('Open a project first.')
                out=filedialog.askdirectory(parent=win,title='Choose folder for Phase 25 runtime preparation bundle')
                if not out:return
                dol=self.project.working_dir/'start.dol'; syms=Path(__file__).parent/'data'/'runtime_symbols_GALE01.txt'
                write_runtime_prep_bundle(out,stage_folder=self.project.working_dir,dol_path=dol if dol.exists() else None,symbols_path=syms if dol.exists() else None)
                p24_status.set('Runtime preparation bundle created: campaign + touchpoints + route atlas' + (' + DOL preflight.' if dol.exists() else '.'))
                messagebox.showinfo('Co-op Runtime Bundle', f'Created runtime preparation bundle in:\n{out}', parent=win)
            except Exception as exc: messagebox.showerror('Co-op Runtime Bundle',str(exc),parent=win)
        ttk.Button(p24bar,text='Export Route Partner Atlas…',command=export_route_atlas).pack(side='left',padx=4)
        ttk.Button(p24bar,text='Preflight Working/start.dol',command=runtime_preflight).pack(side='left',padx=4)
        ttk.Button(p24bar,text='Create Runtime Prep Bundle…',command=create_runtime_prep_bundle).pack(side='left',padx=4)


        def make_table(parent, kind):
            top=ttk.Frame(parent); top.pack(fill='x')
            ttk.Label(top,text=('Source-derived encounter table. Stage kind and two percentage scales are confirmed; unknown payload bytes are preserved.'),wraplength=820,justify='left').pack(side='left')
            tree=ttk.Treeview(parent,columns=('idx','group','slot','stage','s0','s1','payload'),show='headings',height=20)
            for key,title,w in [('idx','Index',55),('group','Group',55),('slot','Slot',45),('stage','Stage Kind',80),('s0','Scale 0 %',80),('s1','Scale 1 %',80),('payload','Preserved payload',430)]:
                tree.heading(key,text=title); tree.column(key,width=w,anchor='center' if key!='payload' else 'w')
            tree.pack(fill='both',expand=True,pady=8)
            form=ttk.Frame(parent); form.pack(fill='x')
            vstage=tk.StringVar(); vs0=tk.StringVar(); vs1=tk.StringVar(); selected={'index':None}
            for col,(label,var) in enumerate([('Stage kind',vstage),('Scale 0 %',vs0),('Scale 1 %',vs1)]):
                ttk.Label(form,text=label).grid(row=0,column=col*2,sticky='e',padx=(4,2)); ttk.Entry(form,textvariable=var,width=10).grid(row=0,column=col*2+1,sticky='w')
            def entries(): return editor.classic_entries() if kind=='classic' else editor.adventure_entries()
            def reload():
                tree.delete(*tree.get_children())
                for e in entries():
                    extra=(' '.join(f'{a:02X}:{b:02X}:{c:02X}' for a,b,c in e.opponent_triplets)+(' / '+e.payload[9:].hex() if e.payload[9:] else '')) if kind=='classic' else e.payload.hex()
                    tree.insert('', 'end', iid=str(e.index), values=(e.index,e.group,e.slot,e.stage_kind,e.scale0_pct,e.scale1_pct,extra))
            def choose(_=None):
                sel=tree.selection()
                if not sel:return
                e=entries()[int(sel[0])]; selected['index']=e.index
                vstage.set(str(e.stage_kind)); vs0.set(str(e.scale0_pct)); vs1.set(str(e.scale1_pct))
            def apply():
                if selected['index'] is None:return
                try:
                    kwargs=dict(stage_kind=int(vstage.get(),0),scale0_pct=int(vs0.get(),0),scale1_pct=int(vs1.get(),0))
                    if kind=='classic': editor.patch_classic(selected['index'],**kwargs)
                    else: editor.patch_adventure(selected['index'],**kwargs)
                    editor.dol.save_as(dol_path); reload(); tree.selection_set(str(selected['index']))
                    self.status.configure(text=f'Phase 21 {kind} table entry {selected["index"]} patched in Working/start.dol')
                except Exception as exc: messagebox.showerror('Mode table edit',str(exc),parent=win)
            tree.bind('<<TreeviewSelect>>',choose)
            ttk.Button(form,text='Apply to Working/start.dol',command=apply).grid(row=0,column=6,padx=8)
            def export():
                out=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile='melee_1p_tables.json',filetypes=[('JSON','*.json')])
                if out: editor.export_tables(out)
            ttk.Button(form,text='Export full table JSON…',command=export).grid(row=0,column=7,padx=4)
            reload()
        make_table(classic,'classic'); make_table(adv,'adventure')

        # Phase 21: retail GmEvent.dat is already a data-driven match runtime.
        # We expose its confirmed rule/player fields and can turn an ordinary
        # 3/4-player event into a real two-human local co-op experiment.
        event_state={'archive':None,'path':None,'selected_event':None,'selected_player':None}
        event_top=ttk.Frame(event); event_top.pack(fill='x')
        ttk.Label(event_top,text='GmEvent.dat authoring — edit retail Event Match rules/players and build two-human co-op experiments without PowerPC code injection.',wraplength=760,justify='left').pack(side='left',fill='x',expand=True)
        event_status=tk.StringVar(value='GmEvent.dat not loaded')
        ttk.Label(event,textvariable=event_status,foreground='#555555').pack(anchor='w',pady=(4,6))

        def load_event_path(path):
            arc=EventMatchArchive(path)
            event_state['archive']=arc; event_state['path']=Path(path)
            rep=arc.report(); event_status.set(f"Loaded {Path(path).name}: {rep['event_count']} events — {rep['ordinary_events']} normal / {rep['bonus_events']} bonus / {rep['multiround_events']} multi-round")
            reload_events()
            return arc

        def use_project_event():
            p=self.project.working_dir/'GmEvent.dat'
            if p.exists(): load_event_path(p); return
            ans=messagebox.askyesnocancel('GmEvent.dat','Working/GmEvent.dat is not in this project.\n\nYes: import it from a clean GALE01 1.02 ISO.\nNo: choose a GmEvent.dat file manually.',parent=win)
            if ans is None:return
            try:
                if ans:
                    iso=filedialog.askopenfilename(parent=win,title='Select clean GALE01 1.02 ISO',filetypes=[('GameCube ISO','*.iso'),('All files','*.*')])
                    if not iso:return
                    self.project.import_event_archive_from_iso(iso); load_event_path(self.project.working_dir/'GmEvent.dat')
                else:
                    src=filedialog.askopenfilename(parent=win,title='Select GmEvent.dat',filetypes=[('GmEvent.dat','GmEvent.dat'),('DAT','*.dat'),('All files','*.*')])
                    if not src:return
                    self.project.register_event_archive(src); load_event_path(self.project.working_dir/'GmEvent.dat')
            except Exception as exc: messagebox.showerror('Event Match import',str(exc),parent=win)

        ttk.Button(event_top,text='Load / Import GmEvent.dat…',command=use_project_event).pack(side='right',padx=4)
        body=ttk.Panedwindow(event,orient='horizontal'); body.pack(fill='both',expand=True)
        left=ttk.Frame(body); right=ttk.Frame(body); body.add(left,weight=3); body.add(right,weight=2)
        etree=ttk.Treeview(left,columns=('num','kind','count','stage','time','teams','speed'),show='headings',height=21)
        for k,t,w in [('num','Event',55),('kind','Kind',55),('count','Players',60),('stage','StageKind',80),('time','Time',65),('teams','Teams',55),('speed','Speed',65)]:
            etree.heading(k,text=t); etree.column(k,width=w,anchor='center')
        etree.pack(fill='both',expand=True,padx=(0,6),pady=4)

        rules_box=ttk.LabelFrame(right,text='Confirmed event rules',padding=6); rules_box.pack(fill='x',pady=4)
        rv_stage=tk.StringVar(); rv_time=tk.StringVar(); rv_speed=tk.StringVar(); rv_teams=tk.BooleanVar(); rv_ff=tk.BooleanVar(); rv_timer=tk.BooleanVar(); rv_countup=tk.BooleanVar(); rv_items=tk.StringVar()
        rvars=[('Stage Kind',rv_stage),('Time Limit',rv_time),('Game Speed',rv_speed),('Item Freq',rv_items)]
        for rr,(lab,var) in enumerate(rvars): ttk.Label(rules_box,text=lab).grid(row=rr,column=0,sticky='e',padx=3,pady=2); ttk.Entry(rules_box,textvariable=var,width=14).grid(row=rr,column=1,sticky='w')
        ttk.Checkbutton(rules_box,text='Teams',variable=rv_teams).grid(row=0,column=2,sticky='w',padx=8)
        ttk.Checkbutton(rules_box,text='Friendly fire',variable=rv_ff).grid(row=1,column=2,sticky='w',padx=8)
        ttk.Checkbutton(rules_box,text='Timer enabled',variable=rv_timer).grid(row=2,column=2,sticky='w',padx=8)
        ttk.Checkbutton(rules_box,text='Timer counts up',variable=rv_countup).grid(row=3,column=2,sticky='w',padx=8)

        pbox=ttk.LabelFrame(right,text='Player records',padding=6); pbox.pack(fill='both',expand=True,pady=4)
        ptree=ttk.Treeview(pbox,columns=('slot','type','char','stocks','team','cpu','hp','atk','def','scale'),show='headings',height=8)
        for k,t,w in [('slot','Slot',42),('type','Type',60),('char','CharKind',62),('stocks','Stocks',48),('team','Team',42),('cpu','CPU',38),('hp','HP',45),('atk','Atk',52),('def','Def',52),('scale','Scale',52)]:
            ptree.heading(k,text=t); ptree.column(k,width=w,anchor='center')
        ptree.pack(fill='x')
        pv_type=tk.StringVar(); pv_char=tk.StringVar(); pv_stocks=tk.StringVar(); pv_team=tk.StringVar(); pv_cpu=tk.StringVar(); pv_hp=tk.StringVar(); pv_atk=tk.StringVar(); pv_def=tk.StringVar(); pv_scale=tk.StringVar()
        pf=ttk.Frame(pbox); pf.pack(fill='x',pady=(6,0))
        labels=[('Type 0=Human 1=CPU',pv_type),('CharKind',pv_char),('Stocks',pv_stocks),('Team',pv_team),('CPU Lv',pv_cpu),('HP',pv_hp),('Attack ratio',pv_atk),('Defense ratio',pv_def),('Model scale',pv_scale)]
        for rr,(lab,var) in enumerate(labels):
            ttk.Label(pf,text=lab).grid(row=rr//3,column=(rr%3)*2,sticky='e',padx=2,pady=1); ttk.Entry(pf,textvariable=var,width=9).grid(row=rr//3,column=(rr%3)*2+1,sticky='w')

        def reload_events():
            etree.delete(*etree.get_children()); ptree.delete(*ptree.get_children())
            a=event_state['archive']
            if not a:return
            for e in a.events():
                kind={0:'Normal',1:'Bonus',2:'Rounds'}.get(e.kind,str(e.kind))
                etree.insert('', 'end', iid=str(e.index),values=(e.display_number,kind,e.player_count_field,e.rules.stage_kind,e.rules.time_limit,'Yes' if e.rules.is_teams else 'No',f'{e.rules.game_speed:g}'))

        def event_choose(_=None):
            a=event_state['archive']; sel=etree.selection()
            if not a or not sel:return
            e=a.event(int(sel[0])); event_state['selected_event']=e.index; event_state['selected_player']=None
            rv_stage.set(str(e.rules.stage_kind)); rv_time.set(str(e.rules.time_limit)); rv_speed.set(f'{e.rules.game_speed:g}'); rv_teams.set(bool(e.rules.is_teams)); rv_ff.set(e.rules.friendly_fire); rv_timer.set(e.rules.timer_enabled); rv_countup.set(e.rules.timer_counts_up); rv_items.set(str(e.rules.item_freq))
            ptree.delete(*ptree.get_children())
            for p in e.players:
                ptree.insert('', 'end',iid=str(p.pointer_index),values=(p.pointer_index,p.slot_type_name,p.character_kind,p.stocks,p.team,p.cpu_level,p.hp,f'{p.attack_ratio:g}',f'{p.defense_ratio:g}',f'{p.model_scale:g}'))

        def player_choose(_=None):
            a=event_state['archive']; ei=event_state['selected_event']; sel=ptree.selection()
            if not a or ei is None or not sel:return
            pi=int(sel[0]); p=next(x for x in a.event(ei).players if x.pointer_index==pi); event_state['selected_player']=pi
            pv_type.set(str(p.slot_type)); pv_char.set(str(p.character_kind)); pv_stocks.set(str(p.stocks)); pv_team.set(str(p.team)); pv_cpu.set(str(p.cpu_level)); pv_hp.set(str(p.hp)); pv_atk.set(f'{p.attack_ratio:g}'); pv_def.set(f'{p.defense_ratio:g}'); pv_scale.set(f'{p.model_scale:g}')

        def save_event_archive():
            a=event_state['archive']
            if not a:return
            a.save(event_state['path']); self.status.configure(text='Phase 21 GmEvent.dat saved to Working; Build ISO will include it.')

        def apply_event_rules():
            a=event_state['archive']; i=event_state['selected_event']
            if not a or i is None:return
            try:
                a.set_rules(i,stage_kind=int(rv_stage.get(),0),time_limit=int(rv_time.get(),0),game_speed=float(rv_speed.get()),is_teams=rv_teams.get(),friendly_fire=rv_ff.get(),timer_enabled=rv_timer.get(),timer_counts_up=rv_countup.get(),item_freq=int(rv_items.get(),0)); save_event_archive(); reload_events(); etree.selection_set(str(i)); event_choose()
            except Exception as exc: messagebox.showerror('Event rules',str(exc),parent=win)

        def apply_event_player():
            a=event_state['archive']; i=event_state['selected_event']; pi=event_state['selected_player']
            if not a or i is None or pi is None:return
            try:
                a.set_player(i,pi,character_kind=int(pv_char.get(),0),slot_type=int(pv_type.get(),0),stocks=int(pv_stocks.get(),0),team=int(pv_team.get(),0),cpu_level=int(pv_cpu.get(),0),hp=int(pv_hp.get(),0),attack_ratio=float(pv_atk.get()),defense_ratio=float(pv_def.get()),model_scale=float(pv_scale.get())); save_event_archive(); event_choose(); ptree.selection_set(str(pi)); player_choose()
            except Exception as exc: messagebox.showerror('Event player',str(exc),parent=win)

        btns=ttk.Frame(pbox); btns.pack(fill='x',pady=5)
        ttk.Button(btns,text='Apply Player',command=apply_event_player).pack(side='left')
        ttk.Button(rules_box,text='Apply Rules',command=apply_event_rules).grid(row=4,column=0,columnspan=3,sticky='ew',pady=(5,0))

        duo_box=ttk.LabelFrame(right,text='Playable Duo experiment',padding=6); duo_box.pack(fill='x',pady=4)
        duo_p2=tk.StringVar(value='1'); duo_cpu=tk.StringVar(value='7'); duo_stocks=tk.StringVar(value='3')
        for rr,(lab,var) in enumerate([('P2 fixed CharacterKind',duo_p2),('Opponent CPU level',duo_cpu),('Stocks',duo_stocks)]):
            ttk.Label(duo_box,text=lab).grid(row=rr,column=0,sticky='e',padx=3,pady=2); ttk.Entry(duo_box,textvariable=var,width=10).grid(row=rr,column=1,sticky='w')
        ttk.Label(duo_box,text='Uses an existing normal Event Match with ≥3 player records. P1 may use vanilla Event CSS; P2 is fixed because retail Event CSS only selects P1.',wraplength=420,justify='left').grid(row=3,column=0,columnspan=2,sticky='w',pady=5)
        def make_duo_event():
            a=event_state['archive']; i=event_state['selected_event']
            if not a or i is None:return
            try:
                res=a.make_duo_coop(i,p2_character_kind=int(duo_p2.get(),0),cpu_level=int(duo_cpu.get(),0),stocks=int(duo_stocks.get(),0)); save_event_archive(); reload_events(); etree.selection_set(str(i)); event_choose(); messagebox.showinfo('Duo Event prepared',f"Event {res['event_number']} now has P1 + P2 as local Human teammates.\n\nP2 CharacterKind: {res['p2_character_kind']}\nCPU level: {res['cpu_level']}\n\nThis is a real GmEvent.dat runtime edit. Test controller behavior in Dolphin/hardware before treating it as production-safe.",parent=win)
            except Exception as exc: messagebox.showerror('Duo Event',str(exc),parent=win)
        ttk.Button(duo_box,text='Convert Selected Event to P1 + P2 Co-op',command=make_duo_event).grid(row=4,column=0,columnspan=2,sticky='ew',pady=4)
        def export_event_report():
            a=event_state['archive']
            if not a:return
            out=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile='GmEvent_report.json',filetypes=[('JSON','*.json')])
            if out:a.export_json(out)
        ttk.Button(duo_box,text='Export Event Report…',command=export_event_report).grid(row=5,column=0,columnspan=2,sticky='ew',pady=2)
        etree.bind('<<TreeviewSelect>>',event_choose); ptree.bind('<<TreeviewSelect>>',player_choose)
        if (self.project.working_dir/'GmEvent.dat').exists():
            try: load_event_path(self.project.working_dir/'GmEvent.dat')
            except Exception as exc: event_status.set(f'GmEvent.dat present but invalid: {exc}')

        ttk.Label(duo,text='Duo Challenge Recipe authoring',font=('TkDefaultFont',11,'bold')).pack(anchor='w')
        ttk.Label(duo,text='This creates a stable SDK recipe for future two-human co-op/challenge scene injection. It does not falsely claim the vanilla 1P scene supports two humans yet.',wraplength=850,justify='left').pack(anchor='w',pady=(2,10))
        f=ttk.Frame(duo); f.pack(anchor='w')
        name=tk.StringVar(value='Duo Challenge 1'); stages=tk.StringVar(value='2,3,4'); stocks=tk.StringVar(value='4'); cpu=tk.StringVar(value='7')
        for r,(lab,var) in enumerate([('Recipe name',name),('Stage kinds (comma separated)',stages),('Stocks',stocks),('CPU level',cpu)]):
            ttk.Label(f,text=lab).grid(row=r,column=0,sticky='e',padx=4,pady=3); ttk.Entry(f,textvariable=var,width=40).grid(row=r,column=1,sticky='w',pady=3)
        def save_recipe():
            try:
                sk=[int(x.strip(),0) for x in stages.get().split(',') if x.strip()]
                recipe=CustomModeRecipe(name=name.get(),players=[ModePlayer(0,'human',0),ModePlayer(1,'human',0),ModePlayer(2,'cpu',1,cpu_level=int(cpu.get(),0)),ModePlayer(3,'disabled',1)],stage_kinds=sk,stock_count=int(stocks.get(),0),notes='Phase 21 duo/co-op challenge recipe; Event Match tab can also create a concrete runtime experiment')
                default=self.project.mode_recipe_dir()/(name.get().strip().replace(' ','_')+'.json')
                out=filedialog.asksaveasfilename(parent=win,initialdir=str(default.parent),initialfile=default.name,defaultextension='.json',filetypes=[('Mode recipe','*.json')])
                if out: recipe.save(out); messagebox.showinfo('Duo recipe',f'Saved {out}',parent=win)
            except Exception as exc: messagebox.showerror('Duo recipe',str(exc),parent=win)
        ttk.Button(f,text='Save Duo Recipe…',command=save_recipe).grid(row=4,column=0,columnspan=2,sticky='ew',pady=8)
        ttk.Label(duo,text='Runtime next step: inject a dedicated scene/state that consumes this recipe and initializes two human PlayerInitData slots plus CPU/team rules. This keeps mode design separate from executable patch mechanics.',wraplength=850,justify='left',foreground='#666666').pack(anchor='w',pady=12)


    def open_stage_page_lab(self):
        if not self.project:
            messagebox.showinfo('Stage Hub','Open a project first.')
            return
        win=tk.Toplevel(self); win.title('Phase 26 — Stage Select Hub / Custom Maps / Co-op Launcher'); win.geometry('1280x850')
        ttk.Label(win,text='Stage Select Hub',font=('TkDefaultFont',14,'bold')).pack(anchor='w',padx=10,pady=(10,2))
        ttk.Label(win,text=(
            'Page 0 remains the retail Stage Select Screen. Page 1 starts conservatively in the familiar bottom row: '
            'custom stages reuse the Battlefield, Dream Land, and Final Destination button positions, while Co-op Adventure '
            'and Duo Challenges use the two remaining bottom-row buttons. D-pad Up/Down pages through additional maps. '
            'The retail MnSlMap hierarchy is reused rather than expanded.'),wraplength=1210,justify='left').pack(anchor='w',padx=10,pady=(0,8))
        state={'pages':load_project_page_set(self.project),'page_index':0}

        body=ttk.Panedwindow(win,orient='horizontal'); body.pack(fill='both',expand=True,padx=10,pady=4)
        left=ttk.Frame(body,padding=6); right=ttk.Frame(body,padding=6); body.add(left,weight=1); body.add(right,weight=4)
        ptree=ttk.Treeview(left,columns=('count','layout'),show='tree headings',height=23)
        ptree.heading('#0',text='Page'); ptree.heading('count',text='Tiles'); ptree.heading('layout',text='Layout')
        ptree.column('#0',width=155); ptree.column('count',width=52,anchor='center'); ptree.column('layout',width=105)
        ptree.pack(fill='both',expand=True)

        preview_box=ttk.LabelFrame(right,text='In-SDK Stage Select preview',padding=8); preview_box.pack(fill='x')
        nav=ttk.Frame(preview_box); nav.pack(fill='x',pady=(0,5))
        page_title=tk.StringVar(); indicator=tk.StringVar(); transition=tk.StringVar(value='')
        ttk.Label(nav,textvariable=page_title,font=('TkDefaultFont',11,'bold')).pack(side='left')
        ttk.Label(nav,textvariable=transition,foreground='#666666').pack(side='left',padx=12)
        ttk.Label(nav,textvariable=indicator,font=('TkDefaultFont',11,'bold')).pack(side='right',padx=8)
        grid=ttk.Frame(preview_box); grid.pack(anchor='center',pady=4)
        tile_widgets=[]
        for slot in range(30):
            r,c=divmod(slot,6)
            cell=ttk.LabelFrame(grid,text=('Random' if slot==29 else f'{slot:02d}'),padding=3,width=18,height=4)
            cell.grid(row=r,column=c,padx=3,pady=3,sticky='nsew')
            lbl=ttk.Label(cell,text='',width=18,anchor='center',justify='center',wraplength=125)
            lbl.pack(fill='both',expand=True)
            tile_widgets.append((cell,lbl))
        for c in range(6): grid.columnconfigure(c,weight=1)

        etree=ttk.Treeview(right,columns=('slot','kind','target','skin','thumb'),show='tree headings',height=11)
        for c,t,w in [('slot','Grid',50),('kind','Type',65),('target','Target',245),('skin','Retail skin',150),('thumb','Thumbnail',160)]:
            etree.heading(c,text=t); etree.column(c,width=w)
        etree.heading('#0',text='Title'); etree.column('#0',width=210); etree.pack(fill='both',expand=True,pady=(7,0))
        detail=tk.StringVar(value=''); ttk.Label(right,textvariable=detail,wraplength=900,justify='left',foreground='#555555').pack(anchor='w',pady=(5,0))

        def _entry_for_slot(page,slot):
            return next((e for e in page.entries if e.effective_grid_slot==slot),None)

        def render_preview(animate=False):
            pages=state['pages'].pages
            if not pages:return
            pi=max(0,min(state['page_index'],len(pages)-1)); state['page_index']=pi; page=pages[pi]
            page_title.set(page.title); indicator.set(f'{pi+1}/{len(pages)}')
            if animate:
                transition.set('D-pad page swap • retail icon pulse')
                win.after(450,lambda:transition.set(''))
            for slot,(cell,lbl) in enumerate(tile_widgets):
                if slot==29:
                    lbl.configure(text='Random\n(active page)'); continue
                if page.builtin_retail:
                    skin=RETAIL_SLOT_SKINS.get(slot)
                    lbl.configure(text=(skin['name'] if skin else 'Retail stage'))
                    continue
                e=_entry_for_slot(page,slot)
                if e is None:
                    lbl.configure(text='')
                else:
                    prefix='MODE' if e.kind=='mode' else 'STAGE'
                    thumb='\n[custom art]' if e.thumbnail_path else ''
                    lbl.configure(text=f'{prefix}\n{e.title}{thumb}')
            # Keep page tree selection in sync with preview navigation.
            iid=str(pi)
            if ptree.exists(iid): ptree.selection_set(iid); ptree.see(iid)

        def show_page(_=None, animate=False):
            sel=ptree.selection()
            if sel: state['page_index']=int(sel[0])
            etree.delete(*etree.get_children())
            page=state['pages'].pages[state['page_index']]
            if page.builtin_retail:
                detail.set('Retail page is untouched. Slots 0–23 use MnSlMap model group x40; slots 24–28 use x20; Random uses x10.')
            else:
                for i,e in enumerate(sorted(page.entries,key=lambda x:x.effective_grid_slot)):
                    target=e.stage_filename if e.kind=='stage' else e.mode_id
                    skin=RETAIL_SLOT_SKINS.get(e.preview_slot,{}).get('name',f'Slot {e.preview_slot}')
                    thumb=Path(e.thumbnail_path).name if e.thumbnail_path else 'retail reuse'
                    etree.insert('', 'end', iid=str(i), text=e.title, values=(e.effective_grid_slot,e.kind,target,skin,thumb))
                detail.set(f'{page.title}: {len(page.entries)}/{MAX_VISIBLE_SLOTS} tiles. First custom stages intentionally use Battlefield/Dream Land/Final Destination bottom-row positions. Mode tiles are intercepted before normal stage launch.')
            render_preview(animate=animate)

        def refresh():
            ptree.delete(*ptree.get_children())
            for i,p in enumerate(state['pages'].pages):
                ptree.insert('', 'end', iid=str(i), text=p.title, values=(('Retail' if p.builtin_retail else len(p.entries)),p.layout))
            state['page_index']=min(state['page_index'],len(state['pages'].pages)-1)
            ptree.selection_set(str(state['page_index'])); show_page()

        def page_delta(delta):
            n=len(state['pages'].pages); pi=state['page_index']+delta
            if state['pages'].wrap_pages: pi%=n
            else: pi=max(0,min(n-1,pi))
            state['page_index']=pi; ptree.selection_set(str(pi)); show_page(animate=True)

        ptree.bind('<<TreeviewSelect>>',show_page)
        navbtn=ttk.Frame(preview_box); navbtn.pack(fill='x',pady=(4,0))
        ttk.Button(navbtn,text='D-pad ↑ Previous Page',command=lambda:page_delta(-1)).pack(side='left')
        ttk.Button(navbtn,text='D-pad ↓ Next Page',command=lambda:page_delta(1)).pack(side='left',padx=6)

        def rebuild():
            state['pages']=build_project_page_set(self.project,include_coop_modes=True); state['page_index']=1 if len(state['pages'].pages)>1 else 0; refresh()
        def save_pages():
            try:
                save_project_page_set(self.project,state['pages'])
                messagebox.showinfo('Stage Hub','Saved the paged SSS hub configuration into the project manifest.',parent=win)
            except Exception as exc: messagebox.showerror('Stage Hub',str(exc),parent=win)
        def selected_entry():
            page=state['pages'].pages[state['page_index']]
            if page.builtin_retail:return None
            sel=etree.selection()
            if not sel:return None
            ordered=sorted(page.entries,key=lambda x:x.effective_grid_slot)
            return ordered[int(sel[0])]
        def assign_thumbnail():
            e=selected_entry()
            if e is None:
                messagebox.showinfo('Thumbnail','Select a custom stage or mode tile first.',parent=win); return
            f=filedialog.askopenfilename(parent=win,title=f'Choose thumbnail for {e.title}',filetypes=[('PNG image','*.png'),('All images','*.png *.gif *.ppm *.pgm')])
            if not f:return
            e.thumbnail_path=str(Path(f))
            show_page()
        def clear_thumbnail():
            e=selected_entry()
            if e is not None: e.thumbnail_path=None; show_page()
        def export_pages():
            out=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile='stage_pages.json',filetypes=[('JSON','*.json')])
            if out: state['pages'].save(out)
        def export_visuals():
            out=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile='sss_visual_manifest.json',filetypes=[('JSON','*.json')])
            if out: Path(out).write_text(json.dumps(stage_page_visual_manifest(state['pages']),indent=2),encoding='utf-8')
        def export_plan():
            out=filedialog.asksaveasfilename(parent=win,defaultextension='.json',initialfile='paged_sss_runtime_plan.json',filetypes=[('JSON','*.json')])
            if out: Path(out).write_text(json.dumps(stage_page_runtime_plan(state['pages']),indent=2),encoding='utf-8')
        def validate_menu():
            candidates=[self.project.working_dir/'MnSlMap.usd',self.project.working_dir/'MnSlMap.dat']
            path=next((x for x in candidates if x.exists()),None)
            if not path:
                pathstr=filedialog.askopenfilename(parent=win,title='Choose MnSlMap.dat/.usd',filetypes=[('Melee menu archive','MnSlMap.*'),('DAT/USD','*.dat *.usd'),('All files','*.*')])
                if not pathstr:return
                path=Path(pathstr)
            try:
                r=inspect_sss_menu(path)
                messagebox.showinfo('MnSlMap validated',f"{r['filename']}\nPublic root: 0x{r['root_offset']:X}\nModel groups: {r['model_count']}\n\nRegular icons: {r['regular_icon_model_group']}\nBottom row: {r['bottom_row_icon_model_group']}\nRandom: {r['random_model_group']}\n\nThe Phase 26 sparse page specifically reuses the source-confirmed x20 bottom-row model.",parent=win)
            except Exception as exc: messagebox.showerror('MnSlMap validation',str(exc),parent=win)
        def preflight():
            dol=self.project.working_dir/'start.dol'; sym=Path(__file__).with_name('data')/'runtime_symbols_GALE01.txt'
            if not dol.exists():
                messagebox.showinfo('Stage Hub preflight','Working/start.dol is not present yet. The visual/page/mode hub is fully authored, but executable page-switch and mode-dispatch hooks require start.dol.',parent=win); return
            try:
                r=preflight_sss_dol(dol,sym); out=self.project.build_dir/'paged_sss_preflight.json'; self.project.build_dir.mkdir(exist_ok=True)
                out.write_text(json.dumps(r,indent=2),encoding='utf-8')
                messagebox.showinfo('Stage Hub preflight',f"PASS\nDOL SHA-1: {r['dol_sha1']}\nHook sites captured: {len(r['hooks'])}\n\nSaved {out}",parent=win)
            except Exception as exc: messagebox.showerror('Stage Hub preflight',str(exc),parent=win)
        def export_integrated_bundle():
            out=filedialog.askdirectory(parent=win,title='Choose folder for integrated Stage Select Hub bundle')
            if not out:return
            try:
                campaign=CoopAdventureCampaign.vanilla_sequence('Co-op Adventure')
                atlas=None
                if all((self.project.working_dir/n).exists() for n in ('GrNKr.dat','GrNSr.dat','GrNZr.dat','GrNBr.dat')):
                    atlas=build_route_partner_atlas(self.project.working_dir)
                combined_pf=None
                dol=self.project.working_dir/'start.dol'; sym=Path(__file__).with_name('data')/'runtime_symbols_GALE01.txt'
                if dol.exists():
                    combined_pf={'sss':preflight_sss_dol(dol,sym),'coop_adventure':preflight_runtime_dol(dol,sym)}
                write_hub_bundle(out,state['pages'],campaign=campaign,route_atlas=atlas,dol_preflight=combined_pf)
                messagebox.showinfo('Stage Hub Bundle',f'Created integrated hub bundle in:\n{out}\n\nIncludes paged SSS layout, visual manifest, custom-stage bridge, direct Co-op Adventure dispatch, retail Adventure campaign/runtime plan, and route atlas when available.',parent=win)
            except Exception as exc: messagebox.showerror('Stage Hub Bundle',str(exc),parent=win)

        bar=ttk.Frame(win); bar.pack(fill='x',padx=10,pady=(4,10))
        ttk.Button(bar,text='Rebuild Bottom-Row Hub',command=rebuild).pack(side='left')
        ttk.Button(bar,text='Save To Project',command=save_pages).pack(side='left',padx=4)
        ttk.Button(bar,text='Assign Thumbnail…',command=assign_thumbnail).pack(side='left',padx=4)
        ttk.Button(bar,text='Clear Thumbnail',command=clear_thumbnail).pack(side='left',padx=4)
        ttk.Button(bar,text='Validate MnSlMap',command=validate_menu).pack(side='left',padx=4)
        ttk.Button(bar,text='Export Visual Manifest…',command=export_visuals).pack(side='left',padx=4)
        ttk.Button(bar,text='Export Runtime Plan…',command=export_plan).pack(side='left',padx=4)
        ttk.Button(bar,text='Create Integrated Hub Bundle…',command=export_integrated_bundle).pack(side='left',padx=4)
        ttk.Button(bar,text='Preflight start.dol',command=preflight).pack(side='left',padx=4)
        refresh()

    def destroy(self):
        if self.dirty or self.global_dirty:
            what = []
            if self.dirty: what.append('character')
            if self.global_dirty: what.append('global')
            ans = messagebox.askyesnocancel('Unsaved changes', f'Save current in-memory {" and ".join(what)} changes before closing?')
            if ans is None:
                return
            if ans and not self.save_working():
                return
        super().destroy()


if __name__ == '__main__':
    app=MeleeSDK()
    if len(sys.argv)>1:
        arg = Path(sys.argv[1])
        try:
            if arg.is_dir() and (arg / MANIFEST_NAME).exists():
                app.project=MeleeProject(arg); app._after_project_open('Project opened from command line.')
            else:
                app.fighter=FighterDAT(arg); app._refresh_all(); app.status.configure(text=f'{arg.name} — {app.fighter.fighter_name} — standalone DAT mode')
        except Exception as e:
            messagebox.showerror('Open failed',str(e))
    app.mainloop()
