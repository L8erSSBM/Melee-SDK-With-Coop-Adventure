# Melee SDK 0.21.7 — Direct requeue session retirement

This open-testing build is based on 0.21.6 and keeps its Mushroom Kingdom
rollback repair plus the Pokemon Stadium Slippi SIS text-lifetime guard.

0.21.7 fixes a separate lifecycle hazard after an SDK Co-op Adventure failure
returns to Slippi Direct. The completed Online-return hook now retires the
relocated Adventure ODB pointer **before** the bridge phase is disabled. The
next Direct Start therefore lets native Slippi create a fresh Online session
instead of seeing the reserved `0x817FE000` Adventure ODB as a recyclable heap
object.

The change is deliberately scoped to the completed Online handoff. Adventure
chapter transitions, Staff Roll/completion, active campaign rollback, ordinary
Direct matches and standalone gameplay are unchanged.

See [0.21.7 release notes](0.21.7_RELEASE_NOTES.md) for the failure model,
validation and recommended two-peer test sequence. Historical notes remain in
the package for regression context.
